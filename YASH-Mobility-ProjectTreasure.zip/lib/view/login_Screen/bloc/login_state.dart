part of 'login_bloc.dart';

@immutable

/// This state will be emit on login Screen.
abstract class LoginState {}

/// This state will be emit on login Screen.
class LoginInitial extends LoginState {}

/// This state will be emit on login Screen.
class LoginActionState extends LoginState {}

/// This state will be emit on login Screen which will have the array of data.
class UserLoggedInState extends LoginActionState {

}

/// This state will be emit on login Screen
class UserLoginLoaderState extends LoginState {}

/// This state will be emit on login Screen
class UserLoginLoadedState extends LoginState {}

/// This state will be emit on login Screen when the internet is disconnect of the device
class UserLoginFailedState extends LoginActionState {}
