
class ResourcesData {

  int? id;
  String? resourceName;
  String? resourceEmail;
  String? designation;

  ResourcesData({
    this.id,
    this.resourceName,
    this.resourceEmail,
    this.designation,
  });
  ResourcesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    resourceName = json['resource_name']?.toString();
    resourceEmail = json['resource_email']?.toString();
    designation = json['designation']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['resource_name'] = resourceName;
    data['resource_email'] = resourceEmail;
    data['designation'] = designation;
    return data;
  }
}

class Resources {

  String? message;
  List<ResourcesData?>? data;

  Resources({
    this.message,
    this.data,
  });
  Resources.fromJson(Map<String, dynamic> json) {
    message = json['message']?.toString();
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ResourcesData>[];
      v.forEach((v) {
        arr0.add(ResourcesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['message'] = message;
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}
