import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/create_project_screen/ui/create_project_screen.dart';
import 'package:yash_mobility_project_treasure/view/filter_screen/ui/filter_screen.dart';
import 'package:yash_mobility_project_treasure/view/home_screen/bloc/home_bloc.dart';
import 'package:yash_mobility_project_treasure/view/profile_screen/ui/profile_screen.dart';
import 'package:yash_mobility_project_treasure/view/projects_screen/ui/projects_screen.dart';

import '../../../components/custom_alert_dialog/custom_alert_dialog.dart';
import '../../../components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import '../../../resources/string.dart';

class HomeScreen extends StatefulWidget {
  final bool isFilterScreen;
  final bool isProposalFilterScreen;
  final bool isProjectFiltersApplied;
  final bool isProposalFiltersApplied;
  int? pageIndex;
  bool? clearFilter;
  final Database database;
  HomeScreen(
      {super.key,
      required this.isFilterScreen,
      required this.isProposalFilterScreen,
      this.pageIndex,
      this.clearFilter,
      required this.isProjectFiltersApplied,
      required this.isProposalFiltersApplied,
      required this.database});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  var pageController = PageController();
  int currentIndex = Dimensions.selection_0;
  late DateTime startTime;
  final HomeBloc homeBloc = HomeBloc();
  final List<String> basicDetails = [];
  String projectName = '';
  var ctime;

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    pageController = PageController(initialPage: widget.pageIndex ?? 0);
    currentIndex = widget.pageIndex ?? 0;
    startTime = DateTime.now();
    SharedPrefs.instance.setBool(Constants.isUserLoggedIn, true);
    SharedPrefs.instance
        .setString(Constants.appActiveLifeSpanStart, startTime.toString());
    SharedPrefs.instance.setString(Constants.appState, Constants.appLaunched);
    SharedPrefs.instance.setBool(Constants.projectsLaunchedKey, true);
    SharedPrefs.instance.setBool(Constants.proposalsLaunchedKey, true);
    super.initState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      startTime = DateTime.now();
      SharedPrefs.instance
          .setString(Constants.appActiveLifeSpanStart, startTime.toString());
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.inactive) {
      SharedPrefs.instance.setString(Constants.appState, Constants.appClosed);
    }
  }

  List<Widget> bottomNavScreen = <Widget>[
    Text(Strings().bottomNavigationItemMore),
  ];
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        DateTime now = DateTime.now();
        if (ctime == null ||
            now.difference(ctime) > const Duration(seconds: 2)) {
          ctime = now;
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Press Back Button Again to Exit')));
          return Future.value(false);
        }
        return Future.value(true);
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: Dimensions.elevation_0,
          backgroundColor: AppColors.appBottomNavigationBar,
          foregroundColor: AppColors.white,
          automaticallyImplyLeading: false,
          centerTitle: false,
          title: currentIndex == Dimensions.selection_0
              ? Text(Strings().appBarTitle, textAlign: TextAlign.start)
              : currentIndex == Dimensions.selection_1
                  ? Text(Strings().bottomNavigationTitleProposals,
                      textAlign: TextAlign.start)
                  : Text(Strings().bottomNavigationTitleMore,
                      textAlign: TextAlign.start),
          actions: [
            Row(
              children: <Widget>[
                Visibility(
                  visible: SharedPrefs.instance.getString(Constants.userRole) !=
                      Strings().user,
                  child: IconButton(
                    onPressed: () {
                      SharedPrefs.instance.remove(Constants.basicDetailDraft);
                      SharedPrefs.instance
                          .remove(Constants.technicalDetailDraft);
                      SharedPrefs.instance
                          .remove(Constants.additionalDetailDraft);
                      SharedPrefs.instance
                          .remove(Constants.resourceDetailDraft);
                      SharedPrefs.instance.remove('docAttached');
                      files.clear();
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          settings:
                              const RouteSettings(name: "/createProjectScreen"),
                          builder: (context) => CreateProjectScreen(
                              currentIndex,
                              projectName,
                              currentIndex == 0 ? true : false,
                              database: widget.database),
                        ),
                      );
                    },
                    icon: const Icon(
                      Icons.add,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => FilterScreen(
                                projectsFilter:
                                    currentIndex == 0 ? true : false,
                                proposalsFilter:
                                    currentIndex == 1 ? true : false,
                                database: widget.database)));
                  },
                  icon: const Icon(
                    Icons.filter_alt_outlined,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ProfileScreen(database: widget.database)));
                  },
                  icon: const Icon(
                    Icons.account_circle_outlined,
                  ),
                ),
              ],
            ),
          ],
        ),
        body: PageView(
          controller: pageController,
          physics: const NeverScrollableScrollPhysics(),
          children: <Widget>[
            Center(
              child: ProjectsScreen(
                  isProjectScreen:
                      widget.isProjectFiltersApplied ? false : true,
                  isProposalScreen: false,
                  isFilteredProjectsScreen: widget.isProjectFiltersApplied,
                  isFilteredProposalsScreen: false,
                  isProjectFiltersApplies: widget.isProjectFiltersApplied,
                  isProposalFiltersApplies: widget.isProposalFiltersApplied,
                  database: widget.database),
            ),
            Center(
              child: ProjectsScreen(
                  isProjectScreen: false,
                  isProposalScreen:
                      widget.isProposalFiltersApplied ? false : true,
                  isFilteredProjectsScreen: false,
                  isFilteredProposalsScreen: widget.isProposalFiltersApplied,
                  isProjectFiltersApplies: widget.isProjectFiltersApplied,
                  isProposalFiltersApplies: widget.isProposalFiltersApplied,
                  database: widget.database),
            ),
          ],
        ),
        bottomNavigationBar: NavigationBarTheme(
          data: NavigationBarThemeData(
              indicatorColor: AppColors.appBottomNavigationBar,
              labelTextStyle: MaterialStateProperty.all(
                TextStyle(
                  fontSize: Dimensions.font_14,
                ),
              )),
          child: NavigationBar(
            backgroundColor: AppColors.homeScreenBottomColor,
            selectedIndex: currentIndex,
            onDestinationSelected: (index) {
              if (index == 2) {
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ProfileScreen(database: widget.database)));
                });
              } else {
                setState(() {
                  pageController.jumpToPage(index);
                  currentIndex = index;
                });
              }
            },
            destinations: [
              NavigationDestination(
                selectedIcon: SizedBox(
                  height: Dimensions.height_30,
                  width: Dimensions.width_50,
                  child: Image.asset(Strings().projectSelectedIcon),
                ),
                icon: SizedBox(
                  height: Dimensions.height_30,
                  width: Dimensions.width_50,
                  child: Image.asset(Strings().projectUnselectedIcon),
                ),
                label: Strings().bottomNavigationTitleProjects,
              ),
              NavigationDestination(
                selectedIcon: SizedBox(
                  height: Dimensions.height_30,
                  width: Dimensions.width_50,
                  child: Image.asset(Strings().proposalSelectedIcon),
                ),
                icon: SizedBox(
                  height: Dimensions.height_30,
                  width: Dimensions.width_50,
                  child: Image.asset(Strings().proposalUnselectedIcon),
                ),
                label: Strings().bottomNavigationTitleProposals,
              ),
              NavigationDestination(
                selectedIcon: SizedBox(
                  height: Dimensions.height_30,
                  width: Dimensions.width_50,
                  child: Image.asset(Strings().moreSelectedIcon),
                ),
                icon: SizedBox(
                  height: Dimensions.height_30,
                  width: Dimensions.width_50,
                  child: Image.asset(Strings().moreUnselectedIcon),
                ),
                label: Strings().bottomNavigationTitleMore,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // listener for positive button
  void positiveButtonCallback() {
    Navigator.of(context).pop();
  }

  // listener for negative button
  void negativeButtonCallback() {
    Navigator.of(context).pop();
  }

  // listener for single button
  void actionSingleButtonCallback() {
    Navigator.of(context).pop();
  }

  // All with yes no button without background
  CustomDialogBox dialog() {
    return CustomDialogBox(
      title: Strings().logoutButtonTitle.toTitleCase(),
      description: Strings().logoutDiscriptionButtonTitle,
      actionPositive: Strings().cancelButton.toTitleCase(),
      actionNegative: Strings().logOutButton.toTitleCase(),
      showTitle: true,
      showDescription: true,
      showDialogImage: true,
      showActionPositive: true,
      showActionNegative: true,
      showSingleActionButton: false,
      buttonTextColor: Colors.black,
      onPositiveButtonClick: positiveButtonCallback,
      onNegativeButtonClick: negativeButtonCallback,
      actionOnPressed: actionSingleButtonCallback,
    );
  }
}
