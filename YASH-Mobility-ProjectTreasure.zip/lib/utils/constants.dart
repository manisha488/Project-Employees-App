class Constants {
  /// shared pref constants
  static const token = 'token';
  static const isUserLoggedIn = 'isLoggedIn';
  static const userId = 'userId';
  static const username = 'username';
  static const userEmailID = 'userEmailID';
  static const userFirstName = 'userFirstName';
  static const userLastName = 'userLastName';
  static const employeeID = 'employeeID';
  static const userCreatedAt = 'userCreatedAt';
  static const userRole = 'userRole';
  static const authorization = 'Authorization';
  static const appActiveLifeSpanStart = "activeLifeSpan";
  static const isProjectsListUpdated = "isProjectsListUpdated";
  static const isProposalsListUpdated = "isProposalsListUpdated";
  static const searchCharacterCount = 3;
  static const appActiveTime = 1; //30 min
  static const appState = "appState";
  static const appLaunched = "appLaunched";
  static const appClosed = "appClosed";
  static const proposalsLaunchedKey = "ProposalsLaunchedKey";
  static const projectsLaunchedKey = "ProjectsLaunchedKey";
  static const projectName = "ProjectName";
  static const basicDetailDraft = "basicDetailDraft";
  static const technicalDetailDraft = "technicalDetailDraft";
  static const additionalDetailDraft = "additionalDetailDraft";
  static const resourceDetailDraft = "resourcesDetails";
  static const fileUrl = "url";

  /// Request body parameters
  static const identifier = "identifier";
  static const password = "password";

  // Request Post Api body parameters
  static const projects = "projects";
}
