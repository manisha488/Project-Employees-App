class RouteName {
  static const String login = 'Login Screen';
  static const String signup = 'SignUp Screen';
  static const String home = 'Home Screen';
}
