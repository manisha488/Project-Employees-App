import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/components/custom_dropdownlist/custom_dropdownlist.dart';
import 'package:yash_mobility_project_treasure/components/custom_textfield/custom_text_form_field.dart';
import 'package:yash_mobility_project_treasure/components/drop_DownList/dropdownlist.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/proposal_details.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/regex.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/additional_details_screen/ui/aditional_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/technical_information_screen/bloc/technical_information_screen_bloc.dart';

import '../../../../components/custom_alert_dialog/custom_alert_dialog.dart';
import '../../../../components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/projects_list.dart';
import '../../../../model/response/proposals_list.dart';
import '../../../../utils/common_utils/display_message_utils.dart';
import '../../../../utils/constants.dart';
import '../../../../utils/shared_preference_utils.dart';
import '../../create_project_screen/ui/create_project_screen.dart';
import '../../review_screen/ui/review_screen.dart';

class TechnicalInformationScreen extends StatefulWidget {
  const TechnicalInformationScreen(
      this.currentIndex,
      this.projectName,
      this.basicDetailDraft,
      this.isBasicScreen,
      this.draftSelected,
      this.isReviewScreen,
      this.additionalDetailDraft,
      this.isProject,
      {super.key,
      required this.database});

  final int currentIndex;
  final String projectName;
  final bool basicDetailDraft;
  final bool isBasicScreen;
  final bool draftSelected;
  final bool isReviewScreen;
  final bool isProject;
  final bool additionalDetailDraft;
  final Database database;

  @override
  State<TechnicalInformationScreen> createState() =>
      _TechnicalInformationScreenState();
}

class _TechnicalInformationScreenState
    extends State<TechnicalInformationScreen> {
  String? projectManagementMethodologyValue;

  bool technicalDetailDraft = false;

  bool isProject = false;
  bool isButtonEnabled = false;
  bool isDropdownOpened = false;
  bool projectMethodologyDropdownOpened = false;
  bool isTechnicalScreen = false;
  bool isReviewScreen = false;
  bool additionalDetailScreen = false;
  bool isSaved = false;

  ///Get data Declaration
  String draftKnownIssue = " ";
  String draftDependencies = " ";
  String dataIndexPlatform = " ";
  String dataIndexTechnology = " ";
  String draftMethodology = " ";
  String draftRiskFactor = " ";
  dynamic draftPlatform;
  List<String> draftPlat = [];
  dynamic draftTechnology;
  List<String> draftTech = [];

  dynamic resultProposals;
  List<String> platformName = [];
  List<String> technologyName = [];
  List<String> methodologiesName = [];
  List<MultiSelectionFiltersData?> selectedPlatform = [];
  List<MultiSelectionFiltersData?> selectedTechnology = [];
  List<MultiSelectionFiltersData?> proposalSelectedPlatform = [];
  List<MultiSelectionFiltersData?> proposalSelectedTechnology = [];
  List<MultiSelectionFiltersData> methodologyList = [];
  List<String> projectMethodologyDropDownList = [];
  List<MultiSelectionFiltersData?> platformList = [];
  List<MultiSelectionFiltersData?> technologyList = [];
  List<ProposalDetails> proposalTechnicalDetails = [];
  List<MultiSelectionFiltersData?> draftPlatformsList = [];
  List<MultiSelectionFiltersData?> draftTechnologiesList = [];

  ///Create Project Technical Detail Screen Controllers
  final TextEditingController platformController = TextEditingController();
  final TextEditingController technologyController = TextEditingController();
  final TextEditingController riskFactorController = TextEditingController();
  final TextEditingController knownIssuesController = TextEditingController();
  final TextEditingController projectManagementMethodologyController =
      TextEditingController();
  final TextEditingController dependenciesController = TextEditingController();
  final platformNotifier = ValueNotifier<List<MultiSelectionFiltersData?>>([]);
  final technologyNotifier =
      ValueNotifier<List<MultiSelectionFiltersData?>>([]);

  ///Create Proposal Technical Detail Screen Controllers
  final TextEditingController proposalPlatformController =
      TextEditingController();
  final TextEditingController proposalTechnologyController =
      TextEditingController();
  final TextEditingController proposalRiskFactorController =
      TextEditingController();
  final TextEditingController proposalDependencyController =
      TextEditingController();
  final proposalPlatformNotifier =
      ValueNotifier<List<MultiSelectionFiltersData?>>([]);
  final proposalTechnologyNotifier =
      ValueNotifier<List<MultiSelectionFiltersData?>>([]);

  List<Map<String, dynamic>> platformMap = [];
  Map<String, Object> plat = {};
  List<Map<String, dynamic>> technologyMap = [];
  Map<String, Object> tech = {};

  List<CreateProjectData> createBasicDetails = [];
  List<ProjectsData> basicDetails = [];
  List<CreateProposalData> createProposalBasicDetails = [];
  List<ProposalsData> proposalBasicDetails = [];

  ///Database declaration.
  final db = CustomDataBaseWrapper();

  final TechnicalInformationScreenBloc technicalInformationScreenBloc =
      TechnicalInformationScreenBloc();

  ///Next Button enable & disable function
  void _checkButtonStatus() {
    setState(() {
      if (isProject == true) {
        if ((platformNotifier.value.isNotEmpty ||
                platformNotifier.value != []) &&
            (technologyNotifier.value.isNotEmpty ||
                technologyNotifier.value != []) &&
            projectManagementMethodologyController.text.isNotEmpty) {
          isButtonEnabled = true;
        } else {
          isButtonEnabled = false;
        }
      } else {
        print('here');
        print(
            "proposal platform: ${jsonEncode(proposalPlatformNotifier.value)}");
        print(
            "proposal tech : ${jsonEncode(proposalTechnologyNotifier.value)}");
        if ((proposalPlatformNotifier.value.isNotEmpty &&
                proposalPlatformNotifier.value != []) &&
            (proposalTechnologyNotifier.value.isNotEmpty &&
                proposalTechnologyNotifier.value != [])) {
          isButtonEnabled = true;
        } else {
          isButtonEnabled = false;
        }
      }
    });
  }

  /// Get all draft data.
  void getData() async {
    if (isProject) {
      var result = await db.getSpecificProjectsList(widget.projectName);
      int index = result.length;
      for (int i = 0; i < index; i++) {
        setState(() {
          draftKnownIssue = result[i].attributes!.knownIssues!;
          draftDependencies = result[i].attributes!.dependencies!;
          draftRiskFactor = result[i].attributes!.riskFactor!;
          print("draftmethod: $draftMethodology");
          if (result[i].attributes!.methodology!.data != null) {
            print('object');
            draftMethodology =
                result[i].attributes!.methodology!.data!.attributes!.name!;
          }
          if (result[i].attributes!.platforms!.data != null) {
            draftPlatform = result[i].attributes!.platforms;
          }

          if (result[i].attributes!.technologies!.data != null) {
            draftTechnology = result[i].attributes!.technologies;
          }
          if (widget.isBasicScreen) {
            if (draftKnownIssue != " ") {
              knownIssuesController.text = draftKnownIssue;
            }
            if (draftDependencies != " ") {
              dependenciesController.text = draftDependencies;
            }
            if (draftRiskFactor != " ") {
              riskFactorController.text = draftRiskFactor;
            }
            if (draftMethodology != " ") {
              print('not null');
              projectManagementMethodologyController.text = draftMethodology;
            }
            if (draftPlatform != null) {
              for (int j = 0; j < draftPlatform!.data.length; j++) {
                //if (draftPlatform!.data![j]!.attributes!.name != "[]") {
                draftPlatformsList = draftPlatform!.data!;
              }
            }

            if (draftTechnology != null) {
              for (int j = 0; j < draftTechnology!.data.length; j++) {
                //if (draftTechnology!.data![j]!.attributes!.name != "[]") {
                draftPlatformsList = draftTechnology!.data!;
                draftTech.add(draftTechnology!.data![j]!.attributes!.name);
              }
            }
          }
          if (technicalDetailDraft) {
            knownIssuesController.text = draftKnownIssue;
            dependenciesController.text = draftDependencies;
            riskFactorController.text = draftRiskFactor;
            if (draftMethodology != "[]") {
              projectManagementMethodologyController.text = draftMethodology;
            }
            if (draftPlatform != null) {
              for (int j = 0; j < draftPlatform!.data.length; j++) {
                //if (draftPlatform!.data![j]!.attributes!.name != "[]") {
                draftPlatformsList = draftPlatform!.data!;
              }
            }

            if (draftTechnology != null) {
              for (int j = 0; j < draftTechnology!.data.length; j++) {
                //if (draftTechnology!.data![j]!.attributes!.name != "[]") {
                draftPlatformsList = draftTechnology!.data!;
                draftTech.add(draftTechnology!.data![j]!.attributes!.name);
                //}
              }
            }
          }
          if (widget.isReviewScreen) {
            if (draftKnownIssue != " ") {
              knownIssuesController.text = draftKnownIssue;
            }
            if (draftDependencies != " ") {
              dependenciesController.text = draftDependencies;
            }
            if (draftRiskFactor != " ") {
              riskFactorController.text = draftRiskFactor;
            }
            if (draftMethodology != " ") {
              projectManagementMethodologyController.text = draftMethodology;
            }
            List<Map<String, dynamic>> storedItems = [];
            if (draftPlatform != null) {
              List<dynamic> p = jsonDecode(jsonEncode(draftPlatform!.data!));
              for (var i = 0; i < p.length; i++) {
                storedItems.add(p[i]);
              }
              var m = {"data": storedItems};
              var n = MultiSelectionFilters.fromJson(m);

              for (int j = 0; j < draftPlatform!.data.length; j++) {
                setState(() {
                  if (draftPlatform!.data![j]!.attributes!.name != "[]") {
                    draftPlatformsList = n.data!;
                  } else {
                    draftPlatformsList = [];
                  }
                });
              }
            }
            if (draftTechnology != null) {
              List<dynamic> t = jsonDecode(jsonEncode(draftTechnology!.data!));
              List<Map<String, dynamic>> storedTechs = [];
              for (var i = 0; i < t.length; i++) {
                storedTechs.add(t[i]);
              }
              var techMap = {"data": storedItems};
              var map = MultiSelectionFilters.fromJson(techMap);

              for (int j = 0; j < draftTechnology!.data.length; j++) {
                setState(() {
                  if (draftTechnology!.data![j]!.attributes!.name != "[]") {
                    draftTechnologiesList = map.data!;
                    draftTech.add(draftTechnology!.data![j]!.attributes!.name);
                  }
                });
              }
            }
          }
        });
      }
    } else {
      resultProposals = await db.getSpecificProposalList(widget.projectName);
      int index = resultProposals.length;
      for (int i = 0; i < index; i++) {
        setState(() {
          draftDependencies = resultProposals[i].attributes!.dependencies!;
          draftRiskFactor = resultProposals[i].attributes!.riskFactors!;
          draftPlatform = resultProposals[i].attributes!.platforms;
          draftTechnology = resultProposals[i].attributes!.technologies;
          if (widget.isBasicScreen) {
            if (draftDependencies != " ") {
              proposalDependencyController.text = draftDependencies;
            }
            if (draftRiskFactor != " ") {
              proposalRiskFactorController.text = draftRiskFactor;
            }
            if (draftPlatform.data != null) {
              for (int j = 0; j < draftPlatform!.data!.length; j++) {
                if (draftPlatform!.data![j]!.attributes!.name != "[]") {
                  draftPlat.add(draftPlatform!.data![j]!.attributes!.name);
                } else {
                  draftPlatformsList = [];
                }
              }
            }
            if (draftTechnology.data != null) {
              for (int j = 0; j < draftTechnology!.dataQ.length; j++) {
                if (draftTechnology!.data![j]!.attributes!.name != "[]") {
                  draftTech.add(draftTechnology!.data![j]!.attributes!.name);
                }
              }
            }
          }

          if (technicalDetailDraft) {
            proposalDependencyController.text = draftDependencies;
            proposalRiskFactorController.text = draftRiskFactor;
            if (draftPlatform != null) {
              for (int j = 0; j < draftPlatform!.data!.length; j++) {
                draftPlat.add(draftPlatform!.data![j]!.attributes!.name);
              }
            }
            if (draftTechnology != null) {
              for (int j = 0; j < draftTechnology!.data!.length; j++) {
                draftTech.add(draftTechnology!.data![j]!.attributes!.name);
              }
            }
          }

          if (widget.isReviewScreen) {
            if (draftDependencies != " ") {
              proposalDependencyController.text = draftDependencies;
            }
            if (draftRiskFactor != " ") {
              proposalRiskFactorController.text = draftRiskFactor;
            }
            if (draftPlatform.data != null) {
              for (int j = 0; j < draftPlatform!.data!.length; j++) {
                if (draftPlatform!.data![j]!.attributes!.name != "[]") {
                  draftPlat.add(draftPlatform!.data![j]!.attributes!.name);
                } else {
                  draftPlatformsList = [];
                }
              }
            }
            if (draftTechnology.data != null) {
              for (int j = 0; j < draftTechnology!.data!.length; j++) {
                if (draftTechnology!.data![j]!.attributes!.name != "[]") {
                  draftTech.add(draftTechnology!.data![j]!.attributes!.name);
                }
              }
            }
          }
        });
      }
    }
  }

  @override
  void initState() {
    setState(() {
      ///Event for Platform dropdown list.
      technicalInformationScreenBloc.add(PlatformLoadedEvent());

      ///Event for Technology dropdown list.
      technicalInformationScreenBloc.add(TechnologyLoadedEvent());

      ///Event for Project Management Methodology dropdown list.
      technicalInformationScreenBloc.add(ProjectMethodologyEvent());
    });

    isProject = widget.isProject;
    if (isProject == true) {
      db.getSpecificProjectsList(widget.projectName);
      getData();
      platformNotifier.addListener(_checkButtonStatus);
      technologyNotifier.addListener(_checkButtonStatus);
      projectManagementMethodologyController.addListener(_checkButtonStatus);
    } else {
      db.getSpecificProposalList(widget.projectName);
      getData();
      proposalPlatformNotifier.addListener(_checkButtonStatus);
      proposalTechnologyNotifier.addListener(_checkButtonStatus);
    }
    super.initState();
  }

  /// Navigation to Draft Screen.
  void navigateToDraftScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/draftScreen'));
  }

  /// Navigation to Basic Detail Screen.
  void navigateToBasicScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/basicDetailScreen'));
  }

  @override
  void dispose() {
    projectManagementMethodologyController.dispose();
    proposalRiskFactorController.dispose();
    proposalDependencyController.dispose();
    super.dispose();
  }

  /// Direct Navigation to Home Screen.
  void navigateToHomePage(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/createProjectScreen'));
  }

  void returnProjectDetails(BuildContext context) {
    if (isProject == true) {
      setState(() {
        ///Platform list
        List<dynamic> platforms =
            jsonDecode(SharedPrefs.instance.getString('platforms')!);
        List<Map<String, dynamic>> platformsMapList = [];
        Map<String, dynamic>? platform;
        for (var i = 0; i < platforms.length; i++) {
          if (widget.isReviewScreen) {
            setState(() {
              var funcItem = (platforms[i]);
              platformsMapList.add(funcItem);
              platform = {"data": platformsMapList};
            });
          } else {
            var funcItem = (platforms[i]);
            platformsMapList.add(funcItem);
            setState(() {
              platform = {"data": platformsMapList};
            });
          }
        }

        ///Technology list
        List<dynamic> techs =
            jsonDecode(SharedPrefs.instance.getString('technologies') ?? "[]");
        Map<String, dynamic>? technology;
        List<Map<String, dynamic>> techMapList = [];
        for (var i = 0; i < techs.length; i++) {
          if (widget.isReviewScreen) {
            setState(() {
              var funcItem = (techs[i]);
              techMapList.add(funcItem);
              technology = {"data": techMapList};
            });
          } else {
            var funcItem = (techs[i]);
            techMapList.add(funcItem);
            setState(() {
              technology = {"data": techMapList};
            });
          }
        }

        ///Methodology list
        var methodology = {
          "data": json.decode(SharedPrefs.instance.getString('methodology')!)
        };

        var attributes = ProjectsDataAttributes(
            name: widget.projectName,
            platforms: ProjectsDataAttributesPlatforms.fromJson(platform!),
            technologies:
                ProjectsDataAttributesTechnologies.fromJson(technology!),
            knownIssues: knownIssuesController.text.isEmpty
                ? ""
                : knownIssuesController.text,
            dependencies: dependenciesController.text.isEmpty
                ? ""
                : dependenciesController.text,
            methodology:
                ProjectsDataAttributesMethodology.fromJson(methodology),
            riskFactor: riskFactorController.text.isEmpty
                ? ""
                : riskFactorController.text);

        basicDetails.add(ProjectsData(attributes: attributes));
        db.updateTechnicalDetail(basicDetails);

        technicalDetailDraft = true;
        SharedPrefs.instance
            .setBool(Constants.technicalDetailDraft, technicalDetailDraft);
      });
    } else {
      ///Platform list
      List<dynamic> platforms =
          jsonDecode(SharedPrefs.instance.getString('platforms')!);
      List<Map<String, dynamic>> platformsMapList = [];
      Map<String, dynamic>? platform;
      for (var i = 0; i < platforms.length; i++) {
        if (widget.isReviewScreen) {
          setState(() {
            var funcItem = (platforms[i]);
            platformsMapList.add(funcItem);
            platform = {"data": platformsMapList};
          });
        } else {
          var funcItem = (platforms[i]);
          platformsMapList.add(funcItem);
          setState(() {
            platform = {"data": platformsMapList};
          });
        }
      }

      ///Technology list
      List<dynamic> techs =
          jsonDecode(SharedPrefs.instance.getString('technologies') ?? "[]");
      Map<String, dynamic>? technology;
      List<Map<String, dynamic>> techMapList = [];
      for (var i = 0; i < techs.length; i++) {
        if (widget.isReviewScreen) {
          setState(() {
            var funcItem = (techs[i]);
            techMapList.add(funcItem);
            technology = {"data": techMapList};
          });
        } else {
          var funcItem = (techs[i]);
          techMapList.add(funcItem);
          setState(() {
            technology = {"data": techMapList};
          });
        }
      }
      setState(() {
        var attributes = ProposalsDataAttributes(
            name: widget.projectName,
            platforms: ProposalsDataAttributesPlatforms.fromJson(platform!),
            technologies:
                ProposalsDataAttributesTechnologies.fromJson(technology!),
            dependencies: proposalDependencyController.text.isEmpty
                ? null
                : proposalDependencyController.text,
            riskFactors: proposalRiskFactorController.text.isEmpty
                ? null
                : proposalRiskFactorController.text);
        proposalBasicDetails.add(ProposalsData(attributes: attributes));
        db.updateProposalTechnicalDetail(proposalBasicDetails);
        technicalDetailDraft = true;
        SharedPrefs.instance
            .setBool(Constants.technicalDetailDraft, technicalDetailDraft);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    ///Bloc implementation.
    return BlocConsumer<TechnicalInformationScreenBloc,
        TechnicalInformationState>(
      bloc: technicalInformationScreenBloc,
      listenWhen: (previous, current) => current is TechnicalInfoActionState,
      buildWhen: (previous, current) => current is! TechnicalInfoActionState,
      listener: (context, state) {
        /// State for Technical information Attachment button.
        if (state is TechnicalInfoAttachmentBtnState) {
          ShowBottomSheet.getInstance.permissionHandlerMethod(context);
        }

        /// State for Technical information Save button.
        else if (state is TechnicalInfoSaveBtnState) {
          if (isProject == true) {
            if ((platformNotifier.value.isNotEmpty ||
                    platformNotifier.value != []) &&
                (technologyNotifier.value.isNotEmpty ||
                    technologyNotifier.value != []) &&
                projectManagementMethodologyController.text.isNotEmpty) {
              returnProjectDetails(context);
              setState(() {
                isSaved = true;
              });
              DisplayMessageUtils.toastMessage(
                  Strings().dataSavedSuccessfullyToastMessage);
            } else {
              return;
            }
          } else {
            if ((proposalPlatformNotifier.value.isNotEmpty ||
                    proposalPlatformNotifier.value != []) &&
                (proposalTechnologyNotifier.value.isNotEmpty ||
                    proposalTechnologyNotifier.value != [])) {
              returnProjectDetails(context);
              setState(() {
                isSaved = true;
              });
              DisplayMessageUtils.toastMessage(
                  Strings().dataSavedSuccessfullyToastMessage);
            } else {
              return;
            }
          }
        }

        ///State for Platform dropdown list.
        else if (state is PlatformLoadedState) {
          List<MultiSelectionFiltersData> jsonFilterPlatform = state.platforms;
          platformList.addAll(jsonFilterPlatform);
        }

        ///State for Technology dropdown list.
        else if (state is TechnologyLoadedState) {
          List<MultiSelectionFiltersData> jsonFilterTechnology =
              state.techFilters;
          technologyList.addAll(jsonFilterTechnology);
        }

        ///State for Project Management Methodology dropdown list.
        else if (state is ProjectMethodologyState) {
          List<MultiSelectionFiltersData> jsonFilterDomain =
              state.projectMethodology;
          methodologyList.addAll(jsonFilterDomain);
        }

        ///State for Navigation from Technical information screen to Additional detail screen.
        else if (state is NavigateTechInfoToAdditionalDetailState) {
          returnProjectDetails(context);
          isTechnicalScreen = true;
          Navigator.of(context).push(
            MaterialPageRoute(
              settings: const RouteSettings(name: "/additionDetailScreen"),
              builder: (context) => AdditionalDetailScreen(
                  widget.currentIndex,
                  widget.projectName,
                  widget.basicDetailDraft,
                  isTechnicalScreen,
                  technicalDetailDraft,
                  widget.draftSelected,
                  isReviewScreen,
                  widget.additionalDetailDraft,
                  isProject: isProject,
                  database: widget.database),
            ),
          );
        }
      },
      builder: (context, state) {
        return WillPopScope(
          onWillPop: () async {
            if (isProject) {
              var result = await db.getSpecificProjectsList(widget.projectName);
              for (int i = 0; i < result.length; i++) {
                if (result[i].attributes!.platforms!.data != null) {
                  dataIndexPlatform = result[i]
                      .attributes!
                      .platforms!
                      .data![0]!
                      .attributes!
                      .name!;
                }
                if (result[i].attributes!.technologies!.data != null) {
                  dataIndexTechnology = result[i]
                      .attributes!
                      .technologies!
                      .data![0]!
                      .attributes!
                      .name!;
                }
              }

              if (!context.mounted) return false;
              if (widget.isBasicScreen) {
                if (platformNotifier.value.isNotEmpty ||
                    technologyNotifier.value.isNotEmpty) {
                  if (dataIndexPlatform == "[]" ||
                      dataIndexTechnology == '[]') {
                    showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (BuildContext context) {
                          return dialog();
                        });
                  } else {
                    Navigator.pop(context);
                  }
                } else {
                  Navigator.pop(context);
                }
              } else if (widget.isReviewScreen) {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReviewScreen(
                            widget.currentIndex,
                            widget.projectName,
                            widget.additionalDetailDraft,
                            widget.draftSelected,
                            additionalDetailScreen,
                            isProject: isProject,
                            database: widget.database)));
              } else {
                SharedPrefs.instance.remove('ddplatforms');
                SharedPrefs.instance.remove('ddTech');
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateProjectScreen(
                              widget.currentIndex,
                              widget.projectName,
                              widget.isProject,
                              database: widget.database,
                            )));
              }
            } else {
              var result = await db.getSpecificProposalList(widget.projectName);
              if (!context.mounted) return false;
              if (widget.isBasicScreen) {
                if (proposalPlatformNotifier.value.isNotEmpty ||
                    proposalTechnologyNotifier.value.isNotEmpty) {
                  if (dataIndexPlatform == "[]" ||
                      dataIndexTechnology == '[]') {
                    showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (BuildContext context) {
                          return dialog();
                        });
                  } else {
                    Navigator.pop(context);
                  }
                } else {
                  Navigator.pop(context);
                }
              } else if (widget.isReviewScreen) {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReviewScreen(
                            widget.currentIndex,
                            widget.projectName,
                            widget.additionalDetailDraft,
                            widget.draftSelected,
                            additionalDetailScreen,
                            isProject: isProject,
                            database: widget.database)));
              } else {
                SharedPrefs.instance.remove('ddplatforms');
                SharedPrefs.instance.remove('ddTech');
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateProjectScreen(
                              widget.currentIndex,
                              widget.projectName,
                              widget.isProject,
                              database: widget.database,
                            )));
              }
            }
            return false;
          },
          child: Scaffold(
            backgroundColor: AppColors.white,
            appBar: AppBar(
              backgroundColor: AppColors.createProjectAppBarColor,
              iconTheme: IconThemeData(color: AppColors.white),
              title: Text(
                isProject == true
                    ? Strings().createProjectAppbarTitle.toTitleCase()
                    : Strings().createProposalAppbarTitle.toTitleCase(),
                style: TextStyle(
                    color: AppColors.white, fontSize: Dimensions.font_20),
              ),
              actions: [
                IconButton(
                    onPressed: () {
                      /// Event for Technical information Attachment button.
                      technicalInformationScreenBloc
                          .add(TechnicalInfoAttachmentBtnEvent());
                    },
                    icon: Icon(Icons.attach_file,
                        size: Dimensions.iconSize_20, color: AppColors.white)),
                TextButton(
                  onPressed: () {
                    /// Event for Technical information Save button.
                    technicalInformationScreenBloc
                        .add(TechnicalInfoSaveBtnEvent());
                  },
                  child: Text(
                    Strings().saveDraftAppbarTitle.toTitleCase(),
                    style: TextStyle(color: AppColors.white),
                  ),
                ),
              ],
            ),
            body: GestureDetector(
              onTap: () {
                setState(() {
                  projectMethodologyDropdownOpened = false;
                });
                FocusScope.of(context).requestFocus(FocusNode());
              },
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                      Dimensions.padding_16,
                      Dimensions.padding_24,
                      Dimensions.padding_16,
                      Dimensions.padding_0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: AppColors.green,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color:
                                      AppColors.createScreenButtonBorderColor),
                            ),
                            child: Center(
                                child: Icon(
                              Icons.done,
                              size: Dimensions.iconSize_18,
                              color: AppColors.white,
                            )),
                          ),
                          SizedBox(
                            width: Dimensions.width_25,
                            child: Divider(
                              color: AppColors.grey,
                              thickness: Dimensions.verticalDividerThickness_1,
                            ),
                          ),
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: AppColors.createProjectAppBarColor,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color: AppColors.stepperBorderColor),
                            ),
                            child: Center(
                                child: Text(
                              Strings().progressIndicatorTitle_2,
                              style: TextStyle(color: AppColors.white),
                            )),
                          ),
                          SizedBox(
                            width: Dimensions.width_25,
                            child: Divider(
                              color: AppColors.grey,
                              thickness: Dimensions.verticalDividerThickness_1,
                            ),
                          ),
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color: AppColors.stepperBorderColor),
                            ),
                            child: Center(
                                child:
                                    Text(Strings().progressIndicatorTitle_3)),
                          ),
                        ],
                      ),
                      SizedBox(height: Dimensions.height_32),
                      Text(
                        Strings().technicalInfoTitle.toTitleCase(),
                        style: TextStyle(
                            fontSize: Dimensions.font_16,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: Dimensions.height_16),
                      platformMultiDropdownList(),
                      SizedBox(height: Dimensions.height_29),
                      technologyMultiDropdownList(),
                      SizedBox(height: Dimensions.height_29),
                      CustomTextField(
                        onTapped: () {
                          setState(() {
                            isDropdownOpened = false;
                            projectMethodologyDropdownOpened = false;
                          });
                        },
                        textEditingController: isProject == true
                            ? riskFactorController
                            : proposalRiskFactorController,
                        labelText: Strings().textFieldRiskFactor,
                        regEx: RegEx().projectObjectiveRegEx,
                      ),
                      SizedBox(height: Dimensions.height_29),
                      if (isProject == true)
                        Column(
                          children: [
                            CustomTextField(
                              onTapped: () {
                                setState(() {
                                  isDropdownOpened = false;
                                  projectMethodologyDropdownOpened = false;
                                });
                              },
                              textEditingController: knownIssuesController,
                              labelText: Strings().textFieldKnownIssues,
                              regEx: RegEx().projectObjectiveRegEx,
                            ),
                            SizedBox(height: Dimensions.height_29),
                            projectMethodologyDropdown(),
                            SizedBox(height: Dimensions.height_29),
                          ],
                        ),
                      CustomTextField(
                        onTapped: () {
                          setState(() {
                            isDropdownOpened = false;
                            projectMethodologyDropdownOpened = false;
                          });
                        },
                        textEditingController: isProject
                            ? dependenciesController
                            : proposalDependencyController,
                        labelText: Strings().textFieldDependencies,
                        regEx: RegEx().projectObjectiveRegEx,
                      ),
                      SizedBox(height: Dimensions.height_29),
                      Visibility(
                        visible: widget.isReviewScreen ? false : true,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () async {
                                if (!context.mounted) return;
                                if (widget.isBasicScreen) {
                                  if (platformNotifier.value.isNotEmpty ||
                                      technologyNotifier.value.isNotEmpty) {
                                    showDialog(
                                        barrierDismissible: false,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return dialog();
                                        });
                                  } else {
                                    Navigator.pop(context);
                                  }
                                } else if (widget.isReviewScreen) {
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => ReviewScreen(
                                              widget.currentIndex,
                                              widget.projectName,
                                              widget.additionalDetailDraft,
                                              widget.draftSelected,
                                              additionalDetailScreen,
                                              isProject: isProject,
                                              database: widget.database)));
                                } else {
                                  SharedPrefs.instance.remove('ddplatforms');
                                  SharedPrefs.instance.remove('ddTech');
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CreateProjectScreen(
                                                widget.currentIndex,
                                                widget.projectName,
                                                widget.isProject,
                                                database: widget.database,
                                              )));
                                }
                              },
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_60),
                              child: Container(
                                height: Dimensions.height_40,
                                width: Dimensions.width_160,
                                decoration: BoxDecoration(
                                  color: AppColors.white,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.borderRadius_60),
                                  border: Border.all(
                                      color:
                                          AppColors.createProjectAppBarColor),
                                ),
                                child: Center(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.arrow_back_ios_new,
                                          color: AppColors
                                              .createProjectAppBarColor,
                                          size: Dimensions.iconSize_18),
                                      SizedBox(width: Dimensions.width_10),
                                      Text(
                                        Strings().previousButton.toTitleCase(),
                                        style: TextStyle(
                                            fontSize: Dimensions.font_14,
                                            fontWeight: FontWeight.bold,
                                            color: AppColors
                                                .createProjectAppBarColor),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_40,
                              width: Dimensions.width_160,
                              child: ElevatedButton(
                                onPressed: isButtonEnabled
                                    ? () async {
                                        ///Event for Navigation from Technical information screen to Additional detail screen.
                                        final navigator = Navigator.of(context);
                                        isTechnicalScreen = true;
                                        if (isProject) {
                                          var result =
                                              await db.getSpecificProjectsList(
                                                  widget.projectName);
                                          if (result.isNotEmpty) {
                                            returnProjectDetails(context);
                                            navigator.push(
                                              MaterialPageRoute(
                                                settings: const RouteSettings(
                                                    name:
                                                        "/additionDetailScreen"),
                                                builder: (context) =>
                                                    AdditionalDetailScreen(
                                                        widget.currentIndex,
                                                        widget.projectName,
                                                        widget.basicDetailDraft,
                                                        isTechnicalScreen,
                                                        technicalDetailDraft,
                                                        widget.draftSelected,
                                                        isReviewScreen,
                                                        widget
                                                            .additionalDetailDraft,
                                                        isProject: isProject,
                                                        database:
                                                            widget.database),
                                              ),
                                            );
                                          } else {
                                            returnProjectDetails(context);
                                            navigator.push(
                                              MaterialPageRoute(
                                                settings: const RouteSettings(
                                                    name:
                                                        "/additionDetailScreen"),
                                                builder: (context) =>
                                                    AdditionalDetailScreen(
                                                        widget.currentIndex,
                                                        widget.projectName,
                                                        widget.basicDetailDraft,
                                                        isTechnicalScreen,
                                                        technicalDetailDraft,
                                                        widget.draftSelected,
                                                        isReviewScreen,
                                                        widget
                                                            .additionalDetailDraft,
                                                        isProject: isProject,
                                                        database:
                                                            widget.database),
                                              ),
                                            );
                                          }
                                        } else {
                                          var result =
                                              await db.getSpecificProposalList(
                                                  widget.projectName);
                                          if (result.isNotEmpty) {
                                            returnProjectDetails(context);
                                            navigator.push(
                                              MaterialPageRoute(
                                                settings: const RouteSettings(
                                                    name:
                                                        "/additionDetailScreen"),
                                                builder: (context) =>
                                                    AdditionalDetailScreen(
                                                        widget.currentIndex,
                                                        widget.projectName,
                                                        widget.basicDetailDraft,
                                                        isTechnicalScreen,
                                                        technicalDetailDraft,
                                                        widget.draftSelected,
                                                        isReviewScreen,
                                                        widget
                                                            .additionalDetailDraft,
                                                        isProject:
                                                            widget.isProject,
                                                        database:
                                                            widget.database),
                                              ),
                                            );
                                          } else {
                                            returnProjectDetails(context);
                                            navigator.push(
                                              MaterialPageRoute(
                                                settings: const RouteSettings(
                                                    name:
                                                        "/additionDetailScreen"),
                                                builder: (context) =>
                                                    AdditionalDetailScreen(
                                                        widget.currentIndex,
                                                        widget.projectName,
                                                        widget.basicDetailDraft,
                                                        isTechnicalScreen,
                                                        technicalDetailDraft,
                                                        widget.draftSelected,
                                                        isReviewScreen,
                                                        widget
                                                            .additionalDetailDraft,
                                                        isProject:
                                                            widget.isProject,
                                                        database:
                                                            widget.database),
                                              ),
                                            );
                                          }
                                        }
                                      }
                                    : null,
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith<Color?>(
                                    (Set<MaterialState> states) {
                                      if (states
                                          .contains(MaterialState.disabled)) {
                                        return AppColors.nextButtonColor;
                                      }
                                      return AppColors.createProjectAppBarColor;
                                    },
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      Strings().nextButton.toTitleCase(),
                                      style: TextStyle(
                                          color: AppColors.white,
                                          fontSize: Dimensions.font_14),
                                    ),
                                    SizedBox(
                                      width: Dimensions.width_5,
                                    ),
                                    Icon(
                                      Icons.arrow_forward_ios_sharp,
                                      size: Dimensions.iconSize_18,
                                      color: AppColors.white,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.height_29),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Platform dropdown list Bloc implementation.
  Widget platformMultiDropdownList() {
    return BlocProvider(
      create: (_) => technicalInformationScreenBloc,
      child: BlocListener<TechnicalInformationScreenBloc,
          TechnicalInformationState>(
        listener: (context, state) {},
        child: BlocBuilder<TechnicalInformationScreenBloc,
            TechnicalInformationState>(
          builder: (context, state) {
            return MultiDropDown(
              controller: (platformList.isNotEmpty) ? [] : draftPlatformsList,
              items: (platformList.isEmpty) ? draftPlatformsList : platformList,
              title: Strings().textFieldPlatform.toTitleCase(),
              alertDialogTitle: Strings().dialogPlatformTitle,
              height: Dimensions.height_35,
              width: Dimensions.width_110,
              onSelectionChanged: (selectedItems) {
                if (isProject == true) {
                  if (selectedItems.isNotEmpty) {
                    if (platformNotifier.value != "[]") {
                      setState(() {
                        platformNotifier.value = selectedItems;
                        selectedPlatform = selectedItems;
                      });
                    } else {
                      setState(() {
                        selectedPlatform = selectedItems;
                      });
                      platformNotifier.value = selectedItems;
                    }
                  }
                } else {
                  if (selectedItems.isNotEmpty) {
                    if (proposalPlatformNotifier.value != "[]") {
                      setState(() {
                        proposalPlatformNotifier.value = selectedItems;
                        selectedPlatform = selectedItems;
                      });
                    } else {
                      setState(() {
                        selectedPlatform = selectedItems;
                      });
                      proposalPlatformNotifier.value = selectedItems;
                    }
                  }
                }
              },
              dKey: "platforms",
            );
          },
        ),
      ),
    );
  }

  /// Technology dropdown list Bloc implementation.
  Widget technologyMultiDropdownList() {
    return BlocProvider(
      create: (_) => technicalInformationScreenBloc,
      child: BlocListener<TechnicalInformationScreenBloc,
          TechnicalInformationState>(
        listener: (context, state) {},
        child: BlocBuilder<TechnicalInformationScreenBloc,
            TechnicalInformationState>(
          builder: (context, state) {
            return MultiDropDown(
              controller:
                  technologyList.isNotEmpty ? [] : draftTechnologiesList,
              items: technologyList.isEmpty
                  ? draftTechnologiesList
                  : technologyList,
              title: Strings().textFieldTechnology.toTitleCase(),
              alertDialogTitle: Strings().dialogTechnologyTitle,
              height: Dimensions.height_35,
              width: Dimensions.width_220,
              dKey: "technologies",
              onSelectionChanged: (selectedItems) {
                if (isProject == true) {
                  if (selectedItems.isNotEmpty) {
                    if (technologyNotifier.value != "[]") {
                      setState(() {
                        technologyNotifier.value = selectedItems;
                        selectedTechnology = selectedItems;
                      });
                    } else {
                      setState(() {
                        selectedTechnology = selectedItems;
                      });
                      technologyNotifier.value = selectedItems;
                    }
                  }
                } else {
                  if (selectedItems.isNotEmpty) {
                    if (proposalTechnologyNotifier.value != "[]") {
                      setState(() {
                        proposalTechnologyNotifier.value = selectedItems;
                        selectedTechnology = selectedItems;
                      });
                    } else {
                      setState(() {
                        selectedTechnology = selectedItems;
                      });
                      proposalTechnologyNotifier.value = selectedItems;
                    }
                  }
                }
              },
            );
          },
        ),
      ),
    );
  }

  /// Project Management Methodology dropdown list Bloc implementation.
  Widget projectMethodologyDropdown() {
    return BlocProvider(
      create: (_) => technicalInformationScreenBloc,
      child: BlocListener<TechnicalInformationScreenBloc,
          TechnicalInformationState>(
        listener: (context, state) {},
        child: BlocBuilder<TechnicalInformationScreenBloc,
            TechnicalInformationState>(
          builder: (context, state) {
            return CustomDropDown(
              controller: projectManagementMethodologyController,
              onTapped: () {
                setState(() {
                  FocusScope.of(context).requestFocus(FocusNode());
                  projectMethodologyDropdownOpened =
                      !projectMethodologyDropdownOpened;
                  isDropdownOpened = false;
                });
              },
              list: [],
              isTitleCase: true,
              wlist: methodologyList,
              dbkey: 'methodology',
              title:
                  Strings().textFieldProjectManagementMethodology.toTitleCase(),
              onChanged: (selectedItem) {
                projectManagementMethodologyController.text = selectedItem!;
                projectMethodologyDropdownOpened = false;
              },
              isStretchedDropDown: projectMethodologyDropdownOpened,
            );
          },
        ),
      ),
    );
  }

  // listener for positive button
  void positiveButtonCallback() {
    SharedPrefs.instance.remove('platforms');
    SharedPrefs.instance.remove('technologies');
    navigateToBasicScreen(context);
  }

  // listener for negative button
  void negativeButtonCallback() {
    Navigator.of(context).pop();
  }

  // listener for single button
  void actionSingleButtonCallback() {
    Navigator.of(context).pop();
  }

  // All with yes no button without background
  CustomDialogBox dialog() {
    return CustomDialogBox(
      title: Strings().dialogDraftTitle.toTitleCase(),
      description: Strings().dialogTechnicalDraftDiscription,
      actionPositive: Strings().dialogDraftNegativeButton.toTitleCase(),
      actionNegative: Strings().dialogDraftPositiveButton.toTitleCase(),
      showTitle: true,
      showDescription: true,
      showDialogImage: true,
      showActionPositive: true,
      showActionNegative: true,
      showSingleActionButton: false,
      buttonTextColor: Colors.black,
      onPositiveButtonClick: positiveButtonCallback,
      onNegativeButtonClick: negativeButtonCallback,
      actionOnPressed: actionSingleButtonCallback,
    );
  }
}
