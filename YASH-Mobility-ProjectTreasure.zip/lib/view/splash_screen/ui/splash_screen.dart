import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/home_screen/ui/home_screen.dart';
import 'package:yash_mobility_project_treasure/view/login_Screen/ui/login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen(this.database, {super.key});

  final Database database;
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: Dimensions.seconds_3), () => checkLoginStatus());
  }

  void checkLoginStatus() {
    final navigator = Navigator.of(context);

    bool isLoggedIn =
        SharedPrefs.instance.getBool(Constants.isUserLoggedIn) ?? false;

    print(isLoggedIn);

    if (isLoggedIn) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          settings:
          const RouteSettings(name: "/homeScreen"),
          builder: (context) =>  HomeScreen(isFilterScreen: false, isProposalFilterScreen: false, pageIndex: 0, isProjectFiltersApplied: false, isProposalFiltersApplied: false, database: widget.database,),
        ),
      );
    } else {
      navigator.pushReplacement(
          MaterialPageRoute(builder: (context) => LoginScreen(widget.database)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
            AppColors.splashScreenBackgroundColor,
            AppColors.white
          ])),
      child: Stack(
        children: <Widget>[
          Container(
            alignment: Alignment.center,
            child: Image.asset(
              Strings().splashScreenProjectTreasureLogo,
              height: Dimensions.height_120,
              width: Dimensions.width_120,
            ),
          ),
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                        top: Dimensions.padding_30,
                        right: Dimensions.padding_20),
                    child: Image.asset(
                      Strings().splashScreenYashLogo,
                      height: Dimensions.height_50,
                      width: Dimensions.width_72,
                    ),
                  ),
                ],
              )
            ],
          )
        ],
      ),
    );
  }
}
