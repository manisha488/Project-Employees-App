import 'package:another_flushbar/flushbar.dart';
import 'package:another_flushbar/flushbar_route.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';

import '../../resources/dimen.dart';
import '../../resources/string.dart';
import '../../view/login_Screen/ui/login_screen.dart';

final GlobalKey flushBarKey = GlobalKey();

class DisplayMessageUtils {
  ///Method to change the focus of the field
  static void fieldFocusChange(
      BuildContext context, FocusNode current, FocusNode next) {
    current.unfocus();
    FocusScope.of(context).requestFocus(next);
  }

  ///Method to display the toast message
  static toastMessage(String message) {
    Fluttertoast.showToast(
      msg: message,
    );
  }

  ///Method to display the flushBar error message
  static void flushBarErrorMessage(
      BuildContext context,
      String message,
      Color backgroundColor,
      String textButtonTitle,
      VoidCallback onTextButtonPress,
      ) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          key: flushBarKey,
          forwardAnimationCurve: Curves.decelerate,
          margin: EdgeInsets.symmetric(
              horizontal: Dimensions.horizontalMargin_10,
              vertical: Dimensions.verticalMargin_10),
          padding: EdgeInsets.all(Dimensions.padding_15),
          duration: Duration(seconds: Dimensions.seconds_3),
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_8),
          backgroundColor: backgroundColor,
          reverseAnimationCurve: Curves.easeInOut,
          positionOffset: Dimensions.positionOffset_20,
          messageText: SizedBox(
            height: Dimensions.height_30,
            width: Dimensions.width_300,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(message, style: const TextStyle(color: Colors.white)),
                InkWell(
                  onTap: onTextButtonPress,
                  child: Text(textButtonTitle,
                      style:
                      TextStyle(color: AppColors.flushBarViewClickColor)),
                ),
                InkWell(
                    onTap: () {
                      (flushBarKey.currentWidget as Flushbar).dismiss();
                    },
                    child: Icon(
                      Icons.close_sharp,
                      color: AppColors.white,
                    ))
              ],
            ),
          ),
        )..show(context));
  }

  ///Method to display the toast message
  static void flushBarToastMessage(
      BuildContext context,
      String message,
      String message1,
      Color backgroundColor,
      VoidCallback settingApp,
      ) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          forwardAnimationCurve: Curves.decelerate,
          margin: EdgeInsets.symmetric(
              horizontal: Dimensions.horizontalMargin_10,
              vertical: Dimensions.verticalMargin_10),
          padding: EdgeInsets.all(Dimensions.padding_15),
          duration: Duration(seconds: Dimensions.seconds_3),
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_8),
          backgroundColor: backgroundColor,
          reverseAnimationCurve: Curves.easeInOut,
          positionOffset: Dimensions.positionOffset_20,
          messageText: SizedBox(
            height: Dimensions.height_30,
            width: Dimensions.width_300,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(message, style: const TextStyle(color: Colors.white)),
                InkWell(
                  onTap: settingApp,
                  child: Text(
                    Strings().toastMessageStorageSetting,
                    semanticsLabel: Strings().toastMessageStorage,
                    style: TextStyle(color: AppColors.flushBarViewClickColor),
                  ),
                ),
              ],
            ),
          ),
        )..show(context));
  }

  /// Method to display the snackBar message
  static snackBarMessage(BuildContext context, String message) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(message)));
  }

  // static showSnackBar(String message) {
  //   ScaffoldMessenger.of(navigatorKey.currentContext!).showSnackBar(
  //     SnackBar(
  //       content: Text(message),
  //       duration: Duration(seconds: Dimensions.seconds_3),
  //     ),
  //   );
  // }
}
