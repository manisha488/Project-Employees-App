import 'package:yash_mobility_project_treasure/model/all_filters.dart';

class FetchAllFilter {
  static Future<List<AllFilters>> fetchProjectFilters() async {
    final dummyFilters = [
     AllFilters('Start/ end date'),
      AllFilters('Status'),
      AllFilters('Project name'),
      AllFilters('Resource name'),
      AllFilters('Platform'),
      AllFilters('Technology'),
      AllFilters('Functionality'),
      AllFilters('Available Documents'),
      AllFilters('Domain')
    ];
    return dummyFilters;
  }

  static Future<List<AllFilters>> fetchProposalsFilters() async {
    final dummyFilters = [
      AllFilters('Start/ end date'),
      AllFilters('Status'),
      AllFilters('Proposal name'),
      AllFilters('Resource name'),
      AllFilters('Platform'),
      AllFilters('Technology'),
      AllFilters('Functionality'),
      AllFilters('Available Documents'),
      AllFilters('Domain')
    ];
    return dummyFilters;
  }
}