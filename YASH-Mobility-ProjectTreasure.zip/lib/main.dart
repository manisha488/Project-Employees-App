import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/clear_filters.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/additional_details_screen/ui/aditional_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/basic_details_screen/ui/basic_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/create_project_screen/ui/create_project_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/technical_information_screen/ui/technical_information_screen.dart';
import 'package:yash_mobility_project_treasure/view/draft_screen/ui/draft_screen.dart';
import 'package:yash_mobility_project_treasure/view/home_screen/ui/home_screen.dart';
import 'package:yash_mobility_project_treasure/view/login_Screen/ui/login_screen.dart';
import 'package:yash_mobility_project_treasure/view/splash_screen/ui/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SharedPrefs.init();
  // NotificationService().initNotification();
  final database = await initializeDatabase();

  runApp(MyApp(database));
}

Future<Database> initializeDatabase() async {
  // Get the application documents directory
  final databasesPath = await getDatabasesPath();
  final path = join(databasesPath, 'pt.db');

  // Check if the database exists
  final exists = await databaseExists(path);

  if (!exists) {
    // If the database doesn't exist, copy it from the assets
    print("Copying database from assets");
    try {
      // Load database from asset
      final data = await rootBundle.load('assets/pt.db');
      final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);

      // Save copied database to the documents directory
      await File(path).writeAsBytes(bytes, flush: true);
    } catch (e) {
      print("Error copying database: $e");
    }
  } else {
    print("Opening existing database");
  }

  // Open the database
  return await openDatabase(path);
}

class MyApp extends StatelessWidget {
  final Database database;

  MyApp(this.database,{super.key});

  final clearFilters = ClearFilters();
  final currentIndex = 0;
  final String projectName = "";
  final bool basicDetailDraft = false;
  final bool isBasicScreen = false;
  final bool technicalDetailDraft = false;
  final bool additionalDetailDraft = false;
  final bool draftSelected = false;
  final bool isProject = false;
  final bool isReviewScreen = false;

  /// This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    clearFilters.clearSharedPrefsForProject();
    clearFilters.clearSharedPrefsForProposals();
    SharedPrefs.instance.remove(Strings().isProjectsFiltersApplied);
    SharedPrefs.instance.remove(Strings().filtersToApplyKey);
    SharedPrefs.instance.setBool(Constants.projectsLaunchedKey, true);
    return MaterialApp(
      title: Strings().projectTitle,
      debugShowCheckedModeBanner: false,
      // navigatorKey: navigatorKey,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.appThemeColor),
        useMaterial3: true,
      ),
      initialRoute: '/splashScreen',
      routes: {
        '/splashScreen': (context) => SplashScreen(database),
        '/loginScreen': (context) => LoginScreen(database),
        '/homeScreen': (context) => HomeScreen(
              isFilterScreen: false,
              isProposalFilterScreen: false,
              isProjectFiltersApplied: false,
              isProposalFiltersApplied: false,
          database: database
            ),
        '/createProjectScreen': (context) =>
            CreateProjectScreen(currentIndex, projectName, true, database: database),
        '/basicDetailScreen': (context) => BasicDetailScreen(
              currentIndex,
              projectName,
              draftSelected,
              isReviewScreen,
              additionalDetailDraft,
              isProject: true,
          database: database
            ),
        '/technicalInformationScreen': (context) => TechnicalInformationScreen(
            currentIndex,
            projectName,
            basicDetailDraft,
            isBasicScreen,
            draftSelected,
            isReviewScreen,
            additionalDetailDraft,
            true,
          database: database,
        ),
        '/additionDetailScreen': (context) => AdditionalDetailScreen(
            currentIndex,
            projectName,
            basicDetailDraft,
            isBasicScreen,
            technicalDetailDraft,
            draftSelected,
            isReviewScreen,
            additionalDetailDraft,
            isProject: true,
        database: database,
        ),
        '/draftScreen': (context) => DraftScreen(isProject, database: database),
      },
    );
  }
}
