import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';

import '../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../model/response/create_project_model_list.dart';
import '../../../model/response/create_proposal_model_list.dart';
import '../../../resources/dimen.dart';
import '../../../utils/common_utils/statusColorUtils.dart';
import '../../create_project_screen/review_screen/ui/review_screen.dart';

class DraftScreen extends StatefulWidget {
  const DraftScreen(this.isProject, {super.key, required this.database});

  final bool isProject;
  final Database database;

  @override
  State<DraftScreen> createState() => _DraftScreenState();
}

class _DraftScreenState extends State<DraftScreen> {
  List<CreateProjectData> projectResult = [];
  List<CreateProposalData> proposalResult = [];
  List<int> selectedIndexes = [];
  List<CreateProjectData> result = [];

  int currentIndexProject = 0;
  int currentIndexProposal = 1;

  String projectName = " ";
  String proposalName = " ";

  bool draftSelected = false;
  bool isReviewScreen = false;
  bool additionalDetailDraft = false;
  bool additionalDetailScreen = false;

  ///Database declaration.
  final db = CustomDataBaseWrapper();

  void getData() async {
    if (widget.isProject) {
      projectResult = await db.getDraftProjectsList();
      setState(() {});
    } else {
      proposalResult = await db.getDraftProposalList();
      setState(() {});
    }
  }

  void deleteSelectedItems() {
    setState(() {
      selectedIndexes.sort((a, b) => b.compareTo(a));
      List<CreateProjectData> selectedProjects = [];
      List<CreateProposalData> selectedProposals = [];
      selectedIndexes.forEach((index) {
        if (widget.isProject) {
          setState(() {
            selectedProjects.add(projectResult[index]);
            db.deleteProjectModel(selectedProjects);
          });
          projectResult.removeAt(index);
        } else {
          setState(() {
            selectedProposals.add(proposalResult[index]);
            db.deleteProposalModel(selectedProposals);
          });
          proposalResult.removeAt(index);
        }
      });

      selectedIndexes.clear();
    });
  }

  @override
  void initState() {
    getData();
    SharedPrefs.instance.remove('platforms');
    SharedPrefs.instance.remove('technologies');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          actions: selectedIndexes.isNotEmpty
              ? [
                  IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () {
                      deleteSelectedItems();
                    },
                  ),
                ]
              : null,
          backgroundColor: AppColors.appBottomNavigationBar,
          foregroundColor: AppColors.white,
          title: Text(
            Strings().draftScreenAppBarTitle,
            style: TextStyle(color: AppColors.white),
          ),
          iconTheme: IconThemeData(
            color: AppColors.white,
          ),
        ),
        body: widget.isProject
            ? projectsListWidget(projectResult)
            : proposalListWidget(proposalResult));
  }

  Widget cards(
    void Function() onTap,
    GestureLongPressCallback? onLongPress,
    String name,
    String status,
    String summary,
    String startDate,
    String endDate,
    int index,
  ) {
    bool isSelected = selectedIndexes.contains(index);

    return GestureDetector(
      onTap: onTap,
      onLongPress: () {
        setState(() {
          if (selectedIndexes.contains(index)) {
            selectedIndexes.remove(index);
          } else {
            selectedIndexes.add(index);
          }
        });
        if (onLongPress != null) {
          onLongPress();
        }
      },
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: isSelected ? AppColors.grey_300 : AppColors.white,
              borderRadius: BorderRadius.circular(Dimensions.borderRadius_5),
              border: Border.all(
                color: AppColors.projectCardBorderColor,
                width: Dimensions.width_1,
              ),
            ),
            child: Padding(
              padding: EdgeInsets.all(Dimensions.padding_15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          name.toTitleCase(),
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: Dimensions.font_16,
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.fromLTRB(
                          Dimensions.padding_8,
                          Dimensions.padding_5,
                          Dimensions.padding_8,
                          Dimensions.padding_5,
                        ),
                        decoration: BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(Dimensions.borderRadius_20),
                          color: StatusColors.getColors(status.toTitleCase()),
                        ),
                        child: Center(
                          child: Text(
                            status.toCapitalized(),
                            style: TextStyle(
                              fontSize: Dimensions.font_12,
                              color: AppColors.black,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: Dimensions.height_10,
                  ),
                  Text(
                    summary.toCapitalized(),
                    maxLines: Dimensions.maxLines_3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: status.toString() == Strings().cancelledStatus
                          ? AppColors.cancelledProjectBody
                          : AppColors.projectBody,
                      fontSize: Dimensions.font_14,
                    ),
                  ),
                  SizedBox(
                    height: Dimensions.height_10,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: Dimensions.height_10,
          ),
        ],
      ),
    );
  }

  /// Widget to display all projects
  Widget projectsListWidget(List<CreateProjectData> resultProject) {
    print('project');
    if (resultProject.isEmpty) {
      return Center(
          child: Text(
        Strings().noRecordsFoundText,
        style: TextStyle(
          color: AppColors.projectBody,
        ),
      ));
    } else {
      return Padding(
        padding: EdgeInsets.all(Dimensions.padding_8),
        child: ListView.builder(
            shrinkWrap: true,
            itemCount: resultProject.length,
            itemBuilder: (context, index) {
              if (resultProject.isEmpty) {
                return resultProject.isEmpty
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : Center(
                        child: Text(
                        Strings().noRecordsFoundText,
                        style: TextStyle(
                          color: AppColors.projectBody,
                        ),
                      ));
              } else {
                return cards(() {
                  projectName = resultProject[index].attributes!.name!;
                  if (widget.isProject) {
                    draftSelected = true;
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ReviewScreen(
                                currentIndexProject,
                                projectName,
                                additionalDetailDraft,
                                draftSelected,
                                additionalDetailScreen,
                                isProject: widget.isProject,
                                database: widget.database)));
                  } else {}
                },
                    null,
                    resultProject[index].attributes!.name!,
                    resultProject[index]
                            .attributes!
                            .status
                            ?.data
                            ?.attributes
                            ?.name ??
                        "",
                    resultProject[index].attributes!.summary!,
                    resultProject[index].attributes!.startDate!,
                    resultProject[index].attributes!.endDate ?? "",
                    index);
              }
            }),
      );
    }
  }

  /// Widget to display all proposal
  Widget proposalListWidget(List<CreateProposalData> resultProposal) {
    print('proposal');
    print(resultProposal);
    if (resultProposal.isEmpty) {
      return Center(
          child: Text(
        Strings().noRecordsFoundText,
        style: TextStyle(
          color: AppColors.projectBody,
        ),
      ));
    } else {
      return Padding(
        padding: EdgeInsets.all(Dimensions.padding_8),
        child: ListView.builder(
            shrinkWrap: true,
            itemCount: resultProposal.length,
            itemBuilder: (context, index) {
              if (resultProposal.isEmpty) {
                return resultProposal.isEmpty
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : Center(
                        child: Text(
                        Strings().noRecordsFoundText,
                        style: TextStyle(
                          color: AppColors.projectBody,
                        ),
                      ));
              } else {
                return cards(() {
                  proposalName = resultProposal[index].attributes!.name!;
                  if (!widget.isProject) {
                    draftSelected = true;
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ReviewScreen(
                                  currentIndexProject,
                                  proposalName,
                                  additionalDetailDraft,
                                  draftSelected,
                                  additionalDetailScreen,
                                  isProject: widget.isProject,
                                database: widget.database
                                )));

                    print(
                        "Summary : ${resultProposal[index].attributes!.summery}");
                  } else {}
                },
                    null,
                    resultProposal[index].attributes!.name!,
                    resultProposal[index]
                            .attributes!
                            .status
                            ?.data
                            ?.attributes
                            ?.name ??
                        "",
                    resultProposal[index].attributes!.summery ?? " ",
                    resultProposal[index].attributes!.proposalReceivedDate ??
                        " ",
                    resultProposal[index].attributes!.proposalSubmittedDate ??
                        " ",
                    index);
              }
            }),
      );
    }
  }
}
