import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/data/filters_data/fetch_subFilters.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/resoucesList.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/model/response/proposals_list.dart';
import 'package:yash_mobility_project_treasure/services/network_exceptions.dart';

part 'sub_filters_event.dart';
part 'sub_filters_state.dart';

class SubFiltersBloc extends Bloc<SubFiltersEvent, SubFiltersState> {
  final db = CustomDataBaseWrapper();
  SubFiltersBloc() : super(SubFiltersInitial()) {
    on<SubFiltersEvent>((event, emit) {});
    on<ProjectNamesFiltersClickedEvent>(projectNamesFiltersClickedEvent);
    on<ProposalNamesFiltersClickedEvent>(proposalNamesFiltersClickedEvent);
    on<DatesFilterClickedEvent>(datesFilterClickedEvent);
    on<DocumentFilterClickedEvent>(documentFilterClockedEvent);
    on<ResourceNameFilterClickedEvent>(resourceNameFilterClickedEvent);
    on<FiltersLoadingEvent>(filtersLoadingEvent);
    on<OfflineTechnologiesLoadedEvent>(offlineTechnologiesLoadedEvent);
    on<OfflineDomainsLoadedEvent>(offlineDomainsLoadedEvent);
    on<OfflinePlatformsLoadedEvent>(offlinePlatformsLoadedEvent);
    on<OfflineStatusLoadedEvent>(offlineStatusLoadedEvent);
    on<OfflineFunctionalitiesLoadedEvent>(offlineFunctionalitiesLoadedEvent);
  }

  FutureOr<void> datesFilterClickedEvent(
      DatesFilterClickedEvent event, Emitter<SubFiltersState> emit) {
    emit(DateFiltersClickedState());
  }

  FutureOr<void> documentFilterClockedEvent(
      DocumentFilterClickedEvent event, Emitter<SubFiltersState> emit) async {
    List<DummyMultiselectFilters> documentFilters =
        await FetchPlatformFilter.fetchDocumentFilters();
    emit(DocumentFiltersLoadedState(documentFilters));
  }

  FutureOr<void> resourceNameFilterClickedEvent(
      ResourceNameFilterClickedEvent event,
      Emitter<SubFiltersState> emit) async {
    List<ResourcesListData>? resources;
    await db.getResourcesData().then((value) {
      resources = value;
    });
    emit(ResourceNameFiltersClickedState(resources!));
  }

  FutureOr<void> projectNamesFiltersClickedEvent(
      ProjectNamesFiltersClickedEvent event,
      Emitter<SubFiltersState> emit) async {
    List<ProjectsData>? projectNames;
    await db.getProjectsList('projects').then((value) {
      projectNames = value;
    });
    emit(ProjectNamesFiltersLoadedState(projectNames!));
  }

  FutureOr<void> filtersLoadingEvent(
      FiltersLoadingEvent event, Emitter<SubFiltersState> emit) {
    emit(FiltersLoadingState());
  }

  FutureOr<void> proposalNamesFiltersClickedEvent(
      ProposalNamesFiltersClickedEvent event,
      Emitter<SubFiltersState> emit) async {
    List<ProposalsData>? proposalNames;
    await db.getProposalsList("proposals").then((value) {
      proposalNames = value;
    });
    emit(ProposalsNamesFiltersLoadedState(proposalNames!));
  }

  FutureOr<void> offlineTechnologiesLoadedEvent(
      OfflineTechnologiesLoadedEvent event,
      Emitter<SubFiltersState> emit) async {
    List<MultiSelectionFiltersData>? offlineTech;
    await db.getData('technologies').then((value) {
      offlineTech = value;
    });
    emit(OfflineTechnologiesLoadedState(offlineTech!));
  }

  FutureOr<void> offlineDomainsLoadedEvent(
      OfflineDomainsLoadedEvent event, Emitter<SubFiltersState> emit) async {
    List<MultiSelectionFiltersData>? offlineDomains;
    await db.getData('domains').then((value) {
      offlineDomains = value;
    });
    emit(OfflineDomainsLoadedState(offlineDomains!));
  }

  FutureOr<void> offlinePlatformsLoadedEvent(
      OfflinePlatformsLoadedEvent event, Emitter<SubFiltersState> emit) async {
    List<MultiSelectionFiltersData>? offlinePlatforms;
    await db.getData('platforms').then((value) {
      offlinePlatforms = value;
    });
    emit(OfflinePlatformsLoadedState(offlinePlatforms!));
  }

  FutureOr<void> offlineStatusLoadedEvent(
      OfflineStatusLoadedEvent event, Emitter<SubFiltersState> emit) async {
    List<MultiSelectionFiltersData>? offlineStatus;
    await db.getData('status').then((value) {
      offlineStatus = value;
    });
    emit(OfflineStatusLoadedState(offlineStatus!));
  }

  FutureOr<void> offlineFunctionalitiesLoadedEvent(
      OfflineFunctionalitiesLoadedEvent event,
      Emitter<SubFiltersState> emit) async {
    List<MultiSelectionFiltersData>? offlineFunctionalities;
    await db.getData('functionalities').then((value) {
      offlineFunctionalities = value;
    });
    emit(OfflineFunctionalitiesLoadedState(offlineFunctionalities!));
  }
}
