class ErrorStrings {
  /// Error Strings for network exceptions
  String noInternet =
      'Problem with internet connection. Please make sure that your device is connected to internet';
  String unableToProcessData = 'Unable to process the data';
  String somethingWentWrong = 'Something went wrong, please try after sometime';
  String invalidStatusCode = 'Received invalid status code:';
  String unExpectedError = 'Unexpected error occurred';
  String serviceUnavailable =
      'The server is temporarily unable to service your request, please try again later';
  String internalServerError =
      'The server encountered an internal error and unable to complete your request';
  String requestTimeOut =
      'There was a problem with your request. Please try again later';
  String methodNotAllowed =
      'The requested method is not supported by the resource.';
  String notFound = 'The requested resource could not be found on the server.';
  String badRequest =
      'The request was invalid, and the server could not process it.';
  String unauthorizedRequest =
      'The request requires authentication, please provide valid credentials.';
  String sendTimeOut = 'Send timeout in connection with API server.';
  String conflictError = 'Error due to a conflict.';
  String badResponse = 'Bad response.';
  String badCertificate = 'Bad Certificate.';
  String requestCanceled = 'Request Cancelled.';
  String notImplemented = 'Not Implemented.';
  String notAcceptable = 'Not acceptable';
  String connectionTimeOut =
      'Looks like the server is taking to long to respond, please try again in sometime';
}
