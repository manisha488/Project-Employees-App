import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/display_message_utils.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/regex.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/text_form_field_utils.dart';
import 'package:yash_mobility_project_treasure/view/home_screen/ui/home_screen.dart';
import 'package:yash_mobility_project_treasure/view/login_Screen/bloc/login_bloc.dart';
import 'package:yash_mobility_project_treasure/view/weather_screen/weather_page.dart';

import '../../../components/custom_textfield/custom_text_form_field.dart';
import '../../../model/User.dart';
import '../../../utils/constants.dart';
import '../../../utils/shared_preference_utils.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class LoginScreen extends StatefulWidget {
  const LoginScreen(this.database, {super.key});

  final Database database;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  late String userName;
  late String password;

  dynamic result;
  List<dynamic> _journals = [];
  final LoginBloc loginBloc = LoginBloc();
  var isValidEmail = false;
  var isValidPassword = false;
  bool isButtonEnabled = false;

  ///Database declaration.
  final db = CustomDataBaseWrapper();
  // final db1 = SQLHelper();

  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  /// method to get the checkButtonStatus
  void _checkButtonStatus() {
    setState(() {
      if (emailController.text.isNotEmpty &&
          passwordController.text.isNotEmpty) {
        userName = emailController.text;
        password = passwordController.text;
        isButtonEnabled = true;
      } else {
        isButtonEnabled = false;
      }
    });
  }

  returnProjectDetails() {
    var attributes = User(
        id: 0,
        username: emailController.text,
        password: passwordController.text,
        name: '');
    _journals.add(attributes);
    // db1.createItem(attributes);
  }

  @override
  void initState() {
    loginBloc.add(CreateDBEvent());

    emailController.addListener(_checkButtonStatus);
    passwordController.addListener(_checkButtonStatus);

    super.initState();
  }

  void clearText() {
    passwordController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<LoginBloc, LoginState>(
      bloc: loginBloc,
      listenWhen: (previous, current) => current is LoginActionState,
      buildWhen: (previous, current) => current is! LoginActionState,
      listener: (context, state) {
        if (state is UserLoginLoaderState) {
        } else if (state is UserLoggedInState) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              settings: const RouteSettings(name: "/homeScreen"),
              builder: (context) => HomeScreen(
                isFilterScreen: false,
                isProposalFilterScreen: false,
                pageIndex: 0,
                isProjectFiltersApplied: false,
                isProposalFiltersApplied: false,
                database: widget.database,
              ),
            ),
          );
        } else if (state is UserLoginFailedState) {
          DisplayMessageUtils.toastMessage(Strings().incorrectCredential);
          clearText();
        }
      },
      builder: (context, state) {
        return Scaffold(
          body: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(FocusNode());
            },
            child: SingleChildScrollView(
              child: Container(
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      AppColors.splashScreenBackgroundColor,
                      AppColors.white
                    ])),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        SizedBox(
                          height: Dimensions.padding_16,
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              top: Dimensions.padding_30,
                              right: Dimensions.padding_16),
                          child: Image.asset(
                            Strings().splashScreenYashLogo,
                            height: Dimensions.height_48,
                            width: Dimensions.width_71,
                          ),
                        ),
                      ],
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: EdgeInsets.all(Dimensions.padding_16),
                            child: Form(
                              key: _formKey,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(height: Dimensions.height_20),
                                  Center(
                                    child: Image.asset(
                                      Strings().loginScreenProjectTreasureLogo,
                                      height: Dimensions.height_80,
                                      width: Dimensions.width_80,
                                    ),
                                  ),
                                  SizedBox(height: Dimensions.height_80),
                                  CustomTextFormField(
                                    title: Strings().loginEmailTextFieldTitle,
                                    titleStyle: TextStyle(
                                        color: AppColors.textFieldHintColor,
                                        fontSize: Dimensions.font_14),
                                    keyboardType: TextInputType.emailAddress,
                                    textEditingController: emailController,
                                    borderType: FormFieldBorderType.outline,
                                    filledColor: AppColors.loginBackgroundColor,
                                    focusBorderColor: AppColors.blue,
                                    borderColor:
                                        AppColors.loginTextFieldBorderColor,
                                    obscureText: false,
                                    prefixIcon: Icons.email_outlined,
                                    iconPadding: Dimensions.padding_20,
                                    iconSize: Dimensions.iconSize_24,
                                    iconColor: AppColors.textFieldHintColor,
                                    onSaved: (value) {
                                      emailController.text = value!;
                                    },
                                    validator: (value) {
                                      return null;
                                    },
                                    successBorderColor: AppColors.blue,
                                    regEx: RegEx().emailRegEx,
                                    minLength: Dimensions.minLength_6,
                                    maxLength: Dimensions.maxLength_10,
                                    errorMessageWeak:
                                        Strings().loginWeakEmailMessage,
                                    errorMessageMedium:
                                        Strings().loginMediumEmailMessage,
                                    borderRadius: Dimensions.borderRadius_40,
                                    onTapped: () {},
                                  ),
                                  SizedBox(height: Dimensions.height_20),
                                  CustomTextFormField(
                                    onTapped: () {
                                      if (passwordController.text.isEmpty) {
                                        _formKey.currentState!.validate();
                                        isValidPassword = false;
                                      }
                                    },
                                    title:
                                        Strings().loginPasswordTextFieldTitle,
                                    titleStyle: TextStyle(
                                        color: AppColors.textFieldHintColor,
                                        fontSize: Dimensions.font_14),
                                    keyboardType: TextInputType.visiblePassword,
                                    textEditingController: passwordController,
                                    borderType: FormFieldBorderType.outline,
                                    focusBorderColor: AppColors.blue,
                                    borderColor:
                                        AppColors.loginTextFieldBorderColor,
                                    obscureText: true,
                                    obscuringCharacter:
                                        Strings().passwordObscureCharacter,
                                    prefixIcon: Icons.lock_outline,
                                    iconPadding: Dimensions.padding_20,
                                    iconSize: Dimensions.iconSize_24,
                                    iconColor: AppColors.textFieldHintColor,
                                    onSaved: (value) {
                                      emailController.text = value!;
                                    },
                                    filledColor: AppColors.loginBackgroundColor,
                                    successBorderColor: AppColors.blue,
                                    regEx: RegEx().passwordRegEx,
                                    minLength: Dimensions.minLength_6,
                                    maxLength: Dimensions.maxLength_10,
                                    borderRadius: Dimensions.borderRadius_40,
                                    onChanged: (value) {
                                      if (passwordController.text.isEmpty) {
                                        _formKey.currentState!.validate();
                                      }
                                    },
                                    validator: (value) {
                                      return null;
                                    },
                                  ),
                                  SizedBox(height: Dimensions.height_50),
                                  SizedBox(
                                      height: Dimensions.height_60,
                                      width: getSize(context).width,
                                      child: _loginButton()),
                                  SizedBox(height: Dimensions.height_25),
                                  SizedBox(
                                      height: Dimensions.height_60,
                                      width: getSize(context).width,
                                      child: ElevatedButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        const WeatherPage()));
                                          },
                                          style: ButtonStyle(
                                            backgroundColor: MaterialStateProperty
                                                .all(AppColors
                                                    .createProjectAppBarColor),
                                          ),
                                          child: Text(
                                            Strings().weatherButtonTitle,
                                            style: TextStyle(
                                              color: AppColors.white,
                                            ),
                                          ))),
                                  SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              Dimensions.height0_2),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// create the widget for the loginButton
  Widget _loginButton() {
    return ElevatedButton(
        onPressed: isButtonEnabled
            ? () async {
                FocusScope.of(context).requestFocus(FocusNode());
                loginBloc.add(GetUserLoggedIn(
                    userName: emailController.text,
                    password: passwordController.text));

                SharedPrefs.instance
                    .setString(Constants.userEmailID, emailController.text);
              }
            : null,
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.resolveWith<Color?>(
            (Set<MaterialState> states) {
              if (states.contains(MaterialState.disabled)) {
                return AppColors.grey; // Disabled color
              }
              return AppColors.enableLoginButtonColor; // Enabled color
            },
          ),
        ),
        child: BlocProvider(
          create: (_) => loginBloc,
          child: BlocListener<LoginBloc, LoginState>(
            listener: (context, state) {},
            child: BlocBuilder<LoginBloc, LoginState>(
              builder: (context, state) {
                if (state is LoginInitial) {
                  return Text(
                    Strings().loginButtonTitle,
                    style: TextStyle(
                      color: AppColors.white,
                    ),
                  );
                } else if (state is UserLoginLoaderState) {
                  return Text(
                    Strings().loginButtonTitle,
                    style: TextStyle(
                      color: AppColors.white,
                    ),
                  );
                } else if (state is UserLoginLoadedState) {
                  return Text(
                    Strings().loginButtonTitle,
                    style: TextStyle(
                      color: AppColors.white,
                    ),
                  );
                } else if (state is UserLoginFailedState) {
                  return Text(
                    Strings().loginButtonTitle,
                    style: TextStyle(
                      color: AppColors.white,
                    ),
                  );
                } else {
                  return Container();
                }
              },
            ),
          ),
        ));
  }
}
