part of 'additional_detail_screen_bloc.dart';

@immutable
abstract class AdditionalDetailState {}

class AdditionalDetailInitialState extends AdditionalDetailState {}

class AdditionalDetailActionState extends AdditionalDetailState {}

///State for Additional detail Attachment button.
class AdditionalDetailAttachmentButtonState
    extends AdditionalDetailActionState {}

///State for Additional detail Save button.
class AdditionalDetailSaveButtonState extends AdditionalDetailActionState {}

///State for Navigation from Additional detail screen to Resources detail screen.
class NavigateAdditionalDetailToResourceDetailState
    extends AdditionalDetailActionState {}

///State for Navigation from Additional detail screen to Review screen.
class NavigateAdditionalDetailToReviewState
    extends AdditionalDetailActionState {}

///State for Additional detail screen Create project button.
class AdditionalDetailCreateProjectButtonState
    extends AdditionalDetailActionState {
  final CreateProjectData? createProject;
  AdditionalDetailCreateProjectButtonState(this.createProject);
}

///State for Additional detail screen Create proposal button.
class AdditionalDetailCreateProposalButtonState
    extends AdditionalDetailActionState {
  final CreateProposalData? createProposal;
  AdditionalDetailCreateProposalButtonState(this.createProposal);
}

///State for Resource Post Api
class ResourceStoreState extends AdditionalDetailActionState {
  final List<ResourcesData?> resources;

  ResourceStoreState(this.resources);
}

///State for Currency dropdown list.
class CurrencyLoadedState extends AdditionalDetailActionState {
  final List<Currencies?> currencyFilter;
  CurrencyLoadedState(this.currencyFilter);
}

///State for Location dropdown list.
class LocationLoadedState extends AdditionalDetailActionState {
  final List<LocationData?> locationFilter;

  LocationLoadedState(this.locationFilter);
}

class CreateProjectLoadingState extends AdditionalDetailState {}

class CreateProjectLoadedState extends AdditionalDetailState {}

class CreateProjectFailedState extends AdditionalDetailState {}

class ResourcesAddedState extends AdditionalDetailState {}

/// State for the Upload Document Post Api
class UploadDocumentState extends AdditionalDetailActionState {
  final List<DocumentsData?>? details;
  UploadDocumentState(this.details);
}

class UploadDocumentFailedState extends AdditionalDetailActionState {
  final NetworkExceptions exception;
  UploadDocumentFailedState(this.exception);
}
