import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_alert_dialog/custom_alert_dialog.dart';
import 'package:yash_mobility_project_treasure/model/proposal_details.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/additional_details_screen/ui/aditional_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/basic_details_screen/ui/basic_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/create_project_screen/bloc/create_project_screen_bloc.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/review_screen/ui/review_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/technical_information_screen/ui/technical_information_screen.dart';
import 'package:yash_mobility_project_treasure/view/home_screen/ui/home_screen.dart';

import '../../../../components/custom_alert_dialog/dialog.dart';
import '../../../../components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/resource_model_list.dart';
import '../../../../utils/common_utils/display_message_utils.dart';
import '../../../../utils/constants.dart';
import '../../../../utils/shared_preference_utils.dart';

final GlobalKey<State> _keyLoader = GlobalKey<State>();

class CreateProjectScreen extends StatefulWidget {
  const CreateProjectScreen(this.currentIndex, this.projectName, this.isProject,
      {super.key, required this.database});

  final int currentIndex;
  final String projectName;
  final bool isProject;
  final Database database;

  @override
  State<CreateProjectScreen> createState() => _CreateProjectScreenState();
}

class _CreateProjectScreenState extends State<CreateProjectScreen> {
  bool isProject = false;

  bool basicDetailDraft = false;
  bool technicalDetailDraft = false;
  bool additionalDetailDraft = false;
  bool isBasicScreen = false;
  bool draftSelected = false;
  bool isReviewScreen = false;
  bool additionalDetailScreen = false;

  List<ProposalDetails> proposalBasicDetails = [];
  List<ProposalDetails> proposalAdditionalDetails = [];
  List<ProposalDetails> proposalTechnicalInformation = [];
  List<ResourcesData?> resourceDetail = [];
  dynamic document;
  final TextEditingController projectNameController = TextEditingController();
  final TextEditingController currencyController = TextEditingController();

  dynamic resultProjects;
  dynamic resultProposals;
  int id = 1;
  String name = "";
  String domain = "";
  String objective = "";
  String summery = "";
  List<CreateProjectDataAttributesFunctionalitiesData?>? functionalityProject =
      [];
  List<CreateProposalDataAttributesFunctionalitiesData?>?
      functionalityProposal = [];
  String startDate = "";
  String endDate = "";
  String status = " ";
  String platformProjectName = " ";
  String technologyProjectName = " ";
  List<CreateProjectDataAttributesPlatformsData?>? platformProject = [];
  List<CreateProposalDataAttributesPlatformsData?>? platformProposal = [];
  List<CreateProjectDataAttributesTechnologiesData?>? technologyProject = [];
  List<CreateProposalDataAttributesTechnologiesData?>? technologyProposal = [];
  List<CreateProjectDataAttributesResourcesData?>? resourcesProject = [];
  List<CreateProposalDataAttributesResourcesData?>? resourcesProposal = [];
  String dependency = "";
  String clientName = "";
  String budget = "";
  String currency = "";
  String location = "";
  String comments = "";
  String feedback = "";
  String riskFactor = "";
  String riskFactors = "";
  String knownIssues = "";
  String methodology = "";
  dynamic draftFunctionality;
  dynamic draftPlatform;
  dynamic draftTechnology;
  dynamic draftDomain;
  dynamic draftStatus;
  dynamic draftMethodology;
  dynamic draftResource;

  ///Database declaration.
  final db = CustomDataBaseWrapper();

  ///Bloc declaration
  final CreateProjectScreenBloc createProjectScreenBloc =
      CreateProjectScreenBloc();

  ///Screen size function
  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  @override
  void initState() {
    basicDetailDraft =
        SharedPrefs.instance.getBool(Constants.basicDetailDraft) ?? false;

    technicalDetailDraft =
        SharedPrefs.instance.getBool(Constants.technicalDetailDraft) ?? false;

    additionalDetailDraft =
        SharedPrefs.instance.getBool(Constants.additionalDetailDraft) ?? false;

    isProject = widget.isProject;

    if (widget.isProject) {
      db.getSpecificProjectsList(widget.projectName);
      getData();
    } else {
      db.getSpecificProposalList(widget.projectName);
      getData();
    }

    if (basicDetailDraft == false) {
      SharedPrefs.instance.remove('functionality');
    } else {}
    if (technicalDetailDraft == false) {
      SharedPrefs.instance.remove('technologies');
      SharedPrefs.instance.remove('platforms');
    } else {}

    super.initState();
  }

  void getData() async {
    if (isProject) {
      resultProjects = await db.getSpecificProjectsList(widget.projectName);
      setState(() {
        int index = resultProjects.length;
        for (int i = 0; i < index; i++) {
          setState(() {
            List<Map<String, dynamic>> mapFun = [];
            List<Map<String, dynamic>> mapPlat = [];
            List<Map<String, dynamic>> mapTech = [];
            List<Map<String, dynamic>> mapDomain = [];
            List<Map<String, dynamic>> mapStatus = [];
            List<Map<String, dynamic>> mapMeth = [];

            id = 0;
            name = resultProjects[i].attributes!.name!;
            domain =
                resultProjects[i].attributes!.domain!.data!.attributes!.name!;
            Map<String, dynamic> uDomain = {};
            setState(() {
              uDomain = {"id": resultProjects[i].attributes!.domain!.data!.id};
              mapDomain.add(uDomain);
            });
            draftDomain = mapDomain;
            objective = resultProjects[i].attributes!.objectives!;
            summery = resultProjects[i].attributes!.summary!;
            functionalityProject =
                resultProjects[i].attributes!.functionalities!.data!;

            Map<String, dynamic> uFun = {};
            for (var j = 0;
                j < resultProjects[i].attributes!.functionalities!.data!.length;
                j++) {
              setState(() {
                uFun = {
                  "id": resultProjects[i]
                      .attributes!
                      .functionalities!
                      .data![j]!
                      .id
                };
                mapFun.add(uFun);
              });
            }
            draftFunctionality = mapFun;
            startDate = resultProjects[i].attributes!.startDate!;
            endDate = resultProjects[i].attributes!.endDate!;
            status =
                resultProjects[i].attributes!.status!.data!.attributes!.name!;
            Map<String, dynamic> uStatus = {};
            setState(() {
              uStatus = {"id": resultProjects[i].attributes!.status!.data!.id};
              mapStatus.add(uStatus);
            });
            draftStatus = mapStatus;
            platformProject = resultProjects[i].attributes!.platforms!.data;
            if (platformProject != null) {
              platformProjectName = resultProjects[i]
                  .attributes!
                  .platforms!
                  .data![i]!
                  .attributes!
                  .name!;
              Map<String, dynamic> uPlat = {};
              for (var j = 0;
                  j < resultProjects[i].attributes!.platforms!.data!.length;
                  j++) {
                setState(() {
                  uPlat = {
                    "id": resultProjects[i].attributes!.platforms!.data![j]!.id
                  };
                  mapPlat.add(uPlat);
                });
              }
              draftPlatform = mapPlat;
            }

            technologyProject =
                resultProjects[i].attributes!.technologies!.data;
            if (technologyProject != null) {
              technologyProjectName = resultProjects[i]
                  .attributes!
                  .technologies!
                  .data![i]!
                  .attributes!
                  .name!;
              Map<String, dynamic> uTech = {};
              for (var j = 0;
                  j < resultProjects[i].attributes!.technologies!.data!.length;
                  j++) {
                setState(() {
                  uTech = {
                    "id":
                        resultProjects[i].attributes!.technologies!.data![j]!.id
                  };
                  mapTech.add(uTech);
                });
              }
              draftTechnology = mapTech;
            }

            document = resultProjects[i].attributes!.documents;
            currency = resultProjects[i].attributes!.currency!;
            location = resultProjects[i].attributes!.location!;
            draftResource = resultProjects[i].attributes!.resources;

            SharedPrefs.instance.setString(
                Constants.resourceDetailDraft, jsonEncode(draftResource));

            var res =
                SharedPrefs.instance.getString(Constants.resourceDetailDraft);
            if (res != null) {
              List<ResourcesData> storedItems = [];
              ResourcesData y = ResourcesData();
              if (draftResource.data != null) {
                for (var j = 0; j < draftResource.data!.length; j++) {
                  setState(() {
                    y.id = draftResource.data![i]!.id;
                    y.designation =
                        draftResource.data![i]!.attributes!.designation;
                    y.resourceEmail =
                        draftResource.data![i]!.attributes!.resourceEmail;
                    y.resourceName =
                        draftResource.data![i]!.attributes!.resourceName;
                    storedItems.add(y);
                  });
                }
                resourceDetail = storedItems;
              }
            }
            comments = resultProjects[i].attributes!.comments!;
            feedback = resultProjects[i].attributes!.feedback!;
            riskFactor = resultProjects[i].attributes!.riskFactor!;
            knownIssues = resultProjects[i].attributes!.knownIssues!;
            if (resultProjects[i].attributes!.methodology!.data != null) {
              methodology = resultProjects[i]
                  .attributes!
                  .methodology!
                  .data!
                  .attributes!
                  .name!;

              Map<String, dynamic> uMeth = {};
              setState(() {
                uMeth = {
                  "id": resultProjects[i].attributes!.methodology!.data!.id
                };
                mapMeth.add(uMeth);
              });
              draftMethodology = mapMeth;
            }

            dependency = resultProjects[i].attributes!.dependencies!;
            clientName = resultProjects[i].attributes!.clientName!;
            budget = resultProjects[i].attributes!.budget!;
          });
          SharedPrefs.instance
              .setString('functionality', jsonEncode(functionalityProject));
          if (platformProject != null) {
            SharedPrefs.instance
                .setString('platforms', jsonEncode(platformProject));
          }
          if (technologyProject != null) {
            SharedPrefs.instance
                .setString('technologies', jsonEncode(technologyProject));
          }
        }
      });
    } else {
      resultProposals = await db.getSpecificProposalList(widget.projectName);
      List<Map<String, dynamic>> mapFun = [];
      List<Map<String, dynamic>> mapPlat = [];
      List<Map<String, dynamic>> mapTech = [];
      List<Map<String, dynamic>> mapDomain = [];
      List<Map<String, dynamic>> mapStatus = [];
      int index = resultProposals.length;
      for (int i = 0; i < index; i++) {
        setState(() {
          id = 0;
          name = resultProposals[i].attributes!.name!;
          domain =
              resultProposals[i].attributes!.domain!.data!.attributes!.name!;
          Map<String, dynamic> uDomain = {};
          setState(() {
            uDomain = {"id": resultProposals[i].attributes!.domain!.data!.id};
            mapDomain.add(uDomain);
          });
          draftDomain = mapDomain;
          objective = resultProposals[i].attributes!.objectives!;
          summery = resultProposals[i].attributes!.summery!;
          functionalityProposal =
              resultProposals[i].attributes!.functionalities!.data!;

          Map<String, dynamic> uFun = {};
          for (var j = 0;
              j < resultProposals[i].attributes!.functionalities!.data!.length;
              j++) {
            setState(() {
              uFun = {
                "id":
                    resultProposals[i].attributes!.functionalities!.data![j]!.id
              };
              mapFun.add(uFun);
            });
          }
          draftFunctionality = mapFun;
          startDate = resultProposals[i].attributes!.proposalReceivedDate!;
          endDate = resultProposals[i].attributes!.proposalSubmittedDate!;
          status =
              resultProposals[i].attributes!.status!.data!.attributes!.name!;
          Map<String, dynamic> uStatus = {};
          setState(() {
            uStatus = {"id": resultProposals[i].attributes!.status!.data!.id};
            mapStatus.add(uStatus);
          });
          draftStatus = mapStatus;

          platformProposal = resultProposals[i].attributes!.platforms!.data;
          if (platformProposal != null) {
            Map<String, dynamic> uPlat = {};
            for (var j = 0;
                j < resultProposals[i].attributes!.platforms!.data!.length;
                j++) {
              setState(() {
                uPlat = {
                  "id": resultProposals[i].attributes!.platforms!.data![j]!.id
                };
                mapPlat.add(uPlat);
              });
            }
            draftPlatform = mapPlat;
          }

          technologyProposal =
              resultProposals[i].attributes!.technologies!.data;
          if (technologyProposal != null) {
            Map<String, dynamic> uTech = {};
            for (var j = 0;
                j < resultProposals[i].attributes!.technologies!.data!.length;
                j++) {
              setState(() {
                uTech = {
                  "id":
                      resultProposals[i].attributes!.technologies!.data![j]!.id
                };
                mapTech.add(uTech);
              });
            }
            draftTechnology = mapTech;
          }

          draftResource = resultProposals[i].attributes!.resources;

          SharedPrefs.instance.setString(
              Constants.resourceDetailDraft, jsonEncode(draftResource));

          var res =
              SharedPrefs.instance.getString(Constants.resourceDetailDraft);
          if (res != null) {
            List<ResourcesData> storedItems = [];
            ResourcesData y = ResourcesData();
            if (draftResource.data != null) {
              for (var j = 0; j < draftResource.data!.length; j++) {
                setState(() {
                  y.id = draftResource.data![i]!.id;
                  y.designation =
                      draftResource.data![i]!.attributes!.designation;
                  y.resourceEmail =
                      draftResource.data![i]!.attributes!.resourceEmail;
                  y.resourceName =
                      draftResource.data![i]!.attributes!.resourceName;
                  storedItems.add(y);
                });
              }
              resourceDetail = storedItems;
            }
          }
          SharedPrefs.instance.setString(
              Constants.resourceDetailDraft, jsonEncode(draftResource));
          currency = resultProposals[i].attributes!.currency!;
          location = resultProposals[i].attributes!.location!;
          comments = resultProposals[i].attributes!.comments!;
          feedback = resultProposals[i].attributes!.feedback!;
          dependency = resultProposals[i].attributes!.dependencies!;
          clientName = resultProposals[i].attributes!.clientDetails!;
          budget = resultProposals[i].attributes!.budget!;
          riskFactors = resultProposals[i].attributes!.riskFactors!;
        });
        SharedPrefs.instance
            .setString('functionality', jsonEncode(functionalityProposal));
        if (platformProposal != null) {
          SharedPrefs.instance
              .setString('platforms', jsonEncode(platformProposal));
        }
        if (technologyProposal != null) {
          SharedPrefs.instance
              .setString('technologies', jsonEncode(technologyProposal));
        }
      }
    }
  }

  /// Navigation to Create Project Screen.
  void navigateToHomeScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/homeScreen'));
  }

  @override
  Widget build(BuildContext context) {
    ///Create project Bloc implementation
    return BlocConsumer<CreateProjectScreenBloc, CreateProjectState>(
      bloc: createProjectScreenBloc,
      listenWhen: (previous, current) => current is CreateProjectActionState,
      buildWhen: (previous, current) => current is! CreateProjectActionState,
      listener: (context, state) {
        /// State for Navigation from Create project Screen to Basic detail screen.
        if (state is NavigateCreateProjectToBasicDetailState) {
          if (basicDetailDraft) {
            DisplayMessageUtils.toastMessage(
                Strings().editFromDraftsToastMessage);
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                  settings: const RouteSettings(name: "/basicDetailScreen"),
                  builder: (context) => BasicDetailScreen(
                        widget.currentIndex,
                        widget.projectName,
                        draftSelected,
                        isReviewScreen,
                        additionalDetailDraft,
                        isProject: isProject,
                        database: widget.database,
                      )),
            );
          }
        }

        /// State for Navigation from Create project Screen to Technical detail screen.
        else if (state is NavigateCreateProjectToTechInfoState) {
          if (basicDetailDraft || proposalBasicDetails.isNotEmpty) {
            if (technicalDetailDraft) {
              DisplayMessageUtils.toastMessage(
                  Strings().editFromDraftsToastMessage);
            } else {
              Navigator.of(context).push(
                MaterialPageRoute(
                    settings: const RouteSettings(
                        name: "/technicalInformationScreen"),
                    builder: (context) => TechnicalInformationScreen(
                          widget.currentIndex,
                          widget.projectName,
                          basicDetailDraft,
                          isBasicScreen,
                          draftSelected,
                          isReviewScreen,
                          additionalDetailDraft,
                          isProject,
                          database: widget.database,
                        )),
              );
            }
          } else {
            null;
          }
        }

        ///State for Navigation from Create project Screen to Additional detail screen.
        else if (state is NavigateCreateProjectToAdditionalDetailState) {
          if (technicalDetailDraft || proposalTechnicalInformation.isNotEmpty) {
            if (additionalDetailDraft) {
              DisplayMessageUtils.toastMessage(
                  Strings().editFromDraftsToastMessage);
            } else {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AdditionalDetailScreen(
                          widget.currentIndex,
                          widget.projectName,
                          basicDetailDraft,
                          isBasicScreen,
                          technicalDetailDraft,
                          draftSelected,
                          additionalDetailDraft,
                          isReviewScreen,
                          isProject: isProject,
                          database: widget.database)));
            }
          } else {
            null;
          }
        }

        ///State for Navigation from Create project Screen to Review screen.
        else if (state is NavigateCreateProjectToReviewState) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ReviewScreen(
                      widget.currentIndex,
                      widget.projectName,
                      additionalDetailDraft,
                      draftSelected,
                      additionalDetailScreen,
                      isProject: isProject,
                      database: widget.database)));
        } else if (state is ResourceStoreState) {
          setState(() {
            resourceDetail = state.resources;
          });
          List<int?> mapResources = [];
          List<Map<String, dynamic>> mapRes = [];

          ///Resources list
          Map<String, dynamic>? q;
          for (var i = 0; i < resourceDetail.length; i++) {
            setState(() {
              var resItem = (resourceDetail[i]!.id);
              mapResources.add(resItem);
              q = {"id": jsonEncode(mapResources[i])};
              mapRes.add(q!);
            });
          }

          List<int?> mapResources1 = [];
          List<Map<String, dynamic>>? d;
          Map<String, dynamic>? dd;
          if (document != null) {
            if (jsonEncode(document) != "{}") {
              d = [];
              for (var i = 0; i < document.length; i++) {
                print("document: $document");
                var doc = (document![i]!.id);
                mapResources1.add(doc);
                setState(() {
                  dd = {"id": jsonEncode(mapResources1[i])};
                  d!.add(dd!);
                });
              }
            }
          }

          if (isProject) {
            createProjectScreenBloc.add(CreateProjectClickedEvent(
                objectives: objective,
                startDate: startDate,
                endDate: endDate,
                clientName: clientName,
                budget: budget,
                knownIssues: knownIssues,
                dependencies: dependency,
                comments: comments,
                documents: d,
                feedback: feedback,
                name: name,
                summary: summery,
                currency: currency,
                location: location,
                riskFactor: riskFactor,
                technologies: draftTechnology,
                domain: draftDomain,
                platforms: draftPlatform,
                resources: mapRes.isNotEmpty ? mapRes : null,
                functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                status: draftStatus,
                methodology: draftMethodology));
            db.deleteProjectModel(resultProjects);
            navigateToHomePage(context);
            DisplayMessageUtils.flushBarErrorMessage(
                context,
                Strings().projectCreatedMessage,
                AppColors.flushBarBackgroundColor,
                Strings().view,
                () {});
          } else {
            ///Proposal Post API
            createProjectScreenBloc.add(CreateProposalClickedEvent(
              objectives: objective,
              proposalReceivedDate: startDate,
              proposalSubmittedDate: endDate,
              clientDetails: clientName,
              budget: budget,
              dependencies: dependency,
              comments: comments,
              documents: d,
              feedback: feedback,
              name: name,
              summery: summery,
              currency: currency,
              location: location,
              riskFactors: riskFactors,
              technologies: draftTechnology,
              domain: draftDomain,
              platforms: draftPlatform,
              resources: mapRes.isNotEmpty ? mapRes : null,
              functionalities: jsonDecode(jsonEncode(draftFunctionality)),
              status: draftStatus,
            ));
            db.deleteProposalModel(resultProposals);
            navigateToHomePage(context);
            DisplayMessageUtils.flushBarErrorMessage(
                context,
                Strings().proposalCreatedMessage,
                AppColors.flushBarBackgroundColor,
                Strings().view,
                () {});
          }
        } else if (state is UploadDocumentState) {
          setState(() {
            document = state.details;
          });
          List<int?> mapResources1 = [];
          List<Map<String, dynamic>> d = [];
          Map<String, dynamic>? dd;
          for (var i = 0; i < document!.length; i++) {
            print("document: $document");
            var doc = (document![i]!.id);
            mapResources1.add(doc);
            setState(() {
              dd = {"id": jsonEncode(mapResources1[i])};
              d.add(dd!);
            });
          }
          files.clear();

          int index = resourceDetail.length;
          if (resourceDetail.isNotEmpty) {
            for (int i = 0; i < index; i++) {
              createProjectScreenBloc.add(ResourceStoreEvent(
                  resourceName: resourceDetail[i]!.resourceName,
                  resourceEmail: resourceDetail[i]!.resourceEmail,
                  designation: resourceDetail[i]!.designation));
            }
          } else {
            if (isProject) {
              createProjectScreenBloc.add(CreateProjectClickedEvent(
                  objectives: objective,
                  startDate: startDate,
                  endDate: endDate,
                  clientName: clientName,
                  budget: budget,
                  knownIssues: knownIssues,
                  dependencies: dependency,
                  comments: comments,
                  documents: d,
                  feedback: feedback,
                  name: name,
                  summary: summery,
                  currency: currency,
                  location: location,
                  riskFactor: riskFactor,
                  technologies: draftTechnology,
                  domain: draftDomain,
                  platforms: draftPlatform,
                  resources: null,
                  functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                  status: draftStatus,
                  methodology: draftMethodology));
              db.deleteProjectModel(resultProjects);
              navigateToHomePage(context);
              DisplayMessageUtils.flushBarErrorMessage(
                  context,
                  Strings().projectCreatedMessage,
                  AppColors.flushBarBackgroundColor,
                  Strings().view,
                  () {});
            } else {
              ///Proposal Post API
              createProjectScreenBloc.add(CreateProposalClickedEvent(
                objectives: objective,
                proposalReceivedDate: startDate,
                proposalSubmittedDate: endDate,
                clientDetails: clientName,
                budget: budget,
                dependencies: dependency,
                comments: comments,
                documents: d,
                feedback: feedback,
                name: name,
                summery: summery,
                currency: currency,
                location: location,
                riskFactors: riskFactors,
                technologies: draftTechnology,
                domain: draftDomain,
                platforms: draftPlatform,
                resources: null,
                functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                status: draftStatus,
              ));
              db.deleteProposalModel(resultProposals);
              navigateToHomePage(context);
              DisplayMessageUtils.flushBarErrorMessage(
                  context,
                  Strings().proposalCreatedMessage,
                  AppColors.flushBarBackgroundColor,
                  Strings().view,
                  () {});
            }

            // DisplayMessageUtils.showSnackBar(Strings().fileIsUploadString);
            files.clear();
          }
        } else if (state is UploadDocumentFailedState) {
          // DisplayMessageUtils.showSnackBar(
          //     NetworkExceptions.getErrorMessage(state.exception));
        }

        ///Create project button state.
        else if (state is CreateProjectClickedState) {
          db.deleteSingleProjectModel(state.createProject!);
          navigateToHomePage(context);
          DisplayMessageUtils.flushBarErrorMessage(
              context,
              Strings().projectCreatedMessage,
              AppColors.flushBarBackgroundColor,
              Strings().view,
              () {});
        } else if (state is CreateProposalClickedState) {
          db.deleteSingleProposalModel(state.createProposal!);
          navigateToHomePage(context);
          DisplayMessageUtils.flushBarErrorMessage(
              context,
              Strings().proposalCreatedMessage,
              AppColors.flushBarBackgroundColor,
              Strings().view,
              () {});
        }
      },
      builder: (context, state) {
        return WillPopScope(
          onWillPop: () async {
            navigateToHomeScreen(context);
            return false;
          },
          child: Scaffold(
              backgroundColor: AppColors.white,
              appBar: AppBar(
                backgroundColor: AppColors.createProjectAppBarColor,
                title: Text(
                  isProject == true
                      ? Strings().createProjectAppbarTitle.toTitleCase()
                      : Strings().createProposalAppbarTitle.toTitleCase(),
                  style: TextStyle(
                      color: AppColors.white, fontSize: Dimensions.font_20),
                ),
                iconTheme: IconThemeData(
                  color: AppColors.white,
                ),
              ),
              body: Padding(
                  padding: EdgeInsets.fromLTRB(
                      Dimensions.padding_11,
                      Dimensions.padding_24,
                      Dimensions.padding_11,
                      Dimensions.padding_0),
                  child: Column(children: [
                    Visibility(
                      visible: isProject == true
                          ? (basicDetailDraft ? true : false)
                          : (proposalBasicDetails.isNotEmpty ? true : false),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: basicDetailDraft == false &&
                                      proposalBasicDetails.isEmpty
                                  ? AppColors.white
                                  : AppColors.green,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color:
                                      AppColors.createScreenButtonBorderColor),
                            ),
                            child: Center(
                                child: basicDetailDraft == false &&
                                        proposalBasicDetails.isEmpty
                                    ? Text(Strings().progressIndicatorTitle_1)
                                    : Icon(
                                        Icons.done,
                                        size: Dimensions.iconSize_18,
                                        color: AppColors.white,
                                      )),
                          ),
                          SizedBox(
                            width: Dimensions.width_25,
                            child: Divider(
                              color: AppColors.grey,
                              thickness: Dimensions.verticalDividerThickness_1,
                            ),
                          ),
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: technicalDetailDraft == false &&
                                      proposalTechnicalInformation.isEmpty
                                  ? AppColors.white
                                  : AppColors.green,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color:
                                      AppColors.createScreenButtonBorderColor),
                            ),
                            child: Center(
                                child: technicalDetailDraft == false &&
                                        proposalTechnicalInformation.isEmpty
                                    ? Text(Strings().progressIndicatorTitle_2)
                                    : Icon(
                                        Icons.done,
                                        size: Dimensions.iconSize_18,
                                        color: AppColors.white,
                                      )),
                          ),
                          SizedBox(
                            width: Dimensions.width_25,
                            child: Divider(
                              color: AppColors.grey,
                              thickness: Dimensions.verticalDividerThickness_1,
                            ),
                          ),
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: additionalDetailDraft == false &&
                                      proposalAdditionalDetails.isEmpty
                                  ? AppColors.white
                                  : AppColors.green,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color:
                                      AppColors.createScreenButtonBorderColor),
                            ),
                            child: Center(
                                child: additionalDetailDraft == false &&
                                        proposalAdditionalDetails.isEmpty
                                    ? Text(Strings().progressIndicatorTitle_3)
                                    : Icon(
                                        Icons.done,
                                        size: Dimensions.iconSize_18,
                                        color: AppColors.white,
                                      )),
                          ),
                        ],
                      ),
                    ),
                    Visibility(
                        visible:
                            basicDetailDraft && proposalBasicDetails.isNotEmpty
                                ? true
                                : false,
                        child: SizedBox(height: Dimensions.height_32)),
                    Visibility(
                      visible:
                          basicDetailDraft || proposalBasicDetails.isNotEmpty
                              ? false
                              : true,
                      child: Text(
                        isProject == true
                            ? Strings().basicDetailsHeading
                            : Strings().proposalBasicDetailsHeading,
                        style: TextStyle(
                            color: AppColors.basicDetailsHeadingColor),
                      ),
                    ),
                    SizedBox(height: Dimensions.height_19),
                    InkWell(
                      onTap: () {
                        ///Event for Navigation from Create project Screen to Basic detail screen.
                        createProjectScreenBloc
                            .add(NavigateCreateProjectToBasicDetailEvent());
                      },
                      child: Container(
                        height: Dimensions.height_56,
                        width: getSize(context).width,
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius:
                              BorderRadius.circular(Dimensions.borderRadius_5),
                          border: Border.all(
                              color: AppColors.createProjectAppBarColor),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(left: Dimensions.padding_16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                Strings().basicDetailTitle.toTitleCase(),
                                style: TextStyle(
                                    fontSize: Dimensions.font_16,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.createProjectAppBarColor),
                              ),
                              Padding(
                                padding: EdgeInsets.all(Dimensions.padding_16),
                                child: basicDetailDraft ||
                                        proposalBasicDetails.isNotEmpty
                                    ? Container(
                                        height: Dimensions.height_24,
                                        width: Dimensions.width_24,
                                        decoration: BoxDecoration(
                                          color: AppColors.green,
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.borderRadius_40),
                                          border: Border.all(
                                              color: AppColors
                                                  .createScreenButtonBorderColor),
                                        ),
                                        child: Center(
                                            child: Icon(
                                          Icons.done,
                                          size: Dimensions.iconSize_18,
                                          color: AppColors.white,
                                        )),
                                      )
                                    : Icon(
                                        Icons.arrow_forward_ios_sharp,
                                        size: Dimensions.iconSize_24,
                                        color:
                                            AppColors.createProjectAppBarColor,
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: Dimensions.height_24),
                    InkWell(
                      onTap: () {
                        ///Event for Navigation from Create project Screen to Technical detail screen.
                        createProjectScreenBloc
                            .add(NavigateCreateProjectToTechInfoEvent());
                      },
                      child: Container(
                        height: Dimensions.height_56,
                        width: getSize(context).width,
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius:
                              BorderRadius.circular(Dimensions.borderRadius_5),
                          border: Border.all(
                              color: basicDetailDraft == false &&
                                      proposalBasicDetails.isEmpty
                                  ? AppColors.createScreenButtonBorderColor
                                  : AppColors.createProjectAppBarColor),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(left: Dimensions.padding_16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                Strings().technicalInfoButton.toTitleCase(),
                                style: TextStyle(
                                    fontSize: Dimensions.font_16,
                                    fontWeight: FontWeight.bold,
                                    color: basicDetailDraft == false &&
                                            proposalBasicDetails.isEmpty
                                        ? AppColors.grey_300
                                        : AppColors.createProjectAppBarColor),
                              ),
                              Padding(
                                padding: EdgeInsets.all(Dimensions.padding_16),
                                child: technicalDetailDraft ||
                                        proposalTechnicalInformation.isNotEmpty
                                    ? Container(
                                        height: Dimensions.height_24,
                                        width: Dimensions.width_24,
                                        decoration: BoxDecoration(
                                          color: AppColors.green,
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.borderRadius_40),
                                          border: Border.all(
                                              color: AppColors
                                                  .createScreenButtonBorderColor),
                                        ),
                                        child: Center(
                                            child: Icon(
                                          Icons.done,
                                          size: Dimensions.iconSize_18,
                                          color: AppColors.white,
                                        )),
                                      )
                                    : Icon(
                                        Icons.arrow_forward_ios_sharp,
                                        size: Dimensions.iconSize_24,
                                        color: basicDetailDraft == false &&
                                                proposalBasicDetails.isEmpty
                                            ? AppColors.grey_300
                                            : AppColors
                                                .createProjectAppBarColor,
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: Dimensions.height_24),
                    InkWell(
                      onTap: () {
                        ///Event for Navigation from Create project Screen to Additional detail screen.
                        createProjectScreenBloc.add(
                            NavigateCreateProjectToAdditionalDetailEvent());
                      },
                      child: Container(
                        height: Dimensions.height_56,
                        width: getSize(context).width,
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius:
                              BorderRadius.circular(Dimensions.borderRadius_5),
                          border: Border.all(
                              color: technicalDetailDraft == false &&
                                      proposalTechnicalInformation.isEmpty
                                  ? AppColors.createScreenButtonBorderColor
                                  : AppColors.createProjectAppBarColor),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(left: Dimensions.padding_16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                Strings().additionalDetailsButton,
                                style: TextStyle(
                                    fontSize: Dimensions.font_16,
                                    fontWeight: FontWeight.bold,
                                    color: technicalDetailDraft == false &&
                                            proposalTechnicalInformation.isEmpty
                                        ? AppColors.grey_300
                                        : AppColors.createProjectAppBarColor),
                              ),
                              Padding(
                                padding: EdgeInsets.all(Dimensions.padding_16),
                                child: additionalDetailDraft ||
                                        proposalAdditionalDetails.isNotEmpty
                                    ? Container(
                                        height: Dimensions.height_24,
                                        width: Dimensions.width_24,
                                        decoration: BoxDecoration(
                                          color: AppColors.green,
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.borderRadius_40),
                                          border: Border.all(
                                              color: AppColors
                                                  .createScreenButtonBorderColor),
                                        ),
                                        child: Center(
                                            child: Icon(
                                          Icons.done,
                                          size: Dimensions.iconSize_18,
                                          color: AppColors.white,
                                        )),
                                      )
                                    : Icon(
                                        Icons.arrow_forward_ios_sharp,
                                        size: Dimensions.iconSize_24,
                                        color: technicalDetailDraft == false &&
                                                proposalTechnicalInformation
                                                    .isEmpty
                                            ? AppColors.grey_300
                                            : AppColors
                                                .createProjectAppBarColor,
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: Dimensions.height_24),
                    Visibility(
                      visible: technicalDetailDraft ||
                              proposalTechnicalInformation.isNotEmpty
                          ? true
                          : false,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              ///Event for Navigation from Create project Screen to Review screen.
                              // createProjectScreenBloc
                              //     .add(NavigateCreateProjectToReviewEvent());
                            },
                            child: Container(
                              height: Dimensions.height_40,
                              width: Dimensions.width_160,
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(
                                    Dimensions.borderRadius_60),
                                border: Border.all(
                                    color: AppColors.createProjectAppBarColor),
                              ),
                              child: Center(
                                child: Text(
                                  Strings().reviewButton.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_14,
                                      fontWeight: FontWeight.bold,
                                      color:
                                          AppColors.createProjectAppBarColor),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: Dimensions.width_32),
                          createProjectButton()
                        ],
                      ),
                    ),
                  ]))),
        );
      },
    );
  }

  /// listener for positive button
  void positiveButtonCallback() {
    Navigator.of(context).pop();
    ShowBottomSheet.getInstance.showBottomSheet(context);
  }

  /// listener for negative button
  void negativeButtonCallback() {
    Navigator.of(context).pop();
  }

  /// listener for single button
  actionSingleButtonCallback() {
    if (resourceDetail.isNotEmpty) {
      print(5);
      Dialogs.showLoadingDialog(context, _keyLoader, isProject);
      int index = resourceDetail.length;
      for (int i = 0; i < index; i++) {
        createProjectScreenBloc.add(ResourceStoreEvent(
            resourceName: resourceDetail[i]!.resourceName,
            resourceEmail: resourceDetail[i]!.resourceEmail,
            designation: resourceDetail[i]!.designation));
      }
    } else {
      Dialogs.showLoadingDialog(context, _keyLoader, isProject);
      if (isProject) {
        print(6);
        createProjectScreenBloc.add(CreateProjectClickedEvent(
            objectives: objective,
            startDate: startDate,
            endDate: endDate,
            clientName: clientName,
            budget: budget,
            knownIssues: knownIssues,
            dependencies: dependency,
            comments: comments,
            documents: null,
            feedback: feedback,
            name: name,
            summary: summery,
            currency: currency,
            location: location,
            riskFactor: riskFactor,
            technologies: draftTechnology,
            domain: draftDomain,
            platforms: draftPlatform,
            resources: null,
            functionalities: jsonDecode(jsonEncode(draftFunctionality)),
            status: draftStatus,
            methodology: draftMethodology));
      } else {
        ///Proposal Post API
        createProjectScreenBloc.add(CreateProposalClickedEvent(
          objectives: objective,
          proposalReceivedDate: startDate,
          proposalSubmittedDate: endDate,
          clientDetails: clientName,
          budget: budget,
          dependencies: dependency,
          comments: comments,
          documents: null,
          feedback: feedback,
          name: name,
          summery: summery,
          currency: currency,
          location: location,
          riskFactors: riskFactors,
          technologies: draftTechnology,
          domain: draftDomain,
          platforms: draftPlatform,
          resources: null,
          functionalities: jsonDecode(jsonEncode(draftFunctionality)),
          status: draftStatus,
        ));
      }
    }
  }

  /// All with yes no button without background
  CustomDialogBox dialog() {
    return CustomDialogBox(
        title: Strings().dialogTitle.toTitleCase(),
        description: Strings().dialogDiscription,
        actionPositive: Strings().positiveButton.toTitleCase(),
        actionNegative: Strings().negativeButton.toTitleCase(),
        showTitle: true,
        showDescription: true,
        showDialogImage: true,
        showActionPositive: true,
        showActionNegative: true,
        showSingleActionButton: false,
        buttonTextColor: Colors.black,
        onPositiveButtonClick: positiveButtonCallback,
        onNegativeButtonClick: negativeButtonCallback,
        actionOnPressed: actionSingleButtonCallback);
  }

  String trimAfterSpace(String input) {
    int spaceIndex = input.indexOf(' ');
    if (spaceIndex == -1) {
      return input;
    } else {
      return input.substring(0, spaceIndex);
    }
  }

  ///Navigate to Home screen.
  void navigateToHomePage(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/homeScreen'));
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => HomeScreen(
                isFilterScreen: false,
                isProposalFilterScreen: false,
                isProjectFiltersApplied: false,
                isProposalFiltersApplied: false,
                database: widget.database)));
  }

  Widget createProjectButton() {
    return InkWell(
      onTap: () {
        if (technicalDetailDraft || proposalTechnicalInformation.isNotEmpty) {
          navigateToHomePage(context);
          DisplayMessageUtils.flushBarErrorMessage(
              context,
              Strings().projectCreatedMessage,
              AppColors.flushBarBackgroundColor,
              Strings().view,
              () {});
        } else {
          null;
        }
      },
      borderRadius: BorderRadius.circular(Dimensions.borderRadius_60),
      child: Container(
        height: Dimensions.height_40,
        width: Dimensions.width_160,
        decoration: BoxDecoration(
          color: AppColors.createProjectAppBarColor,
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_60),
          border: Border.all(color: Colors.transparent),
        ),
        child: BlocProvider.value(
          value: createProjectScreenBloc,
          child: BlocListener<CreateProjectScreenBloc, CreateProjectState>(
            listener: (context, state) {},
            child: BlocBuilder<CreateProjectScreenBloc, CreateProjectState>(
              builder: (context, state) {
                if (state is CreateProjectLoadingState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is UploadDocumentState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is ResourceStoreState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is CreateProjectClickedState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else if (state is CreateProposalClickedState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else if (state is CreateProjectFailedState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                }
              },
            ),
          ),
        ),
      ),
    );
  }
}
