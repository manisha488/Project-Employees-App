import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/model/response/proposals_list.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/statusColorUtils.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/project_details_screen/ui/project_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/projects_screen/bloc/projects_bloc.dart';

class ProjectsScreen extends StatefulWidget {
  final bool isProjectScreen;
  final bool isProposalScreen;
  final bool isProjectFiltersApplies;
  final bool isProposalFiltersApplies;
  final bool isFilteredProjectsScreen;
  final bool isFilteredProposalsScreen;
  final Database database;
  const ProjectsScreen(
      {super.key,
      required this.isProjectScreen,
      required this.isProposalScreen,
      required this.isFilteredProjectsScreen,
      required this.isFilteredProposalsScreen,
      required this.isProjectFiltersApplies,
      required this.isProposalFiltersApplies,
      required this.database});

  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  final ProjectsBloc listBloc = ProjectsBloc();
  List<ProjectsData?> offlineProjects = [];
  List<ProjectsData?> filteredProjects = [];
  List<ProjectsData?> filteredSearchedProjects = [];
  List<ProposalsData?> filteredProposals = [];
  List<ProposalsData?> filteredSearchedProposals = [];
  List<ProjectsData?> searchedProjects = [];
  List<ProjectsData?> searchedFilteredProjects = [];
  List<ProposalsData?> offlineProposals = [];
  List<ProposalsData?> searchedProposals = [];
  final TextEditingController _searchController = TextEditingController();
  final db = CustomDataBaseWrapper();
  bool isLoading = false;
  bool isDataAvail = false;
  Timer? timer;
  late final FocusNode myFocusNode;

  @override
  void initState() {
    initializeDateFormatting();
    getOfflineData();
    myFocusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    myFocusNode.dispose();
    super.dispose();
  }

  /// To fetch the apis after every 30 min this function is used as it periodically hits the api after 30 min.
  void periodicTimer() {
    if (Utils.getActiveLifeSpan().inMinutes.toInt() >=
        Constants.appActiveTime) {
      if (!mounted) {
      } else {
        setState(() {
          if ((widget.isFilteredProjectsScreen &&
                  SharedPrefs.instance
                          .getBool(Strings().applyFiltersForProjectsKeyText) ==
                      true) ||
              (widget.isFilteredProposalsScreen &&
                  SharedPrefs.instance
                          .getBool(Strings().applyFiltersForProposalsKeyText) ==
                      true)) {
            if (widget.isFilteredProjectsScreen &&
                widget.isProjectFiltersApplies) {
              listBloc.add(FilteredProjectsLoadedEvent());
              listBloc.add(ProjectsInitialEvent());
              listBloc.add(ProposalsInitialEvent());
            } else if (widget.isFilteredProposalsScreen &&
                widget.isProposalFiltersApplies) {
              listBloc.add(FilteredProposalsLoadedEvent());
              listBloc.add(ProjectsInitialEvent());
              listBloc.add(ProposalsInitialEvent());
            }
          } else {
            listBloc.add(ProjectsInitialEvent());
            listBloc.add(ProposalsInitialEvent());
          }
        });
      }
    } else {
      listBloc.add(OfflineProjectsLoadedEvent());
      listBloc.add(OfflineProposalsLoadedEvent());
    }
  }

  List<dynamic> getOfflineData() {
    if (widget.isProjectScreen) {
      db.getProjectsList('projects').then((value) {
        setState(() {
          offlineProjects = value.reversed.toList();
        });
      });
      return offlineProjects;
    } else if (widget.isProposalScreen) {
      db.getProposalsList("proposals").then((value) {
        setState(() {
          offlineProposals = value.reversed.toList();
          ;
        });
        listBloc.add(OfflineProposalsLoadedEvent());
        if (offlineProposals.isEmpty) {
          listBloc.add(ProposalsInitialEvent());
        }
      });
      return offlineProposals;
    } else if (widget.isFilteredProjectsScreen &&
        widget.isProjectFiltersApplies) {
      db.getProjectsList('filteredProjects').then((value) {
        setState(() {
          filteredProjects = value.reversed.toList();
        });
      });
      return filteredProjects;
    } else if (widget.isFilteredProposalsScreen &&
        widget.isProposalFiltersApplies) {
      db.getProposalsList('filteredProposals').then((value) {
        setState(() {
          filteredProposals = value.reversed.toList();
        });
      });
      return filteredProjects;
    } else {
      return [];
    }
  }

  /// A switch case is used to manage all the possible states of the screen.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<ProjectsBloc, ProjectsState>(
        bloc: listBloc,
        listenWhen: (previous, current) {
          return true;
        },
        buildWhen: (previous, current) => current is! ProjectsActionState,
        listener: (context, state) {
          switch (state.runtimeType) {
            case ProjectsErrorState:
              final successState = state as ProjectsErrorState;
              getOfflineData();
            // DisplayMessageUtils.showSnackBar('${successState.exception}');
            case ProjectsInternetDisconnected:
              getOfflineData();
            // DisplayMessageUtils.showSnackBar(Strings().noInternetText);
            case ProjectsLoadedSuccessState:
              final successState = state as ProjectsLoadedSuccessState;
              if (Utils.getActiveLifeSpan().inMinutes.toInt() >=
                  Constants.appActiveTime) {
                setState(() {
                  offlineProjects = successState.projects.reversed.toList();
                });
              } else {
                listBloc.add(OfflineProjectsLoadedEvent());
              }

            case FilteredProjectsLoaded:
              db.getProjectsList('filteredProjects').then((value) {
                setState(() {
                  filteredProjects = value.reversed.toList();
                });
              });
            case FilteredProposalsLoaded:
              db.getProposalsList('filteredProposals').then((value) {
                setState(() {
                  filteredProposals = value.reversed.toList();
                });
              });
            case OfflineProjectsLoaded:
              db.getProjectsList('projects').then((value) {
                setState(() {
                  offlineProjects = value.reversed.toList();
                });
              });

            case OfflineProposalsLoaded:
              db.getProposalsList("proposals").then((value) {
                setState(() {
                  offlineProposals = value.reversed.toList();
                  ;
                });
              });
            case ProposalsLoadedSuccessfully:
              final successState = state as ProposalsLoadedSuccessfully;
              if (Utils.getActiveLifeSpan().inMinutes.toInt() >=
                  Constants.appActiveTime) {
                setState(() {
                  offlineProposals = successState.proposals.reversed.toList();
                });
              } else {
                listBloc.add(OfflineProposalsLoadedEvent());
              }
          }
        },
        builder: (context, state) {
          return Column(
            children: [
              (widget.isProjectScreen || widget.isFilteredProjectsScreen)
                  ? searchBar(
                      context: context, text: Strings().searchbarHintText)
                  : searchBar(
                      context: context,
                      text: Strings().searchProposalBarHintText),
              if (widget.isFilteredProjectsScreen ||
                  (widget.isProjectFiltersApplies && widget.isProjectScreen))
                filteredProjectsListWidget(
                    searchedList: filteredSearchedProjects,
                    offlineData: filteredProjects),
              if (widget.isFilteredProposalsScreen ||
                  (widget.isProposalFiltersApplies && widget.isProposalScreen))
                filteredProposalsListWidget(
                    searchedList: filteredSearchedProposals,
                    offlineData: filteredProposals),
              if (widget.isProjectScreen && !widget.isProjectFiltersApplies)
                offlineProjectsListWidget(
                    searchedList: searchedProjects,
                    offlineData: offlineProjects),
              if (widget.isProposalScreen && !widget.isProposalFiltersApplies)
                offlineProposalsListWidget(
                    searchedList: searchedProposals,
                    offlineData: offlineProposals)
            ],
          );
        },
      ),
    );
  }

  /// This widget is used to showcase all projects and proposals
  Widget cards({
    required void Function() onTap,
    required String name,
    required String status,
    required String summary,
    required String startDate,
    required String endDate,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(Dimensions.borderRadius_5),
                border: Border.all(
                    color: AppColors.projectCardBorderColor,
                    width: Dimensions.width_1)),
            child: Padding(
              padding: EdgeInsets.all(Dimensions.padding_15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          name.toTitleCase(),
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: Dimensions.font_16,
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.fromLTRB(
                            Dimensions.padding_8,
                            Dimensions.padding_5,
                            Dimensions.padding_8,
                            Dimensions.padding_5),
                        decoration: BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(Dimensions.borderRadius_20),
                          color: StatusColors.getColors(status.toTitleCase()),
                        ),
                        child: Center(
                          child: Text(
                            status.toCapitalized(),
                            style: TextStyle(
                                fontSize: Dimensions.font_12,
                                color: AppColors.black),
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: Dimensions.height_10,
                  ),
                  Text(
                    summary.toCapitalized(),
                    maxLines: Dimensions.maxLines_3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: status.toString() == Strings().cancelledStatus
                            ? AppColors.cancelledProjectBody
                            : AppColors.projectBody,
                        fontSize: Dimensions.font_14),
                  ),
                  SizedBox(
                    height: Dimensions.height_10,
                  ),
                  if (endDate != "")
                    Text(
                      '${convertDate(date: startDate)} - ${convertDate(date: endDate)}',
                      style: TextStyle(
                          color: AppColors.dateColor,
                          fontWeight: FontWeight.w600,
                          fontSize: Dimensions.font_12),
                    ),
                  SizedBox(
                    height: Dimensions.height_10,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: Dimensions.height_10,
          ),
        ],
      ),
    );
  }

  /// This function converts date into required format
  String convertDate({required String date}) {
    DateTime tempDate = DateFormat("yyyy-MM-dd").parse(date);
    var convertedDate = DateFormat('dd MMM yyyy').format(tempDate);

    return convertedDate;
  }

  ///online search
  Widget onlineSearchBar(
      {required BuildContext context, required String text}) {
    return Padding(
      padding: EdgeInsets.fromLTRB(Dimensions.padding_10, Dimensions.padding_15,
          Dimensions.padding_10, Dimensions.padding_4),
      child: TextFormField(
        focusNode: myFocusNode,
        textAlign: TextAlign.start,
        controller: _searchController,
        onChanged: (String value) {
          if (value.length >= Constants.searchCharacterCount &&
              Utils.getActiveLifeSpan().inMinutes.toInt() >=
                  Constants.appActiveTime) {
            widget.isProjectScreen
                ? listBloc.add(GetUserSearchIn(value))
                : listBloc.add(GetUserSearchInProposal(value));
          } else if (Utils.getActiveLifeSpan().inMinutes.toInt() >=
              Constants.appActiveTime) {
            widget.isProjectScreen
                ? listBloc.add(ProjectsInitialEvent())
                : listBloc.add(ProposalsInitialEvent());
          }
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: AppColors.homeSearchBarBorderColor,
              ),
              borderRadius:
                  BorderRadius.all(Radius.circular(Dimensions.borderRadius_30)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                  color: AppColors.appBottomNavigationBar
                      .withOpacity(Dimensions.opacity_05)),
              borderRadius:
                  BorderRadius.all(Radius.circular(Dimensions.borderRadius_30)),
            ),
            prefixIcon: InkWell(
              child: Icon(
                Icons.search,
                color: AppColors.searchBarHintTextColor,
              ),
            ),
            hintText: text,
            hintStyle: TextStyle(color: AppColors.searchBarHintTextColor)),
      ),
    );
  }

  /// Searchbar with online and offline search
  Widget searchBar({required BuildContext context, required String text}) {
    return Padding(
      padding: EdgeInsets.fromLTRB(Dimensions.padding_10, Dimensions.padding_15,
          Dimensions.padding_10, Dimensions.padding_4),
      child: TextFormField(
        focusNode: myFocusNode,
        textAlign: TextAlign.start,
        controller: _searchController,
        onChanged: (String value) {
          if (widget.isProjectScreen) {
            setState(() {});
            searchedProjects.clear();
            var projectIndex = offlineProjects.length;
            for (var i = 0; i < projectIndex; i++) {
              var dataIndex =
                  offlineProjects[i]!.attributes!.functionalities!.data!.length;
              var functionAttribute =
                  offlineProjects[i]!.attributes!.functionalities;
              var projectName = offlineProjects[i]!.attributes!.name ?? "";
              String? functionality = "";
              for (var j = 0; j < dataIndex; j++) {
                functionality =
                    functionAttribute!.data![j]!.attributes!.name ?? "";
              }
              if (projectName.toLowerCase().contains(value.toLowerCase()) ||
                  functionality!.toLowerCase().contains(value.toLowerCase())) {
                setState(() {
                  searchedProjects.add(offlineProjects[i]);
                });
              }
            }
          } else if (widget.isFilteredProjectsScreen) {
            setState(() {});
            filteredSearchedProjects.clear();
            var projectIndex = filteredProjects.length;
            for (var i = 0; i < projectIndex; i++) {
              var dataIndex = filteredProjects[i]!
                  .attributes!
                  .functionalities!
                  .data!
                  .length;
              var functionAttribute =
                  filteredProjects[i]!.attributes!.functionalities;
              var projectName = filteredProjects[i]!.attributes!.name ?? "";
              String? functionality = "";
              for (var j = 0; j < dataIndex; j++) {
                functionality =
                    functionAttribute!.data![j]!.attributes!.name ?? "";
              }
              if (projectName.toLowerCase().contains(value.toLowerCase()) ||
                  functionality!.toLowerCase().contains(value.toLowerCase())) {
                setState(() {
                  filteredSearchedProjects.add(filteredProjects[i]);
                });
              }
            }
          } else if (widget.isFilteredProposalsScreen) {
            setState(() {});
            filteredSearchedProposals.clear();
            var projectIndex = filteredProposals.length;
            for (var i = 0; i < projectIndex; i++) {
              var dataIndex = filteredProposals[i]!
                  .attributes!
                  .functionalities!
                  .data!
                  .length;
              var functionAttribute =
                  filteredProposals[i]!.attributes!.functionalities;
              var projectName = filteredProposals[i]!.attributes!.name ?? "";
              String? functionality = "";
              for (var j = 0; j < dataIndex; j++) {
                functionality =
                    functionAttribute!.data![j]!.attributes!.name ?? "";
              }
              if (projectName.toLowerCase().contains(value.toLowerCase()) ||
                  functionality!.toLowerCase().contains(value.toLowerCase())) {
                setState(() {
                  filteredSearchedProposals.add(filteredProposals[i]);
                });
              }
            }
          } else {
            setState(() {});
            searchedProposals.clear();
            var proposalIndex = offlineProposals.length;
            for (var i = 0; i < proposalIndex; i++) {
              var dataIndex = offlineProposals[i]!
                  .attributes!
                  .functionalities!
                  .data!
                  .length;
              var functionAttribute =
                  offlineProposals[i]!.attributes!.functionalities;
              var proposalName = offlineProposals[i]!.attributes!.name;
              String? functionality;
              for (var j = 0; j < dataIndex; j++) {
                functionality = functionAttribute!.data![j]!.attributes!.name;
              }
              if (proposalName!.toLowerCase().contains(value.toLowerCase()) ||
                  functionality!.toLowerCase().contains(value.toLowerCase())) {
                setState(() {
                  searchedProposals.add(offlineProposals[i]);
                });
              }
            }
          }
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: AppColors.homeSearchBarBorderColor,
              ),
              borderRadius:
                  BorderRadius.all(Radius.circular(Dimensions.borderRadius_30)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                  color: AppColors.appBottomNavigationBar
                      .withOpacity(Dimensions.opacity_05)),
              borderRadius:
                  BorderRadius.all(Radius.circular(Dimensions.borderRadius_30)),
            ),
            prefixIcon: InkWell(
              child: Icon(
                Icons.search,
                color: AppColors.searchBarHintTextColor,
              ),
            ),
            hintText: text,
            hintStyle: TextStyle(color: AppColors.searchBarHintTextColor)),
      ),
    );
  }

  /// Widget to display all offline projects
  Widget offlineProjectsListWidget(
      {required List<ProjectsData?> searchedList,
      required List<ProjectsData?> offlineData}) {
    if (offlineData.isEmpty) {
      return const Expanded(
        child: Center(child: CircularProgressIndicator()),
      );
    } else if (offlineData.isEmpty &&
        Utils.getActiveLifeSpan().inMinutes.toInt() >=
            Constants.appActiveTime) {
      return const Center(
        child: Text('Something went wrong!'),
      );
    } else if (searchedList.isEmpty && _searchController.text.isNotEmpty) {
      return Expanded(child: Center(child: Text(Strings().noRecordsFoundText)));
    } else {
      return Expanded(
        child: Padding(
          padding: EdgeInsets.all(Dimensions.height_10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: _searchController.text.isEmpty
                  ? offlineData.length
                  : searchedList.length,
              itemBuilder: (context, index) {
                final projects =
                    searchedList.isEmpty || _searchController.text.isEmpty
                        ? offlineData[index]!.attributes
                        : searchedList[index]!.attributes;
                if (offlineData.isEmpty && searchedList.isEmpty) {
                  return Center(
                      child: Text(
                    Strings().noRecordsFoundText,
                    style: TextStyle(
                      color: AppColors.projectBody,
                    ),
                  ));
                } else {
                  return cards(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (builder) => ProjectDetailsScreen(
                                    filteredProject: null,
                                    isFilteredProject: false,
                                    projectData: projects,
                                    proposalData: null,
                                    isDetailScreen: true,
                                    filteredProposals: null,
                                    isProposalDetailScreen: false,
                                    isFilteredProposal: false,
                                  )));
                    },
                    name: projects!.name ?? "",
                    status: projects.status?.data?.attributes?.name ?? "",
                    summary: projects.summary ?? "",
                    startDate: projects.startDate ?? "",
                    endDate: projects.endDate ?? "",
                  );
                }
              }),
        ),
      );
    }
  }

  /// Widget to display all offline proposals.
  Widget offlineProposalsListWidget(
      {required List<ProposalsData?> searchedList,
      required List<ProposalsData?> offlineData}) {
    if (offlineData.isEmpty) {
      return const Expanded(child: Center(child: CircularProgressIndicator()));
    } else if (offlineData.isEmpty &&
        Utils.getActiveLifeSpan().inMinutes.toInt() >=
            Constants.appActiveTime) {
      return const Center(
        child: Text('Something went wrong!'),
      );
    } else if (searchedList.isEmpty && _searchController.text.isNotEmpty) {
      return Expanded(child: Center(child: Text(Strings().noRecordsFoundText)));
    } else {
      //offlineData = offlineData.reversed.toList();
      return Expanded(
        child: Padding(
          padding: EdgeInsets.all(Dimensions.height_10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: _searchController.text.isEmpty
                  ? offlineData.length
                  : searchedList.length,
              itemBuilder: (context, index) {
                final proposals =
                    searchedList.isEmpty || _searchController.text.isEmpty
                        ? offlineData[index]!.attributes
                        : searchedList[index]!.attributes;
                if (offlineData.isEmpty && searchedList.isEmpty) {
                  return Center(
                      child: Text(
                    Strings().noRecordsFoundText,
                    style: TextStyle(
                      color: AppColors.projectBody,
                    ),
                  ));
                } else {
                  return cards(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (builder) => ProjectDetailsScreen(
                                    filteredProject: null,
                                    isFilteredProject: false,
                                    proposalData: proposals,
                                    projectData: null,
                                    isDetailScreen: false,
                                    filteredProposals: null,
                                    isProposalDetailScreen: true,
                                    isFilteredProposal: false,
                                  )));
                    },
                    name: proposals!.name!,
                    status: proposals.status!.data!.attributes!.name!,
                    summary: proposals.summery!,
                    startDate: proposals.proposalReceivedDate!,
                    endDate: proposals.proposalSubmittedDate ?? "",
                  );
                }
              }),
        ),
      );
    }
  }

  // Widget to display filtered projects.
  Widget filteredProjectsListWidget(
      {required List<ProjectsData?> searchedList,
      required List<ProjectsData?> offlineData}) {
    if (offlineData.isEmpty) {
      return Expanded(child: Center(child: Text(Strings().noRecordsFoundText)));
    } else if (searchedList.isEmpty && _searchController.text.isNotEmpty) {
      return Expanded(child: Center(child: Text(Strings().noRecordsFoundText)));
    } else {
      return Expanded(
        child: Padding(
          padding: EdgeInsets.all(Dimensions.height_10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: _searchController.text.isEmpty
                  ? offlineData.length
                  : searchedList.length,
              itemBuilder: (context, index) {
                final projects =
                    searchedList.isEmpty || _searchController.text.isEmpty
                        ? offlineData[index]!
                        : searchedList[index]!;
                if (offlineData.isEmpty && searchedList.isEmpty) {
                  return Center(
                      child: Text(
                    Strings().noRecordsFoundText,
                    style: TextStyle(
                      color: AppColors.projectBody,
                    ),
                  ));
                } else {
                  return cards(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (builder) => ProjectDetailsScreen(
                                    filteredProject: projects,
                                    isFilteredProject: true,
                                    projectData: null,
                                    proposalData: null,
                                    isDetailScreen: false,
                                    filteredProposals: null,
                                    isProposalDetailScreen: false,
                                    isFilteredProposal: false,
                                  )));
                    },
                    name: projects.attributes!.name ?? "",
                    status:
                        projects.attributes!.status?.data!.attributes!.name ??
                            "",
                    summary: projects.attributes!.summary ?? "",
                    startDate: projects.attributes!.startDate ?? "",
                    endDate: projects.attributes!.endDate ?? "",
                  );
                }
              }),
        ),
      );
    }
  }

  /// Widget to display filtered projects.
  Widget filteredProposalsListWidget(
      {required List<ProposalsData?> searchedList,
      required List<ProposalsData?> offlineData}) {
    if (offlineData.isEmpty) {
      return Expanded(child: Center(child: Text(Strings().noRecordsFoundText)));
    } else if (searchedList.isEmpty && _searchController.text.isNotEmpty) {
      return Expanded(child: Center(child: Text(Strings().noRecordsFoundText)));
    } else {
      return Expanded(
        child: Padding(
          padding: EdgeInsets.all(Dimensions.height_10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: _searchController.text.isEmpty
                  ? offlineData.length
                  : searchedList.length,
              itemBuilder: (context, index) {
                final proposals =
                    searchedList.isEmpty || _searchController.text.isEmpty
                        ? offlineData[index]!
                        : searchedList[index]!;
                if (offlineData.isEmpty && searchedList.isEmpty) {
                  return Center(
                      child: Text(
                    Strings().noRecordsFoundText,
                    style: TextStyle(
                      color: AppColors.projectBody,
                    ),
                  ));
                } else {
                  return cards(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (builder) => ProjectDetailsScreen(
                                    filteredProject: null,
                                    isFilteredProject: false,
                                    projectData: null,
                                    proposalData: null,
                                    isDetailScreen: false,
                                    filteredProposals: proposals,
                                    isProposalDetailScreen: false,
                                    isFilteredProposal: true,
                                  )));
                    },
                    name: proposals.attributes!.name ?? "",
                    status:
                        proposals.attributes!.status!.data!.attributes!.name ??
                            "",
                    summary: proposals.attributes!.summery ?? "",
                    startDate: proposals.attributes!.proposalReceivedDate ?? "",
                    endDate: proposals.attributes!.proposalSubmittedDate ?? "",
                  );
                }
              }),
        ),
      );
    }
  }
}
