class Strings {
  ///main
  String projectTitle = 'Project Treasure';
  String proposalName = 'Proposal Name';
  String projectName = 'Project Name';
  String loginError = "Login error";
  String onHoldStatus = "On Hold";
  String inProgressStatus = "In Progress";
  String cancelledStatus = "Cancelled";
  String completedStatus = "Complete";
  String notStartedStatus = "Not started";
  String inCompletedStatus = "Incomplete";
  String overdueStatus = "Overdue";
  String approvedStatus = "Approved";
  String noRecordsFoundText = 'No records found!';
  String noInternetText =
      'You are not connected to internet, please check your network connection to get updated data';

  /// Home Screen
  String appBarTitle = 'Projects';
  String homeScreenTitle = "Home Screen";
  String bottomNavigationTitleProjects = 'Projects';
  String bottomNavigationTitleProposals = 'Proposals';
  String bottomNavigationTitleMore = 'More';
  String searchbarHintText = 'Search by Project Name, Functionality';
  String searchProposalBarHintText = 'Search by Proposal Name, Functionality';
  String proposalSelectedIcon = 'assets/proposals-selected_bottom nav.png';
  String proposalUnselectedIcon = 'assets/proposal-unselected_bottom nav.png';
  String projectSelectedIcon = 'assets/projects-selected_bottom nav.png';
  String projectUnselectedIcon = 'assets/project-unselected_bottom nav.png';
  String moreUnselectedIcon = 'assets/more-unselected_bottomnav.png';
  String moreSelectedIcon = 'assets/more-selected_bottom nav.png';
  String user = 'user';
  String draftSelectedIcon = 'assets/draft_icon.png';
  String notificationSelectedIcon = 'assets/notification_icon.png';
  String versionSelectedIcon = 'assets/info_icon.png';
  String logOutSelectedIcon = 'assets/logout_icon.png';
  String errorRecordNotFound = "Record not found for given search";
  String draftText = 'Draft';
  String notificationText = 'Notification';
  String versionInfoText = 'Version info';
  String logOutText = 'Log out';

  ///Splash Screen
  String splashScreenYashLogo = 'assets/YashLogo.png';
  String splashScreenProjectTreasureLogo =
      'assets/splash_screen_project_treasurelogo.png';
  String loginScreenProjectTreasureLogo = 'assets/loginScreenAppIcon.png';

  ///Login Screen strings
  String loginEmailTextFieldTitle = 'Email address';
  String loginPasswordTextFieldTitle = 'Password';
  String loginButtonTitle = 'Login';
  String weatherButtonTitle = 'Get Weather Data';
  String loginWeakEmailMessage =
      "Valid e-mail can contain only letters, numbers, '@' and '.'";
  String logoutButtonTitle = 'Logout';
  String logoutDiscriptionButtonTitle =
      'Are you sure you want to logout from this app?';
  String loginEmptyEmailMessage = 'Please enter your Email';
  String loginIncorrectRegexEmailMessage = 'Email do not match regex';
  String loginMediumEmailMessage = 'Medium password';
  String loginEmptyPasswordMessage = 'Please enter your password';
  String loginIncorrectRegexPasswordMessage = 'Password do not match regex';
  String loginWeakPasswordMessage = 'password do not match regex';
  String loginMediumPasswordMessage = 'Medium password';
  String passwordObscureCharacter = '*';
  String apiKey = '08bfbbb0c32105a13648319d36145f24';

  /// Project Details Screen
  String domainText = "Domain";
  String objectiveText = "Objective";
  String summaryText = "Summary";
  String commentsText = "Comments";
  String functionalityText = "Functionality";
  String startDateText = "Start Date";
  String endDateText = "End Date";
  String statusText = "Status";
  String platformText = "Platform";
  String technologyText = "Technology";
  String knownIssueText = "Known Issue";
  String riskFactorText = "Risk factor";
  String dependenciesText = "Dependencies";
  String clientsNameText = "Client's Name";
  String feedbackText = "Feedback";
  String projectResourceText = "Resources Details";
  String projectResourceEmailText = "Resources Email";
  String projectDesignationText = "Resources Designation";
  String basicDetailsText = "Basic Details";
  String technicalInfoText = "Technical Info";
  String additionalDetailsText = "Additional Details";
  String submittedDateText = "Submitted Date";
  String receivedDateText = "Received Date";
  String resourceDetail = 'Resource Details';
  String readMore = ' Read more';
  String basicDetailsTileText = "Basic Details";
  String technicalInfoTileText = "Technical Info";
  String additionalDetailsTileText = "Additional Details";
  String idText = "ID";
  String managementMethodologyText = "Management Methodology";
  String projectCostText = "Project Cost/Budget (Optional)";
  String projectTreasureText = "Project Treasure";
  String showMoreText = "Show More";
  String showLessText = "Show Less";

  String loginSuccessToastMessage = "Logged in Successful";
  String dataSavedSuccessfullyToastMessage = "Data saved to draft";
  String loginFailedToastMessage = "Login failed";

  ///Filter Screen
  String filterTitle = "Filter";
  String clearFiltersText = "Clear filters";
  String applyText = "Apply";
  String selectedDatesFilterKey = "SelectedDates";
  String selectedStartDateFilterKey = "SelectedStartDate";
  String selectedEndDateFilterKey = "SelectedEndDate";
  String selectedStatusFiltersKey = "SelectedStatus";
  String selectedProjectsFiltersKey = "SelectedProjects";
  String selectedResourcesFiltersKey = "SelectedResources";
  String selectedPlatformsFiltersKey = "SelectedPlatforms";
  String selectedTechnologiesFiltersKey = "SelectedTechnologies";
  String selectedFunctionalitiesFiltersKey = "SelectedFunctionalities";
  String selectedDomainsFiltersKey = "SelectedDomains";
  String selectedDocsFiltersKeyText = "SelectedDocs";
  String applyFiltersForProjectsKeyText = "ApplyFiltersForProjects";

  String fileIsUploadString = "Documents are uploaded";
  String proposalSelectedDatesFilterKey = "ProposalSelectedDates";
  String proposalSelectedStartDateFilterKey = "ProposalSelectedStartDate";
  String proposalSelectedEndDateFilterKey = "ProposalSelectedEndDate";
  String proposalSelectedStatusFiltersKey = "ProposalSelectedStatus";
  String selectedProposalsFiltersKey = "SelectedProposals";
  String proposalSelectedResourcesFiltersKey = "ProposalSelectedResources";
  String proposalSelectedPlatformsFiltersKey = "ProposalSelectedPlatforms";
  String proposalSelectedTechnologiesFiltersKey =
      "ProposalSelectedTechnologies";
  String proposalSelectedFunctionalitiesFiltersKey =
      "ProposalSelectedFunctionalities";
  String proposalSelectedDomainsFiltersKey = "ProposalSelectedDomains";
  String proposalSelectedDocsFiltersKeyText = "ProposalSelectedDocs";
  String isProposalsFiltersApplied = "ProposalsFiltersApplied";
  String proposalFiltersToApplyKey = "ProposalFiltersToApply";
  String applyFiltersForProposalsKeyText = "ApplyFiltersForProposals";

  String isProjectsFiltersApplied = "FiltersApplied";
  String filtersToApplyKey = "FiltersToApply";
  String filterCountKeyText = "FilterCount";
  String searchProjectsText = "Search projects";
  String searchProposalsText = "Search proposals";
  String searchResourcesText = "Search resources";

  ///Create Project/Proposal Screen
  String createProjectAppbarTitle = 'Create project';
  String createProposalAppbarTitle = 'Create proposal';
  String progressIndicatorTitle_1 = '1';
  String progressIndicatorTitle_2 = '2';
  String progressIndicatorTitle_3 = '3';
  String basicDetailsHeading =
      'Start creating project by filling up the details under the below sections:';
  String proposalBasicDetailsHeading =
      'Start creating proposal by filling up the details under the below sections:';
  String basicDetailsButton = 'Basic Details';
  String technicalInfoButton = 'Technical info';
  String additionalDetailsButton = 'Additional Details (Optional)';
  String reviewButton = 'Review';
  String createProjectButton = 'Create Project';
  String createProposalButton = 'Create Proposal';
  String editFromDraftsToastMessage = 'Edit through Drafts';

  ///Basic Project Detail Screen
  String basicDetailTitle = 'Basic details';
  String dropDownItemEntertainment = 'Entertainment';
  String dropDownItemEducation = 'Education';
  String dropDownItemSocial = 'Social';
  String dropDownItemGovernment = 'Government';
  String dropDownItemHealthCare = 'Health Care';
  String dropDownItemSecurity = 'Security';
  String dropDownItemTelecom = 'Telecom';
  String dropDownItemFinance = 'Finance';
  String dropDownItemEcommerce = 'E-Commerce';
  String dropDownItemInsurance = 'Insurance';
  String dropDownItemGaming = 'Gaming';
  String dropDownItemTravel = 'Travel';
  String dropDownItemAdvertisement = 'Advertisement';
  String dropDownItemIncomplete = 'Incomplete';
  String dropDownItemInProgress = 'In progress';
  String dropDownItemOnHold = 'On hold';
  String dropDownItemOverdue = 'Overdue';
  String dropDownItemNotStarted = 'Not started';
  String dropDownItemCancelled = 'Cancelled';
  String dropDownItemSubmitted = 'Submitted';
  String dropDownItemApproved = 'Approved';
  String saveDraftAppbarTitle = 'Save draft';
  String projectIDTitle = 'Project ID - ';
  String proposalIDTitle = 'Proposal ID - ';
  String projectNameTitle = 'Project Name - ';
  String proposalNameTitle = 'Proposal Name - ';
  String projectID = '0123456789';
  String textFieldProjectName = 'Project name';
  String textFieldDomain = 'Domain';
  String textFieldObjectives = 'Objectives (Optional)';
  String textFieldProjectSummary = 'Project Summary';
  String textFieldFunctionality = 'Functionality';
  String textFieldStartDate = 'Start date';
  String textFieldEndDate = 'End Date (Optional)';
  String textFieldProjectStatus = 'Project Status';
  String nextButton = 'Next';
  String projectNameEmptyTextFieldMessage = 'Please enter Project name';
  String projectSummeryEmptyTextFieldMessage = 'Please enter Project summery';
  String projectStartDateEmptyTextFieldMessage =
      'Please select project Start Date';
  String projectEndDateEmptyTextFieldMessage = 'Please select project End Date';
  String multiDialogCancelButtonTitle = 'Cancel';
  String multiDialogSaveButtonTitle = 'Save';
  String dateFormat = '1900-01-01';
  String toastMessageStorage = 'Cannot Access storage';
  String toastMessageStorageSetting = 'Open App Settings';
  String dialogDraftTitle = 'Save Draft?';
  String dialogBasicDraftDiscription =
      'Basic details not stored in draft.\nAre you sure you want to exit';
  String dialogDraftPositiveButton = 'No';
  String dialogDraftNegativeButton = 'Yes';
  String fileIsUpload = 'file is Uploaded';
  String creatingProject = ' Creating Project';
  String creatingProposal = ' Creating Proposal';

  ///Technical Project Detail Screen
  String technicalInfoTitle = 'Technical Information';
  String textFieldPlatform = 'Platform';
  String dialogPlatformTitle = 'Select Platform';
  String dialogFunctionalitiesTitle = 'Select Functionalities';
  String textFieldTechnology = 'Technology';
  String dialogTechnologyTitle = 'Select Technology';
  String textFieldRiskFactor = 'Risk Factor (Optional)';
  String proposalRiskFactor = 'Risk Factor';
  String textFieldKnownIssues = 'Known Issues (Optional)';
  String textFieldProjectManagementMethodology =
      'Project management methodology';
  String textFieldDependencies = 'Dependencies (Optional)';
  String previousButton = 'Previous';
  String dialogTechnicalDraftDiscription =
      'Technical details not stored in draft.\nAre you sure you want to exit';

  ///Additional Project Detail Screen
  String additionalDetailTitle = 'Additional Details (Optional)';
  String clientDetails = 'Client details';
  String textFieldClientName = 'Client Name';
  String textFieldCurrency = 'Currency';
  String textFieldProjectBudget = 'Cost/Budget';
  String textFieldLocation = 'Location';
  String resourceDetails = 'Resource Details';
  String textFieldResourceName = 'Name';
  String textFieldResourceDesignation = 'Designation';
  String textFieldResourceEmailAddress = 'Email address';
  String otherDetails = 'Other Details';
  String textFieldComments = 'Comment';
  String textFieldProjectFeedback = 'Project feedback';
  String textFieldProposalFeedback = 'Proposal feedback';
  String dialogAdditionalDraftDiscription =
      'Additional details not stored in draft.\nAre you sure you want to exit';

  ///Platform Items
  String platformMobile = 'Mobile';
  String platformWeb = 'Web';
  String platformWindows = 'Windows';
  String platformCloud = 'Cloud';
  String platformMac = 'Mac';

  ///Technology Items
  String technologyInformationTechnology = 'Information Technology';
  String technologyOperationalTechnology = 'Operational technology';

  ///Basic detail Review Screen
  String projectDomain = 'Project domain';
  String proposalDomain = 'Proposal domain';
  String domain = 'Cloud & Information Security Domain for IT Trending.';
  String projectObjective = 'Project Objective';
  String proposalObjective = 'Proposal Objective';
  String objective = 'Cloud & Information Security Domain for IT Trending.';
  String projectSummary = 'Project Summary';
  String proposalSummary = 'Proposal Summary';
  String summary =
      'A mobile application to capture & consolidate information of the projects done in a centralised space.';
  String projectFunctionality = 'Project Functionality';
  String proposalFunctionality = 'Proposal Functionality';
  String functionality = 'Scanning, firebase';
  String projectStartDate = 'Project start date';
  String proposalStartDate = 'Proposal Received Date';
  String startDate = '14 Sep 2023';
  String projectEndDate = 'Project end date';
  String proposalEndDate = 'proposal Submitted date';
  String endDate = 'Present';
  String projectStatus = 'Project status';
  String proposalStatus = 'Proposal status';
  String status = 'In progress';
  String firstDate = '1900-01-01';

  ///Technical information Review Screen
  String technicalInfo = 'Technical info';
  String projectPlatform = 'Platform';
  String platform = 'Mobile app';
  String projectTechnology = 'Technology';
  String technology = '• Information technology \n• Operation technology';
  String projectManagementMethodology = 'Project management methodology';
  String managementMethodology = 'Agile methodology';
  String projectDependencies = 'Dependencies';
  String dependencies = 'This is a multiline space to keep the input data.';

  ///Additional detail Review screen
  String additionalDetails = 'Additional details';
  String projectClientName = 'Client(s) name';
  String clientName = 'John Doe';
  String projectCost = 'Project cost/budget (optional)';
  String proposalCost = 'Proposal cost/budget (optional)';
  String currency = '₹';
  String projectLocation = 'Location';
  String location = 'India';
  String createProjectSaveDraft = 'Project Not Saved';
  String createProposalSaveDraft = 'proposal Not Saved';
  String incorrectCredential = 'Incorrect Credentials';

  ///Resource detail screen
  String resourceDetailTitle = 'Resource Details';
  String addResourceButtonTitle = 'Add';

  ///Currency
  String rupee = '₹ rupee';
  String dollar = '\$ dollar';
  String euros = '€ euros';

  ///Location
  String india = 'India';
  String us = 'US';
  String europe = 'Europe';

  ///FlushBar
  String view = 'View';
  String projectCreatedMessage = 'Your Project has been created.';
  String proposalCreatedMessage = 'Your Proposal has been created.';

  ///Create project dialog
  String dialogTitle = 'Attachment reminder';
  String dialogTitleDoc = 'Alert';
  String dialogTitleLog = 'Alert';
  String dialogDiscriptionLogOut = "Are you sure you want to logout? ";
  String dialogDiscription =
      "No documents have been attached to this project. Do you want to create project without documents?";
  String positiveButton = "Attach documents";
  String cancelButton = "Cancel";
  String negativeButton = "Create anyway";
  String logOutButton = "Logout";
  String basicDetailsUploadButton = 'Upload';
  String basicDetailsButtonOneDriveText = 'One Drive';
  String basicDetailsButtonThisDeviceText = 'This Device';
  String basicDetailsUploadFrom = 'Upload from';
  String documentAttachText = 'Documents attached';
  String projectDocumentText = 'Document attached';
  String yourAttachmentsText = 'Your Attachments';
  String extensionText = 'extension';
  String xlsxText = 'xlsx';
  String xlsbText = 'xlsb';
  String pptText = 'ppt';
  String pdfText = 'pdf';
  String docText = 'doc';
  String sizeText = 'size';
  String pathText = 'path';
  String nameText = 'name';

  ///Basic Proposal Detail
  String textFieldProposalName = 'Proposal name';
  String textFieldProposalObjective = 'Objectives (Optional)';
  String textFieldProposalStartDate = 'Received date';
  String textFieldProposalEndDate = 'Submitted Date (Optional)';
  String textFieldProposalSummary = 'Proposal Summary';
  String textFieldProposalStatus = 'Proposal Status';

  ///Resource Designation
  String projectManager = 'Project manager';
  String projectLead = 'Project Lead';
  String architecture = 'Architecture';
  String bA = 'BA';
  String scrumMaster = 'Scrum master';
  String developer = 'Developer';
  String qA = 'QA resources';
  String uIDesigner = 'UI designer';

  ///Draft Screen
  String draftScreenAppBarTitle = 'Draft_Screen';

  /// Home Screen
  String bottomNavigationItemProjects = 'Projects';
  String bottomNavigationItemProposals = 'Proposals';
  String bottomNavigationItemMore = 'More';

  /// Project Details Screen

  ///Resource detail screen
  String resourceDetailAddButtonTitle = 'Add';

  ///FlushBar
  String flushBarMessage = 'Your Project has been created.';
  String dialogDiscriptionDoc =
      " On cancel you will loose your files, are you sure to cancel the file upload?";
  String positiveButtonSave = "Cancel";
  String negativeButtonCancel = "File attach";
  String negativeButtonLogout = "Logout";
  String basicDetailsButtonTitle = 'Login';
  String documentText = 'Documents';

  ///Profile Screen
  String profileAppBarTitle = 'Profile';
}
