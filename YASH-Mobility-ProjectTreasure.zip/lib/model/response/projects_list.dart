class ProjectsMetaPagination {
  int? page;
  int? pageSize;
  int? pageCount;
  int? total;

  ProjectsMetaPagination({
    this.page,
    this.pageSize,
    this.pageCount,
    this.total,
  });
  ProjectsMetaPagination.fromJson(Map<String, dynamic> json) {
    page = json['page']?.toInt();
    pageSize = json['pageSize']?.toInt();
    pageCount = json['pageCount']?.toInt();
    total = json['total']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['pageCount'] = pageCount;
    data['total'] = total;
    return data;
  }
}

class ProjectsMeta {
  ProjectsMetaPagination? pagination;

  ProjectsMeta({
    this.pagination,
  });
  ProjectsMeta.fromJson(Map<String, dynamic> json) {
    pagination = (json['pagination'] != null)
        ? ProjectsMetaPagination.fromJson(json['pagination'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesMethodologyDataAttributes {
  String? name;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  ProjectsDataAttributesMethodologyDataAttributes({
    this.name,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  ProjectsDataAttributesMethodologyDataAttributes.fromJson(
      Map<String, dynamic> json) {
    name = json['name']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['name'] = name;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class ProjectsDataAttributesMethodologyData {
  int? id;
  ProjectsDataAttributesMethodologyDataAttributes? attributes;

  ProjectsDataAttributesMethodologyData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesMethodologyData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesMethodologyDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesMethodology {
  ProjectsDataAttributesMethodologyData? data;

  ProjectsDataAttributesMethodology({
    this.data,
  });
  ProjectsDataAttributesMethodology.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? ProjectsDataAttributesMethodologyData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesStatusDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProjectsDataAttributesStatusDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProjectsDataAttributesStatusDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProjectsDataAttributesStatusData {
  int? id;
  ProjectsDataAttributesStatusDataAttributes? attributes;

  ProjectsDataAttributesStatusData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesStatusData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesStatusDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesStatus {
  ProjectsDataAttributesStatusData? data;

  ProjectsDataAttributesStatus({
    this.data,
  });
  ProjectsDataAttributesStatus.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? ProjectsDataAttributesStatusData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesFunctionalitiesDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProjectsDataAttributesFunctionalitiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProjectsDataAttributesFunctionalitiesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProjectsDataAttributesFunctionalitiesData {
  int? id;
  ProjectsDataAttributesFunctionalitiesDataAttributes? attributes;

  ProjectsDataAttributesFunctionalitiesData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesFunctionalitiesData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesFunctionalitiesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesFunctionalities {
  List<ProjectsDataAttributesFunctionalitiesData?>? data;

  ProjectsDataAttributesFunctionalities({
    this.data,
  });
  ProjectsDataAttributesFunctionalities.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProjectsDataAttributesFunctionalitiesData>[];
      v.forEach((v) {
        arr0.add(ProjectsDataAttributesFunctionalitiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProjectsDataAttributesResourcesDataAttributes {
  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  ProjectsDataAttributesResourcesDataAttributes({
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  ProjectsDataAttributesResourcesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class ProjectsDataAttributesResourcesData {
  int? id;
  ProjectsDataAttributesResourcesDataAttributes? attributes;

  ProjectsDataAttributesResourcesData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesResourcesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesResourcesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesResources {
  List<ProjectsDataAttributesResourcesData?>? data;

  ProjectsDataAttributesResources({
    this.data,
  });
  ProjectsDataAttributesResources.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProjectsDataAttributesResourcesData>[];
      v.forEach((v) {
        arr0.add(ProjectsDataAttributesResourcesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProjectsDataAttributesPlatformsDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProjectsDataAttributesPlatformsDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProjectsDataAttributesPlatformsDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProjectsDataAttributesPlatformsData {
  int? id;
  ProjectsDataAttributesPlatformsDataAttributes? attributes;

  ProjectsDataAttributesPlatformsData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesPlatformsData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesPlatformsDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesPlatforms {
  List<ProjectsDataAttributesPlatformsData?>? data;

  ProjectsDataAttributesPlatforms({
    this.data,
  });
  ProjectsDataAttributesPlatforms.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProjectsDataAttributesPlatformsData>[];
      v.forEach((v) {
        arr0.add(ProjectsDataAttributesPlatformsData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProjectsDataAttributesDomainDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProjectsDataAttributesDomainDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProjectsDataAttributesDomainDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProjectsDataAttributesDomainData {
  int? id;
  ProjectsDataAttributesDomainDataAttributes? attributes;

  ProjectsDataAttributesDomainData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesDomainData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesDomainDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesDomain {
  ProjectsDataAttributesDomainData? data;

  ProjectsDataAttributesDomain({
    this.data,
  });
  ProjectsDataAttributesDomain.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? ProjectsDataAttributesDomainData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesTechnologiesDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProjectsDataAttributesTechnologiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProjectsDataAttributesTechnologiesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProjectsDataAttributesTechnologiesData {
  int? id;
  ProjectsDataAttributesTechnologiesDataAttributes? attributes;

  ProjectsDataAttributesTechnologiesData({
    this.id,
    this.attributes,
  });
  ProjectsDataAttributesTechnologiesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributesTechnologiesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProjectsDataAttributesTechnologies {
  List<ProjectsDataAttributesTechnologiesData?>? data;

  ProjectsDataAttributesTechnologies({
    this.data,
  });
  ProjectsDataAttributesTechnologies.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProjectsDataAttributesTechnologiesData>[];
      v.forEach((v) {
        arr0.add(ProjectsDataAttributesTechnologiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProjectsDataAttributesDocumentsConnect {
  String? id;

  ProjectsDataAttributesDocumentsConnect({
    this.id,
  });
  ProjectsDataAttributesDocumentsConnect.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}

class ProjectsDataAttributesDocuments {
  List<ProjectsDataAttributesDocumentsConnect?>? connect;

  ProjectsDataAttributesDocuments({
    this.connect,
  });
  ProjectsDataAttributesDocuments.fromJson(Map<String, dynamic> json) {
    if (json['connect'] != null) {
      final v = json['connect'];
      final arr0 = <ProjectsDataAttributesDocumentsConnect>[];
      v.forEach((v) {
        arr0.add(ProjectsDataAttributesDocumentsConnect.fromJson(v));
      });
      connect = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (connect != null) {
      final v = connect;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['connect'] = arr0;
    }
    return data;
  }
}

class ProjectsDataAttributes {
  String? objectives;
  String? startDate;
  String? endDate;
  String? clientName;
  String? budget;
  String? knownIssues;
  String? dependencies;
  String? comments;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  ProjectsDataAttributesDocuments? documents;
  String? feedback;
  String? name;
  String? summary;
  String? currency;
  String? location;
  String? riskFactor;
  ProjectsDataAttributesTechnologies? technologies;
  ProjectsDataAttributesDomain? domain;
  ProjectsDataAttributesPlatforms? platforms;
  ProjectsDataAttributesResources? resources;
  ProjectsDataAttributesFunctionalities? functionalities;
  ProjectsDataAttributesStatus? status;
  ProjectsDataAttributesMethodology? methodology;

  ProjectsDataAttributes({
    this.objectives,
    this.startDate,
    this.endDate,
    this.clientName,
    this.budget,
    this.knownIssues,
    this.dependencies,
    this.comments,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.documents,
    this.feedback,
    this.name,
    this.summary,
    this.currency,
    this.location,
    this.riskFactor,
    this.technologies,
    this.domain,
    this.platforms,
    this.resources,
    this.functionalities,
    this.status,
    this.methodology,
  });
  ProjectsDataAttributes.fromJson(Map<String, dynamic> json) {
    objectives = json['objectives']?.toString();
    startDate = json['start_date']?.toString();
    endDate = json['end_date']?.toString();
    clientName = json['client_name']?.toString();
    budget = json['budget']?.toString();
    knownIssues = json['known_issues']?.toString();
    dependencies = json['dependencies']?.toString();
    comments = json['comments']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    documents = (json['documents'] != null)
        ? ProjectsDataAttributesDocuments.fromJson(json['documents'])
        : null;
    feedback = json['feedback']?.toString();
    name = json['name']?.toString();
    summary = json['summary']?.toString();
    currency = json['currency']?.toString();
    location = json['location']?.toString();
    riskFactor = json['risk_factor']?.toString();
    technologies = (json['technologies'] != null)
        ? ProjectsDataAttributesTechnologies.fromJson(json['technologies'])
        : null;
    domain = (json['domain'] != null)
        ? ProjectsDataAttributesDomain.fromJson(json['domain'])
        : null;
    platforms = (json['platforms'] != null)
        ? ProjectsDataAttributesPlatforms.fromJson(json['platforms'])
        : null;
    resources = (json['resources'] != null)
        ? ProjectsDataAttributesResources.fromJson(json['resources'])
        : null;
    functionalities = (json['functionalities'] != null)
        ? ProjectsDataAttributesFunctionalities.fromJson(
            json['functionalities'])
        : null;
    status = (json['status'] != null)
        ? ProjectsDataAttributesStatus.fromJson(json['status'])
        : null;
    methodology = (json['methodology'] != null)
        ? ProjectsDataAttributesMethodology.fromJson(json['methodology'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['objectives'] = objectives;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['client_name'] = clientName;
    data['budget'] = budget;
    data['known_issues'] = knownIssues;
    data['dependencies'] = dependencies;
    data['comments'] = comments;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    if (documents != null) {
      data['documents'] = documents!.toJson();
    }
    data['feedback'] = feedback;
    data['name'] = name;
    data['summary'] = summary;
    data['currency'] = currency;
    data['location'] = location;
    data['risk_factor'] = riskFactor;
    if (technologies != null) {
      data['technologies'] = technologies!.toJson();
    }
    if (domain != null) {
      data['domain'] = domain!.toJson();
    }
    if (platforms != null) {
      data['platforms'] = platforms!.toJson();
    }
    if (resources != null) {
      data['resources'] = resources!.toJson();
    }
    if (functionalities != null) {
      data['functionalities'] = functionalities!.toJson();
    }
    if (status != null) {
      data['status'] = status!.toJson();
    }
    if (methodology != null) {
      data['methodology'] = methodology!.toJson();
    }
    return data;
  }
}

class ProjectsData {
  int? id;
  ProjectsDataAttributes? attributes;

  ProjectsData({
    this.id,
    this.attributes,
  });
  ProjectsData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? ProjectsDataAttributes.fromJson(json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class Projects {
  List<ProjectsData?>? data;
  ProjectsMeta? meta;

  Projects({
    this.data,
    this.meta,
  });
  Projects.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProjectsData>[];
      v.forEach((v) {
        arr0.add(ProjectsData.fromJson(v));
      });
      this.data = arr0;
    }
    meta = (json['meta'] != null) ? ProjectsMeta.fromJson(json['meta']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    if (meta != null) {
      data['meta'] = meta!.toJson();
    }
    return data;
  }
}
