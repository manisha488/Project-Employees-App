import 'package:flutter/material.dart';

class CustomButton extends StatefulWidget {
  final String title;
  final bool? loading;
  final Color? buttonColor;
  final double? height;
  final double? width;
  final double? borderRadius;
  final Color? circularIndicatorColor;
  final VoidCallback onPress;
  final TextStyle textStyle;
  final double? elevation;
  final Gradient? gradient;
  final Color? borderColor;

  const CustomButton({
    Key? key,
    this.buttonColor,
    required this.title,
    this.height = 40,
    this.width = 200,
    this.borderRadius = 0,
    this.circularIndicatorColor,
    this.loading = false,
    required this.onPress,
    required this.textStyle,
    this.elevation = 0,
    this.gradient,
    this.borderColor,
  }) : super(key: key);

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    ///OnPress method
    return InkWell(
      onTap: widget.onPress,
      child: Material(
        ///Elevation
        elevation: widget.elevation!,
        borderRadius: BorderRadius.circular(widget.borderRadius!),
        child: Container(
          ///Height
          height: widget.height,

          ///Width
          width: widget.width,
          decoration: BoxDecoration(

              ///Gradient color
              gradient: widget.gradient,

              ///Button Color
              color: widget.buttonColor,

              ///Border radius
              borderRadius: BorderRadius.circular(widget.borderRadius!),
              border: Border.all(color: widget.borderColor ?? Colors.blue)),
          child: Center(
              child: widget.loading!
                  ? CircularProgressIndicator(
                      color: widget.circularIndicatorColor ?? Colors.blue,
                    )
                  : Text(widget.title, style: widget.textStyle)),
        ),
      ),
    );
  }
}
