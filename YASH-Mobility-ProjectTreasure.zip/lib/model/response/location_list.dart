
class LocationData {

  String? iso2;
  String? iso3;
  String? country;
  List<String?>? cities;

  LocationData({
    this.iso2,
    this.iso3,
    this.country,
    this.cities,
  });
  LocationData.fromJson(Map<String, dynamic> json) {
    iso2 = json['iso2']?.toString();
    iso3 = json['iso3']?.toString();
    country = json['country']?.toString();
    if (json['cities'] != null) {
      final v = json['cities'];
      final arr0 = <String>[];
      v.forEach((v) {
        arr0.add(v.toString());
      });
      cities = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['iso2'] = iso2;
    data['iso3'] = iso3;
    data['country'] = country;
    if (cities != null) {
      final v = cities;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v);
      });
      data['cities'] = arr0;
    }
    return data;
  }
}

class ProjectLocation {

  bool? error;
  String? msg;
  List<LocationData?>? data;

  ProjectLocation({
    this.error,
    this.msg,
    this.data,
  });
  ProjectLocation.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    msg = json['msg']?.toString();
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <LocationData>[];
      v.forEach((v) {
        arr0.add(LocationData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['error'] = error;
    data['msg'] = msg;
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}
