package com.yash.yash_mobility_project_treasure.yash_mobility_project_treasure

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
