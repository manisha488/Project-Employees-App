class SearchProjectPagination {
  int? page;
  int? pageSize;
  int? pageCount;
  int? total;

  SearchProjectPagination({
    this.page,
    this.pageSize,
    this.pageCount,
    this.total,
  });
  SearchProjectPagination.fromJson(Map<String, dynamic> json) {
    page = json['page']?.toInt();
    pageSize = json['pageSize']?.toInt();
    pageCount = json['pageCount']?.toInt();
    total = json['total']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['pageCount'] = pageCount;
    data['total'] = total;
    return data;
  }
}

class SearchProjectDataUpdatedBy {
  int? id;
  String? firstname;
  String? lastname;
  String? username;
  String? email;
  String? password;
  String? resetPasswordToken;
  String? registrationToken;
  bool? isActive;
  bool? blocked;
  String? preferedLanguage;
  String? createdAt;
  String? updatedAt;

  SearchProjectDataUpdatedBy({
    this.id,
    this.firstname,
    this.lastname,
    this.username,
    this.email,
    this.password,
    this.resetPasswordToken,
    this.registrationToken,
    this.isActive,
    this.blocked,
    this.preferedLanguage,
    this.createdAt,
    this.updatedAt,
  });
  SearchProjectDataUpdatedBy.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    firstname = json['firstname']?.toString();
    lastname = json['lastname']?.toString();
    username = json['username']?.toString();
    email = json['email']?.toString();
    password = json['password']?.toString();
    resetPasswordToken = json['resetPasswordToken']?.toString();
    registrationToken = json['registrationToken']?.toString();
    isActive = json['isActive'];
    blocked = json['blocked'];
    preferedLanguage = json['preferedLanguage']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['username'] = username;
    data['email'] = email;
    data['password'] = password;
    data['resetPasswordToken'] = resetPasswordToken;
    data['registrationToken'] = registrationToken;
    data['isActive'] = isActive;
    data['blocked'] = blocked;
    data['preferedLanguage'] = preferedLanguage;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class SearchProjectDataCreatedBy {
  int? id;
  String? firstname;
  String? lastname;
  String? username;
  String? email;
  String? password;
  String? resetPasswordToken;
  String? registrationToken;
  bool? isActive;
  bool? blocked;
  String? preferedLanguage;
  String? createdAt;
  String? updatedAt;

  SearchProjectDataCreatedBy({
    this.id,
    this.firstname,
    this.lastname,
    this.username,
    this.email,
    this.password,
    this.resetPasswordToken,
    this.registrationToken,
    this.isActive,
    this.blocked,
    this.preferedLanguage,
    this.createdAt,
    this.updatedAt,
  });
  SearchProjectDataCreatedBy.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    firstname = json['firstname']?.toString();
    lastname = json['lastname']?.toString();
    username = json['username']?.toString();
    email = json['email']?.toString();
    password = json['password']?.toString();
    resetPasswordToken = json['resetPasswordToken']?.toString();
    registrationToken = json['registrationToken']?.toString();
    isActive = json['isActive'];
    blocked = json['blocked'];
    preferedLanguage = json['preferedLanguage']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['username'] = username;
    data['email'] = email;
    data['password'] = password;
    data['resetPasswordToken'] = resetPasswordToken;
    data['registrationToken'] = registrationToken;
    data['isActive'] = isActive;
    data['blocked'] = blocked;
    data['preferedLanguage'] = preferedLanguage;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class SearchProjectDataStatus {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  SearchProjectDataStatus({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  SearchProjectDataStatus.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class SearchProjectDataResources {
  int? id;
  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  SearchProjectDataResources({
    this.id,
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  SearchProjectDataResources.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class SearchProjectDataPlatforms {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  SearchProjectDataPlatforms({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  SearchProjectDataPlatforms.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class SearchProjectDataDomain {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  SearchProjectDataDomain({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  SearchProjectDataDomain.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class SearchProjectDataTechnologies {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  SearchProjectDataTechnologies({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  SearchProjectDataTechnologies.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class SearchProjectData {
  int? id;
  String? objectives;
  String? startDate;
  String? endDate;
  String? clientName;
  String? budget;
  String? knownIssues;
  String? dependencies;
  String? comments;
  String? currency;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? documents;
  String? feedback;
  String? name;
  String? summary;
  List<SearchProjectDataTechnologies?>? technologies;
  SearchProjectDataDomain? domain;
  List<SearchProjectDataPlatforms?>? platforms;
  List<SearchProjectDataResources?>? resources;
  List<SearchProjectDataFunctionalities>? functionalities;
  SearchProjectDataStatus? status;
  SearchProjectDataCreatedBy? createdBy;
  SearchProjectDataUpdatedBy? updatedBy;

  SearchProjectData({
    this.id,
    this.objectives,
    this.startDate,
    this.endDate,
    this.clientName,
    this.budget,
    this.knownIssues,
    this.dependencies,
    this.comments,
    this.currency,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.documents,
    this.feedback,
    this.name,
    this.summary,
    this.technologies,
    this.domain,
    this.platforms,
    this.resources,
    this.functionalities,
    this.status,
    this.createdBy,
    this.updatedBy,
  });
  SearchProjectData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    objectives = json['objectives']?.toString();
    startDate = json['start_date']?.toString();
    endDate = json['end_date']?.toString();
    clientName = json['client_name']?.toString();
    budget = json['budget']?.toString();
    knownIssues = json['known_issues']?.toString();
    dependencies = json['dependencies']?.toString();
    comments = json['comments']?.toString();
    currency = json['currency']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    documents = json['documents']?.toString();
    feedback = json['feedback']?.toString();
    name = json['name']?.toString();
    summary = json['summary']?.toString();
    if (json['technologies'] != null) {
      final v = json['technologies'];
      final arr0 = <SearchProjectDataTechnologies>[];
      v.forEach((v) {
        arr0.add(SearchProjectDataTechnologies.fromJson(v));
      });
      technologies = arr0;
    }
    domain = (json['domain'] != null)
        ? SearchProjectDataDomain.fromJson(json['domain'])
        : null;
    if (json['platforms'] != null) {
      final v = json['platforms'];
      final arr0 = <SearchProjectDataPlatforms>[];
      v.forEach((v) {
        arr0.add(SearchProjectDataPlatforms.fromJson(v));
      });
      platforms = arr0;
    }
    if (json['resources'] != null) {
      final v = json['resources'];
      final arr0 = <SearchProjectDataResources>[];
      v.forEach((v) {
        arr0.add(SearchProjectDataResources.fromJson(v));
      });
      resources = arr0;
    }

    status = (json['status'] != null)
        ? SearchProjectDataStatus.fromJson(json['status'])
        : null;
    createdBy = (json['createdBy'] != null)
        ? SearchProjectDataCreatedBy.fromJson(json['createdBy'])
        : null;
    updatedBy = (json['updatedBy'] != null)
        ? SearchProjectDataUpdatedBy.fromJson(json['updatedBy'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['objectives'] = objectives;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['client_name'] = clientName;
    data['budget'] = budget;
    data['known_issues'] = knownIssues;
    data['dependencies'] = dependencies;
    data['comments'] = comments;
    data['currency'] = currency;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['documents'] = documents;
    data['feedback'] = feedback;
    data['name'] = name;
    data['summary'] = summary;
    if (technologies != null) {
      final v = technologies;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['technologies'] = arr0;
    }
    if (domain != null) {
      data['domain'] = domain!.toJson();
    }
    if (platforms != null) {
      final v = platforms;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['platforms'] = arr0;
    }
    if (resources != null) {
      final v = resources;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['resources'] = arr0;
    }
    if (status != null) {
      data['status'] = status!.toJson();
    }
    if (createdBy != null) {
      data['createdBy'] = createdBy!.toJson();
    }
    if (updatedBy != null) {
      data['updatedBy'] = updatedBy!.toJson();
    }
    return data;
  }
}

class SearchProjectDataFunctionalities {}

class SearchProject {
  List<SearchProjectData?>? data;
  SearchProjectPagination? pagination;

  SearchProject({
    this.data,
    this.pagination,
  });
  SearchProject.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <SearchProjectData>[];
      v.forEach((v) {
        arr0.add(SearchProjectData.fromJson(v));
      });
      this.data = arr0;
    }
    pagination = (json['pagination'] != null)
        ? SearchProjectPagination.fromJson(json['pagination'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    return data;
  }
}
