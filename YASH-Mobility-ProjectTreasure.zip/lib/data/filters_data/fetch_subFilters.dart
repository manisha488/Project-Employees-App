import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';

class FetchPlatformFilter {
  static Future<List<DummyMultiselectFilters>> fetchPlatformFilters() async {
    final dummyFilters = [
      DummyMultiselectFilters('Web'),
      DummyMultiselectFilters('Mac'),
      DummyMultiselectFilters('Mobile'),
      DummyMultiselectFilters('Windows'),
      DummyMultiselectFilters('Cloud'),
    ];
    return dummyFilters;
  }

  static Future<List<DummyMultiselectFilters>> fetchStatusFilters() async {
    final dummyFilters = [
      DummyMultiselectFilters('Completed'),
      DummyMultiselectFilters('Declined'),
      DummyMultiselectFilters('In progress'),
      DummyMultiselectFilters('On hold'),
      DummyMultiselectFilters('Cancelled'),
    ];
    return dummyFilters;
  }

  static Future<List<DummyMultiselectFilters>>
      fetchProjectNamesFilters() async {
    final dummyFilters = [
      DummyMultiselectFilters('Onco'),
      DummyMultiselectFilters('Caremed'),
      DummyMultiselectFilters('Funding express'),
      DummyMultiselectFilters('Storage'),
      DummyMultiselectFilters('Cloud'),
    ];
    return dummyFilters;
  }

  static Future<List<DummyMultiselectFilters>>
      fetchFunctionalityFilters() async {
    final dummyFilters = [
      DummyMultiselectFilters('GPS'),
      DummyMultiselectFilters('Messaging'),
      DummyMultiselectFilters('Payment Gateway'),
      DummyMultiselectFilters('Storage'),
      DummyMultiselectFilters('Cloud'),
    ];
    return dummyFilters;
  }

  static Future<List<DummyMultiselectFilters>>
      fetchResourcesNamesFilters() async {
    final dummyFilters = [
      DummyMultiselectFilters('Ashlesha'),
      DummyMultiselectFilters('Manisha'),
      DummyMultiselectFilters('Anuja'),
      DummyMultiselectFilters('Sayli'),
      DummyMultiselectFilters('Puja'),
    ];
    return dummyFilters;
  }

  static Future<List<DummyMultiselectFilters>> fetchDocumentFilters() async {
    final dummyFilters = [
      DummyMultiselectFilters('Yes'),
      DummyMultiselectFilters('No')
    ];
    return dummyFilters;
  }
}
