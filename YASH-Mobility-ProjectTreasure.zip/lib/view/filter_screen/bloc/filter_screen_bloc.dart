import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/data/filters_data/fetch_all_filters.dart';
import 'package:yash_mobility_project_treasure/data/filters_data/fetch_subFilters.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/all_filters.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/model/response/proposals_list.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';

part 'filter_screen_event.dart';
part 'filter_screen_state.dart';

class FilterScreenBloc extends Bloc<FilterScreenEvent, FilterScreenState> {
  FilterScreenBloc() : super(FilterScreenInitial()) {
    on<FilterScreenEvent>((event, emit) {});
    on<FilterScreenInitialEvent>(filterScreenInitialEvent);
    on<ProposalFiltersLoadedEvent>(proposalFiltersLoadedEvent);
    on<SubFiltersTabClickedEvent>(subFiltersTabClickedEvent);
    on<ApplyFiltersClickedEvent>(applyFiltersClickedEvent);
    on<ApplyProposalsFiltersClickedEvent>(applyProposalsFiltersClickedEvent);
    on<ApplyButtonEnableEvent>(applyButtonEnableEvent);
    on<ApplyButtonEnableForProposalsEvent>(applyButtonEnableForProposalsEvent);
  }

  final db = CustomDataBaseWrapper();

  /// Event to load all main project filters on filter screen.
  FutureOr<void> filterScreenInitialEvent(
      FilterScreenInitialEvent event, Emitter<FilterScreenState> emit) async {
    List<AllFilters> filters = await FetchAllFilter.fetchProjectFilters();
    emit(ProjectsFiltersLoadedSuccessState(filters));
  }

  /// Event to load all main proposals filters on filter screen.
  FutureOr<void> proposalFiltersLoadedEvent(
      ProposalFiltersLoadedEvent event, Emitter<FilterScreenState> emit) async {
    List<AllFilters> filters = await FetchAllFilter.fetchProposalsFilters();
    emit(ProposalFiltersLoadedSuccessState(filters));
  }

  /// Event to load all sub filters on filter screen.
  FutureOr<void> subFiltersTabClickedEvent(
      SubFiltersTabClickedEvent event, Emitter<FilterScreenState> emit) async {
    List<DummyMultiselectFilters> platformFilters =
    await FetchPlatformFilter.fetchPlatformFilters();
    emit(FilterPlatformLoadedSuccessState(platformFilters));
  }

  /// Event to perform apply filters post API integration.
  FutureOr<void> applyFiltersClickedEvent(
      ApplyFiltersClickedEvent event, Emitter<FilterScreenState> emit) async {
    emit(ApplyButtonLoadingState());
    List<ProjectsData>? projects;
    await db.getProjectsList('projects').then((value) {
      projects = value;
    });
    final filteredProjects = projects!.where((project) {
      var projectName = false;
      var resourceName = false;
      var status = false;
      var tech = false;
      var platforms = false;
      var functionality = false;
      var domain = false;
      if (event.projectName != null) {
        event.projectName!.any((field) {
          return
            projectName = project.attributes!.name ==
                    field;
        });
      }
      final startDate = project.attributes!.startDate == event.startDate;
      final endDate = project.attributes!.endDate == event.endDate;
      if (event.projectStatus != null) {
        event.projectStatus!.any((field) { return
          status = project.attributes!.status!.data!.attributes!.name == field;
        });
      }
      if (event.technologies != null) {
        for (var i = 0; i <
            project.attributes!.technologies!.data!.length; i++) {
          event.technologies!.any((field) {
            return
              tech =
                  project.attributes!.technologies!.data![i]!.attributes!.name ==
                      field;
          });
        }
      }

      if (event.platform != null) {
        for (var i = 0; i <
            project.attributes!.platforms!.data!.length; i++) {
          event.platform!.any((field) {
            return
              platforms =
                  project.attributes!.platforms!.data![i]!.attributes!.name ==
                      field;
          });
        }
      }

      if (event.functionalities != null) {
        for (var i = 0; i <
            project.attributes!.functionalities!.data!.length; i++) {
          event.functionalities!.any((field) {
            return
              functionality =
                  project.attributes!.functionalities!.data![i]!.attributes!.name ==
                      field;
          });
        }
      }

      if (event.domain != null) {
        event.domain!.any((field) {
          return
            tech =
                project.attributes!.domain!.data!.attributes!.name ==
                    field;
        });
      }
      if (event.resourceName != null) {
        for (var i = 0; i <
            project.attributes!.resources!.data!.length; i++) {
          event.resourceName!.any((field) {
            return
              resourceName =
                  project.attributes!.resources!.data![i]!.attributes!.resourceName ==
                      field;
          });
        }
      }

      return  projectName || startDate || endDate || status || tech || functionality || platforms || domain || resourceName;
    }).toList();
    db.insertProjects(filteredProjects, "filteredProjects");
    emit(ApplyFiltersState(filteredProjects));

  }

  /// Event to handle apply filters button's UI.
  FutureOr<void> applyButtonEnableEvent(
      ApplyButtonEnableEvent event, Emitter<FilterScreenState> emit) {
    var filters =
        SharedPrefs.instance.getStringList(Strings().filtersToApplyKey) ?? [];

    if ((filters != [] && filters.isNotEmpty)) {
      emit(ApplyButtonEnabledState());
    } else if (filters == [] || filters.isEmpty) {
      SharedPrefs.instance
          .setBool(Strings().applyFiltersForProjectsKeyText, false);
      emit(ApplyButtonDisableState());
    }
  }

  FutureOr<void> applyButtonEnableForProposalsEvent(
      ApplyButtonEnableForProposalsEvent event,
      Emitter<FilterScreenState> emit) {
    var proposalFilters = SharedPrefs.instance
        .getStringList(Strings().proposalFiltersToApplyKey) ??
        [];
    if (proposalFilters != [] && proposalFilters.isNotEmpty) {
      emit(ApplyButtonEnableProposalState());
    } else if (proposalFilters == [] || proposalFilters.isEmpty) {
      SharedPrefs.instance
          .setBool(Strings().applyFiltersForProposalsKeyText, false);
      emit(ApplyButtonDisableProposalState());
    }
  }


  FutureOr<void> applyProposalsFiltersClickedEvent(
      ApplyProposalsFiltersClickedEvent event,
      Emitter<FilterScreenState> emit) async {
    emit(ApplyButtonLoadingState());
    List<ProposalsData>? proposals;
    await db.getProposalsList('proposals').then((value) {
      proposals = value;
    });
    final filteredProposals = proposals!.where((proposal) {
      var proposalName = false;
      var resourceName = false;
      var status = false;
      var tech = false;
      var platforms = false;
      var functionality = false;
      var domain = false;
      if (event.proposalName != null) {
        event.proposalName!.any((field) {
          return
            proposalName = proposal.attributes!.name ==
                field;
        });
        //proposalName = proposal.attributes!.name == event.proposalName ;
      }
      final startDate = proposal.attributes!.proposalReceivedDate == event.proposalReceivedDate;
      final endDate = proposal.attributes!.proposalSubmittedDate == event.proposalSubmittedDate;
      if (event.proposalStatus != null) {
        event.proposalStatus!.any((field) { return
          status = proposal.attributes!.status!.data!.attributes!.name == field;
        });
      }
      if (event.technologies != null) {
        for (var i = 0; i <
            proposal.attributes!.technologies!.data!.length; i++) {
          event.technologies!.any((field) {
            return
              tech =
                  proposal.attributes!.technologies!.data![i]!.attributes!.name ==
                      field;
          });
        }
      }

      if (event.platform != null) {
        for (var i = 0; i <
            proposal.attributes!.platforms!.data!.length; i++) {
          event.platform!.any((field) {
            return
              platforms =
                  proposal.attributes!.platforms!.data![i]!.attributes!.name ==
                      field;
          });
        }
      }

      if (event.functionalities != null) {
        for (var i = 0; i <
            proposal.attributes!.functionalities!.data!.length; i++) {
          event.functionalities!.any((field) {
            return
              functionality =
                  proposal.attributes!.functionalities!.data![i]!.attributes!.name ==
                      field;
          });
        }
      }

      if (event.domain != null) {
        event.domain!.any((field) {
          return
            tech =
                proposal.attributes!.domain!.data!.attributes!.name ==
                    field;
        });
      }
      if (event.resourceName != null) {
        for (var i = 0; i <
            proposal.attributes!.resources!.data!.length; i++) {
          event.resourceName!.any((field) {
            return
              resourceName =
                  proposal.attributes!.resources!.data![i]!.attributes!.resourceName ==
                      field;
          });
        }
      }

      return  proposalName || startDate || endDate || status || tech || functionality || platforms || domain || resourceName;
    }).toList();
    db.insertProposals(filteredProposals, "filteredProposals");
    emit(ApplyProposalFiltersState(filteredProposals));

  }
}
