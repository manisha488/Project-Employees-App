
class CreateProposalMeta {

  CreateProposalMeta({final meta});
  CreateProposalMeta.fromJson(Map<String, dynamic> json) {}
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    return data;
  }
}

class CreateProposalDataAttributesStatusDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProposalDataAttributesStatusDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProposalDataAttributesStatusDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProposalDataAttributesStatusData {

  int? id;
  CreateProposalDataAttributesStatusDataAttributes? attributes;

  CreateProposalDataAttributesStatusData({
    this.id,
    this.attributes,
  });
  CreateProposalDataAttributesStatusData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributesStatusDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesStatus {

  CreateProposalDataAttributesStatusData? data;

  CreateProposalDataAttributesStatus({
    this.data,
  });
  CreateProposalDataAttributesStatus.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProposalDataAttributesStatusData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesResourcesDataAttributes {

  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  CreateProposalDataAttributesResourcesDataAttributes({
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  CreateProposalDataAttributesResourcesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class CreateProposalDataAttributesResourcesData {

  int? id;
  CreateProposalDataAttributesResourcesDataAttributes? attributes;

  CreateProposalDataAttributesResourcesData({
    this.id,
    this.attributes,
  });
  CreateProposalDataAttributesResourcesData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributesResourcesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesResources {

  List<CreateProposalDataAttributesResourcesData?>? data;

  CreateProposalDataAttributesResources({
    this.data,
  });
  CreateProposalDataAttributesResources.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProposalDataAttributesResourcesData>[];
      v.forEach((v) {
        arr0.add(CreateProposalDataAttributesResourcesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProposalDataAttributesTechnologiesDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProposalDataAttributesTechnologiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProposalDataAttributesTechnologiesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProposalDataAttributesTechnologiesData {

  int? id;
  CreateProposalDataAttributesTechnologiesDataAttributes? attributes;

  CreateProposalDataAttributesTechnologiesData({
    this.id,
    this.attributes,
  });
  CreateProposalDataAttributesTechnologiesData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributesTechnologiesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesTechnologies {

  List<CreateProposalDataAttributesTechnologiesData?>? data;

  CreateProposalDataAttributesTechnologies({
    this.data,
  });
  CreateProposalDataAttributesTechnologies.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProposalDataAttributesTechnologiesData>[];
      v.forEach((v) {
        arr0.add(CreateProposalDataAttributesTechnologiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProposalDataAttributesPlatformsDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProposalDataAttributesPlatformsDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProposalDataAttributesPlatformsDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProposalDataAttributesPlatformsData {

  int? id;
  CreateProposalDataAttributesPlatformsDataAttributes? attributes;

  CreateProposalDataAttributesPlatformsData({
    this.id,
    this.attributes,
  });
  CreateProposalDataAttributesPlatformsData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributesPlatformsDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesPlatforms {

  List<CreateProposalDataAttributesPlatformsData?>? data;

  CreateProposalDataAttributesPlatforms({
    this.data,
  });
  CreateProposalDataAttributesPlatforms.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProposalDataAttributesPlatformsData>[];
      v.forEach((v) {
        arr0.add(CreateProposalDataAttributesPlatformsData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProposalDataAttributesFunctionalitiesDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProposalDataAttributesFunctionalitiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProposalDataAttributesFunctionalitiesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProposalDataAttributesFunctionalitiesData {

  int? id;
  CreateProposalDataAttributesFunctionalitiesDataAttributes? attributes;

  CreateProposalDataAttributesFunctionalitiesData({
    this.id,
    this.attributes,
  });
  CreateProposalDataAttributesFunctionalitiesData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributesFunctionalitiesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesFunctionalities {

  List<CreateProposalDataAttributesFunctionalitiesData?>? data;

  CreateProposalDataAttributesFunctionalities({
    this.data,
  });
  CreateProposalDataAttributesFunctionalities.fromJson(
      Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProposalDataAttributesFunctionalitiesData>[];
      v.forEach((v) {
        arr0.add(CreateProposalDataAttributesFunctionalitiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProposalDataAttributesDomainDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProposalDataAttributesDomainDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProposalDataAttributesDomainDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProposalDataAttributesDomainData {

  int? id;
  CreateProposalDataAttributesDomainDataAttributes? attributes;

  CreateProposalDataAttributesDomainData({
    this.id,
    this.attributes,
  });
  CreateProposalDataAttributesDomainData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributesDomainDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesDomain {

  CreateProposalDataAttributesDomainData? data;

  CreateProposalDataAttributesDomain({
    this.data,
  });
  CreateProposalDataAttributesDomain.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProposalDataAttributesDomainData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class CreateProposalDataAttributesDocumentsConnect {

  int? id;

  CreateProposalDataAttributesDocumentsConnect({
    this.id,
  });
  CreateProposalDataAttributesDocumentsConnect.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}

class CreateProposalDataAttributesDocuments {

  List<CreateProposalDataAttributesDocumentsConnect?>? connect;

  CreateProposalDataAttributesDocuments({
    this.connect,
  });
  CreateProposalDataAttributesDocuments.fromJson(Map<String, dynamic> json) {
    if (json['connect'] != null) {
      final v = json['connect'];
      final arr0 = <CreateProposalDataAttributesDocumentsConnect>[];
      v.forEach((v) {
        arr0.add(CreateProposalDataAttributesDocumentsConnect.fromJson(v));
      });
      connect = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (connect != null) {
      final v = connect;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['connect'] = arr0;
    }
    return data;
  }
}

class CreateProposalDataAttributes {

  String? proposalReceivedDate;
  String? proposalSubmittedDate;
  String? clientDetails;
  String? riskFactors;
  String? dependencies;
  CreateProposalDataAttributesDocuments? documents;
  String? feedback;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;
  String? objectives;
  String? summery;
  String? comments;
  String? location;
  String? currency;
  String? budget;
  CreateProposalDataAttributesDomain? domain;
  CreateProposalDataAttributesFunctionalities? functionalities;
  CreateProposalDataAttributesPlatforms? platforms;
  CreateProposalDataAttributesTechnologies? technologies;
  CreateProposalDataAttributesResources? resources;
  CreateProposalDataAttributesStatus? status;

  CreateProposalDataAttributes({
    this.proposalReceivedDate,
    this.proposalSubmittedDate,
    this.clientDetails,
    this.riskFactors,
    this.dependencies,
    this.documents,
    this.feedback,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
    this.objectives,
    this.summery,
    this.comments,
    this.location,
    this.currency,
    this.budget,
    this.domain,
    this.functionalities,
    this.platforms,
    this.technologies,
    this.resources,
    this.status,
  });
  CreateProposalDataAttributes.fromJson(Map<String, dynamic> json) {
    proposalReceivedDate = json['proposal_received_date']?.toString();
    proposalSubmittedDate = json['proposal_submitted_date']?.toString();
    clientDetails = json['client_details']?.toString();
    riskFactors = json['risk_factors']?.toString();
    dependencies = json['dependencies']?.toString();
    documents = (json['documents'] != null)
        ? CreateProposalDataAttributesDocuments.fromJson(json['documents'])
        : null;
    feedback = json['feedback']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
    objectives = json['objectives']?.toString();
    summery = json['summery']?.toString();
    comments = json['comments']?.toString();
    location = json['location']?.toString();
    currency = json['currency']?.toString();
    budget = json['budget']?.toString();
    domain = (json['domain'] != null)
        ? CreateProposalDataAttributesDomain.fromJson(json['domain'])
        : null;
    functionalities = (json['functionalities'] != null)
        ? CreateProposalDataAttributesFunctionalities.fromJson(
            json['functionalities'])
        : null;
    platforms = (json['platforms'] != null)
        ? CreateProposalDataAttributesPlatforms.fromJson(json['platforms'])
        : null;
    technologies = (json['technologies'] != null)
        ? CreateProposalDataAttributesTechnologies.fromJson(
            json['technologies'])
        : null;
    resources = (json['resources'] != null)
        ? CreateProposalDataAttributesResources.fromJson(json['resources'])
        : null;
    status = (json['status'] != null)
        ? CreateProposalDataAttributesStatus.fromJson(json['status'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['proposal_received_date'] = proposalReceivedDate;
    data['proposal_submitted_date'] = proposalSubmittedDate;
    data['client_details'] = clientDetails;
    data['risk_factors'] = riskFactors;
    data['dependencies'] = dependencies;
    if (documents != null) {
      data['documents'] = documents!.toJson();
    }
    data['feedback'] = feedback;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    data['objectives'] = objectives;
    data['summery'] = summery;
    data['comments'] = comments;
    data['location'] = location;
    data['currency'] = currency;
    data['budget'] = budget;
    if (domain != null) {
      data['domain'] = domain!.toJson();
    }
    if (functionalities != null) {
      data['functionalities'] = functionalities!.toJson();
    }
    if (platforms != null) {
      data['platforms'] = platforms!.toJson();
    }
    if (technologies != null) {
      data['technologies'] = technologies!.toJson();
    }
    if (resources != null) {
      data['resources'] = resources!.toJson();
    }
    if (status != null) {
      data['status'] = status!.toJson();
    }
    return data;
  }
}

class CreateProposalData {

  int? id;
  CreateProposalDataAttributes? attributes;

  CreateProposalData({
    this.id,
    this.attributes,
  });
  CreateProposalData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProposalDataAttributes.fromJson(json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProposal {

  CreateProposalData? data;
  CreateProposalMeta? meta;

  CreateProposal({
    this.data,
    this.meta,
  });
  CreateProposal.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProposalData.fromJson(json['data'])
        : null;
    meta = (json['meta'] != null)
        ? CreateProposalMeta.fromJson(json['meta'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    if (meta != null) {
      data['meta'] = meta!.toJson();
    }
    return data;
  }
}
