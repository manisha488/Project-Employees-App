import 'package:flutter/material.dart';

class AppColors {
  ///Basic Colors
  static Color blue = Colors.blue;
  static Color white = Colors.white;
  static Color purple = Colors.purple;
  static Color teal = Colors.teal;
  static Color black = Colors.black;
  static Color grey = Colors.grey;
  static Color? grey_300 = Colors.grey[300];
  static Color? grey_500 = Colors.grey[500];
  static Color? grey_700 = Colors.grey[700];
  static Color red = Colors.red;
  static Color orange = Colors.orange;
  static Color yellow = Colors.yellow;
  static Color green = Colors.green;
  static Color indigo = Colors.indigo;
  static Color pink = Colors.pink;
  static Color appThemeColor = const Color(0xFF023057);
  static Color themeColor = const Color(0xff003E74);

  ///Login Screen
  static Color loginButtonColor = const Color(0xFFBBC2C8);
  static Color loginBackgroundColor = const Color(0xFFFFFFFF);
  static Color loginTextFieldTitleColor = const Color(0xFF333333);
  static Color loginTextFieldBorderColor = const Color(0xFFDBE9FF);
  static Color loginIconDividerColor = const Color(0xFFEDEDED);
  static Color loginTextFieldIconColor = const Color(0xFF666666);
  static Color splashScreenBackgroundColor = const Color(0xFFE6F2FF);
  static Color textFieldHintColor = const Color(0xFF59738D);
  static Color enableLoginButtonColor = const Color(0xFF003E74);

  ///TabBar Colors

  static Color appBottomNavigationBar = const Color(0xff003E74);
  static Color selectedBarItemIcon = const Color(0xffFFFFFF);
  static Color unselectedBarItem = const Color(0xff666666);
  static Color tabBarIconNameColor = const Color(0xff5A738C);

  ///Home_page Colors
  static Color homeAppBar = const Color(0xFFEFEFEF);
  static Color homeAppBarStringColor = const Color(0xff333333);
  static Color homeAppBarIconColor = const Color(0xffFFFFFF);
  static Color homeTextFieldFormColor = const Color(0xff999999);
  static Color homeSearchBarBorderColor = const Color(0xffDBE9FF);
  static Color homeSearchBarBorderColor1 = const Color(0xFF023057);
  static Color homeScreenTopColor = const Color(0xffE6F2FF);
  static Color homeScreenBottomColor = const Color(0xffFFFFFF);
  static Color projectCardBorderColor = const Color(0xFFDBE9FF);
  static Color searchBarHintTextColor = const Color(0xFF92ACC6);
  static Color logoutButtonColor = const Color(0xFF29C5FF);

  static Color cancelledStatus = const Color(0xFFFFC9C9);
  static Color inProgressStatus = const Color(0xFFFFDFAC);
  static Color onHoldStatus = const Color(0xFFD8D8FF);
  static Color notStartedStatus = const Color(0xFFE5E4E2);
  static Color completeStatus = const Color(0xFFD0F0C0);
  static Color incompleteStatus = const Color(0xFFFEC4C1);
  static Color approvedStatus = const Color(0xFFC6FDFA);
  static Color dateColor = const Color(0xFF666666);
  static Color overdueStatus = const Color(0xFFFEE3E2);
  static Color cancelledProjectBody = const Color(0xFF747474);
  static Color projectBody = const Color(0xFF666666);

  ///Filter_screen Colors
  static Color mainFiltersBackgroundColor = const Color(0xFFF9F9F9);
  static Color applyButtonColor = const Color(0xFF003E74);
  static Color filterScrollbarColor = const Color(0xFF59738D);
  static Color checkboxFilledColor = const Color(0xFF29C5FF);
  static Color selectedFilterColor = const Color(0xFF5A738C);
  static Color searchBarBorderColor = const Color(0xFFDBE9FF);
  static Color searchBarIconColor = const Color(0xFF59738D);

  ///Create Project Screen
  static Color createProjectAppBarColor = const Color(0xFF003E74);
  static Color basicDetailsButton = const Color(0xFFD3D2D2);
  static Color createScreenButtonBorderColor = const Color(0xFFD3D2D2);

  ///Basic details screen
  static Color basicDetailProjectIDColor = const Color(0xFF7E7B7B);
  static Color basicDetailHintTextColor = const Color(0xFF333333);
  static Color calenderIconColor = const Color(0xFF666666);
  static Color stepperBorderColor = const Color(0xFFB5B5B5);
  static Color multiSelectDropDownListBorderColor = const Color(0xFF79747E);
  static Color basicDetailsHeadingColor = const Color(0xFF585858);
  static Color basicDetailTextFieldBorderColor = const Color(0xFFDCE8FF);
  static Color nextButtonColor = const Color(0xFFBBC2C8);
  static Color nextButtonColor1 = const Color(0xFF312F36);

  ///Technical information screen
  static Color itemRemoveButtonColor = const Color(0xFF59738D);
  static Color itemBodyButtonColor = const Color(0xFFF2F7FF);
  static Color itemBorderButtonColor = const Color(0xFFDBE9FF);
  static Color itemCheckBoxColor = const Color(0xFF29C5FF);

  ///Review Screen
  static Color reviewBackgroundColor = const Color(0xFFE6F2FF);
  static Color reviewDetailsBorderColor = const Color(0xFFDCE8FF);
  static Color projectStatusColor = const Color(0xFFFFDFAC);
  static Color flushBarBackgroundColor = const Color(0xFF312F36);
  static Color flushBarViewClickColor = const Color(0xFF27C5FF);
  static Color bottomSheetColor = const Color(0xFFFFFFFF);
  static Color bottomSheetItemColor = const Color(0xFFC7BEBE);
  static Color bottomSheetTabColor = const Color(0xFF003E74);
  static Color bottomSheetDragButtonColor = const Color(0xFFBBC2C8);
  static Color bottomSheetTextColor = const Color(0xFF666666);
  static Color bottomSheetIconTextColor = const Color(0xFF333333);
  static Color bottomSheetIconTColor = const Color(0xFF59738D);
  static Color bottomSheetDividerColor = const Color(0xFFDCE8FF);
  static Color bottomSheetBackgroundColor = const Color(0xFFF9F9F9);
  static Color bottomSheetListTitleColor = const Color(0xFFF004AF2);
  static Color bottomSheetButtonColor = const Color(0xFFF003E74);
  static Color homeBackground = const Color(0xFFE6F2FF);

  ///Project Details Screen Colors
  static Color titleColor = const Color(0xFF333333).withOpacity(0.8);
  static Color subTitleColor = const Color(0xFF333333);
  static Color tabBarBackground = const Color(0xFFF9F9F9);

  Color textColor = const Color(0xFF222939);

  static const height25 = SizedBox(
    height: 25,
  );

  TextStyle f14BlackLetterSpacing = const TextStyle(
      fontSize: 14, fontFamily: 'Poppins', color: Color(0xFF222939), letterSpacing: 2);

  TextStyle f16PW =
  const TextStyle(color: Colors.white, fontFamily: 'Poppins', fontSize: 16);

  TextStyle f24WhiteBold = const TextStyle(
      fontSize: 24,
      fontFamily: 'Poppins',
      color: Colors.white,
      fontWeight: FontWeight.bold);

  TextStyle f42WhiteBold = const TextStyle(
      fontSize: 42,
      fontFamily: 'Poppins',
      color: Colors.white,
      fontWeight: FontWeight.bold);
}
