part of 'projects_bloc.dart';

///All the possible states will be manage by extending the following abstract class.

@immutable
abstract class ProjectsState {}

/// The first state to be load on the screen
class ProjectsInitialState extends ProjectsState {}

class ProjectsActionState extends ProjectsState {}

/// This state will run while api list is loading
class ProjectsLoadingState extends ProjectsState {}

/// This state will run when any error occurred in api loading
class ProjectsErrorState extends ProjectsState {
  final NetworkExceptions exception;
  ProjectsErrorState(this.exception);
}

/// This state will be used to handle the Circular Progress indicator on the screen
class ProjectLoaderState extends ProjectsState {}

/// This state will run on Internet unavailability
class ProjectsInternetDisconnected extends ProjectsActionState {
  final NetworkExceptions exception;
  ProjectsInternetDisconnected(this.exception);
}

class SearchProjectErrorState extends ProjectsState {
  final ApiResult<SearchProject> searchDetails;
  SearchProjectErrorState({required this.searchDetails});
}

/// This state will load on successful api call for Projects List
class ProjectsLoadedSuccessState extends ProjectsState {
  final List<ProjectsData> projects;
  ProjectsLoadedSuccessState(this.projects);
}

/// This state will load on successful api call for Proposals List
class ProposalsLoadedSuccessfully extends ProjectsState {
  final List<ProposalsData> proposals;
  ProposalsLoadedSuccessfully(this.proposals);
}

class FilteredProjectsLoaded extends ProjectsState {
  //final List<FilteredProjectsData> filteredProjects;
  //FilteredProjectsLoaded();
}

class FilteredProposalsLoaded extends ProjectsState {}
class OfflineProjectsLoaded extends ProjectsState {}
class OfflineProposalsLoaded extends ProjectsState {}

/// This state will be emit on Project Screen which will have the array of data.
class SearchProjectActionState extends ProjectsState {
  final List<SearchProjectData?> details;
  SearchProjectActionState(this.details);
}

/// This state will be emit on Project Screen which will have the array of data.
class SearchProposalActionState extends ProjectsState {
  final List<ProposalListData?> proposalDetails;
  SearchProposalActionState(this.proposalDetails);
}

/// This state will be emit on Project Screen when the internet is disconnect of the device.
class SearchFailedState extends ProjectsState {
  final NetworkExceptions exception;
  SearchFailedState(this.exception);
}
