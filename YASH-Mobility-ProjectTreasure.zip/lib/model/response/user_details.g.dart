// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_details.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserDetailsImpl _$$UserDetailsImplFromJson(Map<String, dynamic> json) =>
    _$UserDetailsImpl(
      json['jwt'] as String,
      User.fromJson(json['user'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$UserDetailsImplToJson(_$UserDetailsImpl instance) =>
    <String, dynamic>{
      'jwt': instance.jwt,
      'user': instance.user,
    };

_$UserImpl _$$UserImplFromJson(Map<String, dynamic> json) => _$UserImpl(
      json['id'] as int,
      json['username'] as String,
      json['email'] as String,
      json['provider'] as String,
      json['confirmed'] as bool,
      json['blocked'] as bool,
      json['firstName'] as String,
      json['lastName'] as String,
      json['employeeId'] as String,
      json['createdAt'] as String,
      json['updatedAt'] as String,
      json['userRole'] as String,
    );

Map<String, dynamic> _$$UserImplToJson(_$UserImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'username': instance.username,
      'email': instance.email,
      'provider': instance.provider,
      'confirmed': instance.confirmed,
      'blocked': instance.blocked,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
      'employeeId': instance.employeeId,
      'createdAt': instance.createdAt,
      'updatedAt': instance.updatedAt,
      'userRole': instance.userRole,
    };
