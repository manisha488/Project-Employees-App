class ProposalsMetaPagination {
  int? page;
  int? pageSize;
  int? pageCount;
  int? total;

  ProposalsMetaPagination({
    this.page,
    this.pageSize,
    this.pageCount,
    this.total,
  });
  ProposalsMetaPagination.fromJson(Map<String, dynamic> json) {
    page = json['page']?.toInt();
    pageSize = json['pageSize']?.toInt();
    pageCount = json['pageCount']?.toInt();
    total = json['total']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['pageCount'] = pageCount;
    data['total'] = total;
    return data;
  }
}

class ProposalsMeta {
  ProposalsMetaPagination? pagination;

  ProposalsMeta({
    this.pagination,
  });
  ProposalsMeta.fromJson(Map<String, dynamic> json) {
    pagination = (json['pagination'] != null) ? ProposalsMetaPagination.fromJson(json['pagination']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesStatusDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalsDataAttributesStatusDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalsDataAttributesStatusDataAttributes.fromJson(Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalsDataAttributesStatusData {
  int? id;
  ProposalsDataAttributesStatusDataAttributes? attributes;

  ProposalsDataAttributesStatusData({
    this.id,
    this.attributes,
  });
  ProposalsDataAttributesStatusData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributesStatusDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesStatus {
  ProposalsDataAttributesStatusData? data;

  ProposalsDataAttributesStatus({
    this.data,
  });
  ProposalsDataAttributesStatus.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null) ? ProposalsDataAttributesStatusData.fromJson(json['data']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesResourcesDataAttributes {
  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  ProposalsDataAttributesResourcesDataAttributes({
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  ProposalsDataAttributesResourcesDataAttributes.fromJson(Map<String, dynamic> json) {
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class ProposalsDataAttributesResourcesData {
  int? id;
  ProposalsDataAttributesResourcesDataAttributes? attributes;

  ProposalsDataAttributesResourcesData({
    this.id,
    this.attributes,
  });
  ProposalsDataAttributesResourcesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributesResourcesDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesResources {
  List<ProposalsDataAttributesResourcesData?>? data;

  ProposalsDataAttributesResources({
    this.data,
  });
  ProposalsDataAttributesResources.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProposalsDataAttributesResourcesData>[];
      v.forEach((v) {
        arr0.add(ProposalsDataAttributesResourcesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProposalsDataAttributesTechnologiesDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalsDataAttributesTechnologiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalsDataAttributesTechnologiesDataAttributes.fromJson(Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalsDataAttributesTechnologiesData {
  int? id;
  ProposalsDataAttributesTechnologiesDataAttributes? attributes;

  ProposalsDataAttributesTechnologiesData({
    this.id,
    this.attributes,
  });
  ProposalsDataAttributesTechnologiesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributesTechnologiesDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesTechnologies {
  List<ProposalsDataAttributesTechnologiesData?>? data;

  ProposalsDataAttributesTechnologies({
    this.data,
  });
  ProposalsDataAttributesTechnologies.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProposalsDataAttributesTechnologiesData>[];
      v.forEach((v) {
        arr0.add(ProposalsDataAttributesTechnologiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProposalsDataAttributesPlatformsDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalsDataAttributesPlatformsDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalsDataAttributesPlatformsDataAttributes.fromJson(Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalsDataAttributesPlatformsData {
  int? id;
  ProposalsDataAttributesPlatformsDataAttributes? attributes;

  ProposalsDataAttributesPlatformsData({
    this.id,
    this.attributes,
  });
  ProposalsDataAttributesPlatformsData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributesPlatformsDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesPlatforms {
  List<ProposalsDataAttributesPlatformsData?>? data;

  ProposalsDataAttributesPlatforms({
    this.data,
  });
  ProposalsDataAttributesPlatforms.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProposalsDataAttributesPlatformsData>[];
      v.forEach((v) {
        arr0.add(ProposalsDataAttributesPlatformsData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProposalsDataAttributesFunctionalitiesDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalsDataAttributesFunctionalitiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalsDataAttributesFunctionalitiesDataAttributes.fromJson(Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalsDataAttributesFunctionalitiesData {
  int? id;
  ProposalsDataAttributesFunctionalitiesDataAttributes? attributes;

  ProposalsDataAttributesFunctionalitiesData({
    this.id,
    this.attributes,
  });
  ProposalsDataAttributesFunctionalitiesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributesFunctionalitiesDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesFunctionalities {
  List<ProposalsDataAttributesFunctionalitiesData?>? data;

  ProposalsDataAttributesFunctionalities({
    this.data,
  });
  ProposalsDataAttributesFunctionalities.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProposalsDataAttributesFunctionalitiesData>[];
      v.forEach((v) {
        arr0.add(ProposalsDataAttributesFunctionalitiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class ProposalsDataAttributesDomainDataAttributes {
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalsDataAttributesDomainDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalsDataAttributesDomainDataAttributes.fromJson(Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalsDataAttributesDomainData {
  int? id;
  ProposalsDataAttributesDomainDataAttributes? attributes;

  ProposalsDataAttributesDomainData({
    this.id,
    this.attributes,
  });
  ProposalsDataAttributesDomainData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributesDomainDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesDomain {
  ProposalsDataAttributesDomainData? data;

  ProposalsDataAttributesDomain({
    this.data,
  });
  ProposalsDataAttributesDomain.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null) ? ProposalsDataAttributesDomainData.fromJson(json['data']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProposalsDataAttributesDocumentsConnect {
  String? id;

  ProposalsDataAttributesDocumentsConnect({
    this.id,
  });
  ProposalsDataAttributesDocumentsConnect.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}

class ProposalsDataAttributesDocuments {
  List<ProposalsDataAttributesDocumentsConnect?>? connect;

  ProposalsDataAttributesDocuments({
    this.connect,
  });
  ProposalsDataAttributesDocuments.fromJson(Map<String, dynamic> json) {
    if (json['connect'] != null) {
      final v = json['connect'];
      final arr0 = <ProposalsDataAttributesDocumentsConnect>[];
      v.forEach((v) {
        arr0.add(ProposalsDataAttributesDocumentsConnect.fromJson(v));
      });
      connect = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (connect != null) {
      final v = connect;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['connect'] = arr0;
    }
    return data;
  }
}

class ProposalsDataAttributes {
  String? proposalReceivedDate;
  String? proposalSubmittedDate;
  String? clientDetails;
  String? riskFactors;
  String? dependencies;
  String? feedback;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;
  String? objectives;
  String? summery;
  String? comments;
  ProposalsDataAttributesDocuments? documents;
  String? location;
  String? currency;
  String? budget;
  ProposalsDataAttributesDomain? domain;
  ProposalsDataAttributesFunctionalities? functionalities;
  ProposalsDataAttributesPlatforms? platforms;
  ProposalsDataAttributesTechnologies? technologies;
  ProposalsDataAttributesResources? resources;
  ProposalsDataAttributesStatus? status;

  ProposalsDataAttributes({
    this.proposalReceivedDate,
    this.proposalSubmittedDate,
    this.clientDetails,
    this.riskFactors,
    this.dependencies,
    this.feedback,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
    this.objectives,
    this.summery,
    this.comments,
    this.documents,
    this.location,
    this.currency,
    this.budget,
    this.domain,
    this.functionalities,
    this.platforms,
    this.technologies,
    this.resources,
    this.status,
  });
  ProposalsDataAttributes.fromJson(Map<String, dynamic> json) {
    proposalReceivedDate = json['proposal_received_date']?.toString();
    proposalSubmittedDate = json['proposal_submitted_date']?.toString();
    clientDetails = json['client_details']?.toString();
    riskFactors = json['risk_factors']?.toString();
    dependencies = json['dependencies']?.toString();
    feedback = json['feedback']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
    objectives = json['objectives']?.toString();
    summery = json['summery']?.toString();
    comments = json['comments']?.toString();
    documents = (json['documents'] != null) ? ProposalsDataAttributesDocuments.fromJson(json['documents']) : null;
    location = json['location']?.toString();
    currency = json['currency']?.toString();
    budget = json['budget']?.toString();
    domain = (json['domain'] != null) ? ProposalsDataAttributesDomain.fromJson(json['domain']) : null;
    functionalities = (json['functionalities'] != null) ? ProposalsDataAttributesFunctionalities.fromJson(json['functionalities']) : null;
    platforms = (json['platforms'] != null) ? ProposalsDataAttributesPlatforms.fromJson(json['platforms']) : null;
    technologies = (json['technologies'] != null) ? ProposalsDataAttributesTechnologies.fromJson(json['technologies']) : null;
    resources = (json['resources'] != null) ? ProposalsDataAttributesResources.fromJson(json['resources']) : null;
    status = (json['status'] != null) ? ProposalsDataAttributesStatus.fromJson(json['status']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['proposal_received_date'] = proposalReceivedDate;
    data['proposal_submitted_date'] = proposalSubmittedDate;
    data['client_details'] = clientDetails;
    data['risk_factors'] = riskFactors;
    data['dependencies'] = dependencies;
    data['feedback'] = feedback;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    data['objectives'] = objectives;
    data['summery'] = summery;
    data['comments'] = comments;
    if (documents != null) {
      data['documents'] = documents!.toJson();
    }
    data['location'] = location;
    data['currency'] = currency;
    data['budget'] = budget;
    if (domain != null) {
      data['domain'] = domain!.toJson();
    }
    if (functionalities != null) {
      data['functionalities'] = functionalities!.toJson();
    }
    if (platforms != null) {
      data['platforms'] = platforms!.toJson();
    }
    if (technologies != null) {
      data['technologies'] = technologies!.toJson();
    }
    if (resources != null) {
      data['resources'] = resources!.toJson();
    }
    if (status != null) {
      data['status'] = status!.toJson();
    }
    return data;
  }
}

class ProposalsData {
  int? id;
  ProposalsDataAttributes? attributes;

  ProposalsData({
    this.id,
    this.attributes,
  });
  ProposalsData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ProposalsDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class Proposals {
  List<ProposalsData?>? data;
  ProposalsMeta? meta;

  Proposals({
    this.data,
    this.meta,
  });
  Proposals.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProposalsData>[];
      v.forEach((v) {
        arr0.add(ProposalsData.fromJson(v));
      });
      this.data = arr0;
    }
    meta = (json['meta'] != null) ? ProposalsMeta.fromJson(json['meta']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    if (meta != null) {
      data['meta'] = meta!.toJson();
    }
    return data;
  }
}