import 'package:freezed_annotation/freezed_annotation.dart';
part 'api_response.freezed.dart';
part 'api_response.g.dart';

@freezed
class ApiResponse with _$ApiResponse {
  const factory ApiResponse(dynamic data, Error error) = _ApiResponse;

  factory ApiResponse.fromJson(Map<String, dynamic> json) =>
      _$ApiResponseFromJson(json);
}

@freezed
class Error with _$Error {
  const factory Error(
      int status, String name, String message, Details details) = _Error;

  factory Error.fromJson(Map<String, dynamic> json) => _$ErrorFromJson(json);
}

@freezed
class Details with _$Details {
  const factory Details() = _Details;
  factory Details.fromJson(Map<String, dynamic> json) =>
      _$DetailsFromJson(json);
}
