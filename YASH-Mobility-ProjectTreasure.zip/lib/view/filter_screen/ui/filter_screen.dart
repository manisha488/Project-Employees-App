import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/components/custom_filter_widget/custom_filter_widget.dart';
import 'package:yash_mobility_project_treasure/model/all_filters.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/clear_filters.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/filter_screen/bloc/filter_screen_bloc.dart';
import 'package:yash_mobility_project_treasure/view/home_screen/ui/home_screen.dart';
import 'package:yash_mobility_project_treasure/view/sub_filters_screen/bloc/sub_filters_bloc.dart';

/// To reset the screen after clearing all the filters on click of clear filters button
class ResetFilterScreen extends StatefulWidget {
  final bool projectsFilter;
  final bool proposalsFilter;
  final Database database;
  const ResetFilterScreen(
      {super.key, required this.projectsFilter, required this.proposalsFilter, required this.database});

  @override
  State<ResetFilterScreen> createState() => _ResetFilterScreenState();
}

class _ResetFilterScreenState extends State<ResetFilterScreen> {
  @override
  Widget build(BuildContext context) {
    return FilterScreen(
      clearFilter: false,
      projectsFilter: widget.projectsFilter,
      proposalsFilter: widget.proposalsFilter,
      database: widget.database,
    );
  }
}

/// Filter Screen
class FilterScreen extends StatefulWidget {
  final bool projectsFilter;
  final bool proposalsFilter;
  bool? clearFilter;
  final Database database;
  FilterScreen({
    super.key,
    this.clearFilter,
    required this.projectsFilter,
    required this.proposalsFilter,
    required this.database
  });

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  final FilterScreenBloc filtersBloc = FilterScreenBloc();
  final SubFiltersBloc subFiltersBloc = SubFiltersBloc();
  final clearFilters = ClearFilters();
  int? selectedIndexListView = Dimensions.count_0;
  var count = '${Dimensions.count_0}';
  Map<int, int>? categoryCounts = {};
  List<String> finalFilters = [];
  List<AllFilters> filters = [];
  bool? isAppliedFilter;
  bool isButtonEnabledForProjects =
      (SharedPrefs.instance.getBool(Strings().applyFiltersForProjectsKeyText) ??
          false);
  bool isButtonEnabledForProposals = (SharedPrefs.instance
          .getBool(Strings().applyFiltersForProposalsKeyText) ??
      false);
  final db = CustomDataBaseWrapper();

  @override
  void initState() {
    widget.projectsFilter
        ? filtersBloc.add(FilterScreenInitialEvent())
        : filtersBloc.add(ProposalFiltersLoadedEvent());
    subFiltersBloc.add(DatesFilterClickedEvent());
    widget.projectsFilter
        ? filtersBloc.add(ApplyButtonEnableEvent())
   : filtersBloc.add(ApplyButtonEnableForProposalsEvent());

    checkFilters();
    checkFiltersForProposals();
    super.initState();
  }

  /// Function to check number of filters applied.
  String filtersCountString({required int index}) {
    List<String>? status = [];
    switch (index) {
      case 0:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedDatesFilterKey)
            : SharedPrefs.instance
                .getStringList(Strings().proposalSelectedDatesFilterKey);

      case 1:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedStatusFiltersKey)
            : SharedPrefs.instance
                .getStringList(Strings().proposalSelectedStatusFiltersKey);

      case 2:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedProjectsFiltersKey)
            : SharedPrefs.instance
                .getStringList(Strings().selectedProposalsFiltersKey);

      case 3:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedResourcesFiltersKey)
            : SharedPrefs.instance
                .getStringList(Strings().proposalSelectedResourcesFiltersKey);

      case 4:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedPlatformsFiltersKey)
            : SharedPrefs.instance
                .getStringList(Strings().proposalSelectedPlatformsFiltersKey);

      case 5:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedTechnologiesFiltersKey)
            : SharedPrefs.instance.getStringList(
                Strings().proposalSelectedTechnologiesFiltersKey);

      case 6:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedFunctionalitiesFiltersKey)
            : SharedPrefs.instance.getStringList(
                Strings().proposalSelectedFunctionalitiesFiltersKey);

      case 7:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedDocsFiltersKeyText)
            : SharedPrefs.instance
                .getStringList(Strings().proposalSelectedDocsFiltersKeyText);

      case 8:
        status = widget.projectsFilter
            ? SharedPrefs.instance
                .getStringList(Strings().selectedDomainsFiltersKey)
            : SharedPrefs.instance
                .getStringList(Strings().proposalSelectedDomainsFiltersKey);
    }
    count = "${status?.length ?? ""}";

    return count;
  }

  /// Function to check if filters are applied or not.
  bool? checkFilters() {
    List<String> isFiltersApplied =
        SharedPrefs.instance.getStringList(Strings().filtersToApplyKey) ?? [];
    if (isFiltersApplied.isEmpty || isFiltersApplied == []) {
      isAppliedFilter = false;
      SharedPrefs.instance.setBool(Strings().isProjectsFiltersApplied, false);
      return isAppliedFilter;
    } else {
      isAppliedFilter = true;
      SharedPrefs.instance.setBool(Strings().isProjectsFiltersApplied, true);
      return isAppliedFilter;
    }
  }

  bool? checkFiltersForProposals() {
    List<String> isProposalsFiltersApplied = SharedPrefs.instance
            .getStringList(Strings().proposalFiltersToApplyKey) ??
        [];
    if (isProposalsFiltersApplied.isEmpty || isProposalsFiltersApplied == []) {
      isAppliedFilter = false;
      SharedPrefs.instance.setBool(Strings().isProposalsFiltersApplied, false);
      return isAppliedFilter;
    } else {
      isAppliedFilter = true;
      SharedPrefs.instance.setBool(Strings().isProposalsFiltersApplied, true);
      return isAppliedFilter;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            Expanded(
              flex: Dimensions.flex_5,
              child: BlocConsumer<FilterScreenBloc, FilterScreenState>(
                bloc: filtersBloc,
                listenWhen: (previous, current) =>
                    current is FiltersActionState,
                buildWhen: (previous, current) =>
                    current is! FiltersActionState,
                listener: (context, state) {
                  if (state is ProjectsFiltersLoadedSuccessState) {
                    setState(() {
                      filters = state.filters;
                    });
                  } else if (state is ProposalFiltersLoadedSuccessState) {
                    final proposalsState = state;
                    setState(() {
                      filters = proposalsState.filters;
                    });
                  } else if (state is ApplyFiltersState) {
                    checkFilters();
                    setState(() {
                      widget.clearFilter = true;
                    });
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                          builder: (builder) => HomeScreen(
                                isFilterScreen: widget.clearFilter!,
                                isProposalFilterScreen: false,
                                //filteredProjects: state.filters,
                                pageIndex: 0,
                                isProjectFiltersApplied: (SharedPrefs.instance.getStringList(Strings().filtersToApplyKey) ?? []).isNotEmpty  ? true :
                                    false,
                                isProposalFiltersApplied: (SharedPrefs.instance.getStringList(Strings().proposalFiltersToApplyKey) ?? []).isNotEmpty  ? true :
                                false,
                            database: widget.database,
                              )),
                      (Route<dynamic> route) => false,
                    );
                  } else if (state is ApplyProposalFiltersState) {
                    checkFiltersForProposals();
                    setState(() {
                      widget.clearFilter = true;
                    });
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                          builder: (builder) => HomeScreen(
                              isFilterScreen: false,
                              isProposalFilterScreen: true,
                              //filteredProposals: state.filters,
                              pageIndex: 1,
                              isProjectFiltersApplied: (SharedPrefs.instance.getStringList(Strings().filtersToApplyKey) ?? []).isNotEmpty  ? true :
                              false,
                              isProposalFiltersApplied: (SharedPrefs.instance.getStringList(Strings().proposalFiltersToApplyKey) ?? []).isNotEmpty  ? true :
                              false,
                            database: widget.database,)),
                      (Route<dynamic> route) => false,
                    );
                  }
                },
                builder: (context, state) {
                  return Container(
                      color: AppColors.mainFiltersBackgroundColor,
                      child: Column(
                        children: [
                          Row(
                            children: [
                              IconButton(
                                  onPressed: () {
                                    if (widget.projectsFilter) {
                                      if (SharedPrefs.instance.getBool(Strings()
                                              .isProjectsFiltersApplied) ==
                                          false) {
                                        clearFilters
                                            .clearSharedPrefsForProject();
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (builder) => HomeScreen(
                                                  pageIndex: 0,
                                                    isFilterScreen:
                                                        widget.clearFilter ??
                                                            false,
                                                    isProposalFilterScreen:
                                                        false,
                                                    isProjectFiltersApplied:
                                                        SharedPrefs.instance
                                                                .getBool(Strings()
                                                                    .isProjectsFiltersApplied) ??
                                                            false,
                                                    isProposalFiltersApplied:
                                                        SharedPrefs.instance
                                                                .getBool(Strings()
                                                                    .isProposalsFiltersApplied) ??
                                                            false,
                                                  database: widget.database,)));
                                      } else {
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (builder) => HomeScreen(
                                                  pageIndex: 0,
                                                    isFilterScreen:
                                                        widget.clearFilter ??
                                                            false,
                                                    isProposalFilterScreen:
                                                        false,
                                                    isProjectFiltersApplied:
                                                        SharedPrefs.instance
                                                                .getBool(Strings()
                                                                    .isProjectsFiltersApplied) ??
                                                            false,
                                                    isProposalFiltersApplied:
                                                        SharedPrefs.instance
                                                                .getBool(Strings()
                                                                    .isProposalsFiltersApplied) ??
                                                            false,
                                                  database: widget.database,)));
                                      }
                                    } else {
                                      if (SharedPrefs.instance.getBool(Strings()
                                              .isProposalsFiltersApplied) ==
                                          false) {
                                        clearFilters
                                            .clearSharedPrefsForProposals();
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (builder) => HomeScreen(
                                                  pageIndex: 1,
                                                    isFilterScreen:
                                                    false,
                                                    isProposalFilterScreen:
                                                    widget.clearFilter ??
                                                        false,
                                                    isProjectFiltersApplied:
                                                    SharedPrefs.instance
                                                        .getBool(Strings()
                                                        .isProjectsFiltersApplied) ??
                                                        false,
                                                    isProposalFiltersApplied:
                                                    SharedPrefs.instance
                                                        .getBool(Strings()
                                                        .isProposalsFiltersApplied) ??
                                                        false,
                                                  database: widget.database,)));
                                       // Navigator.pop(context);
                                      } else {
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (builder) => HomeScreen(
                                                  pageIndex: 1,
                                                    isFilterScreen:
                                                    false,
                                                    isProposalFilterScreen:
                                                    widget.clearFilter ??
                                                        false,
                                                    isProjectFiltersApplied:
                                                    SharedPrefs.instance
                                                        .getBool(Strings()
                                                        .isProjectsFiltersApplied) ??
                                                        false,
                                                    isProposalFiltersApplied:
                                                    SharedPrefs.instance
                                                        .getBool(Strings()
                                                        .isProposalsFiltersApplied) ??
                                                        false,
                                                  database: widget.database,)));
                                        //Navigator.pop(context);
                                      }
                                    }
                                  },
                                  icon: const Icon(Icons.arrow_back)),
                              SizedBox(
                                width: Dimensions.width_10,
                              ),
                              Text(
                                Strings().filterTitle,
                                style: TextStyle(fontSize: Dimensions.font_22),
                              )
                            ],
                          ),
                          SizedBox(
                            height: Dimensions.height_10,
                          ),
                          Expanded(
                            child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: filters.length,
                                itemBuilder: (context, index) {
                                  filtersCountString(index: index);
                                  return Container(
                                    color: selectedIndexListView == index
                                        ? Colors.white
                                        : null,
                                    child: ListTile(
                                      contentPadding:
                                          selectedIndexListView == index
                                              ? EdgeInsets.only(
                                                  right: Dimensions.padding_20)
                                              : null,
                                      minLeadingWidth:
                                          selectedIndexListView == index
                                              ? Dimensions.paddingNegative_5
                                              : null,
                                      leading: selectedIndexListView == index
                                          ? Container(
                                              width: Dimensions.width_4,
                                              color: AppColors
                                                  .filterScrollbarColor,
                                            )
                                          : null,
                                      selected: selectedIndexListView == index,
                                      onTap: () {
                                        setState(() {
                                          selectedIndexListView = index;
                                          switch (selectedIndexListView) {
                                            case 0:
                                              return subFiltersBloc.add(
                                                  DatesFilterClickedEvent());
                                            case 1:
                                              return subFiltersBloc.add(
                                                  OfflineStatusLoadedEvent());
                                            case 2:
                                              return widget.projectsFilter
                                                  ? subFiltersBloc.add(
                                                      ProjectNamesFiltersClickedEvent())
                                                  : subFiltersBloc.add(
                                                      ProposalNamesFiltersClickedEvent());
                                            case 3:
                                              return subFiltersBloc.add(
                                                  ResourceNameFilterClickedEvent());
                                            case 4:
                                              return subFiltersBloc.add(
                                                  OfflinePlatformsLoadedEvent());
                                            case 5:
                                              return subFiltersBloc.add(
                                                  OfflineTechnologiesLoadedEvent());
                                            case 6:
                                              return subFiltersBloc.add(
                                                  OfflineFunctionalitiesLoadedEvent());
                                            case 7:
                                              return subFiltersBloc.add(
                                                  DocumentFilterClickedEvent());
                                            case 8:
                                              return subFiltersBloc.add(
                                                  OfflineDomainsLoadedEvent());
                                            default:
                                              return subFiltersBloc.add(
                                                  SubFiltersInitialEvent());
                                          }
                                        });
                                      },
                                      title: Text(
                                        filters[index].title.toTitleCase(),
                                        style: TextStyle(
                                            color:
                                                AppColors.selectedFilterColor,
                                            fontWeight:
                                                selectedIndexListView == index
                                                    ? FontWeight.w600
                                                    : FontWeight.normal,
                                            fontSize: Dimensions.font_16),
                                      ),
                                      trailing: filtersCountString(
                                                  index: index) ==
                                              "${Dimensions.count_0}"
                                          ? const Text('')
                                          : Text(
                                              filtersCountString(index: index),
                                              style: TextStyle(
                                                  color: AppColors
                                                      .filterScrollbarColor),
                                            ),
                                    ),
                                  );
                                }),
                          ),
                        ],
                      ));
                },
              ),
            ),
            Expanded(
              flex: Dimensions.flex_6,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () {
                            if (widget.projectsFilter) {
                              clearFilters.clearSharedPrefsForProject();
                              SharedPrefs.instance
                                  .remove(Strings().filtersToApplyKey);
                            } else {
                              clearFilters.clearSharedPrefsForProposals();
                              SharedPrefs.instance
                                  .remove(Strings().proposalFiltersToApplyKey);
                            }
                            if (!context.mounted) {
                              return;
                            }
                            Navigator.pushReplacement(
                                context,
                                PageRouteBuilder(
                                    pageBuilder: (_, __, ___) =>
                                        ResetFilterScreen(
                                          projectsFilter: widget.projectsFilter,
                                          proposalsFilter:
                                              widget.proposalsFilter,
                                          database: widget.database,
                                        )));
                          },
                          child: Text(
                            Strings().clearFiltersText.toTitleCase(),
                            style: TextStyle(color: AppColors.applyButtonColor),
                          )),
                    ],
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          BlocConsumer<SubFiltersBloc, SubFiltersState>(
                              bloc: subFiltersBloc,
                              buildWhen: (previous, current) =>
                                  current is! SubFiltersActionState,
                              listenWhen: (previous, current) =>
                                  current is SubFiltersActionState,
                              listener: (context, state) {},
                              builder: (context, state) {
                                switch (state.runtimeType) {
                                  case OfflinePlatformsLoadedState:
                                    final loadedPlatformsState =
                                        state as OfflinePlatformsLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      items: loadedPlatformsState.offlinePlatforms,
                                      length:
                                          loadedPlatformsState.offlinePlatforms.length,
                                      isDateFilter: false,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      isPlatformFilter: true,
                                      isStatusFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings()
                                              .selectedPlatformsFiltersKey
                                          : Strings()
                                              .proposalSelectedPlatformsFiltersKey,
                                    );

                                  case DateFiltersClickedState:
                                     return widget.projectsFilter
                                        ?  SubFilterList(
                                            bloc: filtersBloc,
                                            selectedIndex:
                                                selectedIndexListView!,
                                            items: const [],
                                            isDateFilter: true,
                                            proposalDates: false,
                                            isResourceFilter: false,
                                            isProjectsFilter: false,
                                            isProposalNamesFilter: false,
                                            isStatusFilter: false,
                                            isPlatformFilter: false,
                                            isTechFilter: false,
                                            isFunctionalityFilter: false,
                                            isDocFilter: false,
                                            isDomainsFilter: false,
                                            length: 0,
                                            filterKey: Strings()
                                                .selectedDatesFilterKey,
                                      allFiltersKey:  Strings().filtersToApplyKey,
                                          )
                                        : SubFilterList(
                                            bloc: filtersBloc,
                                            selectedIndex:
                                                selectedIndexListView!,
                                            items: const [],
                                            isDateFilter: true,
                                            proposalDates: true,
                                            isResourceFilter: false,
                                            isProjectsFilter: false,
                                            isProposalNamesFilter: false,
                                            isStatusFilter: false,
                                            isPlatformFilter: false,
                                            isTechFilter: false,
                                            isFunctionalityFilter: false,
                                            isDocFilter: false,
                                            isDomainsFilter: false,
                                            length: 0,
                                            filterKey: Strings()
                                                .proposalSelectedDatesFilterKey,
                                      allFiltersKey: Strings().proposalFiltersToApplyKey,
                                          );

                                  case ProjectNamesFiltersLoadedState:
                                    final projectNames =
                                        state as ProjectNamesFiltersLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      projects: projectNames.projectNames,
                                      selectedIndex: selectedIndexListView!,
                                      isDateFilter: false,
                                      length: projectNames.projectNames.length,
                                      isResourceFilter: false,
                                      isProjectsFilter: true,
                                      isProposalNamesFilter: false,
                                      filterKey:
                                          Strings().selectedProjectsFiltersKey,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                    );

                                  case ProposalsNamesFiltersLoadedState:
                                    final proposalName = state
                                        as ProposalsNamesFiltersLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      proposals: proposalName.proposalNames,
                                      selectedIndex: selectedIndexListView!,
                                      isDateFilter: false,
                                      length: proposalName.proposalNames.length,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: true,
                                      filterKey:
                                          Strings().selectedProposalsFiltersKey,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                    );

                                  case OfflineStatusLoadedState:
                                    final loadedStatusState =
                                        state as OfflineStatusLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      items: loadedStatusState.offlineStatus,
                                      isDateFilter: false,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      isStatusFilter: true,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      length: loadedStatusState
                                          .offlineStatus.length,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings().selectedStatusFiltersKey
                                          : Strings()
                                              .proposalSelectedStatusFiltersKey,
                                    );

                                  case ResourceNameFiltersClickedState:
                                    final loadedResourcesState = state
                                        as ResourceNameFiltersClickedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      resources: loadedResourcesState
                                          .resourceNamesFilters,
                                      isDateFilter: false,
                                      isResourceFilter: true,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      length: loadedResourcesState
                                          .resourceNamesFilters.length,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings()
                                              .selectedResourcesFiltersKey
                                          : Strings()
                                              .proposalSelectedResourcesFiltersKey,
                                    );

                                  case OfflineTechnologiesLoadedState:
                                    final loadedTechState =
                                        state as OfflineTechnologiesLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      items: loadedTechState.offlineTech,
                                      isDateFilter: false,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      isTechFilter: true,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings()
                                              .selectedTechnologiesFiltersKey
                                          : Strings()
                                              .proposalSelectedTechnologiesFiltersKey,
                                      length:
                                          loadedTechState.offlineTech.length,
                                    );

                                  case OfflineFunctionalitiesLoadedState:
                                    final loadedFunctionalitiesState = state
                                        as OfflineFunctionalitiesLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      items: loadedFunctionalitiesState
                                          .offlineFunctionalities,
                                      isDateFilter: false,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      isFunctionalityFilter: true,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isDocFilter: false,
                                      isDomainsFilter: false,
                                      length: loadedFunctionalitiesState
                                          .offlineFunctionalities.length,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings()
                                              .selectedFunctionalitiesFiltersKey
                                          : Strings()
                                              .proposalSelectedFunctionalitiesFiltersKey,
                                    );

                                  case OfflineDomainsLoadedState:
                                    final loadedDomainsState =
                                        state as OfflineDomainsLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      items: loadedDomainsState.offlineDomains,
                                      isDateFilter: false,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      isDomainsFilter: true,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDocFilter: false,
                                      length: loadedDomainsState
                                          .offlineDomains.length,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings().selectedDomainsFiltersKey
                                          : Strings()
                                              .proposalSelectedDomainsFiltersKey,
                                    );

                                  case DocumentFiltersLoadedState:
                                    final loadedDocFiltersState =
                                        state as DocumentFiltersLoadedState;
                                    return SubFilterList(
                                      bloc: filtersBloc,
                                      selectedIndex: selectedIndexListView!,
                                      items: const [],
                                      dummyItems:
                                          loadedDocFiltersState.documentFilters,
                                      isDateFilter: false,
                                      isResourceFilter: false,
                                      isProjectsFilter: false,
                                      isProposalNamesFilter: false,
                                      isDocFilter: true,
                                      isStatusFilter: false,
                                      isPlatformFilter: false,
                                      isTechFilter: false,
                                      isFunctionalityFilter: false,
                                      isDomainsFilter: false,
                                      length: loadedDocFiltersState
                                          .documentFilters.length,
                                      allFiltersKey: widget.projectsFilter
                                          ? Strings().filtersToApplyKey
                                          : Strings().proposalFiltersToApplyKey,
                                      filterKey: widget.projectsFilter
                                          ? Strings().selectedDocsFiltersKeyText
                                          : Strings()
                                              .proposalSelectedDocsFiltersKeyText,
                                    );
                                  case NoInternetState:
                                    return Center(
                                        heightFactor: Dimensions.heightFactor_8,
                                        child: Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: MediaQuery.of(context)
                                                      .size
                                                      .height *
                                                  Dimensions
                                                      .mediaQueryHeight_002),
                                          child: Text(
                                            Strings().noInternetText,
                                          ),
                                        ));
                                  case LoadingState:
                                    return Center(
                                      heightFactor: Dimensions.heightFactor_16,
                                      child: CircularProgressIndicator(
                                        strokeAlign: Dimensions.stokeAlign_3,
                                      ),
                                    );
                                  default:
                                    return const Center(
                                      child: CircularProgressIndicator(),
                                    );
                                }
                              }),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_20,
                        bottom: Dimensions.padding_10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: Dimensions.applyButtonWidth_148,
                          child: widget.projectsFilter
                              ? _applyButton(isButtonEnabledForProjects)
                              : _applyButton(isButtonEnabledForProposals),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Apply filters button.
  Widget _applyButton(bool enableButton) {
    return ElevatedButton(
        onPressed: enableButton
            ? () async {
                FocusScope.of(context).requestFocus(FocusNode());
                if (widget.projectsFilter) {
                  db.deleteAll('filteredProjects');
                  var projects = SharedPrefs.instance
                      .getStringList(Strings().selectedProjectsFiltersKey);
                  filtersBloc.add(ApplyFiltersClickedEvent(
                      projectName: projects == null || projects.isEmpty ? null : projects,
                      startDate: SharedPrefs.instance
                          .getString(Strings().selectedStartDateFilterKey),
                      endDate: SharedPrefs.instance
                          .getString(Strings().selectedEndDateFilterKey),
                      resourceName: SharedPrefs.instance.getStringList(
                          Strings().selectedResourcesFiltersKey),
                      availableDoc: SharedPrefs.instance.getStringList(
                          Strings().selectedDocsFiltersKeyText)?[0],
                      projectStatus: SharedPrefs.instance
                          .getStringList(Strings().selectedStatusFiltersKey),
                      platform: SharedPrefs.instance
                          .getStringList(Strings().selectedPlatformsFiltersKey),
                      technologies: SharedPrefs.instance.getStringList(
                          Strings().selectedTechnologiesFiltersKey),
                      domain: SharedPrefs.instance
                          .getStringList(Strings().selectedDomainsFiltersKey),
                      functionalities:
                          SharedPrefs.instance.getStringList(Strings().selectedFunctionalitiesFiltersKey)));
                  SharedPrefs.instance
                      .setBool(Strings().applyFiltersForProjectsKeyText, true);
                } else if (widget.projectsFilter == false) {
                  db.deleteAll('filteredProposals');
                  var proposals = SharedPrefs.instance
                      .getStringList(Strings().selectedProposalsFiltersKey);
                  filtersBloc.add(ApplyProposalsFiltersClickedEvent(
                      proposalName: proposals == null || proposals.isEmpty ? null : proposals,
                      proposalReceivedDate: SharedPrefs.instance.getString(
                          Strings().proposalSelectedStartDateFilterKey),
                      proposalSubmittedDate: SharedPrefs.instance.getString(
                          Strings().proposalSelectedEndDateFilterKey),
                      resourceName: SharedPrefs.instance.getStringList(
                          Strings().proposalSelectedResourcesFiltersKey),
                      availableDoc: SharedPrefs.instance.getStringList(
                          Strings().proposalSelectedDocsFiltersKeyText)?[0],
                      proposalStatus: SharedPrefs.instance.getStringList(
                          Strings().proposalSelectedStatusFiltersKey),
                      platform: SharedPrefs.instance.getStringList(
                          Strings().proposalSelectedPlatformsFiltersKey),
                      technologies:
                          SharedPrefs.instance.getStringList(Strings().proposalSelectedTechnologiesFiltersKey),
                      domain: SharedPrefs.instance.getStringList(Strings().proposalSelectedDomainsFiltersKey),
                      functionalities: SharedPrefs.instance.getStringList(Strings().proposalSelectedFunctionalitiesFiltersKey)));
                  SharedPrefs.instance
                      .setBool(Strings().applyFiltersForProposalsKeyText, true);
                }
              }
            : null,
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.resolveWith<Color?>(
            (Set<MaterialState> states) {
              if (states.contains(MaterialState.disabled)) {
                return AppColors.grey; // Disabled color
              }
              return AppColors.enableLoginButtonColor; // Enabled color
            },
          ),
        ),
        child: BlocProvider(
          create: (_) => filtersBloc,
          child: BlocListener<FilterScreenBloc, FilterScreenState>(
            listener: (context, state) {
              if (state is ApplyButtonEnabledState) {
                setState(() {
                  isButtonEnabledForProjects = true;
                });
              } else if (state is ApplyButtonDisableState) {
                setState(() {
                  isButtonEnabledForProjects = false;
                });
              } else if (state is ApplyButtonEnableProposalState) {
                setState(() {
                  isButtonEnabledForProposals = true;
                });
              } else if (state is ApplyButtonDisableProposalState) {
                setState(() {
                  isButtonEnabledForProposals = false;
                });
              }
            },
            child: BlocBuilder<FilterScreenBloc, FilterScreenState>(
              builder: (context, state) {
                if (state is ApplyButtonLoadingState) {
                  return Center(
                    child: Transform.scale(
                        scale: 0.5,
                        child: CircularProgressIndicator(
                          color: AppColors.white,
                        )),
                  );
                } else {
                  return Text(
                    Strings().applyText,
                    style: TextStyle(color: AppColors.white),
                  );
                }
              },
            ),
          ),
        ));
  }
}
