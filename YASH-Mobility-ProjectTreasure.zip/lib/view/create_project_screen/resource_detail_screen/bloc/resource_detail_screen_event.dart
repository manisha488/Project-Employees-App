part of 'resource_detail_screen_bloc.dart';

@immutable
abstract class ResourceDetailEvent {}

class ResourceDetailInitialEvent extends ResourceDetailEvent {}

/// State for Resource detail Save button.
class ResourceDetailSaveBtnEvent extends ResourceDetailEvent {}

/// State for Resource detail Add button.
class ResourceDetailAddBtnEvent extends ResourceDetailEvent {}

/// State for Designation dropdown list.
class DesignationLoadedEvent extends ResourceDetailEvent {}
