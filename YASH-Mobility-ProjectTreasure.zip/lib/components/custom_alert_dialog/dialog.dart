import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';

import '../../resources/colors.dart';

class Dialogs {
  static Future<void> showLoadingDialog(
      BuildContext context, GlobalKey key, bool isProject) async {
    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
              onWillPop: () async => false,
              child: SimpleDialog(
                  key: key,
                  backgroundColor: Colors.black54,
                  children: <Widget>[
                    Center(
                      child: Column(children: [
                        CircularProgressIndicator(
                          color: AppColors.white,
                        ),
                        SizedBox(
                          height: Dimensions.height_20,
                        ),
                        Text(
                          isProject
                              ? Strings().creatingProject.toTitleCase()
                              : Strings().creatingProposal.toTitleCase(),
                          style: TextStyle(color: AppColors.white),
                        )
                      ]),
                    )
                  ]));
        });
  }
}
