import 'dart:async';
import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:yash_mobility_project_treasure/model/currencies.dart';
import 'package:yash_mobility_project_treasure/repository/api_repository.dart';
import 'package:yash_mobility_project_treasure/services/api_result.dart';
import 'package:yash_mobility_project_treasure/services/network_exceptions.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';

import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/document_list.dart';
import '../../../../model/response/location_list.dart';
import '../../../../model/response/resource_model_list.dart';
import '../../../../resources/error_strings.dart';

part 'additional_detail_screen_event.dart';
part 'additional_detail_screen_state.dart';

class AdditionalDetailScreenBloc
    extends Bloc<AdditionalDetailEvent, AdditionalDetailState> {
  AdditionalDetailScreenBloc() : super(AdditionalDetailInitialState()) {
    on<AdditionalDetailEvent>((event, emit) {});
    on<AdditionalDetailAttachmentBtnEvent>(additionalDetailAttachmentBtnEvent);
    on<AdditionalDetailSaveBtnEvent>(additionalDetailSaveBtnEvent);
    on<NavigateAdditionalDetailToResourceDetailEvent>(
        navigateAdditionalDetailToResourceDetailEvent);
    on<NavigateAdditionalDetailToReviewEvent>(
        navigateAdditionalDetailToReviewEvent);
    on<AdditionalDetailCreateProjectBtnEvent>(
        additionalDetailCreateProjectBtnEvent);
    on<AdditionalDetailCreateProposalBtnEvent>(
        additionalDetailCreateProposalBtnEvent);
    on<ResourceStoreEvent>(resourceStoreEvent);
    on<CurrencyLoadedEvent>(currencyLoadedEvent);
    on<LocationLoadedEvent>(locationLoadedEvent);
    on<UploadDocumentEvent>(uploadDocument);
  }

  ///Event for Additional detail Attachment button.
  FutureOr<void> additionalDetailAttachmentBtnEvent(
      AdditionalDetailAttachmentBtnEvent event,
      Emitter<AdditionalDetailState> emit) {
    emit(AdditionalDetailAttachmentButtonState());
  }

  ///Event for Additional detail Save button.
  FutureOr<void> additionalDetailSaveBtnEvent(
      AdditionalDetailSaveBtnEvent event, Emitter<AdditionalDetailState> emit) {
    emit(AdditionalDetailSaveButtonState());
  }

  ///Event for Navigation from Additional detail screen to Resources detail screen.
  FutureOr<void> navigateAdditionalDetailToResourceDetailEvent(
      NavigateAdditionalDetailToResourceDetailEvent event,
      Emitter<AdditionalDetailState> emit) {
    emit(NavigateAdditionalDetailToResourceDetailState());
  }

  ///Event for Navigation from Additional detail screen to Review screen.
  FutureOr<void> navigateAdditionalDetailToReviewEvent(
      NavigateAdditionalDetailToReviewEvent event,
      Emitter<AdditionalDetailState> emit) {
    emit(NavigateAdditionalDetailToReviewState());
  }

  ///Event for Additional detail screen Create project button.
  FutureOr<void> additionalDetailCreateProjectBtnEvent(
      AdditionalDetailCreateProjectBtnEvent event,
      Emitter<AdditionalDetailState> emit) async {
    ///Database declaration.
    final db = CustomDataBaseWrapper();
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<CreateProjectData?> createProjects =
          await repository.createProject(
        event.objectives,
        event.startDate,
        event.endDate,
        event.clientName,
        event.budget,
        event.knownIssues,
        event.dependencies,
        event.comments,
        event.documents,
        event.feedback,
        event.name,
        event.summary,
        event.currency,
        event.location,
        event.riskFactor,
        event.technologies,
        event.domain,
        event.platforms,
        event.resources,
        event.functionalities,
        event.status,
        event.methodology,
      );
      emit(CreateProjectLoadedState());
      createProjects.when(success: (createdProject) async {
        db.deleteSingleProjectModel(createdProject!);
        emit(AdditionalDetailCreateProjectButtonState(createdProject));
      }, failure: (NetworkExceptions exceptions) async {
        emit(CreateProjectFailedState());
      });
    } on NetworkExceptions catch (_) {}
  }

  ///Event for Additional detail screen Create proposal button.
  FutureOr<void> additionalDetailCreateProposalBtnEvent(
      AdditionalDetailCreateProposalBtnEvent event,
      Emitter<AdditionalDetailState> emit) async {
    ///Database declaration.
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<CreateProposalData?> createProposal =
          await repository.createProposal(
        event.objectives,
        event.proposalReceivedDate,
        event.proposalSubmittedDate,
        event.clientDetails,
        event.budget,
        event.dependencies,
        event.comments,
        event.documents,
        event.feedback,
        event.name,
        event.summery,
        event.currency,
        event.location,
        event.riskFactors,
        event.technologies,
        event.domain,
        event.platforms,
        event.resources,
        event.functionalities,
        event.status,
      );
      createProposal.when(success: (createdProposal) async {
        emit(AdditionalDetailCreateProposalButtonState(createdProposal));
      }, failure: (NetworkExceptions exceptions) async {
        emit(CreateProjectFailedState());
      });
    } on NetworkExceptions catch (_) {}
  }

  ///Event for storing Resources
  FutureOr<void> resourceStoreEvent(
      ResourceStoreEvent event, Emitter<AdditionalDetailState> emit) async {
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<List<ResourcesData?>> resources = await repository.resources(
          event.resourceName, event.resourceEmail, event.designation);
      resources.when(
          success: (resource) {
            emit(ResourceStoreState(resource));
          },
          failure: (NetworkExceptions exceptions) async {});
    } on NetworkExceptions catch (_) {}
  }

  ///Event for Currency dropdown list.
  FutureOr<void> currencyLoadedEvent(
      CurrencyLoadedEvent event, Emitter<AdditionalDetailState> emit) async {
    List<Currencies?> currencies = [
      Currencies(name: "INR", symbol: "₹"),
      Currencies(name: "USD", symbol: "\$"),
      Currencies(name: "EUR", symbol: "€"),
      Currencies(name: "AED", symbol: " د.إ"),
      Currencies(name: "CHF", symbol: "₣"),
      Currencies(name: "RUB", symbol: "₽"),
      Currencies(name: "SGD", symbol: "S\$"),
      Currencies(name: "CNY", symbol: "¥"),
      Currencies(name: "KRW", symbol: "₩"),
      Currencies(name: "JPY", symbol: "¥"),
    ];
    emit(CurrencyLoadedState(currencies));
  }

  ///Event for Location dropdown list.
  FutureOr<void> locationLoadedEvent(
      LocationLoadedEvent event, Emitter<AdditionalDetailState> emit) async {
    List<LocationData?> location = [
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "India"),
      LocationData(
          iso2: "sa", iso3: "as", cities: [], country: "United States"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Finland"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Japan"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Ireland"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Brazil"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Singapore"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "France"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Germany"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Italy"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "Spain"),
      LocationData(iso2: "sa", iso3: "as", cities: [], country: "New Zealand"),
    ];
    emit(LocationLoadedState(location));
  }

  /// Event for the upload document list
  FutureOr<void> uploadDocument(
      UploadDocumentEvent event, Emitter<AdditionalDetailState> emit) async {
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        return emit(UploadDocumentFailedState(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
      }
      ApiResult<List<DocumentsData?>?> userDocument =
          await repository.uploadDocument(event.file);
      userDocument.when(success: (userDocuments) {
        print("print the state $userDocuments!");
        emit(UploadDocumentState((userDocuments)));
        print("print the state2 $userDocuments!");
        print(jsonEncode(userDocument.toString()));
      }, failure: (NetworkExceptions exception) async {
        emit(UploadDocumentFailedState(exception));
      });
    } on NetworkExceptions catch (_) {}
  }
}
