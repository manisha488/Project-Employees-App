import 'dart:io';

import 'package:dio/dio.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:yash_mobility_project_treasure/resources/error_strings.dart';
import 'package:yash_mobility_project_treasure/services/api_response.dart';

part 'network_exceptions.freezed.dart';

@freezed
abstract class NetworkExceptions with _$NetworkExceptions {
  const factory NetworkExceptions.requestCancelledError(String error) =
      RequestCancelledError;

  const factory NetworkExceptions.unauthorizedRequestError(String reason) =
      UnauthorizedRequestError;

  const factory NetworkExceptions.badRequestError(String error) =
      BadRequestError;

  const factory NetworkExceptions.notFoundError(String reason) = NotFoundError;

  const factory NetworkExceptions.methodNotAllowedError(String error) =
      MethodNotAllowedError;

  const factory NetworkExceptions.notAcceptableError(String error) =
      NotAcceptableError;

  const factory NetworkExceptions.requestTimeoutError(String error) =
      RequestTimeoutError;

  const factory NetworkExceptions.sendTimeoutError(String error) =
      SendTimeoutError;

  const factory NetworkExceptions.conflictError(String error) = ConflictError;

  const factory NetworkExceptions.internalServerError(String error) =
      InternalServerError;

  const factory NetworkExceptions.notImplementedError(String error) =
      NotImplementedError;

  const factory NetworkExceptions.serviceUnavailableError(String error) =
      ServiceUnavailableError;

  const factory NetworkExceptions.noInternetConnectionError(String error) =
      NoInternetConnectionError;

  const factory NetworkExceptions.formatExceptionError(String error) =
      FormatExceptionError;

  const factory NetworkExceptions.unableToProcessError(String error) =
      UnableToProcessError;

  const factory NetworkExceptions.defaultError(String error) = DefaultError;

  const factory NetworkExceptions.connectionError(String error) =
      ConnectionError;

  const factory NetworkExceptions.badCertificateError(String error) =
      BadCertificateError;

  const factory NetworkExceptions.badResponseError(String error) =
      BadResponseError;

  const factory NetworkExceptions.unknownError(String error) = UnknownError;

  const factory NetworkExceptions.unexpectedError(String error) =
      UnexpectedError;
  const factory NetworkExceptions.connectionTimeOutError(String error) =
      ConnectionTimeOutError;

  static NetworkExceptions handleResponse(ApiResponse errorResponse) {
    Error? errorModel;
    try {
      errorModel = Error.fromJson(errorResponse.data);
    } catch (e) {}

    int statusCode = errorModel?.status ?? 0;
    switch (statusCode) {
      case 400:
      case 401:
      case 403:
        return NetworkExceptions.unauthorizedRequestError(
            errorModel?.message ?? ErrorStrings().unauthorizedRequest);
      case 404:
        return NetworkExceptions.notFoundError(
            errorModel?.message ?? ErrorStrings().notFound);

      case 409:
        return NetworkExceptions.conflictError(
            errorModel?.message ?? ErrorStrings().conflictError);

      case 408:
        return NetworkExceptions.requestTimeoutError(
            ErrorStrings().requestTimeOut);

      case 500:
        return NetworkExceptions.internalServerError(
            ErrorStrings().internalServerError);

      case 503:
        return NetworkExceptions.serviceUnavailableError(
            ErrorStrings().serviceUnavailable);
      default:
        return NetworkExceptions.defaultError(
            ErrorStrings().somethingWentWrong);
    }
  }

  static NetworkExceptions getNetworkException(error) {
    ApiResponse? errorModel;
    try {
      errorModel = ApiResponse.fromJson(error.response.data);
    } catch (e) {}
    if (error is Exception) {
      try {
        NetworkExceptions networkExceptions;
        if (error is DioException) {
          switch (error.type) {
            case DioExceptionType.cancel:
              networkExceptions = NetworkExceptions.requestCancelledError(
                  errorModel?.error.message ?? ErrorStrings().requestCanceled);
              break;
            case DioExceptionType.connectionTimeout:
              networkExceptions = NetworkExceptions.connectionTimeOutError(
                  errorModel?.error.message ??
                      ErrorStrings().connectionTimeOut);
              break;
            case DioExceptionType.receiveTimeout:
              networkExceptions = NetworkExceptions.requestTimeoutError(
                  errorModel?.error.message ?? ErrorStrings().requestTimeOut);
              break;
            case DioExceptionType.sendTimeout:
              networkExceptions = NetworkExceptions.sendTimeoutError(
                  errorModel?.error.message ?? ErrorStrings().sendTimeOut);
              break;
            case DioExceptionType.badCertificate:
              networkExceptions = NetworkExceptions.badCertificateError(
                  errorModel?.error.message ?? ErrorStrings().badCertificate);
              break;
            case DioExceptionType.connectionError:
              networkExceptions =
                  NetworkExceptions.connectionError(errorModel!.error.message);
              break;
            case DioExceptionType.badResponse:
              networkExceptions = NetworkExceptions.badResponseError(
                  errorModel?.error.message ??
                      ErrorStrings().somethingWentWrong);
              break;
            case DioExceptionType.unknown:
              networkExceptions = NetworkExceptions.unknownError(
                  ErrorStrings().unExpectedError);
              break;
          }
        } else if (error is SocketException) {
          networkExceptions = NetworkExceptions.noInternetConnectionError(
              ErrorStrings().noInternet);
        } else {
          networkExceptions = NetworkExceptions.unexpectedError(
              ErrorStrings().somethingWentWrong);
        }
        return networkExceptions;
      } on FormatException catch (e) {
        return NetworkExceptions.formatExceptionError(
            ErrorStrings().unableToProcessData);
      } catch (_) {
        return NetworkExceptions.unexpectedError(errorModel!.error.message);
      }
    } else {
      if (error.toString().contains("is not a subtype of")) {
        return NetworkExceptions.unableToProcessError(
            errorModel!.error.message);
      } else {
        return NetworkExceptions.unexpectedError(
            ErrorStrings().unExpectedError);
      }
    }
  }

  static String getErrorMessage(NetworkExceptions networkExceptions) {
    var errorMessage = "";
    networkExceptions.when(internalServerError: (String error) {
      errorMessage = ErrorStrings().internalServerError;
    }, serviceUnavailableError: (String error) {
      errorMessage = ErrorStrings().serviceUnavailable;
    }, requestTimeoutError: (String error) {
      errorMessage = ErrorStrings().requestTimeOut;
    }, noInternetConnectionError: (String error) {
      errorMessage = ErrorStrings().noInternet;
    }, formatExceptionError: (String error) {
      errorMessage = ErrorStrings().unableToProcessData;
    }, notFoundError: (String error) {
      errorMessage = ErrorStrings().notFound;
    }, methodNotAllowedError: (String error) {
      errorMessage = ErrorStrings().methodNotAllowed;
    }, badRequestError: (String error) {
      errorMessage = ErrorStrings().badRequest;
    }, unauthorizedRequestError: (String error) {
      errorMessage = ErrorStrings().unauthorizedRequest;
    }, unexpectedError: (String error) {
      errorMessage = ErrorStrings().unExpectedError;
    }, unableToProcessError: (String error) {
      errorMessage = ErrorStrings().unableToProcessData;
    }, connectionError: (String error) {
      errorMessage = ErrorStrings().noInternet;
    }, conflictError: (String error) {
      errorMessage = error ?? ErrorStrings().conflictError;
    }, sendTimeoutError: (String error) {
      errorMessage = error ?? ErrorStrings().sendTimeOut;
    }, badCertificateError: (String error) {
      errorMessage = error ?? ErrorStrings().badCertificate;
    }, badResponseError: (String error) {
      errorMessage = error ?? ErrorStrings().badResponse;
    }, requestCancelledError: (String error) {
      errorMessage = error ?? ErrorStrings().requestCanceled;
    }, notImplementedError: (String error) {
      errorMessage = error ?? ErrorStrings().notImplemented;
    }, notAcceptableError: (String error) {
      errorMessage = error ?? ErrorStrings().notAcceptable;
    }, unknownError: (String error) {
      errorMessage = ErrorStrings().somethingWentWrong;
    }, defaultError: (String error) {
      errorMessage = ErrorStrings().somethingWentWrong;
    }, connectionTimeOutError: (String error) {
      errorMessage = ErrorStrings().connectionTimeOut;
    });
    return errorMessage;
  }
}
