import 'package:dio/dio.dart';
import 'package:yash_mobility_project_treasure/utils/api_constants.dart';

class ApiInterceptor extends Interceptor {
  @override
  Future<dynamic> onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    // check for the token or refresh token
    // store token in shared preferences whenever you get it and update.
    //get token from shared preferences and check. for every API some times we don't require token
    // so that we can list out such api's and accordingly we can add check
    // check if requested API need token in our case every API need token

    //options.headers.addAll({'Authorization': ApiConstants.token});
    options.baseUrl = ApiConstants.baseUrl;
    options.connectTimeout = const Duration(seconds: 10);
    options.receiveTimeout = const Duration(seconds: 10);
    options.sendTimeout = const Duration(seconds: 10);
    // Depends on the API implementation we can add the header here
    // options.headers = {'Content-Type': 'application/json;  charset=UTF-8'};
    super.onRequest(options, handler);
  }

  @override
  Future<dynamic> onResponse(
      Response response, ResponseInterceptorHandler handler) async {
    //you can perform some operations here like updating refresh token in shared preferences.
    return handler.next(response);
  }

  @override
  Future<dynamic> onError(
      DioException err, ErrorInterceptorHandler handler) async {
    return handler.next(err);
  }
}
