part of 'additional_detail_screen_bloc.dart';

@immutable
abstract class AdditionalDetailEvent {}

class AdditionalDetailInitialEvent extends AdditionalDetailEvent {}

///Event for Additional detail Attachment button.
class AdditionalDetailAttachmentBtnEvent extends AdditionalDetailEvent {}

///Event for Additional detail Save button.
class AdditionalDetailSaveBtnEvent extends AdditionalDetailEvent {}

///Event for Navigation from Additional detail screen to Resources detail screen.
class NavigateAdditionalDetailToResourceDetailEvent
    extends AdditionalDetailEvent {}

///Event for Navigation from Additional detail screen to Review screen.
class NavigateAdditionalDetailToReviewEvent extends AdditionalDetailEvent {}

///Event for Additional detail screen Create project button.
class AdditionalDetailCreateProjectBtnEvent extends AdditionalDetailEvent {
  final String? objectives;
  final String? startDate;
  final String? endDate;
  final String? clientName;
  final String? budget;
  final String? knownIssues;
  final String? dependencies;
  final String? comments;
  final dynamic documents;
  final String? feedback;
  final String? name;
  final String? summary;
  final String? currency;
  final String? location;
  final String? riskFactor;
  final dynamic technologies;
  final dynamic domain;
  final dynamic platforms;
  final dynamic resources;
  final dynamic functionalities;
  final dynamic status;
  final dynamic methodology;

  AdditionalDetailCreateProjectBtnEvent(
      {this.objectives,
      this.startDate,
      this.endDate,
      this.clientName,
      this.budget,
      this.knownIssues,
      this.dependencies,
      this.comments,
      this.documents,
      this.feedback,
      this.name,
      this.summary,
      this.currency,
      this.location,
      this.riskFactor,
      this.technologies,
      this.domain,
      this.platforms,
      this.resources,
      this.functionalities,
      this.status,
      this.methodology});
}

///Event for Additional detail screen Create proposal button.
class AdditionalDetailCreateProposalBtnEvent extends AdditionalDetailEvent {
  final String? objectives;
  final String? proposalReceivedDate;
  final String? proposalSubmittedDate;
  final String? clientDetails;
  final String? budget;
  final String? dependencies;
  final String? comments;
  final dynamic documents;
  final String? feedback;
  final String? name;
  final String? summery;
  final String? currency;
  final String? location;
  final String? riskFactors;
  final dynamic technologies;
  final dynamic domain;
  final dynamic platforms;
  final dynamic resources;
  final dynamic functionalities;
  final dynamic status;

  AdditionalDetailCreateProposalBtnEvent({
    this.objectives,
    this.proposalReceivedDate,
    this.proposalSubmittedDate,
    this.clientDetails,
    this.budget,
    this.dependencies,
    this.comments,
    this.documents,
    this.feedback,
    this.name,
    this.summery,
    this.currency,
    this.location,
    this.riskFactors,
    this.technologies,
    this.domain,
    this.platforms,
    this.resources,
    this.functionalities,
    this.status,
  });
}

class ResourceStoreEvent extends AdditionalDetailEvent {
  final int? id;
  final String? resourceName;
  final String? resourceEmail;
  final String? designation;

  ResourceStoreEvent(
      {this.id, this.resourceName, this.resourceEmail, this.designation});
}

///Event for Currency dropdown list.
class CurrencyLoadedEvent extends AdditionalDetailEvent {}

///Event for Location dropdown list.
class LocationLoadedEvent extends AdditionalDetailEvent {}

/// Event for the Upload Document list
class UploadDocumentEvent extends AdditionalDetailEvent {
  List<Map<String, dynamic>> file;
  UploadDocumentEvent({required this.file});
}
