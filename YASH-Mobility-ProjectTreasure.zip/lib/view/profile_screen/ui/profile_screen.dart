import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';

import '../../../components/custom_alert_dialog/custom_alert_dialog.dart';
import '../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../utils/shared_preference_utils.dart';
import '../../login_Screen/ui/login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({required this.database, super.key});
  final Database database;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String? firstName;
  String? lastName;
  String? email;

  ///Database declaration.
  final db = CustomDataBaseWrapper();

  dynamic result;

  @override
  void initState() {
    firstName = SharedPrefs.instance.getString(Constants.userFirstName);
    email = SharedPrefs.instance.getString(Constants.userEmailID);
    super.initState();
  }

  ///Navigate to login screen.
  navigateToLoginPage(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/loginScreen'));
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => LoginScreen(widget.database)));
  }

  /// Method for cancel button
  cancelButtonCallback(BuildContext context) {
    SharedPrefs.instance.setBool(Constants.isUserLoggedIn, false);
    navigateToLoginPage(context);
  }

  /// Method for upload button
  uploadButtonCallback(BuildContext context) {
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: AppColors.white),
        title: Text(
          Strings().profileAppBarTitle,
          style: TextStyle(color: AppColors.white),
        ),
        actions: [
          IconButton(
            onPressed: () {
              showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (BuildContext context) {
                    return CustomDialogBox(
                        title: Strings().dialogTitleLog,
                        description: Strings().dialogDiscriptionLogOut,
                        actionPositive: Strings().positiveButtonSave,
                        actionNegative: Strings().negativeButtonLogout,
                        showTitle: true,
                        showDescription: true,
                        showDialogImage: true,
                        showActionPositive: true,
                        showActionNegative: true,
                        showSingleActionButton: false,
                        buttonTextColor: Colors.black,
                        onPositiveButtonClick: () {
                          uploadButtonCallback(context);
                        },
                        onNegativeButtonClick: () {},
                        actionOnPressed: () {
                          cancelButtonCallback(context);
                        });
                  });
            },
            icon: const Icon(
              Icons.login_outlined,
            ),
          )
        ],
        backgroundColor: AppColors.appBottomNavigationBar,
      ),
      body: SingleChildScrollView(
          child: Column(
        // mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Material(
                elevation: Dimensions.elevation_1,
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.projectCardBorderColor,
                    border: Border.all(
                      color: AppColors.projectCardBorderColor,
                      width: Dimensions.width_2,
                    ),
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: Dimensions.height_10,
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            left: Dimensions.padding_18,
                            right: Dimensions.padding_18),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: Dimensions.borderRadius_40,
                              child: Image.asset('assets/avatar.png'),
                            ),
                            SizedBox(width: Dimensions.width_30),
                            Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "$firstName",
                                    overflow: TextOverflow.clip,
                                    maxLines: Dimensions.maxLine_1,
                                    softWrap: false,
                                    style: TextStyle(
                                      color: AppColors.black,
                                      fontSize: Dimensions.font_18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: Dimensions.height_10),
                                  Text(
                                    "$email",
                                    style: TextStyle(
                                      color: AppColors.black,
                                      fontSize: Dimensions.font_12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: Dimensions.height_10,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: Dimensions.height_20),
            ],
          ),
        ],
      )),
    );
  }
}
