import 'package:freezed_annotation/freezed_annotation.dart';
part 'user_details.freezed.dart';
part 'user_details.g.dart';

@freezed
class UserDetails with _$UserDetails {
  const factory UserDetails(
    String jwt,
    User user,
  ) = _UserDetails;

  factory UserDetails.fromJson(Map<String, dynamic> json) =>
      _$UserDetailsFromJson(json);
}

@freezed
class User with _$User {
  const factory User(
    int id,
    String username,
    String email,
    String provider,
    bool confirmed,
    bool blocked,
    String firstName,
    String lastName,
    String employeeId,
    String createdAt,
    String updatedAt,
    String userRole,
  ) = _User;

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
}
