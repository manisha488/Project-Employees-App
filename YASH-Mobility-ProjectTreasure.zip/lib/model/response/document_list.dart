class DocumentsData {
  int? id;
  String? name;
  String? alternativeText;
  String? caption;
  String? width;
  String? height;
  String? formats;
  String? hash;
  String? ext;
  String? mime;
  double? size;
  String? url;
  String? previewUrl;
  String? provider;
  String? providerMetadata;
  String? createdAt;
  String? updatedAt;

  DocumentsData({
    this.id,
    this.name,
    this.alternativeText,
    this.caption,
    this.width,
    this.height,
    this.formats,
    this.hash,
    this.ext,
    this.mime,
    this.size,
    this.url,
    this.previewUrl,
    this.provider,
    this.providerMetadata,
    this.createdAt,
    this.updatedAt,
  });
  DocumentsData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    name = json['name']?.toString();
    alternativeText = json['alternativeText']?.toString();
    caption = json['caption']?.toString();
    width = json['width']?.toString();
    height = json['height']?.toString();
    formats = json['formats']?.toString();
    hash = json['hash']?.toString();
    ext = json['ext']?.toString();
    mime = json['mime']?.toString();
    size = json['size']?.toDouble();
    url = json['url']?.toString();
    previewUrl = json['previewUrl']?.toString();
    provider = json['provider']?.toString();
    providerMetadata = json['provider_metadata']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['alternativeText'] = alternativeText;
    data['caption'] = caption;
    data['width'] = width;
    data['height'] = height;
    data['formats'] = formats;
    data['hash'] = hash;
    data['ext'] = ext;
    data['mime'] = mime;
    data['size'] = size;
    data['url'] = url;
    data['previewUrl'] = previewUrl;
    data['provider'] = provider;
    data['provider_metadata'] = providerMetadata;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class Documents {
  List<DocumentsData?>? data;

  Documents({
    this.data,
  });
  Documents.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <DocumentsData>[];
      v.forEach((v) {
        arr0.add(DocumentsData.fromJson(v));
      });
      data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}
