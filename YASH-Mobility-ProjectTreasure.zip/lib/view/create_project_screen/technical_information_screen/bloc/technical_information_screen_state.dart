part of 'technical_information_screen_bloc.dart';

@immutable
abstract class TechnicalInformationState {}

class TechnicalInfoInitialState extends TechnicalInformationState {}

class TechnicalInfoActionState extends TechnicalInformationState {}

/// State for Technical information Attachment button.
class TechnicalInfoAttachmentBtnState extends TechnicalInfoActionState {}

/// State for Technical information Save button.
class TechnicalInfoSaveBtnState extends TechnicalInfoActionState {}

///State for Navigation from Technical information screen to Additional detail screen.
class NavigateTechInfoToAdditionalDetailState
    extends TechnicalInfoActionState {}

///State for Platform dropdown list.
class PlatformLoadedState extends TechnicalInfoActionState {
  final List<MultiSelectionFiltersData> platforms;
  PlatformLoadedState(this.platforms);
}

///State for Technology dropdown list.
class TechnologyLoadedState extends TechnicalInfoActionState {
  final List<MultiSelectionFiltersData> techFilters;
  TechnologyLoadedState(this.techFilters);
}

///State for Project Management Methodology dropdown list.
class ProjectMethodologyState extends TechnicalInfoActionState {
  final List<MultiSelectionFiltersData> projectMethodology;
  ProjectMethodologyState(this.projectMethodology);
}

/// State for Internet disconnection.
class InternetDisconnectedState extends TechnicalInfoActionState{
  final NetworkExceptions exceptions;

  InternetDisconnectedState(this.exceptions);
}
