import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';

/// This class defines the custom dialog box with bellow properties.
class CustomDialogBox extends StatefulWidget {
  final String? title;
  final String? description;
  final String? actionPositive;
  final String? actionNegative;
  final bool showTitle;
  final bool showDescription;
  final bool showDialogImage;
  final bool showActionPositive;
  final bool showActionNegative;
  final bool showSingleActionButton;
  final Color? textColor;
  final Color? buttonBgColor;
  final Color? buttonTextColor;
  final Function() onPositiveButtonClick;
  final Function() onNegativeButtonClick;
  final Function() actionOnPressed;

  const CustomDialogBox(
      {super.key,
      this.title,
      this.description,
      this.actionPositive,
      this.actionNegative,
      required this.showTitle,
      required this.showDescription,
      required this.showDialogImage,
      required this.showActionPositive,
      required this.showActionNegative,
      required this.showSingleActionButton,
      this.textColor,
      this.buttonBgColor,
      this.buttonTextColor,
      required this.onPositiveButtonClick,
      required this.onNegativeButtonClick,
      required this.actionOnPressed});

  @override
  State<CustomDialogBox> createState() => _CustomDialogBoxState();
}

class _CustomDialogBoxState extends State<CustomDialogBox> {
  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      child: Dialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Dimensions.borderRadius_10)),
        elevation: Dimensions.elevation_0,
        backgroundColor: Colors.transparent,
        child: contentBox(context), // custom dialog view
      ),
    );
  }

  contentBox(context) {
    ///return dialog with title, description, yes-no button and ok button
    ///visibility widget added to set the visibility to widget.
    return Stack(
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(
              left: Dimensions.padding_16,
              top: Dimensions.padding_21,
              bottom: Dimensions.padding_21),
          decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: Colors.white,
              borderRadius: BorderRadius.circular(Dimensions.borderRadius_10),
              boxShadow: [
                BoxShadow(
                    color: Colors.black38,
                    offset: Offset(Dimensions.offset_0, Dimensions.offset_0),
                    blurRadius: Dimensions.borderRadius_10,
                    blurStyle: BlurStyle.solid)
              ]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (widget.showTitle)
                Visibility(
                  child: Text(
                    widget.title!,
                    style: TextStyle(
                      fontSize: Dimensions.font_24,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              if (widget.showTitle)
                Visibility(
                    child: SizedBox(
                  height: Dimensions.height_15,
                )),
              if (widget.showDescription)
                Visibility(
                  child: Text(
                    widget.description!,
                    style: TextStyle(
                      fontSize: Dimensions.font_14,
                      fontStyle: FontStyle.normal,
                    ),
                  ),
                ),
              SizedBox(
                height: Dimensions.height_22,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  if (widget.showActionPositive)
                    Visibility(
                      child: InkWell(
                        onTap: widget.onPositiveButtonClick,
                        child: Text(
                          widget.actionPositive!,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.createProjectAppBarColor),
                        ),
                      ),
                    ),
                  SizedBox(
                    width: Dimensions.width_5,
                  ),
                  // When dialog with single button required, use this button.
                  if (widget.showActionNegative)
                    Visibility(
                      child: ElevatedButton(
                        onPressed: widget.actionOnPressed,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.createProjectAppBarColor
                        ),
                        child: Text(
                          widget.actionNegative!,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.white),
                        ),
                      ),
                    )
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
