import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:yash_mobility_project_treasure/components/custom_alert_dialog/custom_alert_dialog.dart';
import 'package:yash_mobility_project_treasure/components/custom_textfield/custom_text_form_field.dart';
import 'package:yash_mobility_project_treasure/components/drop_DownList/dropdownlist.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/regex.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/resource_detail_screen/bloc/resource_detail_screen_bloc.dart';
import '../../../../model/MultiSelectionFilters.dart';
import '../../../../model/response/resource_model_list.dart';

class ResourceDetailScreen extends StatefulWidget {
  const ResourceDetailScreen(this.currentIndex, {super.key});

  final int currentIndex;

  @override
  State<ResourceDetailScreen> createState() => _ResourceDetailScreenState();
}

class _ResourceDetailScreenState extends State<ResourceDetailScreen> {
  /// Form key for validation.
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  ///Form key for clearing selection for dropdown list.
  GlobalKey<CustomDropDownState> customDropDownKey =
      GlobalKey<CustomDropDownState>();

  String ddValue = '';

  bool isProject = false;
  bool isButtonEnabled = false;
  bool isSaved = false;
  bool isDropdownOpened = false;
  bool designationDropdownOpened = false;
  List<String> designationName = [];
  List<MultiSelectionFiltersData> designationList = [];
  List<ResourcesData> resourceDetails = [];
  List<String> resourceNames =
      SharedPrefs.instance.getStringList('resourceNames') ?? [];

  ///Create Project Resource Screen Controllers
  final TextEditingController resourceNameController = TextEditingController();
  final TextEditingController resourceDesignationController =
      TextEditingController();
  final TextEditingController resourceEmailAddressController =
      TextEditingController();

  final ResourceDetailScreenBloc resourceDetailScreenBloc =
      ResourceDetailScreenBloc();

  /// Screen size function.
  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  void returnResourceDetails(BuildContext context) {
    setState(() {
      resourceDetails.add(ResourcesData(
          resourceName: resourceNameController.text,
          resourceEmail: resourceEmailAddressController.text,
          designation: resourceDesignationController.text));

      resourceNameController.clear();
      resourceDesignationController.clear();
      resourceEmailAddressController.clear();
    });
  }

  ///Button enable & disable function.
  void _checkButtonStatus() {
    setState(() {
      if (resourceNameController.text.isNotEmpty &&
          resourceDesignationController.text.isNotEmpty &&
          resourceEmailAddressController.text.isNotEmpty) {
        isButtonEnabled = true;
      } else {
        isButtonEnabled = false;
        isSaved = false;
      }
    });
  }

  @override
  void dispose() {
    resourceNameController.dispose();
    resourceDesignationController.dispose();
    resourceEmailAddressController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    setState(() {
      /// State for Designation dropdown list.
      resourceDetailScreenBloc.add(DesignationLoadedEvent());
    });

    resourceNameController.addListener(_checkButtonStatus);
    resourceDesignationController.addListener(_checkButtonStatus);
    resourceEmailAddressController.addListener(_checkButtonStatus);

    var t = SharedPrefs.instance.getString(Constants.resourceDetailDraft);
    if (t != null && t != "{}"){
      Map<String, dynamic> u ;
      List<dynamic> list = jsonDecode(t);
      List<Map<String, dynamic>> storedItems = [];
      for (var i = 0; i < list.length; i++) {
        storedItems.add(list[i]);
      }
      u = {"data" : storedItems};
      for(var i = 0; i< storedItems.length; i++) {
        resourceDetails.add(ResourcesData.fromJson(u['data'][i]));

      }
    }

    if (widget.currentIndex == 0) {
      isProject = true;
    } else {
      isProject = false;
    }
    super.initState();
  }

  void clearDropdownSelection() {
    setState(() {
      isDropdownOpened = false;
    });

    resourceDesignationController.text = '';
  }

  void navigateToAdditionalScreen(BuildContext context) {
    Navigator.of(context)
        .popUntil(ModalRoute.withName('/additionDetailScreen'));
  }

  @override
  Widget build(BuildContext context) {
    void positiveButtonCallback() {
      Navigator.pop(context);
      Navigator.pop(context, resourceDetails);
      SharedPrefs.instance.setString(Constants.resourceDetailDraft, jsonEncode(resourceDetails));
    }

    // listener for negative button
    void negativeButtonCallback() {
      navigateToAdditionalScreen(context);
    }

    // listener for single button
    void actionSingleButtonCallback() {
      navigateToAdditionalScreen(context);
    }

    CustomDialogBox dialog() {
      return CustomDialogBox(
        title: "Save Resources?",
        description: "Resources are not saved.\nYou want to save it?",
        actionPositive: 'Yes',
        actionNegative: 'No',
        showTitle: true,
        showDescription: true,
        showDialogImage: true,
        showActionPositive: true,
        showActionNegative: true,
        showSingleActionButton: false,
        buttonTextColor: Colors.black,
        onPositiveButtonClick: positiveButtonCallback,
        onNegativeButtonClick: negativeButtonCallback,
        actionOnPressed: actionSingleButtonCallback,
      );
    }

    /// Bloc implementation.
    return BlocConsumer<ResourceDetailScreenBloc, ResourceDetailState>(
      bloc: resourceDetailScreenBloc,
      listenWhen: (previous, current) => current is ResourceDetailActionState,
      buildWhen: (previous, current) => current is! ResourceDetailActionState,
      listener: (context, state) {
        /// State for Resource detail Save button.
        if (state is ResourceDetailSaveBtnState) {
          if (resourceDetails.isNotEmpty) {
            isSaved = true;
            SharedPrefs.instance.setString(Constants.resourceDetailDraft, jsonEncode(resourceDetails));
            Navigator.pop(context, resourceDetails);
          } else {
            isSaved = false;
            return;
          }
        }

        /// State for Designation dropdown list.
        else if (state is DesignationLoadedState) {
          List<MultiSelectionFiltersData> jsonFilterDesignation =
              state.designationFilter;
          designationList.addAll(jsonFilterDesignation);
        }

        /// State for Resource detail Add button.
        else if (state is ResourceDetailAddBtnState) {
          setState(() {
            if (_formKey.currentState!.validate()) {
              FocusScope.of(context).requestFocus(FocusNode());
              returnResourceDetails(context);
              customDropDownKey.currentState?.clearSelection();
            }
          });
        }
      },
      builder: (context, state) {
        return WillPopScope(
          onWillPop: () async {
            if (isSaved == false && resourceDetails.isNotEmpty) {
              showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (BuildContext context) {
                    return dialog();
                  });
              return true;
            } else {
              Navigator.pop(context);
              return false;
            }
          },
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: AppColors.createProjectAppBarColor,
              iconTheme: IconThemeData(color: AppColors.white),
              title: Text(
                Strings().resourceDetailTitle,
                style: TextStyle(color: AppColors.white),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    /// State for Resource detail Save button.
                    resourceDetailScreenBloc.add(ResourceDetailSaveBtnEvent());
                  },
                  child: Text(
                    Strings().multiDialogSaveButtonTitle,
                    style: TextStyle(color: AppColors.white),
                  ),
                ),
              ],
            ),
            body: GestureDetector(
              onTap: () {
                setState(() {
                  isDropdownOpened = false;
                  designationDropdownOpened = false;
                });
                FocusScope.of(context).requestFocus(FocusNode());
              },
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Padding(
                    padding: EdgeInsets.all(Dimensions.padding_16),
                    child: Column(
                      children: [
                        CustomTextField(
                          onTapped: () {
                            setState(() {
                              isDropdownOpened = false;
                              designationDropdownOpened = false;
                            });
                          },
                          textCapitalization: TextCapitalization.words,
                          keyboardType: TextInputType.text,
                          textEditingController: resourceNameController,
                          labelText: Strings().textFieldResourceName,
                          regEx: RegExp("[a-zA-Zá-úÁ-Ú ]"),
                        ),
                        SizedBox(height: Dimensions.height_16),
                        resourcesDropdown(),
                        SizedBox(height: Dimensions.height_16),
                        CustomTextField(
                          onTapped: () {
                            setState(() {
                              isDropdownOpened = false;
                              designationDropdownOpened = false;
                            });
                          },
                          textEditingController: resourceEmailAddressController,
                          keyboardType: TextInputType.emailAddress,
                          labelText: Strings().textFieldResourceEmailAddress,
                          isCapitalised: false,
                          validator: (value) {
                            RegExp regexp = RegEx().emailRegEx;
                            if (value!.isEmpty) {
                              return ("Please enter your Email");
                            }
                            if (!regexp.hasMatch(value)) {
                              return ("Please enter valid Email.");
                            }
                            return null;
                          },
                          onSaved: (value) {
                            resourceEmailAddressController.text = value!;
                          },
                          regEx: RegExp("[a-zA-Zá-úÁ-Ú@_.]"),
                        ),
                        SizedBox(height: Dimensions.height_16),
                        SizedBox(
                          height: Dimensions.height_40,
                          width: getSize(context).width,
                          child: ElevatedButton(
                            onPressed: isButtonEnabled
                                ? () {
                                    /// State for Resource detail Add button.
                                    resourceDetailScreenBloc
                                        .add(ResourceDetailAddBtnEvent());
                                  }
                                : null,
                            style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.resolveWith<Color?>(
                                (Set<MaterialState> states) {
                                  if (states.contains(MaterialState.disabled)) {
                                    return AppColors.nextButtonColor;
                                  }
                                  return AppColors.createProjectAppBarColor;
                                },
                              ),
                            ),
                            child: Text(
                              Strings().addResourceButtonTitle,
                              style: TextStyle(
                                  color: AppColors.white,
                                  fontSize: Dimensions.font_14),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: Dimensions.height_16,
                        ),
                        if (resourceDetails.isNotEmpty)
                          Container(
                            height: MediaQuery.of(context).size.height *
                                Dimensions.height0_4,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(Dimensions.borderRadius_20)),
                            ),
                            child: ListView(
                                scrollDirection: Axis.vertical,
                                children: [
                                  Column(
                                    children: resourceDetails.map((e) {
                                      return Column(
                                        children: [
                                          Container(
                                            width: getSize(context).width,
                                            decoration: BoxDecoration(
                                              color:
                                                  AppColors.itemBodyButtonColor,
                                              border: Border.all(
                                                  color: AppColors
                                                      .itemBorderButtonColor),
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      Dimensions
                                                          .borderRadius_5),
                                            ),
                                            child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  Dimensions.padding_8,
                                                  Dimensions.padding_8,
                                                  Dimensions.padding_0,
                                                  Dimensions.padding_8),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Flexible(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          '${e.resourceName} ',
                                                          style: TextStyle(
                                                              fontSize:
                                                                  Dimensions
                                                                      .font_16),
                                                        ),
                                                        SizedBox(
                                                          height: Dimensions
                                                              .height_4,
                                                        ),
                                                        Text(
                                                          '${e.designation}',
                                                          style: TextStyle(
                                                              fontSize:
                                                                  Dimensions
                                                                      .font_16),
                                                        ),
                                                        SizedBox(
                                                          height: Dimensions
                                                              .height_4,
                                                        ),
                                                        Text(
                                                          e.resourceEmail ??
                                                              " ",
                                                          style: TextStyle(
                                                              fontSize:
                                                                  Dimensions
                                                                      .font_12),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  IconButton(
                                                    onPressed: () {
                                                      setState(() {
                                                        resourceDetails
                                                            .remove(e);
                                                        SharedPrefs.instance.setString(Constants.resourceDetailDraft, jsonEncode(resourceDetails));
                                                      });
                                                    },
                                                    icon: Icon(
                                                      Icons.cancel_outlined,
                                                      color: AppColors
                                                          .createProjectAppBarColor,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Dimensions.height_8,
                                          )
                                        ],
                                      );
                                    }).toList(),
                                  ),
                                ]),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget resourcesDropdown() {
    return BlocProvider(
      create: (_) => resourceDetailScreenBloc,
      child: BlocListener<ResourceDetailScreenBloc, ResourceDetailState>(
        listener: (context, state) {},
        child: BlocBuilder<ResourceDetailScreenBloc, ResourceDetailState>(
          builder: (context, state) {
            return CustomDropDown(
              isTitleCase: true,
              isCapitalize: false,
              key: customDropDownKey,
              dropdownValue: ddValue,
              controller: resourceDesignationController,
              onTapped: () {
                FocusScope.of(context).requestFocus(FocusNode());
                setState(() {
                  isDropdownOpened = false;
                  designationDropdownOpened = !designationDropdownOpened;
                });
              },
              list: const [],
              wlist: designationList,
              title: Strings().textFieldResourceDesignation.toTitleCase(),
              onChanged: (selectedItem) {
                resourceDesignationController.text = selectedItem ?? "";
                designationDropdownOpened = false;
              },
              dbkey: "resources",
              isStretchedDropDown: designationDropdownOpened,
            );
          },
        ),
      ),
    );
  }
}
