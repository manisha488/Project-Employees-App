part of 'review_screen_bloc.dart';

@immutable
abstract class ReviewEvent {}

class ReviewInitialEvent extends ReviewEvent {}

/// Event for Review screen Attachment button.
class ReviewAttachmentBtnEvent extends ReviewEvent {}

/// Event for Review screen Save button.
class ReviewSaveDraftBtnEvent extends ReviewEvent {}

/// Event for Review screen Basic detail Edit button.
class ReviewBasicDetailEditBtnEvent extends ReviewEvent {}

/// Event for Review screen Basic detail Expand button.
class ReviewBasicDetailExpandBtnEvent extends ReviewEvent {}

/// Event for Review screen Technical information Edit button.
class ReviewTechnicalInfoEditBtnEvent extends ReviewEvent {}

/// Event for Review screen Technical information Expand button.
class ReviewTechnicalInfoExpandBtnEvent extends ReviewEvent {}

/// Event for Review screen Additional detail Edit button.
class ReviewAdditionalDetailEditBtnEvent extends ReviewEvent {}

/// Event for Review screen Additional detail Expand button
class ReviewAdditionalDetailExpandBtnEvent extends ReviewEvent {}

/// Event for Review screen Create project button.
class ReviewCreateProjectBtnEvent extends ReviewEvent {
  final String? objectives;
  final String? startDate;
  final String? endDate;
  final String? clientName;
  final String? budget;
  final String? knownIssues;
  final String? dependencies;
  final String? comments;
  final dynamic documents;
  final String? feedback;
  final String? name;
  final String? summary;
  final String? currency;
  final String? location;
  final String? riskFactor;
  final dynamic technologies;
  final dynamic domain;
  final dynamic platforms;
  final dynamic resources;
  final dynamic functionalities;
  final dynamic status;
  final dynamic methodology;

  ReviewCreateProjectBtnEvent(
      {this.objectives,
      this.startDate,
      this.endDate,
      this.clientName,
      this.budget,
      this.knownIssues,
      this.dependencies,
      this.comments,
      this.documents,
      this.feedback,
      this.name,
      this.summary,
      this.currency,
      this.location,
      this.riskFactor,
      this.technologies,
      this.domain,
      this.platforms,
      this.resources,
      this.functionalities,
      this.status,
      this.methodology});
}

///Event for Review screen Create Proposal button.
class ReviewCreateProposalBtnEvent extends ReviewEvent {
  final String? objectives;
  final String? proposalReceivedDate;
  final String? proposalSubmittedDate;
  final String? clientDetails;
  final String? budget;
  final String? dependencies;
  final String? comments;
  final dynamic documents;
  final String? feedback;
  final String? name;
  final String? summery;
  final String? currency;
  final String? location;
  final String? riskFactors;
  final dynamic technologies;
  final dynamic domain;
  final dynamic platforms;
  final dynamic resources;
  final dynamic functionalities;
  final dynamic status;

  ReviewCreateProposalBtnEvent({
    this.objectives,
    this.proposalReceivedDate,
    this.proposalSubmittedDate,
    this.clientDetails,
    this.budget,
    this.dependencies,
    this.comments,
    this.documents,
    this.feedback,
    this.name,
    this.summery,
    this.currency,
    this.location,
    this.riskFactors,
    this.technologies,
    this.domain,
    this.platforms,
    this.resources,
    this.functionalities,
    this.status,
  });
}

class PostDataEvent extends ReviewEvent {
  final Map<String, dynamic> data;

  PostDataEvent(this.data);
}

class ResourceStoreEvent extends ReviewEvent {
  final int? id;
  final String? resourceName;
  final String? resourceEmail;
  final String? designation;

  ResourceStoreEvent(
      {this.id, this.resourceName, this.resourceEmail, this.designation});
}

/// Event for the Upload Document list
class UploadDocumentEvent extends ReviewEvent {
  List<Map<String, dynamic>> file;
  UploadDocumentEvent({required this.file});
}
