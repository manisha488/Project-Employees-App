import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/resource_detail.dart';

class ProposalDetails {
  String? proposalId;
  late String? proposalName;
  late String? proposalDomain;
  late String? proposalObjective;
  late String? proposalSummary;
  late String? proposalDescription;
  late List<MultiSelectionFiltersData?>? proposalFunctionality;
  late String? proposalStartDate;
  late String? proposalEndDate;
  late String? proposalStatus;
  late List<MultiSelectionFiltersData?>? proposalPlatform;
  late List<MultiSelectionFiltersData?>? proposalTechnology;
  late String? proposalRiskFactor;
  late String? proposalDependencies;
  late String? proposalClientName;
  late String? proposalCurrency;
  late String? proposalCost;
  late String? proposalClientLocation;
  late List<ResourceDetails>? proposalResources;
  late String? proposalComment;
  late String? proposalFeedback;
  late String? proposalDocument;

  ProposalDetails({
    this.proposalId,
    this.proposalName,
    this.proposalDomain,
    this.proposalObjective,
    this.proposalSummary,
    this.proposalDescription,
    this.proposalFunctionality,
    this.proposalStartDate,
    this.proposalEndDate,
    this.proposalStatus,
    this.proposalPlatform,
    this.proposalTechnology,
    this.proposalRiskFactor,
    this.proposalDependencies,
    this.proposalClientName,
    this.proposalCurrency,
    this.proposalCost,
    this.proposalClientLocation,
    this.proposalResources,
    this.proposalComment,
    this.proposalFeedback,
    this.proposalDocument,
  });
}
