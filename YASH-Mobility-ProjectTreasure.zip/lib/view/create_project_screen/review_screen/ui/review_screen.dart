import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_alert_dialog/custom_alert_dialog.dart';
import 'package:yash_mobility_project_treasure/model/response/create_project_model_list.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/display_message_utils.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/statusColorUtils.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/basic_details_screen/ui/basic_details_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/review_screen/bloc/review_screen_bloc.dart';

import '../../../../components/custom_alert_dialog/dialog.dart';
import '../../../../components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/resource_model_list.dart';
import '../../../../services/network_exceptions.dart';
import '../../../../utils/constants.dart';
import '../../additional_details_screen/ui/aditional_details_screen.dart';
import '../../create_project_screen/ui/create_project_screen.dart';
import '../../technical_information_screen/ui/technical_information_screen.dart';

final GlobalKey<State> _keyLoader = GlobalKey<State>();

class ReviewScreen extends StatefulWidget {
  const ReviewScreen(
      this.currentIndex,
      this.projectName,
      this.additionalDetailDraft,
      this.draftSelected,
      this.additionalDetailScreen,
      {required this.isProject,
      super.key, required this.database});

  final int currentIndex;
  final String projectName;
  final bool additionalDetailDraft;
  final bool draftSelected;
  final bool isProject;
  final bool additionalDetailScreen;
  final Database database;

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  dynamic project;
  bool isProject = false;
  bool isReviewScreen = false;
  List<ResourcesData?> resourceDetail = [];
  dynamic document;
  bool basicDetailDraft = false;
  bool technicalDetailDraft = false;
  bool isBasicScreen = false;
  bool isTechnicalScreen = false;
  bool isExpandedBasicDetails = false;
  bool isExpandedTechnicalInfo = false;
  bool isExpandedAdditionalDetails = false;
  dynamic resultProjects;
  dynamic resultProposals;
  int id = 1;
  String name = "";
  String domain = "";
  String objective = "";
  String summery = "";
  List<CreateProjectDataAttributesFunctionalitiesData?>? functionalityProject =
      [];
  List<CreateProposalDataAttributesFunctionalitiesData?>?
      functionalityProposal = [];
  String startDate = "";
  String? endDate;
  String status = " ";
  String platformProjectName = " ";
  String technologyProjectName = " ";
  List<CreateProjectDataAttributesPlatformsData?>? platformProject = [];
  List<CreateProposalDataAttributesPlatformsData?>? platformProposal = [];
  List<CreateProjectDataAttributesTechnologiesData?>? technologyProject = [];
  List<CreateProposalDataAttributesTechnologiesData?>? technologyProposal = [];
  List<CreateProjectDataAttributesResourcesData?>? resourcesProject = [];
  List<CreateProposalDataAttributesResourcesData?>? resourcesProposal = [];
  String dependency = "";
  String clientName = "";
  String budget = "";
  String currency = "";
  String location = "";
  String comments = "";
  String feedback = "";
  String riskFactor = "";
  String riskFactors = "";
  String knownIssues = "";
  String methodology = "";
  dynamic draftFunctionality;
  dynamic draftPlatform;
  dynamic draftTechnology;
  dynamic draftDomain;
  dynamic draftStatus;
  dynamic draftMethodology;
  dynamic draftResource;

  ///Database declaration.
  final db = CustomDataBaseWrapper();

  ///Create Project Additional Detail Controllers
  final TextEditingController clientNameController = TextEditingController();
  final TextEditingController currencyController = TextEditingController();
  final TextEditingController projectBudgetController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController resourceNameController = TextEditingController();
  final TextEditingController resourceDesignationController =
      TextEditingController();
  final TextEditingController resourceEmailAddressController =
      TextEditingController();
  final TextEditingController commentController = TextEditingController();
  final TextEditingController projectFeedbackController =
      TextEditingController();

  ///Create Proposal Additional Detail Controllers

  final TextEditingController proposalClientNameController =
      TextEditingController();
  final TextEditingController proposalCurrencyController =
      TextEditingController();
  final TextEditingController proposalBudgetController =
      TextEditingController();
  final TextEditingController proposalLocationController =
      TextEditingController();
  final TextEditingController proposalResourceNameController =
      TextEditingController();
  final TextEditingController proposalResourceDesignationController =
      TextEditingController();
  final TextEditingController proposalResourceEmailAddressController =
      TextEditingController();
  final TextEditingController proposalCommentController =
      TextEditingController();
  final TextEditingController proposalFeedbackController =
      TextEditingController();

  /// Review Screen Bloc declaration.
  final ReviewScreenBloc reviewScreenBloc = ReviewScreenBloc();

  @override
  void initState() {
    if (widget.isProject) {
      isProject = true;
      db.getSpecificProjectsList(widget.projectName);
      getData();
    } else {
      isProject = false;
      db.getSpecificProposalList(widget.projectName);
      getData();
    }
    super.initState();
  }

  ///Screen size function.
  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  /// Navigation to Home Screen.
  void navigateToHomeScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/homeScreen'));
  }

  void getData() async {
    if (widget.isProject) {
      resultProjects = await db.getSpecificProjectsList(widget.projectName);
      setState(() {
        int index = resultProjects.length;
        for (int i = 0; i < index; i++) {
          setState(() {
            List<Map<String, dynamic>> mapFun = [];
            List<Map<String, dynamic>> mapPlat = [];
            List<Map<String, dynamic>> mapTech = [];
            List<Map<String, dynamic>> mapDomain = [];
            List<Map<String, dynamic>> mapStatus = [];
            List<Map<String, dynamic>> mapMeth = [];

            id = 0;
            name = resultProjects[i].attributes!.name!;
            domain =
                resultProjects[i].attributes!.domain!.data!.attributes!.name!;
            Map<String, dynamic> uDomain = {};
            setState(() {
              uDomain = {"id": resultProjects[i].attributes!.domain!.data!.id};
              mapDomain.add(uDomain);
            });
            draftDomain = mapDomain;
            objective = resultProjects[i].attributes!.objectives!;
            summery = resultProjects[i].attributes!.summary!;
            functionalityProject =
                resultProjects[i].attributes!.functionalities!.data!;

            Map<String, dynamic> uFun = {};
            for (var j = 0;
                j < resultProjects[i].attributes!.functionalities!.data!.length;
                j++) {
              setState(() {
                uFun = {
                  "id": resultProjects[i]
                      .attributes!
                      .functionalities!
                      .data![j]!
                      .id
                };
                mapFun.add(uFun);
              });
            }
            draftFunctionality = mapFun;
            startDate = resultProjects[i].attributes!.startDate!;
            endDate = resultProjects[i].attributes!.endDate;
            status =
                resultProjects[i].attributes!.status!.data!.attributes!.name!;
            Map<String, dynamic> uStatus = {};
            setState(() {
              uStatus = {"id": resultProjects[i].attributes!.status!.data!.id};
              mapStatus.add(uStatus);
            });
            draftStatus = mapStatus;

            platformProject = resultProjects[i].attributes!.platforms!.data;
            if (platformProject != null) {
              platformProjectName = resultProjects[i]
                  .attributes!
                  .platforms!
                  .data![i]!
                  .attributes!
                  .name!;
              Map<String, dynamic> uPlat = {};
              for (var j = 0;
                  j < resultProjects[i].attributes!.platforms!.data!.length;
                  j++) {
                setState(() {
                  uPlat = {
                    "id": resultProjects[i].attributes!.platforms!.data![j]!.id
                  };
                  mapPlat.add(uPlat);
                });
              }
              draftPlatform = mapPlat;
            }

            technologyProject =
                resultProjects[i].attributes!.technologies!.data;
            if (technologyProject != null) {
              technologyProjectName = resultProjects[i]
                  .attributes!
                  .technologies!
                  .data![i]!
                  .attributes!
                  .name!;
              Map<String, dynamic> uTech = {};
              for (var j = 0;
                  j < resultProjects[i].attributes!.technologies!.data!.length;
                  j++) {
                setState(() {
                  uTech = {
                    "id":
                        resultProjects[i].attributes!.technologies!.data![j]!.id
                  };
                  mapTech.add(uTech);
                });
              }
              draftTechnology = mapTech;
            }

            if (resultProjects[i].attributes!.methodology!.data != null) {
              methodology = resultProjects[i]
                  .attributes!
                  .methodology!
                  .data!
                  .attributes!
                  .name!;

              Map<String, dynamic> uMeth = {};
              setState(() {
                uMeth = {
                  "id": resultProjects[i].attributes!.methodology!.data!.id
                };
                mapMeth.add(uMeth);
              });
              draftMethodology = mapMeth;
            }
            document = resultProjects[i].attributes!.documents;
            currency = resultProjects[i].attributes!.currency!;
            location = resultProjects[i].attributes!.location!;
            draftResource = resultProjects[i].attributes!.resources;
            if (draftResource.data != null) {
              SharedPrefs.instance.setString(
                  Constants.resourceDetailDraft, jsonEncode(draftResource));
            }
            var res =
                SharedPrefs.instance.getString(Constants.resourceDetailDraft);
            if (res != null) {
              List<ResourcesData> storedItems = [];
              ResourcesData y = ResourcesData();
              if (draftResource.data != null) {
                for (var j = 0; j < draftResource.data!.length; j++) {
                  setState(() {
                    y.id = draftResource.data![i]!.id;
                    y.designation =
                        draftResource.data![i]!.attributes!.designation;
                    y.resourceEmail =
                        draftResource.data![i]!.attributes!.resourceEmail;
                    y.resourceName =
                        draftResource.data![i]!.attributes!.resourceName;
                    storedItems.add(y);
                  });
                }
                resourceDetail = storedItems;
              }
            }
            comments = resultProjects[i].attributes!.comments!;
            feedback = resultProjects[i].attributes!.feedback!;
            riskFactor = resultProjects[i].attributes!.riskFactor!;
            knownIssues = resultProjects[i].attributes!.knownIssues!;
            dependency = resultProjects[i].attributes!.dependencies!;
            clientName = resultProjects[i].attributes!.clientName!;
            budget = resultProjects[i].attributes!.budget!;
          });
          SharedPrefs.instance
              .setString('functionality', jsonEncode(functionalityProject));
          if (platformProject != null) {
            SharedPrefs.instance
                .setString('platforms', jsonEncode(platformProject));
          }
          if (technologyProject != null) {
            SharedPrefs.instance
                .setString('technologies', jsonEncode(technologyProject));
          }
        }
      });
    } else {
      resultProposals = await db.getSpecificProposalList(widget.projectName);
      List<Map<String, dynamic>> mapFun = [];
      List<Map<String, dynamic>> mapPlat = [];
      List<Map<String, dynamic>> mapTech = [];
      List<Map<String, dynamic>> mapDomain = [];
      List<Map<String, dynamic>> mapStatus = [];
      int index = resultProposals.length;
      for (int i = 0; i < index; i++) {
        setState(() {
          id = 0;
          name = resultProposals[i].attributes!.name!;
          domain =
              resultProposals[i].attributes!.domain!.data!.attributes!.name!;
          Map<String, dynamic> uDomain = {};
          setState(() {
            uDomain = {"id": resultProposals[i].attributes!.domain!.data!.id};
            mapDomain.add(uDomain);
          });
          draftDomain = mapDomain;
          objective = resultProposals[i].attributes!.objectives!;
          summery = resultProposals[i].attributes!.summery!;
          functionalityProposal =
              resultProposals[i].attributes!.functionalities!.data!;

          Map<String, dynamic> uFun = {};
          for (var j = 0;
              j < resultProposals[i].attributes!.functionalities!.data!.length;
              j++) {
            setState(() {
              uFun = {
                "id":
                    resultProposals[i].attributes!.functionalities!.data![j]!.id
              };
              mapFun.add(uFun);
            });
          }
          draftFunctionality = mapFun;

          startDate = resultProposals[i].attributes!.proposalReceivedDate!;
          endDate = resultProposals[i].attributes!.proposalSubmittedDate;
          status =
              resultProposals[i].attributes!.status!.data!.attributes!.name!;
          Map<String, dynamic> uStatus = {};
          setState(() {
            uStatus = {"id": resultProposals[i].attributes!.status!.data!.id};
            mapStatus.add(uStatus);
          });
          draftStatus = mapStatus;
          platformProposal = resultProposals[i].attributes!.platforms!.data;
          if (platformProposal != null) {
            Map<String, dynamic> uPlat = {};
            for (var j = 0;
                j < resultProposals[i].attributes!.platforms!.data!.length;
                j++) {
              setState(() {
                uPlat = {
                  "id": resultProposals[i].attributes!.platforms!.data![j]!.id
                };
                mapPlat.add(uPlat);
              });
            }
            draftPlatform = mapPlat;
          }

          technologyProposal =
              resultProposals[i].attributes!.technologies!.data;
          if (technologyProposal != null) {
            Map<String, dynamic> uTech = {};
            for (var j = 0;
                j < resultProposals[i].attributes!.technologies!.data!.length;
                j++) {
              setState(() {
                uTech = {
                  "id":
                      resultProposals[i].attributes!.technologies!.data![j]!.id
                };
                mapTech.add(uTech);
              });
            }
            draftTechnology = mapTech;
          }
          draftResource = resultProposals[i].attributes!.resources;

          // resourcesProposal = resultProposals[i].attributes!.resources!.data!;
          currency = resultProposals[i].attributes!.currency!;
          location = resultProposals[i].attributes!.location!;

          draftResource = resultProposals[i].attributes!.resources;

          SharedPrefs.instance.setString(
              Constants.resourceDetailDraft, jsonEncode(draftResource));

          var res =
              SharedPrefs.instance.getString(Constants.resourceDetailDraft);
          if (res != null) {
            List<ResourcesData> storedItems = [];
            ResourcesData y = ResourcesData();
            if (draftResource.data != null) {
              for (var j = 0; j < draftResource.data!.length; j++) {
                setState(() {
                  y.id = draftResource.data![i]!.id;
                  y.designation =
                      draftResource.data![i]!.attributes!.designation;
                  y.resourceEmail =
                      draftResource.data![i]!.attributes!.resourceEmail;
                  y.resourceName =
                      draftResource.data![i]!.attributes!.resourceName;
                  storedItems.add(y);
                });
              }
              resourceDetail = storedItems;
            }
          }

          comments = resultProposals[i].attributes!.comments!;
          feedback = resultProposals[i].attributes!.feedback!;
          dependency = resultProposals[i].attributes!.dependencies!;
          clientName = resultProposals[i].attributes!.clientDetails!;
          budget = resultProposals[i].attributes!.budget!;
          riskFactors = resultProposals[i].attributes!.riskFactors!;
        });
        SharedPrefs.instance
            .setString('functionality', jsonEncode(functionalityProposal));
        if (platformProposal != null) {
          SharedPrefs.instance
              .setString('platforms', jsonEncode(platformProposal));
        }
        if (technologyProposal != null) {
          SharedPrefs.instance
              .setString('technologies', jsonEncode(technologyProposal));
        }
      }
    }
  }

  /// Navigation to Draft Screen.
  void navigateToDraftScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/draftScreen'));
  }

  ///Navigate to Home screen.
  void navigateToHomePage(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/homeScreen'));
  }

  @override
  Widget build(BuildContext context) {
    /// Bloc implementation.
    return BlocConsumer<ReviewScreenBloc, ReviewState>(
      bloc: reviewScreenBloc,
      listenWhen: (previous, current) => current is ReviewActionState,
      buildWhen: (previous, current) => current is! ReviewActionState,
      listener: (context, state) {
        /// State for Review screen Attachment button.
        if (state is ReviewAttachmentBtnState) {
          ShowBottomSheet.getInstance.permissionHandlerMethod(context);
        }

        /// State for Review screen Save button.
        else if (state is ReviewSaveDraftBtnState) {
        }

        /// State for Review screen Basic detail Edit button.
        else if (state is ReviewBasicDetailEditBtnState) {
          isReviewScreen = true;
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => BasicDetailScreen(
                        widget.currentIndex,
                        widget.projectName,
                        widget.draftSelected,
                        isReviewScreen,
                        widget.additionalDetailDraft,
                        isProject: widget.isProject,
                      database: widget.database
                      )));
        }

        /// State for Review screen Basic detail Expand button.
        else if (state is ReviewBasicDetailExpandBtnState) {
          if (isExpandedBasicDetails == false) {
            setState(() {
              isExpandedBasicDetails = true;
            });
          } else {
            setState(() {
              isExpandedBasicDetails = false;
            });
          }
        }

        /// State for Review screen Technical information Edit button.
        else if (state is ReviewTechnicalInfoEditBtnState) {
          isReviewScreen = true;
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => TechnicalInformationScreen(
                        widget.currentIndex,
                        widget.projectName,
                        basicDetailDraft,
                        isBasicScreen,
                        widget.draftSelected,
                        isReviewScreen,
                        widget.additionalDetailDraft,
                        widget.isProject,
                      database: widget.database
                      )));
        }

        /// State for Review screen Technical information Expand button.
        else if (state is ReviewTechnicalInfoExpandBtnState) {
          if (isExpandedTechnicalInfo == false) {
            setState(() {
              isExpandedTechnicalInfo = true;
            });
          } else {
            setState(() {
              isExpandedTechnicalInfo = false;
            });
          }
        }

        /// State for Review screen Additional detail Edit button.
        else if (state is ReviewAdditionalDetailEditBtnState) {
          isReviewScreen = true;
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AdditionalDetailScreen(
                      widget.currentIndex,
                      widget.projectName,
                      basicDetailDraft,
                      isTechnicalScreen,
                      technicalDetailDraft,
                      widget.draftSelected,
                      isReviewScreen,
                      widget.additionalDetailDraft,
                      isProject: widget.isProject,
                      database: widget.database)));
        }

        /// State for Review screen Additional detail Expand button
        else if (state is ReviewAdditionalDetailExpandBtnState) {
          if (isExpandedAdditionalDetails == false) {
            setState(() {
              isExpandedAdditionalDetails = true;
            });
          } else {
            setState(() {
              isExpandedAdditionalDetails = false;
            });
          }
        } else if (state is ResourceStoreState) {
          setState(() {
            resourceDetail = state.resources;
          });
          List<int?> mapResources = [];
          List<Map<String, dynamic>> mapRes = [];

          ///Resources list
          Map<String, dynamic>? q;
          for (var i = 0; i < resourceDetail.length; i++) {
            setState(() {
              var resItem = (resourceDetail[i]!.id);
              mapResources.add(resItem);
              q = {"id": jsonEncode(mapResources[i])};
              mapRes.add(q!);
            });
          }

          List<int?> mapResources1 = [];
          List<Map<String, dynamic>>? d;
          Map<String, dynamic>? dd;
          if (document != null) {
            if (jsonEncode(document) != "{}") {
              d = [];
              for (var i = 0; i < document.length; i++) {
                var doc = (document![i]!.id);
                mapResources1.add(doc);
                setState(() {
                  dd = {"id": jsonEncode(mapResources1[i])};
                  d!.add(dd!);
                });
              }
            }
          }

          if (isProject) {
            reviewScreenBloc.add(ReviewCreateProjectBtnEvent(
                objectives: objective,
                startDate: startDate,
                endDate: endDate,
                clientName: clientName,
                budget: budget,
                knownIssues: knownIssues,
                dependencies: dependency,
                comments: comments,
                documents: d,
                feedback: feedback,
                name: name,
                summary: summery,
                currency: currency,
                location: location,
                riskFactor: riskFactor,
                technologies: draftTechnology,
                domain: draftDomain,
                platforms: draftPlatform,
                resources: mapRes.isNotEmpty ? mapRes : null,
                functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                status: draftStatus,
                methodology: draftMethodology));
            db.deleteProjectModel(resultProjects);
            navigateToHomePage(context);
            DisplayMessageUtils.flushBarErrorMessage(
                context,
                Strings().projectCreatedMessage,
                AppColors.flushBarBackgroundColor,
                Strings().view,
                () {});
          } else {
            ///Proposal Post API
            reviewScreenBloc.add(ReviewCreateProposalBtnEvent(
              objectives: objective,
              proposalReceivedDate: startDate,
              proposalSubmittedDate: endDate,
              clientDetails: clientName,
              budget: budget,
              dependencies: dependency,
              comments: comments,
              documents: d,
              feedback: feedback,
              name: name,
              summery: summery,
              currency: currency,
              location: location,
              riskFactors: riskFactors,
              technologies: draftTechnology,
              domain: draftDomain,
              platforms: draftPlatform,
              resources: mapRes.isNotEmpty ? mapRes : null,
              functionalities: jsonDecode(jsonEncode(draftFunctionality)),
              status: draftStatus,
            ));
            db.deleteProposalModel(resultProposals);
            navigateToHomePage(context);
            DisplayMessageUtils.flushBarErrorMessage(
                context,
                Strings().proposalCreatedMessage,
                AppColors.flushBarBackgroundColor,
                Strings().view,
                () {});
          }
        } else if (state is UploadDocumentState) {
          setState(() {
            document = state.details;
          });
          List<int?> mapResources1 = [];
          List<Map<String, dynamic>> d = [];
          Map<String, dynamic>? dd;
          for (var i = 0; i < document!.length; i++) {
            var doc = (document![i]!.id);
            mapResources1.add(doc);
            setState(() {
              dd = {"id": jsonEncode(mapResources1[i])};
              d.add(dd!);
            });
          }
          files.clear();

          int index = resourceDetail.length;
          if (resourceDetail.isNotEmpty) {
            for (int i = 0; i < index; i++) {
              reviewScreenBloc.add(ResourceStoreEvent(
                  resourceName: resourceDetail[i]!.resourceName,
                  resourceEmail: resourceDetail[i]!.resourceEmail,
                  designation: resourceDetail[i]!.designation));
            }
          } else {
            if (isProject) {
              reviewScreenBloc.add(ReviewCreateProjectBtnEvent(
                  objectives: objective,
                  startDate: startDate,
                  endDate: endDate,
                  clientName: clientName,
                  budget: budget,
                  knownIssues: knownIssues,
                  dependencies: dependency,
                  comments: comments,
                  documents: d,
                  feedback: feedback,
                  name: name,
                  summary: summery,
                  currency: currency,
                  location: location,
                  riskFactor: riskFactor,
                  technologies: draftTechnology,
                  domain: draftDomain,
                  platforms: draftPlatform,
                  resources: null,
                  functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                  status: draftStatus,
                  methodology: draftMethodology));
              db.deleteProjectModel(resultProjects);
              navigateToHomePage(context);
              DisplayMessageUtils.flushBarErrorMessage(
                  context,
                  Strings().projectCreatedMessage,
                  AppColors.flushBarBackgroundColor,
                  Strings().view,
                  () {});
            } else {
              ///Proposal Post API
              reviewScreenBloc.add(ReviewCreateProposalBtnEvent(
                objectives: objective,
                proposalReceivedDate: startDate,
                proposalSubmittedDate: endDate,
                clientDetails: clientName,
                budget: budget,
                dependencies: dependency,
                comments: comments,
                documents: d,
                feedback: feedback,
                name: name,
                summery: summery,
                currency: currency,
                location: location,
                riskFactors: riskFactors,
                technologies: draftTechnology,
                domain: draftDomain,
                platforms: draftPlatform,
                resources: null,
                functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                status: draftStatus,
              ));
              db.deleteProposalModel(resultProposals);
              navigateToHomePage(context);
              DisplayMessageUtils.flushBarErrorMessage(
                  context,
                  Strings().proposalCreatedMessage,
                  AppColors.flushBarBackgroundColor,
                  Strings().view,
                  () {});
            }

            // DisplayMessageUtils.showSnackBar(Strings().fileIsUploadString);
            files.clear();
          }
        } else if (state is UploadDocumentFailedState) {
          // DisplayMessageUtils.showSnackBar(
          //     NetworkExceptions.getErrorMessage(state.exception));
        }

        /// State for Review screen Create project button.
        else if (state is ReviewCreateProjectBtnState) {
          db.deleteSingleProjectModel(state.createProject!);
          navigateToHomePage(context);
          DisplayMessageUtils.flushBarErrorMessage(
              context,
              Strings().projectCreatedMessage,
              AppColors.flushBarBackgroundColor,
              Strings().view,
              () {});
        } else if (state is ReviewCreateProposalBtnState) {
          db.deleteSingleProposalModel(state.createProposal!);
          navigateToHomePage(context);
          DisplayMessageUtils.flushBarErrorMessage(
              context,
              Strings().proposalCreatedMessage,
              AppColors.flushBarBackgroundColor,
              Strings().view,
              () {});
        }
      },
      builder: (context, state) {
        return WillPopScope(
          onWillPop: () async {
            if (widget.draftSelected) {
              navigateToDraftScreen(context);
            } else if (widget.additionalDetailScreen) {
              Navigator.pop(context);
            } else {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CreateProjectScreen(
                          widget.currentIndex,
                          widget.projectName,
                          widget.isProject,
                          database: widget.database)));
            }
            return false;
          },
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: AppColors.createProjectAppBarColor,
              iconTheme: IconThemeData(color: AppColors.white),
              title: Text(
                isProject == true
                    ? Strings().createProjectAppbarTitle.toTitleCase()
                    : Strings().createProposalAppbarTitle.toTitleCase(),
                style: TextStyle(
                    color: AppColors.white, fontSize: Dimensions.font_20),
              ),
              actions: [
                IconButton(
                    onPressed: () async {
                      /// Event for Review screen Attachment button.
                      reviewScreenBloc.add(ReviewAttachmentBtnEvent());
                    },
                    icon: Icon(Icons.attach_file,
                        size: Dimensions.iconSize_20, color: AppColors.white)),
                // TextButton(
                //   onPressed: () {
                //     /// Event for Review screen Save button.
                //     reviewScreenBloc.add(ReviewSaveDraftBtnEvent());
                //   },
                //   child: Text(
                //     Strings().saveDraftAppbarTitle.toTitleCase(),
                //     style: TextStyle(color: AppColors.white),
                //   ),
                // ),
              ],
            ),
            body: SingleChildScrollView(
              child: Container(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      AppColors.reviewBackgroundColor,
                      AppColors.white
                    ])),
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                      Dimensions.padding_16,
                      Dimensions.padding_24,
                      Dimensions.padding_16,
                      Dimensions.padding_0),
                  child: Column(
                    children: [
                      Container(
                        height: Dimensions.height_56,
                        width: getSize(context).width,
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius:
                              BorderRadius.circular(Dimensions.borderRadius_5),
                          border: Border.all(
                              color: AppColors.reviewDetailsBorderColor),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(left: Dimensions.padding_16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                Strings().basicDetailTitle.toTitleCase(),
                                style: TextStyle(
                                    fontSize: Dimensions.font_16,
                                    fontWeight: FontWeight.bold),
                              ),
                              Row(
                                children: [
                                  IconButton(
                                    onPressed: () {
                                      /// Event for Review screen Basic detail Edit button.
                                      reviewScreenBloc
                                          .add(ReviewBasicDetailEditBtnEvent());
                                    },
                                    icon: Icon(
                                      Icons.edit_outlined,
                                      size: Dimensions.iconSize_24,
                                      color: AppColors.createProjectAppBarColor,
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      /// Event for Review screen Basic detail Expand button.
                                      reviewScreenBloc.add(
                                          ReviewBasicDetailExpandBtnEvent());
                                    },
                                    icon: isExpandedBasicDetails == true
                                        ? Icon(
                                            Icons.keyboard_arrow_up,
                                            size: Dimensions.iconSize_31,
                                            color: AppColors
                                                .createProjectAppBarColor,
                                          )
                                        : Icon(
                                            Icons.keyboard_arrow_down,
                                            size: Dimensions.iconSize_31,
                                            color: AppColors
                                                .createProjectAppBarColor,
                                          ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Visibility(
                        visible: isExpandedBasicDetails == true ? false : true,
                        child: Container(
                          width: getSize(context).width,
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(
                                Dimensions.borderRadius_5),
                            border: Border.all(
                                color: AppColors.reviewDetailsBorderColor),
                          ),
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: Dimensions.padding_16,
                                top: Dimensions.padding_5),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  isProject == true
                                      ? Strings().projectIDTitle
                                      : Strings().proposalIDTitle,
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                Text(
                                  id.toString(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_16,
                                      color:
                                          AppColors.basicDetailHintTextColor),
                                ),
                                SizedBox(
                                  height: Dimensions.height_16,
                                ),
                                Text(
                                  isProject == true
                                      ? Strings().projectNameTitle
                                      : Strings().proposalNameTitle,
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                Text(
                                  name.toString(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_16,
                                      color:
                                          AppColors.basicDetailHintTextColor),
                                ),
                                SizedBox(
                                  height: Dimensions.height_16,
                                ),
                                Text(
                                  isProject == true
                                      ? Strings().projectDomain.toTitleCase()
                                      : Strings().proposalDomain.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                Text(
                                  domain.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_16,
                                      color:
                                          AppColors.basicDetailHintTextColor),
                                ),
                                if (objective != "")
                                  SizedBox(
                                    height: Dimensions.height_16,
                                  ),
                                if (objective != "")
                                  Text(
                                    isProject == true
                                        ? Strings()
                                            .projectObjective
                                            .toTitleCase()
                                        : Strings()
                                            .proposalObjective
                                            .toTitleCase(),
                                    style: TextStyle(
                                        fontSize: Dimensions.font_12,
                                        color: AppColors
                                            .basicDetailProjectIDColor),
                                  ),
                                if (objective != "")
                                  Text(
                                    objective.toTitleCase(),
                                    style: TextStyle(
                                        fontSize: Dimensions.font_16,
                                        color:
                                            AppColors.basicDetailHintTextColor),
                                  ),
                                SizedBox(
                                  height: Dimensions.height_16,
                                ),
                                Text(
                                  isProject == true
                                      ? Strings().projectSummary.toTitleCase()
                                      : Strings().proposalSummary.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                Text(
                                  summery.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_16,
                                      color:
                                          AppColors.basicDetailHintTextColor),
                                ),
                                SizedBox(
                                  height: Dimensions.height_16,
                                ),
                                Text(
                                  isProject == true
                                      ? Strings()
                                          .projectFunctionality
                                          .toTitleCase()
                                      : Strings()
                                          .proposalFunctionality
                                          .toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                ListView.builder(
                                  itemCount: widget.isProject
                                      ? functionalityProject!.length
                                      : functionalityProposal!.length,
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Text(
                                      widget.isProject
                                          ? "${index + 1}.${functionalityProject![index]!.attributes!.name!.toTitleCase()}"
                                          : "${index + 1}.${functionalityProposal![index]!.attributes!.name!.toTitleCase()}",
                                      style: TextStyle(
                                          fontSize: Dimensions.font_16,
                                          color: AppColors
                                              .basicDetailHintTextColor),
                                    );
                                  },
                                ),
                                if (Platform.isAndroid)
                                  SizedBox(
                                    height: Dimensions.height_16,
                                  ),
                                Text(
                                  isProject == true
                                      ? Strings().projectStartDate.toTitleCase()
                                      : Strings()
                                          .proposalStartDate
                                          .toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                Text(
                                  startDate.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_16,
                                      color:
                                          AppColors.basicDetailHintTextColor),
                                ),
                                if (endDate != null)
                                  SizedBox(
                                    height: Dimensions.height_16,
                                  ),
                                if (endDate != null)
                                  Text(
                                    isProject == true
                                        ? Strings().projectEndDate.toTitleCase()
                                        : Strings()
                                            .proposalEndDate
                                            .toTitleCase(),
                                    style: TextStyle(
                                        fontSize: Dimensions.font_12,
                                        color: AppColors
                                            .basicDetailProjectIDColor),
                                  ),
                                if (endDate != null)
                                  Text(
                                    endDate!.toTitleCase(),
                                    style: TextStyle(
                                        fontSize: Dimensions.font_16,
                                        color:
                                            AppColors.basicDetailHintTextColor),
                                  ),
                                if (endDate != null)
                                  SizedBox(
                                    height: Dimensions.height_16,
                                  ),
                                Text(
                                  isProject == true
                                      ? Strings().projectStatus.toTitleCase()
                                      : Strings().proposalStatus.toTitleCase(),
                                  style: TextStyle(
                                      fontSize: Dimensions.font_12,
                                      color:
                                          AppColors.basicDetailProjectIDColor),
                                ),
                                SizedBox(
                                  height: Dimensions.height_5,
                                ),
                                Container(
                                  height: Dimensions.height_22,
                                  width: Dimensions.width_77,
                                  decoration: BoxDecoration(
                                    color: StatusColors.getColors(
                                        status.toTitleCase()),
                                    borderRadius: BorderRadius.circular(
                                        Dimensions.borderRadius_60),
                                  ),
                                  child: Center(
                                    child: Text(
                                      status.toTitleCase(),
                                      style: TextStyle(
                                          fontSize: Dimensions.font_12,
                                          color: AppColors
                                              .basicDetailHintTextColor),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: Dimensions.height_8,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: Dimensions.height_16,
                      ),
                      Column(
                        children: [
                          Visibility(
                            visible: true,
                            child: Container(
                              height: Dimensions.height_56,
                              width: getSize(context).width,
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(
                                    Dimensions.borderRadius_5),
                                border: Border.all(
                                    color: AppColors.reviewDetailsBorderColor),
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: Dimensions.padding_16),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      Strings().technicalInfo.toTitleCase(),
                                      style: TextStyle(
                                          fontSize: Dimensions.font_16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Row(
                                      children: [
                                        IconButton(
                                          onPressed: () {
                                            /// Event for Review screen Technical information Edit button.
                                            reviewScreenBloc.add(
                                                ReviewTechnicalInfoEditBtnEvent());
                                          },
                                          icon: Icon(
                                            Icons.edit_outlined,
                                            size: Dimensions.iconSize_24,
                                            color: AppColors
                                                .createProjectAppBarColor,
                                          ),
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            /// Event for Review screen Technical information Expand button.
                                            reviewScreenBloc.add(
                                                ReviewTechnicalInfoExpandBtnEvent());
                                          },
                                          icon: isExpandedTechnicalInfo == true
                                              ? Icon(
                                                  Icons.keyboard_arrow_up,
                                                  size: Dimensions.iconSize_31,
                                                  color: AppColors
                                                      .createProjectAppBarColor,
                                                )
                                              : Icon(
                                                  Icons.keyboard_arrow_down,
                                                  size: Dimensions.iconSize_31,
                                                  color: AppColors
                                                      .createProjectAppBarColor,
                                                ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Visibility(
                            visible:
                                isExpandedTechnicalInfo == true ? false : true,
                            child: Container(
                              width: getSize(context).width,
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(
                                    Dimensions.borderRadius_5),
                                border: Border.all(
                                    color: AppColors.reviewDetailsBorderColor),
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: Dimensions.padding_16,
                                    top: Dimensions.padding_5),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if (((platformProject == null) &&
                                            (technologyProject == null) &&
                                            (isProject)) ||
                                        ((platformProposal == null) &&
                                                (technologyProposal == null) &&
                                                (!isProject)) ==
                                            true)
                                      const Center(
                                          child: Text("No data added")),
                                    if (((isProject) &&
                                            (platformProject != null) &&
                                            (technologyProject != null) &&
                                            !isExpandedTechnicalInfo) ||
                                        (((!isProject) &&
                                                (platformProposal != null) &&
                                                (technologyProposal != null) &&
                                                !isExpandedTechnicalInfo)) ==
                                            true)
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            Strings()
                                                .projectPlatform
                                                .toTitleCase(),
                                            style: TextStyle(
                                                fontSize: Dimensions.font_12,
                                                color: AppColors
                                                    .basicDetailProjectIDColor),
                                          ),
                                          ListView.builder(
                                            itemCount: isProject
                                                ? platformProject?.length
                                                : platformProposal?.length,
                                            shrinkWrap: true,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              return Text(
                                                isProject == true
                                                    ? "${index + 1}.${platformProject?[index]!.attributes!.name.toString().toTitleCase()}"
                                                    : "${index + 1}.${platformProposal?[index]!.attributes!.name!.toString().toTitleCase()}",
                                                style: TextStyle(
                                                    fontSize:
                                                        Dimensions.font_16,
                                                    color: AppColors
                                                        .basicDetailHintTextColor),
                                              );
                                            },
                                          ),
                                          if (Platform.isAndroid)
                                            SizedBox(
                                              height: Dimensions.height_16,
                                            ),
                                          Text(
                                            Strings()
                                                .projectTechnology
                                                .toTitleCase(),
                                            style: TextStyle(
                                                fontSize: Dimensions.font_12,
                                                color: AppColors
                                                    .basicDetailProjectIDColor),
                                          ),
                                          ListView.builder(
                                            itemCount: isProject
                                                ? technologyProject?.length
                                                : technologyProposal?.length,
                                            shrinkWrap: true,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              return Text(
                                                isProject == true
                                                    ? "${index + 1}.${technologyProject![index]!.attributes!.name!.toString().toTitleCase()}"
                                                    : "${index + 1}.${technologyProposal![index]!.attributes!.name!.toString().toTitleCase()}",
                                                style: TextStyle(
                                                    fontSize:
                                                        Dimensions.font_16,
                                                    color: AppColors
                                                        .basicDetailHintTextColor),
                                              );
                                            },
                                          ),
                                          if (Platform.isAndroid)
                                            SizedBox(
                                              height: Dimensions.height_16,
                                            ),
                                          Visibility(
                                            visible: isProject == true
                                                ? true
                                                : false,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  Strings()
                                                      .projectManagementMethodology
                                                      .toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_12,
                                                      color: AppColors
                                                          .basicDetailProjectIDColor),
                                                ),
                                                Text(
                                                  methodology.toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_16,
                                                      color: AppColors
                                                          .basicDetailHintTextColor),
                                                ),
                                                SizedBox(
                                                  height: Dimensions.height_16,
                                                ),
                                              ],
                                            ),
                                          ),
                                          Visibility(
                                            visible: isProject == true
                                                ? (riskFactor != "") == true
                                                    ? true
                                                    : false
                                                : (riskFactors != "") == true
                                                    ? true
                                                    : false,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  Strings()
                                                      .proposalRiskFactor
                                                      .toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_12,
                                                      color: AppColors
                                                          .basicDetailProjectIDColor),
                                                ),
                                                Text(
                                                  isProject == true
                                                      ? riskFactor.toTitleCase()
                                                      : riskFactors
                                                          .toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_16,
                                                      color: AppColors
                                                          .basicDetailHintTextColor),
                                                ),
                                                SizedBox(
                                                  height: Dimensions.height_16,
                                                ),
                                              ],
                                            ),
                                          ),
                                          Visibility(
                                            visible:
                                                knownIssues != "" && isProject
                                                    ? true
                                                    : false,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  Strings()
                                                      .knownIssueText
                                                      .toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_12,
                                                      color: AppColors
                                                          .basicDetailProjectIDColor),
                                                ),
                                                Text(
                                                  knownIssues.toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_16,
                                                      color: AppColors
                                                          .basicDetailHintTextColor),
                                                ),
                                                SizedBox(
                                                  height: Dimensions.height_16,
                                                ),
                                              ],
                                            ),
                                          ),
                                          Visibility(
                                            visible:
                                                dependency == "" ? false : true,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  Strings()
                                                      .projectDependencies
                                                      .toTitleCase(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_12,
                                                      color: AppColors
                                                          .basicDetailProjectIDColor),
                                                ),
                                                Text(
                                                  dependency.toCapitalized(),
                                                  style: TextStyle(
                                                      fontSize:
                                                          Dimensions.font_16,
                                                      color: AppColors
                                                          .basicDetailHintTextColor),
                                                ),
                                                SizedBox(
                                                  height: Dimensions.height_8,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: Dimensions.height_16,
                      ),
                      Visibility(
                        visible: true,
                        child: Column(
                          children: [
                            Container(
                              height: Dimensions.height_56,
                              width: getSize(context).width,
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(
                                    Dimensions.borderRadius_5),
                                border: Border.all(
                                    color: AppColors.reviewDetailsBorderColor),
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: Dimensions.padding_16),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      Strings().additionalDetails.toTitleCase(),
                                      style: TextStyle(
                                          fontSize: Dimensions.font_16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Row(
                                      children: [
                                        IconButton(
                                          onPressed: (((isProject) &&
                                                      (platformProject !=
                                                          null) &&
                                                      (technologyProject !=
                                                          null) &&
                                                      !isExpandedTechnicalInfo) ||
                                                  (((!isProject) &&
                                                          (platformProposal !=
                                                              null) &&
                                                          (technologyProposal !=
                                                              null) &&
                                                          !isExpandedTechnicalInfo)) ==
                                                      true)
                                              ? () {
                                                  /// Event for Review screen Additional detail Edit button.
                                                  reviewScreenBloc.add(
                                                      ReviewAdditionalDetailEditBtnEvent());
                                                }
                                              : null,
                                          icon: Icon(
                                            Icons.edit_outlined,
                                            size: Dimensions.iconSize_24,
                                            color: AppColors
                                                .createProjectAppBarColor,
                                          ),
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            /// Event for Review screen Additional detail Expand button
                                            reviewScreenBloc.add(
                                                ReviewAdditionalDetailExpandBtnEvent());
                                          },
                                          icon: isExpandedAdditionalDetails ==
                                                  true
                                              ? Icon(
                                                  Icons.keyboard_arrow_up,
                                                  size: Dimensions.iconSize_31,
                                                  color: AppColors
                                                      .createProjectAppBarColor,
                                                )
                                              : Icon(
                                                  Icons.keyboard_arrow_down,
                                                  size: Dimensions.iconSize_31,
                                                  color: AppColors
                                                      .createProjectAppBarColor,
                                                ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Visibility(
                              visible: isExpandedAdditionalDetails == true
                                  ? false
                                  : true,
                              child: Container(
                                width: getSize(context).width,
                                decoration: BoxDecoration(
                                  color: AppColors.white,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.borderRadius_5),
                                  border: Border.all(
                                      color:
                                          AppColors.reviewDetailsBorderColor),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      left: Dimensions.padding_16,
                                      top: Dimensions.padding_5),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      if ((clientName != "" ||
                                              currency != "" ||
                                              budget != "" ||
                                              location != "" ||
                                              comments != "" ||
                                              feedback != "" ||
                                              (resourceDetail.isNotEmpty &&
                                                  resourceDetail?[0]
                                                          ?.resourceName !=
                                                      null)) ==
                                          false)
                                        const Center(
                                            child: Text("No data added")),
                                      if ((clientName != "" ||
                                              currency != "" ||
                                              budget != "" ||
                                              location != "" ||
                                              comments != "" ||
                                              feedback != "" ||
                                              (resourceDetail.isNotEmpty &&
                                                  resourceDetail[0]
                                                          ?.resourceName !=
                                                      null)) ==
                                          true)
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            if (clientName != "")
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    Strings()
                                                        .projectClientName
                                                        .toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_12,
                                                        color: AppColors
                                                            .basicDetailProjectIDColor),
                                                  ),
                                                  Text(
                                                    clientName.toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_16,
                                                        color: AppColors
                                                            .basicDetailHintTextColor),
                                                  ),
                                                  SizedBox(
                                                    height:
                                                        Dimensions.height_16,
                                                  ),
                                                ],
                                              ),
                                            if (currency != "" && budget != "")
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    isProject == true
                                                        ? Strings()
                                                            .projectCost
                                                            .toTitleCase()
                                                        : Strings()
                                                            .proposalCost
                                                            .toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_12,
                                                        color: AppColors
                                                            .basicDetailProjectIDColor),
                                                  ),
                                                  Row(
                                                    children: [
                                                      Text(
                                                        currency.isEmpty
                                                            ? ""
                                                            : currency[0],
                                                        style: TextStyle(
                                                            fontSize: Dimensions
                                                                .font_16,
                                                            color: AppColors
                                                                .basicDetailHintTextColor),
                                                      ),
                                                      SizedBox(
                                                          width: Dimensions
                                                              .width_10),
                                                      Text(
                                                        budget,
                                                        style: TextStyle(
                                                            fontSize: Dimensions
                                                                .font_16,
                                                            color: AppColors
                                                                .basicDetailHintTextColor),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height:
                                                        Dimensions.height_16,
                                                  ),
                                                ],
                                              ),
                                            if (location != "")
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    Strings()
                                                        .projectLocation
                                                        .toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_12,
                                                        color: AppColors
                                                            .basicDetailProjectIDColor),
                                                  ),
                                                  Text(
                                                    location,
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_16,
                                                        color: AppColors
                                                            .basicDetailHintTextColor),
                                                  ),
                                                  SizedBox(
                                                    height: Dimensions.height_8,
                                                  ),
                                                ],
                                              ),
                                            if ((resourceDetail != [] &&
                                                    resourceDetail
                                                        .isNotEmpty) ||
                                                (resourceDetail.length == 1 &&
                                                    resourceDetail[0]
                                                            ?.resourceName !=
                                                        null))
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "Resources",
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_12,
                                                        color: AppColors
                                                            .basicDetailProjectIDColor),
                                                  ),
                                                  ListView.builder(
                                                    itemCount:
                                                        resourceDetail.length,
                                                    shrinkWrap: true,
                                                    physics:
                                                        const NeverScrollableScrollPhysics(),
                                                    itemBuilder:
                                                        (BuildContext context,
                                                            int index) {
                                                      return Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            "${index + 1}.${resourceDetail[index]!.resourceName!.toTitleCase()}",
                                                            style: TextStyle(
                                                                fontSize:
                                                                    Dimensions
                                                                        .font_16,
                                                                color: AppColors
                                                                    .basicDetailHintTextColor),
                                                          ),
                                                          Text(
                                                              "\t\t\t${resourceDetail[index]!.designation!}"),
                                                          Text(
                                                              "\t\t\t${resourceDetail[index]!.resourceEmail!}"),
                                                          SizedBox(
                                                            height: Dimensions
                                                                .height_10,
                                                          ),
                                                        ],
                                                      );
                                                    },
                                                  ),
                                                ],
                                              ),
                                            if (comments != "")
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    Strings()
                                                        .commentsText
                                                        .toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_12,
                                                        color: AppColors
                                                            .basicDetailProjectIDColor),
                                                  ),
                                                  Text(
                                                    comments.toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_16,
                                                        color: AppColors
                                                            .basicDetailHintTextColor),
                                                  ),
                                                  SizedBox(
                                                    height: Dimensions.height_8,
                                                  ),
                                                ],
                                              ),
                                            if (feedback != "")
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    Strings()
                                                        .feedbackText
                                                        .toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_12,
                                                        color: AppColors
                                                            .basicDetailProjectIDColor),
                                                  ),
                                                  Text(
                                                    feedback.toTitleCase(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            Dimensions.font_16,
                                                        color: AppColors
                                                            .basicDetailHintTextColor),
                                                  ),
                                                  SizedBox(
                                                    height: Dimensions.height_8,
                                                  ),
                                                ],
                                              ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: Dimensions.height_16,
                      ),
                      Visibility(
                        visible: (((isProject) &&
                                    (platformProject != null) &&
                                    (technologyProject != null) &&
                                    !isExpandedTechnicalInfo) ||
                                (((!isProject) &&
                                        (platformProposal != null) &&
                                        (technologyProposal != null) &&
                                        !isExpandedTechnicalInfo)) ==
                                    true)
                            ? true
                            : false,
                        child: createProjectButton(),
                      ),
                      SizedBox(
                        height: Dimensions.height_16,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// listener for positive button
  void positiveButtonCallback() {
    Navigator.of(context).pop();
    ShowBottomSheet.getInstance.permissionHandlerMethod(context);
  }

  /// listener for negative button
  void negativeButtonCallback() {
    Navigator.of(context).pop();
  }

  /// listener for single button
  actionSingleButtonCallback() {
    print(5);
    if (resourceDetail.isNotEmpty) {
      print(6);
      Dialogs.showLoadingDialog(context, _keyLoader, isProject);
      int index = resourceDetail.length;
      for (int i = 0; i < index; i++) {
        reviewScreenBloc.add(ResourceStoreEvent(
            resourceName: resourceDetail[i]!.resourceName,
            resourceEmail: resourceDetail[i]!.resourceEmail,
            designation: resourceDetail[i]!.designation));
      }
    } else {
      Dialogs.showLoadingDialog(context, _keyLoader, isProject);
      if (isProject) {
        print(7);
        reviewScreenBloc.add(ReviewCreateProjectBtnEvent(
            objectives: objective,
            startDate: startDate,
            endDate: endDate,
            clientName: clientName,
            budget: budget,
            knownIssues: knownIssues,
            dependencies: dependency,
            comments: comments,
            documents: null,
            feedback: feedback,
            name: name,
            summary: summery,
            currency: currency,
            location: location,
            riskFactor: riskFactor,
            technologies: draftTechnology,
            domain: draftDomain,
            platforms: draftPlatform,
            resources: null,
            functionalities: jsonDecode(jsonEncode(draftFunctionality)),
            status: draftStatus,
            methodology: draftMethodology));
      } else {
        ///Proposal Post API
        reviewScreenBloc.add(ReviewCreateProposalBtnEvent(
          objectives: objective,
          proposalReceivedDate: startDate,
          proposalSubmittedDate: endDate,
          clientDetails: clientName,
          budget: budget,
          dependencies: dependency,
          comments: comments,
          documents: null,
          feedback: feedback,
          name: name,
          summery: summery,
          currency: currency,
          location: location,
          riskFactors: riskFactors,
          technologies: draftTechnology,
          domain: draftDomain,
          platforms: draftPlatform,
          resources: null,
          functionalities: jsonDecode(jsonEncode(draftFunctionality)),
          status: draftStatus,
        ));
      }
    }
  }

  /// All with yes no button without background
  CustomDialogBox dialog() {
    return CustomDialogBox(
      title: Strings().dialogTitle.toTitleCase(),
      description: Strings().dialogDiscription,
      actionPositive: Strings().positiveButton.toTitleCase(),
      actionNegative: Strings().negativeButton.toTitleCase(),
      showTitle: true,
      showDescription: true,
      showDialogImage: true,
      showActionPositive: true,
      showActionNegative: true,
      showSingleActionButton: false,
      buttonTextColor: Colors.black,
      onPositiveButtonClick: positiveButtonCallback,
      onNegativeButtonClick: negativeButtonCallback,
      actionOnPressed: actionSingleButtonCallback,
    );
  }

  String trimAfterSpace(String input) {
    int spaceIndex = input.indexOf(' ');
    if (spaceIndex == -1) {
      return input;
    } else {
      return input.substring(0, spaceIndex);
    }
  }

  Widget createProjectButton() {
    return InkWell(
      onTap: () {
        // ///Event for Review screen Create project button.
        // currencyController.text = trimAfterSpace(currencyController.text);
        // if (files.isEmpty) {
        //   print(1);
        //   showDialog(
        //       barrierDismissible: false,
        //       context: context,
        //       builder: (BuildContext context) {
        //         return dialog();
        //       });
        // }
        //
        // if (SharedPrefs.instance.getBool('docAttached') == true &&
        //     resourceDetail.isNotEmpty) {
        //   print(2);
        //   Dialogs.showLoadingDialog(context, _keyLoader, isProject);
        //   reviewScreenBloc.add(UploadDocumentEvent(file: files));
        // } else if (SharedPrefs.instance.getBool('docAttached') == true ||
        //     resourceDetail.isNotEmpty) {
        //   print(3);
        //   if (SharedPrefs.instance.getBool('docAttached') == true) {
        //     print(4);
        //     Dialogs.showLoadingDialog(context, _keyLoader, isProject);
        //     reviewScreenBloc.add(UploadDocumentEvent(file: files));
        //   } else if (resourceDetail.isNotEmpty) {}
        // }
        if(((isProject) &&
            (platformProject != null) &&
            (technologyProject != null) &&
            !isExpandedTechnicalInfo) ||
            (((!isProject) &&
                (platformProposal != null) &&
                (technologyProposal != null) &&
                !isExpandedTechnicalInfo)) ==
                true){
          navigateToHomePage(context);
          DisplayMessageUtils.flushBarErrorMessage(
              context,
              Strings().projectCreatedMessage,
              AppColors.flushBarBackgroundColor,
              Strings().view,
                  () {});
        }else{
          null;
        }
      },
      borderRadius: BorderRadius.circular(Dimensions.borderRadius_60),
      child: Container(
        height: Dimensions.height_40,
        width: Dimensions.width_250,
        decoration: BoxDecoration(
          color: AppColors.createProjectAppBarColor,
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_60),
          border: Border.all(color: Colors.transparent),
        ),
        child: BlocProvider.value(
          value: reviewScreenBloc,
          child: BlocListener<ReviewScreenBloc, ReviewState>(
            listener: (context, state) {},
            child: BlocBuilder<ReviewScreenBloc, ReviewState>(
              builder: (context, state) {
                if (state is CreateProjectLoadingState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is UploadDocumentState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is ResourceStoreState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is ReviewCreateProjectBtnState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else if (state is ReviewCreateProposalBtnState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else if (state is CreateProjectFailedState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                }
              },
            ),
          ),
        ),
      ),
    );
  }
}
