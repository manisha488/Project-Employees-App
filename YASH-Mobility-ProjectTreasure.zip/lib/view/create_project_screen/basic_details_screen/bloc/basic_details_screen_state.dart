part of 'basic_details_screen_bloc.dart';

@immutable
abstract class BasicDetailState {}

class BasicDetailInitialState extends BasicDetailState {}

class BasicDetailActionState extends BasicDetailState {}

/// State for Basic detail screen Attachment button.
class BasicDetailAttachmentBtnState extends BasicDetailActionState {}

/// State for Basic detail screen Save button.
class BasicDetailSaveBtnState extends BasicDetailActionState {}

/// State for Navigation from Basic detail screen to Technical information screen.
class NavigateBasicDetailToTechInfoState extends BasicDetailActionState {}

/// State for Basic detail screen Domain list.
class DomainLoadedState extends BasicDetailActionState{
  final List<MultiSelectionFiltersData> domainFilters;
  DomainLoadedState(this.domainFilters) ;
}

///State for Functionality dropdown list.
class FunctionalityLoadedState extends BasicDetailActionState {
  final List<MultiSelectionFiltersData> functionality;
  FunctionalityLoadedState(this.functionality);
}

/// State for Basic detail screen Status list.
class StatusLoadedState extends BasicDetailActionState{
  final List<MultiSelectionFiltersData> statusFilters;
  StatusLoadedState(this.statusFilters) ;
}

/// State for Internet disconnection.
class InternetDisconnectedState extends BasicDetailActionState{
  final NetworkExceptions exceptions;

  InternetDisconnectedState(this.exceptions);
}
