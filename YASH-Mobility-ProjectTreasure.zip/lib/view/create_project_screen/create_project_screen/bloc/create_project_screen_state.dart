part of 'create_project_screen_bloc.dart';

@immutable
abstract class CreateProjectState {}

class CreateProjectInitialState extends CreateProjectState {}

class CreateProjectActionState extends CreateProjectState {}

///State for Navigation from Create project Screen to Basic detail screen.
class NavigateCreateProjectToBasicDetailState
    extends CreateProjectActionState {}

///State for Navigation from Create project Screen to Technical detail screen.
class NavigateCreateProjectToTechInfoState extends CreateProjectActionState {}

///State for Navigation from Create project Screen to Additional detail screen.
class NavigateCreateProjectToAdditionalDetailState
    extends CreateProjectActionState {}

///State for Navigation from Create project Screen to Review screen.
class NavigateCreateProjectToReviewState extends CreateProjectActionState {}

///Create project button state.
class CreateProjectClickedState extends CreateProjectActionState {
  final CreateProjectData? createProject;
  CreateProjectClickedState(this.createProject);
}

///Create proposal button state.
class CreateProposalClickedState extends CreateProjectActionState {
  final CreateProposalData? createProposal;
  CreateProposalClickedState(this.createProposal);
}

/// This state will be emit on creating project Screen
class CreateProjectLoadingState extends CreateProjectState {}

class CreateProjectLoadedState extends CreateProjectState {}

class CreateProjectFailedState extends CreateProjectState {}

///State for Resource Post Api
class ResourceStoreState extends CreateProjectActionState {
  final List<ResourcesData?> resources;

  ResourceStoreState(this.resources);
}

/// State for the Upload Document Post Api
class UploadDocumentState extends CreateProjectActionState {
  final List<DocumentsData?>? details;
  UploadDocumentState(this.details);
}

class UploadDocumentFailedState extends CreateProjectActionState {
  final NetworkExceptions exception;
  UploadDocumentFailedState(this.exception);
}
