part of 'review_screen_bloc.dart';

@immutable
abstract class ReviewState {}

class ReviewInitialState extends ReviewState {}

class ReviewActionState extends ReviewState {}

/// State for Review screen Attachment button.
class ReviewAttachmentBtnState extends ReviewActionState {}

/// State for Review screen Save button.
class ReviewSaveDraftBtnState extends ReviewActionState {}

/// State for Review screen Basic detail Edit button.
class ReviewBasicDetailEditBtnState extends ReviewActionState {}

/// State for Review screen Basic detail Expand button.
class ReviewBasicDetailExpandBtnState extends ReviewActionState {}

/// State for Review screen Technical information Edit button.
class ReviewTechnicalInfoEditBtnState extends ReviewActionState {}

/// State for Review screen Technical information Expand button.
class ReviewTechnicalInfoExpandBtnState extends ReviewActionState {}

/// State for Review screen Additional detail Edit button.
class ReviewAdditionalDetailEditBtnState extends ReviewActionState {}

/// State for Review screen Additional detail Expand button
class ReviewAdditionalDetailExpandBtnState extends ReviewActionState {}

/// State for Review screen Create project button.
class ReviewCreateProjectBtnState extends ReviewActionState {
  final CreateProjectData? createProject;
  ReviewCreateProjectBtnState(this.createProject);
}

///State for Additional detail screen Create proposal button.
class ReviewCreateProposalBtnState extends ReviewActionState {
  final CreateProposalData? createProposal;
  ReviewCreateProposalBtnState(this.createProposal);
}

/// Post Data loading state.
class PostLoadingState extends ReviewState {}

/// Post Data success state.
class PostSuccessState extends ReviewState {}

/// Post Data error state.
class PostErrorState extends ReviewState {
  final String errorMessage;
  PostErrorState(this.errorMessage);
}

/// This state will be emit on creating project Screen
class CreateProjectLoadingState extends ReviewActionState {}

class CreateProjectLoadedState extends ReviewActionState {}

class CreateProjectFailedState extends ReviewActionState {}

///State for Resource Post Api
class ResourceStoreState extends ReviewActionState {
  final List<ResourcesData?> resources;

  ResourceStoreState(this.resources);
}

/// State for the Upload Document Post Api
class UploadDocumentState extends ReviewActionState {
  final List<DocumentsData?>? details;
  UploadDocumentState(this.details);
}

class UploadDocumentFailedState extends ReviewActionState {
  final NetworkExceptions exception;
  UploadDocumentFailedState(this.exception);
}
