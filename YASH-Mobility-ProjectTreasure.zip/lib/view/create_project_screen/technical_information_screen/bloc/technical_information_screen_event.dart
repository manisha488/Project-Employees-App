part of 'technical_information_screen_bloc.dart';

@immutable
abstract class TechnicalInformationEvent {}

class TechnicalInformationInitialEvent extends TechnicalInformationEvent {}

/// Event for Technical information Attachment button.
class TechnicalInfoAttachmentBtnEvent extends TechnicalInformationEvent {}

/// Event for Technical information Save button.
class TechnicalInfoSaveBtnEvent extends TechnicalInformationEvent {}

///Event for Navigation from Technical information screen to Additional detail screen.
class NavigateTechInfoToAdditionalDetailEvent
    extends TechnicalInformationEvent {}

///Event for Platform dropdown list.
class PlatformLoadedEvent extends TechnicalInformationEvent{}

///Event for Technology dropdown list.
class TechnologyLoadedEvent extends TechnicalInformationEvent{}

///Event for Project Management Methodology dropdown list.
class ProjectMethodologyEvent extends TechnicalInformationEvent{}