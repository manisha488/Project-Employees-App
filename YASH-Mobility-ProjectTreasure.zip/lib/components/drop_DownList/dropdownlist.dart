import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'scrollbar.dart';

class CustomDropDown extends StatefulWidget {
  final List<String> list;
  final List<MultiSelectionFiltersData>? wlist;
  final Widget? widget;
  final String title;
  final String? dbkey;
  bool isStretchedDropDown;
  final void Function() onTapped;
  final void Function()? onArrowTapped;
  final TextEditingController? controller;
  String? dropdownValue;
  final void Function(String?)? onChanged;
  final bool? isLoading;
   final bool? isTitleCase;
   final bool? isCapitalize;
  final bool isApiCalled;

  CustomDropDown({
    Key? key,
    required this.list,
    required this.title,
    required this.onTapped,
    this.onArrowTapped,
    this.isTitleCase,
    this.isCapitalize,
    required this.isStretchedDropDown,
    this.onChanged,
    this.dropdownValue,
    this.controller,
    this.isLoading,
    this.isApiCalled = false,
    this.widget,
    this.wlist,
    this.dbkey,
  }) : super(key: key);

  @override
  CustomDropDownState createState() => CustomDropDownState();
}

class CustomDropDownState extends State<CustomDropDown> {
  String selectedOption = '';
  bool isFocused = false;
  var option;

  void clearSelection() {
    setState(() {
      selectedOption = '';
      option = null;
      widget.controller?.text = '';
      widget.isStretchedDropDown = false;
    });

    // Trigger the onChanged callback with null if needed
    if (widget.onChanged != null) {
      widget.onChanged!(null);
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTapped,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: widget.isStretchedDropDown
                ? AppColors.basicDetailTextFieldBorderColor
                : AppColors.basicDetailTextFieldBorderColor,
          ),
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_5),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 10, right: 10),
              child: GestureDetector(
                onTap: widget.onTapped,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(15, 10, 10, 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GestureDetector(
                              onTap: widget.onTapped,
                              child: Text(
                                widget.title.toTitleCase(),
                                style: TextStyle(
                                  color: AppColors.createProjectAppBarColor,
                                  fontSize: selectedOption.isEmpty
                                      ? Dimensions.font_16
                                      : Dimensions.font_12,
                                ),
                              ),
                            ),
                            Visibility(
                              visible: (selectedOption.isNotEmpty ||
                                  widget.controller!.text.isNotEmpty)
                                  ? (selectedOption.isNotEmpty ||
                                  widget.controller!.text.isNotEmpty)
                                  : false,
                              child: widget.isTitleCase ?? true
                                  ? Text(
                                (widget.controller!.text.isNotEmpty
                                    ? widget.controller!.text
                                    : selectedOption),
                                style: TextStyle(
                                  fontSize: Dimensions.font_16,
                                ),
                              )
                                  : Text(
                                (widget.controller!.text.isNotEmpty
                                    ? widget.controller!.text
                                    : selectedOption),
                                style: TextStyle(
                                  fontSize: Dimensions.font_16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: widget.onArrowTapped,
                      child: Icon(widget.isStretchedDropDown
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down_outlined),
                    ),
                  ],
                ),
              ),
            ),
            if (widget.isStretchedDropDown)
              SizedBox(
                  height: Dimensions.height_150,
                  child: (widget.isTitleCase! && widget.wlist!.isEmpty) ||
                      (!widget.isTitleCase! && widget.list.isEmpty)
                      ? const Center(child: CircularProgressIndicator())
                      : MyScrollbar(
                    builder: (context, scrollController2) =>
                        ListView.builder(
                          padding: EdgeInsets.all(Dimensions.padding_0),
                          controller: scrollController2,
                          shrinkWrap: true,
                          itemCount: widget.isTitleCase!
                              ? widget.wlist!.length
                              : widget.list.length,
                          itemBuilder: (context, index) {
                            return RadioListTile(
                              title: widget.isTitleCase ?? true
                                  ? Text(widget.isCapitalize ?? true
                                  ? widget.wlist![index].attributes!.name
                                  .toString()
                                  .toTitleCase()
                                  : widget.wlist![index].attributes!.name
                                  .toString()
                                  .capitalizeSpecialWords())
                                  : Text(widget.list[index].toString()),
                              value: widget.isTitleCase!
                                  ? widget.wlist!.elementAt(index)
                                  : widget.list.elementAt(index),
                              groupValue: option,
                              onChanged: (value) {
                                setState(() {
                                  option = widget.isTitleCase!
                                      ? widget.wlist![index]
                                      : widget.list[index];
                                  SharedPrefs.instance.setString(
                                      widget.dbkey!, jsonEncode(option));
                                  if (widget.isTitleCase!) {
                                    if (widget.isCapitalize == false) {
                                      selectedOption =
                                          widget.wlist![index].attributes!.name
                                              .toString()
                                              .capitalizeSpecialWords();
                                    } else {
                                      selectedOption = widget.wlist![index]
                                          .attributes!.name
                                          .toString()
                                          .toTitleCase();
                                    }
                                  } else {
                                    selectedOption = widget.list[index];
                                  }
                                  widget.isStretchedDropDown = false;
                                  // Trigger the onChanged callback if provided
                                  if (widget.onChanged != null) {
                                    widget.dropdownValue = selectedOption;
                                    widget.onChanged!(widget.dropdownValue);
                                  }
                                });
                              },
                            );
                          },
                        ),
                  )),
          ],
        ),
      ),
    );
  }
}
