import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/statusColorUtils.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';

import '../../../model/response/projects_list.dart';
import '../../../model/response/proposals_list.dart';

class ProjectDetailsScreen extends StatefulWidget {
  final bool isDetailScreen;
  final bool isProposalDetailScreen;
  final bool isFilteredProject;
  final bool isFilteredProposal;
  final ProjectsDataAttributes? projectData;
  final ProjectsData? filteredProject;
  final ProposalsData? filteredProposals;
  final ProposalsDataAttributes? proposalData;

  const ProjectDetailsScreen(
      {super.key,
      required this.projectData,
      required this.proposalData,
      required this.isProposalDetailScreen,
      required this.filteredProject,
      required this.isFilteredProject,
      required this.filteredProposals,
      required this.isFilteredProposal,
      required this.isDetailScreen});

  @override
  State<ProjectDetailsScreen> createState() => _ProjectDetailsScreenState();
}

class _ProjectDetailsScreenState extends State<ProjectDetailsScreen>
    with TickerProviderStateMixin {
  bool isExpanded = false;
  bool isExpands = false;
  bool isExpandedDependencies = false;
  bool isExpandedComments = false;
  bool isExpandKnownIssue = false;
  bool isExpandFeedback = false;
  bool isAdditionalDetails = false;
  late final TabController _tabController;
  late final TabController _docController;
  final int characterLimit = Dimensions.characterLimit_170;
  List<String> dummyFiles = [
    'First file',
    'Second File',
    'First file',
    'Second File',
    'First file',
    'Second File',
    'First file',
    'Second File',
    'First file',
    'Second File'
  ];

  @override
  void initState() {
    allData();
    _tabController =
        TabController(length: Dimensions.tabBarIndexLength_3, vsync: this);
    _docController = TabController(length: Dimensions.tabsCount_1, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void allData() {
    if (widget.isDetailScreen) {
      if (widget.projectData!.clientName != "" ||
          widget.projectData!.currency != "" ||
          widget.projectData!.budget != "" ||
          widget.projectData!.feedback != "" ||
          widget.projectData!.comments != "") {
        setState(() {
          isAdditionalDetails = true;
        });
      }
    } else if (widget.isProposalDetailScreen) {
      if (widget.proposalData!.clientDetails! != " " ||
          widget.proposalData!.comments! != " " ||
          widget.proposalData!.feedback! != " " ||
          widget.proposalData!.currency != null ||
          widget.proposalData!.currency != " " ||
          widget.proposalData!.budget != null ||
          widget.proposalData!.budget != " " ||
          widget.proposalData!.location != " " ||
          widget.proposalData!.resources!.data != null) {
        setState(() {
          isAdditionalDetails = true;
        });
      }
    } else if (widget.isFilteredProject) {
      if (widget.filteredProject!.attributes!.clientName! != "" ||
          widget.filteredProject!.attributes!.comments! != "" ||
          widget.filteredProject!.attributes!.feedback! != "" ||
          widget.filteredProject!.attributes!.currency! != "" ||
          widget.filteredProject!.attributes!.budget! != "" ||
          widget.filteredProject!.attributes!.resources!.data!.isNotEmpty) {
        setState(() {
          isAdditionalDetails = true;
        });
      }
    } else if (widget.isFilteredProposal) {
      if (widget.filteredProposals!.attributes!.clientDetails! != "" ||
          widget.filteredProposals!.attributes!.comments! != "" ||
          widget.filteredProposals!.attributes!.feedback! != "" ||
          //widget.filteredProposals!.currency != "" ||
          widget.filteredProposals!.attributes!.currency != null ||
          //widget.filteredProposals!.budget! != "" ||
          widget.filteredProposals!.attributes!.budget != null ||
          widget.filteredProposals!.attributes!.resources!.data!.isNotEmpty) {
        setState(() {
          isAdditionalDetails = true;
        });
      }
    } else {
      setState(() {
        isAdditionalDetails = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            widget.isFilteredProject
                ? widget.filteredProject!.attributes!.name!
                : widget.isFilteredProposal
                    ? widget.filteredProposals!.attributes!.name!
                    : widget.isDetailScreen
                        ? widget.projectData!.name!
                        : widget.proposalData!.name!,
            maxLines: Dimensions.maxTextLines_1,
            textAlign: TextAlign.center,
            style:
                TextStyle(color: AppColors.white, fontSize: Dimensions.font_20),
          ),
          backgroundColor: AppColors.appBottomNavigationBar,
          actions: [
            IconButton(
                onPressed: () {
                  ShowBottomSheet.getInstance.showUploadedDocuments(
                      context, dummyFiles, _docController);
                },
                icon: Icon(
                  Icons.attach_file,
                  color: AppColors.white,
                )),
            // Visibility(
            //     visible: SharedPrefs.instance.getString(Constants.userRole) !=
            //         Strings().user,
            //     child: IconButton(
            //       onPressed: () {},
            //       icon: Icon(
            //         Icons.edit_outlined,
            //         size: Dimensions.iconSize_24,
            //         color: AppColors.white,
            //       ),
            //     )),
          ],
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back,
                color: AppColors.white,
              ))),
      body: Column(
        children: [
          Container(
            color: AppColors.tabBarBackground,
            height: Dimensions.height_50,
            child: TabBar(
                controller: _tabController,
                labelPadding: EdgeInsets.only(right: Dimensions.padding_5),
                padding: EdgeInsets.zero,
                indicatorColor: AppColors.appBottomNavigationBar,
                indicatorPadding: EdgeInsets.zero,
                labelColor: AppColors.appBottomNavigationBar,
                indicatorSize: TabBarIndicatorSize.tab,
                unselectedLabelStyle: TextStyle(
                    color: AppColors.appBottomNavigationBar,
                    fontWeight: FontWeight.normal,
                    fontSize: Dimensions.font_14),
                labelStyle: TextStyle(
                    color: AppColors.appBottomNavigationBar,
                    fontWeight: FontWeight.w600,
                    fontSize: Dimensions.font_14),
                tabs: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_0,
                        right: Dimensions.padding_0),
                    child: Text(
                      Strings().basicDetailsText,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_0,
                        right: Dimensions.padding_0),
                    child: Text(
                      Strings().technicalInfoText,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_0,
                        right: Dimensions.padding_0),
                    child: Text(
                      Strings().additionalDetailsText,
                      maxLines: Dimensions.maxTextLines_1,
                    ),
                  ),
                ]),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(Dimensions.padding_10),
              child: TabBarView(controller: _tabController, children: [
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (widget.isFilteredProject)
                        detailsTextFields(Strings().projectName,
                            widget.filteredProject!.attributes!.name!),
                      if (widget.isFilteredProposal)
                        detailsTextFields(Strings().proposalName,
                            widget.filteredProposals!.attributes!.name!),
                      if (widget.isDetailScreen)
                        detailsTextFields(
                            Strings().projectName, widget.projectData!.name!),
                      if (widget.isProposalDetailScreen)
                        detailsTextFields(
                            Strings().proposalName, widget.proposalData!.name!),
                      detailsTextFields(
                        Strings().domainText,
                        widget.isFilteredProject
                            ? widget.filteredProject!.attributes!.domain!.data!
                                .attributes!.name!
                                .toTitleCase()
                            : widget.isDetailScreen
                                ? widget.projectData!.domain!.data!.attributes!
                                    .name!
                                    .toTitleCase()
                                : widget.isFilteredProposal
                                    ? widget.filteredProposals!.attributes!
                                        .domain!.data!.attributes!.name!
                                        .toTitleCase()
                                    : widget.proposalData!.domain!.data!
                                        .attributes!.name!
                                        .toTitleCase(),
                      ),
                      if (widget.isFilteredProject &&
                          widget.filteredProject!.attributes!.objectives !=
                              null)
                        detailsFields(
                            Strings().objectiveText,
                            expandableFields(isExpands,
                                widget.filteredProject!.attributes!.objectives!,
                                () {
                              setState(() {
                                isExpands = !isExpands;
                              });
                            })),
                      if (widget.isDetailScreen &&
                          widget.projectData!.objectives != null)
                        detailsFields(
                            Strings().objectiveText,
                            expandableFields(
                                isExpands, widget.projectData!.objectives!, () {
                              setState(() {
                                isExpands = !isExpands;
                              });
                            })),
                      if (widget.isProposalDetailScreen &&
                          widget.proposalData!.objectives != null)
                        detailsFields(
                            Strings().objectiveText,
                            expandableFields(
                                isExpands, widget.proposalData!.objectives!,
                                () {
                              setState(() {
                                isExpands = !isExpands;
                              });
                            })),
                      if (widget.isFilteredProposal &&
                          widget.filteredProposals!.attributes!.objectives !=
                              null)
                        detailsFields(
                            Strings().objectiveText,
                            expandableFields(
                                isExpands,
                                widget.filteredProposals!.attributes!
                                    .objectives!, () {
                              setState(() {
                                isExpands = !isExpands;
                              });
                            })),
                      if (widget.isDetailScreen)
                        detailsFields(
                            Strings().summaryText,
                            expandableFields(
                                isExpanded, widget.projectData!.summary!, () {
                              setState(() {
                                isExpanded = !isExpanded;
                              });
                            })),
                      if (widget.isFilteredProject)
                        detailsFields(
                            Strings().summaryText,
                            expandableFields(isExpanded,
                                widget.filteredProject!.attributes!.summary!,
                                () {
                              setState(() {
                                isExpanded = !isExpanded;
                              });
                            })),
                      if (widget.isProposalDetailScreen)
                        detailsFields(
                            Strings().summaryText,
                            expandableFields(
                                isExpanded, widget.proposalData!.summery!, () {
                              setState(() {
                                isExpanded = !isExpanded;
                              });
                            })),
                      if (widget.isFilteredProposal)
                        detailsFields(
                            Strings().summaryText,
                            expandableFields(isExpanded,
                                widget.filteredProposals!.attributes!.summery!,
                                () {
                              setState(() {
                                isExpanded = !isExpanded;
                              });
                            })),
                      SizedBox(
                        height: Dimensions.height_10,
                      ),
                      if (widget.isDetailScreen)
                        detailsListviewFields(
                            Strings().functionalityText,
                            MediaQuery.removePadding(
                              context: context,
                              removeTop: true,
                              removeBottom: true,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget.projectData!
                                      .functionalities!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}. ${widget.projectData!.functionalities!.data![index]!.attributes!.name!.toTitleCase()}"),
                                    );
                                  }),
                            ),
                            context),
                      if (widget.isFilteredProject)
                        detailsListviewFields(
                            Strings().functionalityText,
                            MediaQuery.removePadding(
                              context: context,
                              removeTop: true,
                              removeBottom: true,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget.filteredProject!.attributes!
                                      .functionalities!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}.${widget.filteredProject!.attributes!.functionalities!.data![index]!.attributes!.name!.toTitleCase()}"),
                                    );
                                  }),
                            ),
                            context),
                      if (widget.isProposalDetailScreen)
                        detailsListviewFields(
                            Strings().functionalityText,
                            MediaQuery.removePadding(
                              context: context,
                              removeTop: true,
                              removeBottom: true,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget.proposalData!
                                      .functionalities!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}. ${widget.proposalData!.functionalities!.data![index]!.attributes!.name!.toTitleCase()}"),
                                    );
                                  }),
                            ),
                            context),
                      if (widget.isFilteredProposal)
                        detailsListviewFields(
                            Strings().functionalityText,
                            MediaQuery.removePadding(
                              context: context,
                              removeTop: true,
                              removeBottom: true,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget
                                      .filteredProposals!
                                      .attributes!
                                      .functionalities!
                                      .data!
                                      .length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}. ${widget.filteredProposals!.attributes!.functionalities!.data![index]!.attributes!.name!.toTitleCase()}"),
                                    );
                                  }),
                            ),
                            context),
                      detailsTextFields(
                          widget.isDetailScreen || widget.isFilteredProject
                              ? Strings().startDateText
                              : Strings().receivedDateText,
                          widget.isFilteredProject
                              ? widget.filteredProject!.attributes!.startDate!
                              : widget.isDetailScreen
                                  ? widget.projectData!.startDate!
                                  : widget.isFilteredProposal
                                      ? widget.filteredProposals!.attributes!
                                          .proposalReceivedDate!
                                      : widget
                                          .proposalData!.proposalReceivedDate!),
                      if (widget.isFilteredProject &&
                          widget.filteredProject!.attributes!.endDate != null)
                        detailsTextFields(Strings().endDateText,
                            widget.filteredProject!.attributes!.endDate!),
                      if (widget.isDetailScreen &&
                          widget.projectData!.endDate != null)
                        detailsTextFields(Strings().endDateText,
                            widget.projectData!.endDate!),
                      if (widget.isProposalDetailScreen &&
                          widget.proposalData!.proposalSubmittedDate != null)
                        detailsTextFields(Strings().submittedDateText,
                            widget.proposalData!.proposalSubmittedDate!),
                      if (widget.isFilteredProposal &&
                          widget.filteredProposals!.attributes!
                                  .proposalSubmittedDate !=
                              null)
                        detailsTextFields(
                            Strings().submittedDateText,
                            widget.filteredProposals!.attributes!
                                .proposalSubmittedDate!),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().statusText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            Container(
                                decoration: BoxDecoration(
                                    color: StatusColors.getColors(
                                        widget.isFilteredProject
                                            ? widget
                                                .filteredProject!
                                                .attributes!
                                                .status!
                                                .data!
                                                .attributes!
                                                .name!
                                                .toTitleCase()
                                            : widget.isDetailScreen
                                                ? widget.projectData!.status!
                                                    .data!.attributes!.name!
                                                    .toTitleCase()
                                                : widget.isFilteredProposal
                                                    ? widget
                                                        .filteredProposals!
                                                        .attributes!
                                                        .status!
                                                        .data!
                                                        .attributes!
                                                        .name!
                                                        .toTitleCase()
                                                    : widget
                                                        .proposalData!
                                                        .status!
                                                        .data!
                                                        .attributes!
                                                        .name!
                                                        .toTitleCase()),
                                    borderRadius: BorderRadius.circular(
                                        Dimensions.borderRadius_20)),
                                child: Padding(
                                    padding:
                                        EdgeInsets.fromLTRB(Dimensions.padding_10, Dimensions.padding_5, Dimensions.padding_10, Dimensions.padding_5),
                                    child: Text(widget.isFilteredProject
                                        ? widget.filteredProject!.attributes!.status!.data!.attributes!.name!.toTitleCase()
                                        : widget.isDetailScreen
                                            ? widget.projectData!.status!.data!.attributes!.name!.toTitleCase()
                                            : widget.isFilteredProposal
                                                ? widget.filteredProposals!.attributes!.status!.data!.attributes!.name!.toTitleCase()
                                                : widget.proposalData!.status!.data!.attributes!.name!.toTitleCase())))
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      detailsListviewFields(
                          Strings().platformText,
                          MediaQuery.removePadding(
                            context: context,
                            removeTop: true,
                            removeBottom: true,
                            child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: widget.isFilteredProject
                                    ? widget.filteredProject!.attributes!
                                        .platforms!.data!.length
                                    : widget.isDetailScreen
                                        ? widget.projectData!.platforms!.data!
                                            .length
                                        : widget.isFilteredProposal
                                            ? widget
                                                .filteredProposals!
                                                .attributes!
                                                .platforms!
                                                .data!
                                                .length
                                            : widget.proposalData!.platforms!
                                                .data!.length,
                                itemBuilder: (context, index) {
                                  return ListTile(
                                    visualDensity: VisualDensity(
                                        vertical: Dimensions.verticalLength_4),
                                    contentPadding: EdgeInsets.only(
                                        left: Dimensions.padding_0,
                                        bottom: Dimensions.padding_0),
                                    title: widget.isFilteredProject
                                        ? Text(
                                            "${index + 1}. ${widget.filteredProject!.attributes!.platforms!.data![index]!.attributes!.name!.toTitleCase()}")
                                        : widget.isDetailScreen
                                            ? Text(
                                                "${index + 1}. ${widget.projectData!.platforms!.data![index]!.attributes!.name!.toTitleCase()}")
                                            : widget.isFilteredProposal
                                                ? Text(
                                                    "${index + 1}. ${widget.filteredProposals!.attributes!.platforms!.data![index]!.attributes!.name!.toTitleCase()}")
                                                : Text(
                                                    "${index + 1}. ${widget.proposalData!.platforms!.data![index]!.attributes!.name!.toTitleCase()}"),
                                  );
                                }),
                          ),
                          context),
                      detailsListviewFields(
                          Strings().technologyText,
                          MediaQuery.removePadding(
                            context: context,
                            removeTop: true,
                            removeBottom: true,
                            child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: widget.isFilteredProject
                                    ? widget.filteredProject!.attributes!
                                        .technologies!.data!.length
                                    : widget.isDetailScreen
                                        ? widget.projectData!.technologies!
                                            .data!.length
                                        : widget.isFilteredProposal
                                            ? widget
                                                .filteredProposals!
                                                .attributes!
                                                .technologies!
                                                .data!
                                                .length
                                            : widget.proposalData!.technologies!
                                                .data!.length,
                                itemBuilder: (context, index) {
                                  return ListTile(
                                    visualDensity: VisualDensity(
                                        vertical: Dimensions.verticalLength_4),
                                    contentPadding: EdgeInsets.only(
                                        left: Dimensions.padding_0,
                                        bottom: Dimensions.padding_0),
                                    title: widget.isFilteredProject
                                        ? Text(
                                            "${index + 1}. ${widget.filteredProject!.attributes!.technologies!.data![index]!.attributes!.name!.toTitleCase()}")
                                        : widget.isDetailScreen
                                            ? Text(
                                                "${index + 1}. ${widget.projectData!.technologies!.data![index]!.attributes!.name!.toTitleCase()}")
                                            : widget.isFilteredProposal
                                                ? Text(
                                                    "${index + 1}. ${widget.filteredProposals!.attributes!.technologies!.data![index]!.attributes!.name!.toTitleCase()}")
                                                : Text(
                                                    "${index + 1}. ${widget.proposalData!.technologies!.data![index]!.attributes!.name!.toTitleCase()}"),
                                  );
                                }),
                          ),
                          context),
                      if (widget.isFilteredProject &&
                          widget.filteredProject!.attributes!.knownIssues !=
                              null &&
                          widget.filteredProject!.attributes!.knownIssues !=
                              " ")
                        detailsFields(
                            Strings().knownIssueText,
                            expandableFields(
                                isExpandKnownIssue,
                                widget.filteredProject!.attributes!
                                    .knownIssues!, () {
                              setState(() {
                                isExpandKnownIssue = !isExpandKnownIssue;
                              });
                            })),
                      if (widget.isDetailScreen &&
                          widget.projectData!.knownIssues != null &&
                          widget.projectData!.knownIssues != " ")
                        detailsFields(
                            Strings().knownIssueText,
                            expandableFields(isExpandKnownIssue,
                                widget.projectData!.knownIssues!, () {
                              setState(() {
                                isExpandKnownIssue = !isExpandKnownIssue;
                              });
                            })),
                      if (widget.isProposalDetailScreen &&
                          widget.proposalData!.riskFactors != null &&
                          widget.proposalData!.riskFactors != " ")
                        detailsFields(
                            Strings().riskFactorText,
                            expandableFields(isExpandKnownIssue,
                                widget.proposalData!.riskFactors, () {
                              setState(() {
                                isExpandKnownIssue = !isExpandKnownIssue;
                              });
                            })),
                      if (widget.isFilteredProposal &&
                          widget.filteredProposals!.attributes!.riskFactors !=
                              null &&
                          widget.filteredProposals!.attributes!.riskFactors !=
                              " ")
                        detailsFields(
                            Strings().riskFactorText,
                            expandableFields(
                                isExpandKnownIssue,
                                widget.filteredProposals!.attributes!
                                    .riskFactors!, () {
                              setState(() {
                                isExpandKnownIssue = !isExpandKnownIssue;
                              });
                            })),
                      if (widget.isFilteredProject &&
                          widget.filteredProject!.attributes!.dependencies !=
                              null &&
                          widget.filteredProject!.attributes!.knownIssues !=
                              " ")
                        detailsFields(
                            Strings().dependenciesText,
                            expandableFields(
                                isExpandedDependencies,
                                widget.filteredProject!.attributes!
                                    .dependencies, () {
                              setState(() {
                                isExpandedDependencies =
                                    !isExpandedDependencies;
                              });
                            })),
                      if (widget.isDetailScreen &&
                          widget.projectData!.dependencies != null &&
                          widget.projectData!.knownIssues != " ")
                        detailsFields(
                            Strings().dependenciesText,
                            expandableFields(isExpandedDependencies,
                                widget.projectData!.dependencies, () {
                              setState(() {
                                isExpandedDependencies =
                                    !isExpandedDependencies;
                              });
                            })),
                      if (widget.isProposalDetailScreen &&
                          widget.proposalData!.dependencies != null &&
                          widget.proposalData!.dependencies != " ")
                        detailsFields(
                            Strings().dependenciesText,
                            expandableFields(isExpandedDependencies,
                                widget.proposalData!.dependencies, () {
                              setState(() {
                                isExpandedDependencies =
                                    !isExpandedDependencies;
                              });
                            })),
                      if (widget.isFilteredProposal &&
                          widget.filteredProposals!.attributes!.dependencies !=
                              null &&
                          widget.filteredProposals!.attributes!.dependencies !=
                              " ")
                        detailsFields(
                            Strings().dependenciesText,
                            expandableFields(
                                isExpandedDependencies,
                                widget.filteredProposals!.attributes!
                                    .objectives!, () {
                              setState(() {
                                isExpandedDependencies =
                                    !isExpandedDependencies;
                              });
                            })),
                    ],
                  ),
                ),
                if (!isAdditionalDetails)
                  const Center(
                    child: Text("No additional details"),
                  ),
                if (isAdditionalDetails)
                  SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (widget.isFilteredProject &&
                            widget.filteredProject!.attributes!.clientName !=
                                null &&
                            widget.filteredProject!.attributes!.clientName !=
                                "")
                          detailsTextFields(
                              Strings().clientsNameText,
                              widget.filteredProject!.attributes!.clientName!
                                  .toTitleCase()),
                        if (widget.isDetailScreen &&
                            widget.projectData!.clientName != null &&
                            widget.projectData!.clientName != "")
                          detailsTextFields(Strings().clientsNameText,
                              widget.projectData!.clientName!.toTitleCase()),
                        if (widget.isProposalDetailScreen &&
                            widget.proposalData!.clientDetails != null &&
                            widget.proposalData!.clientDetails != "")
                          detailsTextFields(
                              Strings().clientsNameText,
                              widget.proposalData!.clientDetails!
                                  .toTitleCase()),
                        if (widget.isFilteredProposal &&
                            widget.filteredProposals!.attributes!
                                    .clientDetails !=
                                null &&
                            widget.filteredProposals!.attributes!
                                    .clientDetails !=
                                "")
                          detailsTextFields(
                              Strings().clientsNameText,
                              widget
                                  .filteredProposals!.attributes!.clientDetails!
                                  .toTitleCase()),
                        if (widget.isFilteredProject &&
                            widget.filteredProject!.attributes!.budget != "" &&
                            widget.filteredProject!.attributes!.budget !=
                                null &&
                            widget.filteredProject!.attributes!.currency !=
                                null &&
                            widget.filteredProject!.attributes!.currency != "")
                          detailsTextFields(Strings().projectCost,
                              "${widget.filteredProject!.attributes!.currency!} ${widget.filteredProject!.attributes!.budget!.toTitleCase()}"),
                        if (widget.isFilteredProposal &&
                            widget.filteredProposals!.attributes!.budget !=
                                null &&
                            widget.filteredProposals!.attributes!.budget !=
                                "" &&
                            widget.filteredProposals!.attributes!.currency !=
                                null &&
                            widget.filteredProposals!.attributes!.currency !=
                                "")
                          detailsTextFields(Strings().projectCost,
                              "${widget.filteredProposals!.attributes!.currency!} ${widget.filteredProposals!.attributes!.budget!.toTitleCase()}"),
                        if (widget.isDetailScreen &&
                            widget.projectData!.budget != null &&
                            widget.projectData!.budget != "" &&
                            widget.projectData!.currency != null &&
                            widget.projectData!.currency != "")
                          detailsTextFields(Strings().projectCost,
                              "${widget.projectData!.currency!} ${widget.projectData!.budget!.toTitleCase()}"),
                        if (widget.isProposalDetailScreen &&
                            widget.proposalData!.budget != null &&
                            widget.proposalData!.budget != "" &&
                            widget.proposalData!.currency != null &&
                            widget.proposalData!.currency != "")
                          detailsTextFields(Strings().projectCost,
                              "${widget.proposalData!.currency!} ${widget.proposalData!.budget!.toTitleCase()}"),
                        if (widget.isFilteredProject &&
                            widget.filteredProject!.attributes!.location !=
                                null &&
                            widget.filteredProject!.attributes!.location != " ")
                          detailsTextFields(Strings().location,
                              widget.filteredProject!.attributes!.location!),
                        if (widget.isFilteredProposal &&
                            widget.filteredProposals!.attributes!.location !=
                                null &&
                            widget.filteredProposals!.attributes!.location !=
                                "")
                          detailsTextFields(Strings().location,
                              widget.filteredProposals!.attributes!.location!),
                        if (widget.isDetailScreen &&
                            widget.projectData!.location != null &&
                            widget.projectData!.location != "")
                          detailsTextFields(Strings().location,
                              widget.projectData!.location!),
                        if (widget.isProposalDetailScreen &&
                            widget.proposalData!.location != null &&
                            widget.proposalData!.location != "")
                          detailsTextFields(Strings().location,
                              widget.proposalData!.location!),
                        if (widget.isFilteredProject &&
                            widget.filteredProject!.attributes!.resources !=
                                null &&
                            widget.filteredProject!.attributes!.resources != [])
                          detailsListviewFields(
                              Strings().resourceDetail,
                              ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget.filteredProject!.attributes!
                                      .resources!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}. ${widget.filteredProject!.attributes!.resources!.data![index]!.attributes!.resourceName!.toTitleCase()} - ${widget.filteredProject!.attributes!.resources!.data![index]!.attributes!.designation!.toTitleCase()}"),
                                      subtitle: Text(
                                          "${widget.filteredProject!.attributes!.resources!.data![index]!.attributes!.resourceEmail}"),
                                    );
                                  }),
                              context),
                        if (widget.isDetailScreen &&
                            widget.projectData!.resources != null &&
                            widget.projectData!.resources!.data!.isNotEmpty)
                          detailsListviewFields(
                              Strings().resourceDetail,
                              ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget
                                      .projectData!.resources!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                        visualDensity: VisualDensity(
                                            vertical:
                                                Dimensions.verticalLength_4),
                                        contentPadding: EdgeInsets.only(
                                            left: Dimensions.padding_0,
                                            bottom: Dimensions.padding_0),
                                        title: Text(
                                            "${index + 1}. ${widget.projectData!.resources!.data![index]!.attributes!.resourceName!.toTitleCase()} - ${widget.projectData!.resources!.data![index]!.attributes!.designation}"),
                                        subtitle: Text(
                                            "${widget.projectData!.resources!.data![index]!.attributes!.resourceEmail}"));
                                  }),
                              context),
                        if (widget.isProposalDetailScreen &&
                            widget.proposalData!.resources!.data != null &&
                            widget.proposalData!.resources!.data!.isNotEmpty)
                          detailsListviewFields(
                              Strings().resourceDetail,
                              ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget
                                      .proposalData!.resources!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}. ${widget.proposalData!.resources!.data![index]!.attributes!.resourceName!.toTitleCase()} - ${widget.proposalData!.resources!.data![index]!.attributes!.designation!.toTitleCase()}"),
                                      subtitle: Text(
                                          "${widget.proposalData!.resources!.data![index]!.attributes!.resourceEmail}"),
                                    );
                                  }),
                              context),
                        if (widget.isFilteredProposal &&
                            widget.filteredProposals!.attributes!.resources !=
                                null)
                          detailsListviewFields(
                              Strings().resourceDetail,
                              ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: widget.filteredProposals!
                                      .attributes!.resources!.data!.length,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      visualDensity: VisualDensity(
                                          vertical:
                                              Dimensions.verticalLength_4),
                                      contentPadding: EdgeInsets.only(
                                          left: Dimensions.padding_0,
                                          bottom: Dimensions.padding_0),
                                      title: Text(
                                          "${index + 1}. ${widget.filteredProposals!.attributes!.resources!.data![index]!.attributes!.resourceName!.toTitleCase()} - ${widget.filteredProposals!.attributes!.resources!.data![index]!.attributes!.designation!.toTitleCase()}"),
                                      subtitle: Text(
                                          "${widget.filteredProposals!.attributes!.resources!.data![index]!.attributes!.resourceEmail}"),
                                    );
                                  }),
                              context),
                        if (widget.isFilteredProject &&
                            widget.filteredProject!.attributes!.comments !=
                                null &&
                            widget.filteredProject!.attributes!.comments != "")
                          detailsFields(
                              Strings().commentsText,
                              expandableFields(isExpandedComments,
                                  widget.filteredProject!.attributes!.comments,
                                  () {
                                setState(() {
                                  isExpandedComments = !isExpandedComments;
                                });
                              })),
                        if (widget.isDetailScreen &&
                            widget.projectData!.comments != null &&
                            widget.projectData!.comments != "")
                          detailsFields(
                              Strings().commentsText,
                              expandableFields(isExpandedComments,
                                  widget.projectData!.comments, () {
                                setState(() {
                                  isExpandedComments = !isExpandedComments;
                                });
                              })),
                        if (widget.isProposalDetailScreen &&
                            widget.proposalData!.comments != null &&
                            widget.proposalData!.comments != "")
                          detailsFields(
                              Strings().commentsText,
                              expandableFields(isExpandedComments,
                                  widget.proposalData!.comments, () {
                                setState(() {
                                  isExpandedComments = !isExpandedComments;
                                });
                              })),
                        if (widget.isFilteredProposal &&
                            widget.filteredProposals!.attributes!.comments !=
                                null &&
                            widget.filteredProposals!.attributes!.comments !=
                                "")
                          detailsFields(
                              Strings().commentsText,
                              expandableFields(
                                  isExpandedComments,
                                  widget.filteredProposals!.attributes!
                                      .comments!, () {
                                setState(() {
                                  isExpandedComments = !isExpandedComments;
                                });
                              })),
                        if (widget.isFilteredProject &&
                            widget.filteredProject!.attributes!.feedback !=
                                null &&
                            widget.filteredProject!.attributes!.feedback != "")
                          detailsFields(
                              Strings().feedbackText,
                              expandableFields(isExpandFeedback,
                                  widget.filteredProject!.attributes!.feedback,
                                  () {
                                setState(() {
                                  isExpandFeedback = !isExpandFeedback;
                                });
                              })),
                        if (widget.isDetailScreen &&
                            widget.projectData!.feedback != null &&
                            widget.projectData!.feedback != "")
                          detailsFields(
                            Strings().feedbackText,
                            expandableFields(
                                isExpandFeedback, widget.projectData!.feedback,
                                () {
                              setState(() {
                                isExpandFeedback = !isExpandFeedback;
                              });
                            }),
                          ),
                        if (widget.isProposalDetailScreen &&
                            widget.proposalData!.feedback != null &&
                            widget.proposalData!.feedback != "")
                          detailsFields(
                            Strings().feedbackText,
                            expandableFields(
                                isExpandFeedback, widget.proposalData!.feedback,
                                () {
                              setState(() {
                                isExpandFeedback = !isExpandFeedback;
                              });
                            }),
                          ),
                        if (widget.isFilteredProposal)
                          Visibility(
                              visible: widget.filteredProposals!.attributes!
                                          .feedback !=
                                      null &&
                                  widget.filteredProposals!.attributes!
                                          .feedback !=
                                      "",
                              child: detailsFields(
                                  Strings().feedbackText,
                                  expandableFields(
                                      isExpandFeedback,
                                      widget.filteredProposals!.attributes!
                                          .feedback!, () {
                                    setState(() {
                                      isExpandFeedback = !isExpandFeedback;
                                    });
                                  }))),
                      ],
                    ),
                  )
              ]),
            ),
          )
        ],
      ),
    );
  }
}

/// This widget is used to showcase detailsTextField
Widget detailsTextFields(String title, String subtitle) {
  return Padding(
    padding: EdgeInsets.all(Dimensions.padding_10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: AppColors.titleColor,
            fontSize: Dimensions.font_12,
          ),
        ),
        SizedBox(
          height: Dimensions.height_8,
        ),
        Text(
          subtitle,
          style: TextStyle(
              color: AppColors.subTitleColor, fontSize: Dimensions.font_16),
        ),
      ],
    ),
  );
}

/// This widget is used to showcase detailsField
Widget detailsFields(String title, Widget inWell) {
  return Padding(
    padding: EdgeInsets.all(Dimensions.padding_10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: AppColors.titleColor,
            fontSize: Dimensions.font_12,
          ),
        ),
        SizedBox(
          height: Dimensions.height_8,
        ),
        inWell
      ],
    ),
  );
}

/// Expandable and collapsable text fields
Widget expandableFields(
    bool isExpandable, String? expandableText, void Function()? onTap) {
  return InkWell(
    onTap: onTap,
    child: AnimatedCrossFade(
      duration: Duration(milliseconds: Dimensions.milliseconds_500),
      firstChild: RichText(
        text: TextSpan(
          children: <TextSpan>[
            TextSpan(
              text: expandableText!.length > Dimensions.characterLimit_170
                  ? expandableText
                      .substring(
                          Dimensions.selection_0, Dimensions.characterLimit_170)
                      .replaceAll(RegExp(r"\s+"), " ")
                  : expandableText,
              style: TextStyle(
                  color: AppColors.subTitleColor, fontSize: Dimensions.font_16),
            ),
            if (expandableText.length > Dimensions.characterLimit_170)
              TextSpan(
                text: Strings().readMore,
                style: TextStyle(
                    color: AppColors.blue, fontSize: Dimensions.font_14),
              ),
          ],
        ),
      ),
      crossFadeState:
          isExpandable ? CrossFadeState.showSecond : CrossFadeState.showFirst,
      secondChild: Text(
        expandableText,
        style: TextStyle(
            color: AppColors.subTitleColor, fontSize: Dimensions.font_16),
      ),
    ),
  );
}

/// This widget is used to showcase detailsListviewField
Widget detailsListviewFields(String title, Widget padding, context) {
  return Padding(
    padding: EdgeInsets.only(
      left: Dimensions.padding_10,
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: AppColors.titleColor,
            fontSize: Dimensions.font_12,
          ),
        ),
        MediaQuery.removePadding(
          context: context,
          removeTop: true,
          removeBottom: true,
          child: padding,
        )
      ],
    ),
  );
}
