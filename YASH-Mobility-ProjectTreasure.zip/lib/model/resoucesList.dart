class ResourcesListMetaPagination {
  int? page;
  int? pageSize;
  int? pageCount;
  int? total;

  ResourcesListMetaPagination({
    this.page,
    this.pageSize,
    this.pageCount,
    this.total,
  });
  ResourcesListMetaPagination.fromJson(Map<String, dynamic> json) {
    page = json['page']?.toInt();
    pageSize = json['pageSize']?.toInt();
    pageCount = json['pageCount']?.toInt();
    total = json['total']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['pageCount'] = pageCount;
    data['total'] = total;
    return data;
  }
}

class ResourcesListMeta {
  ResourcesListMetaPagination? pagination;

  ResourcesListMeta({
    this.pagination,
  });
  ResourcesListMeta.fromJson(Map<String, dynamic> json) {
    pagination = (json['pagination'] != null) ? ResourcesListMetaPagination.fromJson(json['pagination']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    return data;
  }
}

class ResourcesListDataAttributes {
  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  ResourcesListDataAttributes({
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  ResourcesListDataAttributes.fromJson(Map<String, dynamic> json) {
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class ResourcesListData {
  int? id;
  ResourcesListDataAttributes? attributes;

  ResourcesListData({
    this.id,
    this.attributes,
  });
  ResourcesListData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null) ? ResourcesListDataAttributes.fromJson(json['attributes']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class ResourcesList {
  List<ResourcesListData?>? data;
  ResourcesListMeta? meta;

  ResourcesList({
    this.data,
    this.meta,
  });
  ResourcesList.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ResourcesListData>[];
      v.forEach((v) {
        arr0.add(ResourcesListData.fromJson(v));
      });
      this.data = arr0;
    }
    meta = (json['meta'] != null) ? ResourcesListMeta.fromJson(json['meta']) : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    if (meta != null) {
      data['meta'] = meta!.toJson();
    }
    return data;
  }
}
