part of 'projects_bloc.dart';

@immutable
abstract class ProjectsEvent {}

/// This event will be used to fetch the api and load all the projects data.
class ProjectsInitialEvent extends ProjectsEvent {}

/// This event will be triggered on Project Screen when user search in searchBar.
class GetUserSearchIn extends ProjectsEvent {
  final String searchInProjects;
  GetUserSearchIn(this.searchInProjects);
}

/// This event will be triggered on Project Screen when user search in searchBar.
class GetUserSearchInProposal extends ProjectsEvent {
  final String searchInProposal;
  GetUserSearchInProposal(this.searchInProposal);
}

/// This event will be used to handle the errors occurred during api fetch.
class ProjectsErrorEvent extends ProjectsEvent {}

/// This event will be used to fetch the api and load all the proposals data.
class ProposalsInitialEvent extends ProjectsEvent {}

class FilteredProjectsLoadedEvent extends ProjectsEvent {}
class OfflineProjectsLoadedEvent extends ProjectsEvent {}
class FilteredProposalsLoadedEvent extends ProjectsEvent {}
class OfflineProposalsLoadedEvent extends ProjectsEvent {}

/// This event will be used to handle the UI of Circular progress indicator of Retry button.
class RetryButtonClickedEvent extends ProjectsEvent {}

class LoadPlatformsListEvent extends ProjectsEvent{}
class LoadStatusListEvent extends ProjectsEvent{}
class LoadTechListEvent extends ProjectsEvent{}
class LoadFunctionalitiesListEvent extends ProjectsEvent{}
class LoadDomainsListEvent extends ProjectsEvent{}
class LoadResourcesListEvent extends ProjectsEvent{}
class LoadMethodologiesListEvent extends ProjectsEvent{}
