part of 'basic_details_screen_bloc.dart';

@immutable
abstract class BasicDetailEvent {}

class BasicDetailInitialEvent extends BasicDetailEvent {}

/// Event for Basic detail screen Attachment button.
class BasicDetailAttachmentBtnEvent extends BasicDetailEvent {}

/// Event for Basic detail screen Save button.
class BasicDetailSaveBtnEvent extends BasicDetailEvent {}

/// Event for Navigation from Basic detail screen to Technical information screen.
class NavigateBasicDetailToTechInfoEvent extends BasicDetailEvent {}

/// Event for Basic detail screen Domain list.
class DomainLoadedEvent extends BasicDetailEvent{}

///Event for Functionality dropdown list.
class FunctionalityLoadedEvent extends BasicDetailEvent{}

/// Event for Basic detail screen Status list.
class StatusLoadedEvent extends BasicDetailEvent{}
