import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';

/// Functions to clear all filters by clearing all the data saved in Shared Preferences.
class ClearFilters {
  void clearSharedPrefsForProject() {
    SharedPrefs.instance.remove(Strings().filterCountKeyText);
    SharedPrefs.instance.remove(Strings().selectedDatesFilterKey);
    SharedPrefs.instance.remove(Strings().selectedStartDateFilterKey);
    SharedPrefs.instance.remove(Strings().selectedEndDateFilterKey);
    SharedPrefs.instance.remove(Strings().selectedStatusFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedProjectsFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedResourcesFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedPlatformsFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedTechnologiesFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedFunctionalitiesFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedDocsFiltersKeyText);
    SharedPrefs.instance.remove(Strings().selectedDomainsFiltersKey);
    SharedPrefs.instance.remove(Strings().filtersToApplyKey);
    SharedPrefs.instance.remove(Strings().applyFiltersForProjectsKeyText);
  }

  void clearSharedPrefsForProposals() {
    SharedPrefs.instance.remove(Strings().proposalSelectedDatesFilterKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedStartDateFilterKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedEndDateFilterKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedStatusFiltersKey);
    SharedPrefs.instance.remove(Strings().selectedProposalsFiltersKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedResourcesFiltersKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedPlatformsFiltersKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedTechnologiesFiltersKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedFunctionalitiesFiltersKey);
    SharedPrefs.instance.remove(Strings().proposalSelectedDocsFiltersKeyText);
    SharedPrefs.instance.remove(Strings().proposalSelectedDomainsFiltersKey);
    SharedPrefs.instance.remove(Strings().applyFiltersForProposalsKeyText);
    SharedPrefs.instance.remove(Strings().proposalFiltersToApplyKey);
  }
}