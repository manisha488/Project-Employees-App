import 'dart:core';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/text_form_field_utils.dart';

///This class defines Custom TextFormField.
class CustomTextFormField extends StatefulWidget {
  final TextEditingController textEditingController;
  final FormFieldBorderType? borderType;
  final Color? borderColor;
  final String? title;
  final Color? titleColor;
  final TextStyle? titleStyle;
  final String? label;
  final Color? labelColor;
  final IconData? prefixIcon;
  final double? iconPadding;
  final double? iconSize;
  final Color? iconColor;
  final IconData? suffixIcon;
  final Color focusBorderColor;
  final Color successBorderColor;
  final String? Function(String?)? validator;
  final void Function(String?)? onSaved;
  final void Function(String?)? onChanged;
  final void Function() onTapped;
  final bool obscureText;
  final String? obscuringCharacter;
  final TextInputType? keyboardType;
  final String? errorMessageWeak;
  final String? errorMessageMedium;
  final RegExp regEx;
  final int? minLength;
  final int? maxLength;
  final double? borderRadius;
  final int? lengthLimit;
  final Color? filledColor;


  const CustomTextFormField({
    super.key,
    required this.textEditingController,
    this.title,
    this.titleColor,
    this.titleStyle,
    this.label,
    this.labelColor,
    this.prefixIcon,
    this.iconPadding,
    this.iconSize,
    this.iconColor,
    this.suffixIcon,
    this.borderType,
    this.borderColor,
    required this.focusBorderColor,
    this.validator,
    this.onSaved,
    this.onChanged,
    required this.obscureText,
    this.obscuringCharacter = '*',
    this.keyboardType,
    this.errorMessageWeak,
    this.errorMessageMedium,
    required this.successBorderColor,
    required this.regEx,
    this.minLength = 6,
    this.maxLength = 8,
    this.borderRadius = 10,
    this.lengthLimit,
    this.filledColor,
    required this.onTapped,
  });

  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  ///Initial TextFormField stage
  TextFormInputStrength _textFormInputStrength =
      TextFormInputStrength.weakPassword;

  ///Border color change to success
  bool _hasError = false;

  @override
  void dispose() {
    widget.textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ///Border color
    final Color borderColor = widget.borderColor ?? Colors.blue;

    ///OnFocus border color
    final Color focusBorderColor = widget.focusBorderColor;

    ///Success border color
    final Color successBorderColor = widget.successBorderColor;

    ///Prefix icon
    final IconData? prefixIcon = widget.prefixIcon;

    ///Suffix icon
    final IconData? suffixIcon = widget.suffixIcon;

    ///Outline border type
    final OutlineInputBorder outlineInputBorder = OutlineInputBorder(
      borderSide: BorderSide(color: borderColor),
      borderRadius: BorderRadius.circular(widget.borderRadius!),
    );

    ///Underline border type
    final UnderlineInputBorder underlineInputBorder = UnderlineInputBorder(
      borderSide: BorderSide(color: borderColor),
    );

    ///Decision making statement for selecting the border type to outline/underline or boxFit
    final InputBorder? inputBorder =
        widget.borderType == FormFieldBorderType.outline
            ? outlineInputBorder
            : widget.borderType == FormFieldBorderType.underline
                ? underlineInputBorder
                : null;

    return TextFormField(
      ///Controller
      controller: widget.textEditingController,

      ///Keyboard type eg: Number/Email/Name
      keyboardType: widget.keyboardType,

      ///Password security text
      obscureText: widget.obscureText,

      ///Password security character
      obscuringCharacter: widget.obscuringCharacter.toString(),

      ///Onchange condition
      onChanged: (value) {
        setState(() {
          _textFormInputStrength = checkTextFormInputStrength(value);
        });
        if (widget.onChanged != null) {
          widget.onChanged!(value);
        }
      },

      ///Maximum length of string handled
      inputFormatters: [LengthLimitingTextInputFormatter(widget.lengthLimit)],

      ///Decoration
      decoration: InputDecoration(
        ///Prefix icon
        prefixIcon: Padding(
          padding: EdgeInsets.all(widget.iconPadding ?? Dimensions.padding_8),
          child: prefixIcon != null
              ? Icon(prefixIcon,
                  size: widget.iconSize ?? Dimensions.iconSize_24,
                  color: widget.iconColor)
              : null,
        ),

        ///Suffix icon
        suffixIcon: suffixIcon != null ? Icon(suffixIcon) : null,

        ///Label & Styling
        labelText: widget.title,
        labelStyle: widget.titleStyle,

        ///Border type
        border: inputBorder,
        enabledBorder: inputBorder,
        focusedBorder: OutlineInputBorder(
          borderSide: _hasError
              ? BorderSide(color: focusBorderColor)
              : BorderSide(color: successBorderColor),
          borderRadius: BorderRadius.circular(widget.borderRadius!),
        ),

        filled: widget.borderType == FormFieldBorderType.boxFit,
        fillColor: widget.borderType == FormFieldBorderType.boxFit
            ? Colors.grey[200]
            : widget.filledColor,
        errorText: _getTextFormInputStrengthErrorMessage(),

        ///  Validator
      ),
      validator: (value) {
        if (widget.validator != null) {
          return widget.validator!(value);
        }
        return null;
      },
      onTap: widget.onTapped,
      onSaved: widget.onSaved,
    );
  }

  ///Error message handled
  TextFormInputStrength checkTextFormInputStrength(String textField) {
    if (!(widget.regEx).hasMatch(textField)) {
      return TextFormInputStrength.weakPassword;
    } else if (textField.length > widget.minLength! &&
        textField.length < widget.maxLength!) {
      return TextFormInputStrength.mediumPassword;
    } else {
      return TextFormInputStrength.strongPassword;
    }
  }

  ///Return error message
  String? _getTextFormInputStrengthErrorMessage() {
    if (_textFormInputStrength == TextFormInputStrength.weakPassword &&
        widget.textEditingController.text.isNotEmpty) {
      _hasError = true;
      return widget.errorMessageWeak;
    } else if (_textFormInputStrength == TextFormInputStrength.mediumPassword) {
      _hasError = true;
      return widget.errorMessageMedium;
    } else if (widget.textEditingController.text.isEmpty) {
      _hasError = true;
      return null;
    } else {
      _hasError = false;
      return null;
    }
  }
}

class CustomTextField extends StatefulWidget {
  final TextEditingController textEditingController;
  final String labelText;
  final TextCapitalization? textCapitalization;
  final String? initialValue;
  final String? Function(String?)? validator;
  final void Function(String?)? onSaved;
  final void Function() onTapped;
  final TextInputType? keyboardType;
  final RegExp regEx;
  final bool? isCapitalised;

  const CustomTextField(
      {super.key,
      required this.textEditingController,
      required this.labelText,
      this.validator,
      this.onSaved,
      this.keyboardType,
      this.initialValue,
        this.isCapitalised,
      required this.onTapped,
      required this.regEx,
      this.textCapitalization});

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  bool isFocused = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (hasFocus) {
        setState(() {
          isFocused = hasFocus;
        });
      },
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: isFocused
                ? AppColors.basicDetailTextFieldBorderColor
                : AppColors.basicDetailTextFieldBorderColor,
          ),
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_5),
        ),
        child: TextFormField(
          textCapitalization:
              widget.textCapitalization ?? TextCapitalization.none,
          controller: widget.textEditingController,
          initialValue: widget.initialValue,
          keyboardType: widget.keyboardType,
          inputFormatters: <TextInputFormatter>[
            FilteringTextInputFormatter.allow(widget.regEx),
          ],
          decoration: InputDecoration(
            border: InputBorder.none,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: AppColors.basicDetailTextFieldBorderColor),
            ),
            labelText: widget.labelText,
            contentPadding: EdgeInsets.only(
                left: Dimensions.padding_16,
                top: Dimensions.padding_12,
                bottom: Dimensions.padding_12),
            labelStyle: TextStyle(
                color: AppColors.createProjectAppBarColor,
                fontSize: Dimensions.font_16),
          ),
          validator: (value) {
            if (widget.validator != null) {
              return widget.validator!(value);
            }
            return null;
          },
          onTap: widget.onTapped,
          onSaved: widget.onSaved,
          onChanged: (text) {
            if (widget.isCapitalised ?? true ) {
              widget.textEditingController.value = TextEditingValue(
                  text: capitalizeNew(text),
                  selection: widget.textEditingController.selection);
              UpperCaseTextFormatter();
            } else {
              widget.textEditingController.value = TextEditingValue(
                  text: text,
                  selection: widget.textEditingController.selection);
            }
          },
          maxLines: null,
        ),
      ),
    );
  }
}

class UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    return TextEditingValue(
      text: capitalize(newValue.text),
      selection: newValue.selection,
    );
  }
}

String capitalizeNew(String s) => s[0].toUpperCase() + s.substring(1);
String capitalize(String value) {
  if (value.trim().isEmpty) return "";
  return "${value[0].toUpperCase()}${value.substring(1).toLowerCase()}";
}
