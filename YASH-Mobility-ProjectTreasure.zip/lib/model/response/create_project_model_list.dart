
class CreateProjectMeta {

  CreateProjectMeta({final meta});
  CreateProjectMeta.fromJson(Map<String, dynamic> json) {}
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    return data;
  }
}

class CreateProjectDataAttributesMethodologyDataAttributes {

  String? name;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  CreateProjectDataAttributesMethodologyDataAttributes({
    this.name,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  CreateProjectDataAttributesMethodologyDataAttributes.fromJson(
      Map<String, dynamic> json) {
    name = json['name']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['name'] = name;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class CreateProjectDataAttributesMethodologyData {

  int? id;
  CreateProjectDataAttributesMethodologyDataAttributes? attributes;

  CreateProjectDataAttributesMethodologyData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesMethodologyData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesMethodologyDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectMethodologyData {

  CreateProjectDataAttributesMethodologyData? data;

  CreateProjectMethodologyData({
    this.data,
  });
  CreateProjectMethodologyData.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProjectDataAttributesMethodologyData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class CreateProjectDataAttributesStatusDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProjectDataAttributesStatusDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProjectDataAttributesStatusDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProjectDataAttributesStatusData {

  int? id;
  CreateProjectDataAttributesStatusDataAttributes? attributes;

  CreateProjectDataAttributesStatusData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesStatusData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesStatusDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectStatusData {

  CreateProjectDataAttributesStatusData? data;

  CreateProjectStatusData({
    this.data,
  });
  CreateProjectStatusData.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProjectDataAttributesStatusData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class CreateProjectDataAttributesFunctionalitiesDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProjectDataAttributesFunctionalitiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProjectDataAttributesFunctionalitiesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProjectDataAttributesFunctionalitiesData {

  int? id;
  CreateProjectDataAttributesFunctionalitiesDataAttributes? attributes;

  CreateProjectDataAttributesFunctionalitiesData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesFunctionalitiesData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesFunctionalitiesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectFunctionalitiesData {

  List<CreateProjectDataAttributesFunctionalitiesData?>? data;

  CreateProjectFunctionalitiesData({
    this.data,
  });
  CreateProjectFunctionalitiesData.fromJson(
      Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProjectDataAttributesFunctionalitiesData>[];
      v.forEach((v) {
        arr0.add(CreateProjectDataAttributesFunctionalitiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProjectDataAttributesResourcesDataAttributes {

  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  CreateProjectDataAttributesResourcesDataAttributes({
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  CreateProjectDataAttributesResourcesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class CreateProjectDataAttributesResourcesData {

  int? id;
  CreateProjectDataAttributesResourcesDataAttributes? attributes;

  CreateProjectDataAttributesResourcesData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesResourcesData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesResourcesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectResourcesData {

  List<CreateProjectDataAttributesResourcesData?>? data;

  CreateProjectResourcesData({
    this.data,
  });
  CreateProjectResourcesData.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProjectDataAttributesResourcesData>[];
      v.forEach((v) {
        arr0.add(CreateProjectDataAttributesResourcesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProjectDataAttributesPlatformsDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProjectDataAttributesPlatformsDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProjectDataAttributesPlatformsDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProjectDataAttributesPlatformsData {

  int? id;
  CreateProjectDataAttributesPlatformsDataAttributes? attributes;

  CreateProjectDataAttributesPlatformsData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesPlatformsData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesPlatformsDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectPlatformData {

  List<CreateProjectDataAttributesPlatformsData?>? data;

  CreateProjectPlatformData({
    this.data,
  });
  CreateProjectPlatformData.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProjectDataAttributesPlatformsData>[];
      v.forEach((v) {
        arr0.add(CreateProjectDataAttributesPlatformsData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProjectDataAttributesDomainDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProjectDataAttributesDomainDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProjectDataAttributesDomainDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProjectDataAttributesDomainData {

  int? id;
  CreateProjectDataAttributesDomainDataAttributes? attributes;

  CreateProjectDataAttributesDomainData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesDomainData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesDomainDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectDomainData {

  CreateProjectDataAttributesDomainData? data;

  CreateProjectDomainData({
    this.data,
  });
  CreateProjectDomainData.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProjectDataAttributesDomainData.fromJson(json['data'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class CreateProjectDataAttributesTechnologiesDataAttributes {

  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  CreateProjectDataAttributesTechnologiesDataAttributes({
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  CreateProjectDataAttributesTechnologiesDataAttributes.fromJson(
      Map<String, dynamic> json) {
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class CreateProjectDataAttributesTechnologiesData {

  int? id;
  CreateProjectDataAttributesTechnologiesDataAttributes? attributes;

  CreateProjectDataAttributesTechnologiesData({
    this.id,
    this.attributes,
  });
  CreateProjectDataAttributesTechnologiesData.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributesTechnologiesDataAttributes.fromJson(
            json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProjectTechnologiesData {

  List<CreateProjectDataAttributesTechnologiesData?>? data;

  CreateProjectTechnologiesData({
    this.data,
  });
  CreateProjectTechnologiesData.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <CreateProjectDataAttributesTechnologiesData>[];
      v.forEach((v) {
        arr0.add(CreateProjectDataAttributesTechnologiesData.fromJson(v));
      });
      this.data = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    return data;
  }
}

class CreateProjectDataAttributesDocumentsConnect {

  int? id;

  CreateProjectDataAttributesDocumentsConnect({
    this.id,
  });
  CreateProjectDataAttributesDocumentsConnect.fromJson(
      Map<String, dynamic> json) {
    id = json['id']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}

class CreateProjectDocumentsData {

  List<CreateProjectDataAttributesDocumentsConnect?>? connect;

  CreateProjectDocumentsData({
    this.connect,
  });
  CreateProjectDocumentsData.fromJson(Map<String, dynamic> json) {
    if (json['connect'] != null) {
      final v = json['connect'];
      final arr0 = <CreateProjectDataAttributesDocumentsConnect>[];
      v.forEach((v) {
        arr0.add(CreateProjectDataAttributesDocumentsConnect.fromJson(v));
      });
      connect = arr0;
    }
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (connect != null) {
      final v = connect;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['connect'] = arr0;
    }
    return data;
  }
}

class CreateProjectDataAttributes {

  String? objectives;
  String? startDate;
  String? endDate;
  String? clientName;
  String? budget;
  String? knownIssues;
  String? dependencies;
  String? comments;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  CreateProjectDocumentsData? documents;
  String? feedback;
  String? name;
  String? summary;
  String? currency;
  String? location;
  String? riskFactor;
  CreateProjectTechnologiesData? technologies;
  CreateProjectDomainData? domain;
  CreateProjectPlatformData? platforms;
  CreateProjectResourcesData? resources;
  CreateProjectFunctionalitiesData? functionalities;
  CreateProjectStatusData? status;
  CreateProjectMethodologyData? methodology;

  CreateProjectDataAttributes({
    this.objectives,
    this.startDate,
    this.endDate,
    this.clientName,
    this.budget,
    this.knownIssues,
    this.dependencies,
    this.comments,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.documents,
    this.feedback,
    this.name,
    this.summary,
    this.currency,
    this.location,
    this.riskFactor,
    this.technologies,
    this.domain,
    this.platforms,
    this.resources,
    this.functionalities,
    this.status,
    this.methodology,
  });
  CreateProjectDataAttributes.fromJson(Map<String, dynamic> json) {
    objectives = json['objectives']?.toString();
    startDate = json['start_date']?.toString();
    endDate = json['end_date']?.toString();
    clientName = json['client_name']?.toString();
    budget = json['budget']?.toString();
    knownIssues = json['known_issues']?.toString();
    dependencies = json['dependencies']?.toString();
    comments = json['comments']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    documents = (json['documents'] != null)
        ? CreateProjectDocumentsData.fromJson(json['documents'])
        : null;
    feedback = json['feedback']?.toString();
    name = json['name']?.toString();
    summary = json['summary']?.toString();
    currency = json['currency']?.toString();
    location = json['location']?.toString();
    riskFactor = json['risk_factor']?.toString();
    technologies = (json['technologies'] != null)
        ? CreateProjectTechnologiesData.fromJson(json['technologies'])
        : null;
    domain = (json['domain'] != null)
        ? CreateProjectDomainData.fromJson(json['domain'])
        : null;
    platforms = (json['platforms'] != null)
        ? CreateProjectPlatformData.fromJson(json['platforms'])
        : null;
    resources = (json['resources'] != null)
        ? CreateProjectResourcesData.fromJson(json['resources'])
        : null;
    functionalities = (json['functionalities'] != null)
        ? CreateProjectFunctionalitiesData.fromJson(
            json['functionalities'])
        : null;
    status = (json['status'] != null)
        ? CreateProjectStatusData.fromJson(json['status'])
        : null;
    methodology = (json['methodology'] != null)
        ? CreateProjectMethodologyData.fromJson(json['methodology'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['objectives'] = objectives;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['client_name'] = clientName;
    data['budget'] = budget;
    data['known_issues'] = knownIssues;
    data['dependencies'] = dependencies;
    data['comments'] = comments;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    if (documents != null) {
      data['documents'] = documents!.toJson();
    }
    data['feedback'] = feedback;
    data['name'] = name;
    data['summary'] = summary;
    data['currency'] = currency;
    data['location'] = location;
    data['risk_factor'] = riskFactor;
    if (technologies != null) {
      data['technologies'] = technologies!.toJson();
    }
    if (domain != null) {
      data['domain'] = domain!.toJson();
    }
    if (platforms != null) {
      data['platforms'] = platforms!.toJson();
    }
    if (resources != null) {
      data['resources'] = resources!.toJson();
    }
    if (functionalities != null) {
      data['functionalities'] = functionalities!.toJson();
    }
    if (status != null) {
      data['status'] = status!.toJson();
    }
    if (methodology != null) {
      data['methodology'] = methodology!.toJson();
    }
    return data;
  }
}

class CreateProjectData {

  int? id;
  CreateProjectDataAttributes? attributes;

  CreateProjectData({
    this.id,
    this.attributes,
  });
  CreateProjectData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    attributes = (json['attributes'] != null)
        ? CreateProjectDataAttributes.fromJson(json['attributes'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    if (attributes != null) {
      data['attributes'] = attributes!.toJson();
    }
    return data;
  }
}

class CreateProject {

  CreateProjectData? data;
  CreateProjectMeta? meta;

  CreateProject({
    this.data,
    this.meta,
  });
  CreateProject.fromJson(Map<String, dynamic> json) {
    data = (json['data'] != null)
        ? CreateProjectData.fromJson(json['data'])
        : null;
    meta = (json['meta'] != null)
        ? CreateProjectMeta.fromJson(json['meta'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (data != null) {
      data['data'] = this.data!.toJson();
    }
    if (meta != null) {
      data['meta'] = meta!.toJson();
    }
    return data;
  }
}
