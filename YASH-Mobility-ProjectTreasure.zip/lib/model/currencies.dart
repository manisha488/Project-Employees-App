
class Currencies {
  String? symbol;
  String? name;

  Currencies({
    this.symbol,
    this.name,
  });
  Currencies.fromJson(Map<String, dynamic> json) {
    symbol = json['symbol']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['symbol'] = symbol;
    data['name'] = name;
    return data;
  }
}
