enum FormFieldBorderType {
  ///OutLine border type
  outline,

  ///UnderLine border type
  underline,

  ///BoxFit border type
  boxFit,
}

enum TextFormInputStrength {
  ///Password strength weak
  weakPassword,

  ///Password strength medium
  mediumPassword,

  ///Password strength strong
  strongPassword,
}
