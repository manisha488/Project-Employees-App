part of 'filter_screen_bloc.dart';

@immutable
abstract class FilterScreenEvent {}

/// Event to load all main filters on filter screen.
class FilterScreenInitialEvent extends FilterScreenEvent {}


class ProposalFiltersLoadedEvent extends FilterScreenEvent {}

/// Event to load all sub filters on filter screen.
class SubFiltersTabClickedEvent extends FilterScreenEvent {}

/// Event to perform apply project filters post API integration.
class ApplyFiltersClickedEvent extends FilterScreenEvent {
  final List<String>? projectName;
  final String? startDate;
  final String? endDate;
  final List<String>? resourceName;
  final String? availableDoc;
  final List<String>? projectStatus;
  final List<String>? platform;
  final List<String>? technologies;
  final List<String>? domain;
  final List<String>? functionalities;

  ApplyFiltersClickedEvent(
      {required this.projectName,
      required this.startDate,
      required this.endDate,
      required this.resourceName,
      required this.availableDoc,
      required this.projectStatus,
      required this.platform,
      required this.technologies,
      required this.domain,
      required this.functionalities});
}

/// Event to perform apply proposal filters post API integration.
class ApplyProposalsFiltersClickedEvent extends FilterScreenEvent {
  final List<String>? proposalName;
  final String? proposalReceivedDate;
  final String? proposalSubmittedDate;
  final List<String>? resourceName;
  final String? availableDoc;
  final List<String>? proposalStatus;
  final List<String>? platform;
  final List<String>? technologies;
  final List<String>? domain;
  final List<String>? functionalities;

  ApplyProposalsFiltersClickedEvent(
      {required this.proposalName,
        required this.proposalReceivedDate,
        required this.proposalSubmittedDate,
        required this.resourceName,
        required this.availableDoc,
        required this.proposalStatus,
        required this.platform,
        required this.technologies,
        required this.domain,
        required this.functionalities});
}

/// Event to handle apply filters button's states.
class ApplyButtonEnableEvent extends FilterScreenEvent{}
class ApplyButtonEnableForProposalsEvent extends FilterScreenEvent{}

