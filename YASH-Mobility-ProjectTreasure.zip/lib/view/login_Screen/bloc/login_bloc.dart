import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';

import '../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../utils/constants.dart';
import '../../../utils/shared_preference_utils.dart';

part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final db = CustomDataBaseWrapper();
  LoginBloc() : super(LoginInitial()) {
    on<LoginScreenEvent>(loginScreenEvent);
    on<CreateDBEvent>(createDBEvent);
    on<GetUserLoggedIn>(getUserLoggedInEvent);
  }

  /// The Event will emit the state which will have the user of data.
  /// This event will be triggered on login Screen.
  FutureOr<void> loginScreenEvent(
      LoginScreenEvent event, Emitter<LoginState> emit) {
    db.getUsers();
  }

  /// The Event will emit the state which will have the user of data.
  /// This event will be triggered on login Screen.
  FutureOr<void> getUserLoggedInEvent(
      GetUserLoggedIn event, Emitter<LoginState> emit) async {
    emit(UserLoginLoaderState());

    var users = await db.getUsers();
    bool user = false;

    users.every((element) {
      if (element['username'] == event.userName &&
          element['password'] == event.password) {
        SharedPrefs.instance
            .setString(Constants.userFirstName, element['name']);
        user = true;
      }
      return true;
    });
    if (user == true) {
      emit(UserLoggedInState());
    } else {
      emit(UserLoginFailedState());
    }

  }

  FutureOr<void> createDBEvent(
      CreateDBEvent event, Emitter<LoginState> emit) async {
    await db.getUsers();
  }
}
