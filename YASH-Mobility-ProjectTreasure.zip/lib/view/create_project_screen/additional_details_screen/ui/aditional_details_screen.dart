import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_alert_dialog/custom_alert_dialog.dart';
import 'package:yash_mobility_project_treasure/components/custom_button/custom_button.dart';
import 'package:yash_mobility_project_treasure/components/custom_textfield/custom_text_form_field.dart';
import 'package:yash_mobility_project_treasure/components/drop_DownList/dropdownlist.dart';
import 'package:yash_mobility_project_treasure/model/proposal_details.dart';
import 'package:yash_mobility_project_treasure/model/response/resource_model_list.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/regex.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/additional_details_screen/bloc/additional_detail_screen_bloc.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/resource_detail_screen/ui/resource_detail_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/review_screen/ui/review_screen.dart';

import '../../../../components/custom_alert_dialog/dialog.dart';
import '../../../../components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/projects_list.dart';
import '../../../../model/response/proposals_list.dart';
import '../../../../utils/common_utils/display_message_utils.dart';
import '../../../../utils/constants.dart';
import '../../../../utils/shared_preference_utils.dart';
import '../../../home_screen/ui/home_screen.dart';
import '../../create_project_screen/ui/create_project_screen.dart';

final GlobalKey<State> _keyLoader = GlobalKey<State>();

class AdditionalDetailScreen extends StatefulWidget {
  const AdditionalDetailScreen(
      this.currentIndex,
      this.projectName,
      this.basicDetailDraft,
      this.isTechnicalScreen,
      this.technicalDetailDraft,
      this.draftSelected,
      this.isReviewScreen,
      this.additionalDetailDraft,
      {required this.isProject,
      super.key,
      required this.database});

  final int currentIndex;
  final String projectName;
  final bool basicDetailDraft;
  final bool isTechnicalScreen;
  final bool technicalDetailDraft;
  final bool draftSelected;
  final bool isReviewScreen;
  final bool isProject;
  final bool additionalDetailDraft;
  final Database database;

  @override
  State<AdditionalDetailScreen> createState() => _AdditionalDetailScreenState();
}

class _AdditionalDetailScreenState extends State<AdditionalDetailScreen> {
  String? clientNameValue;
  String? currencyValue;
  String? locationValue;

  bool isProject = false;
  bool isSaved = false;
  bool isButtonEnabled = false;
  bool isDropdownOpened = false;
  bool currencyDropdownOpened = false;
  bool locationDropdownOpened = false;
  bool additionalDetailDraft = false;
  bool additionalDetailScreen = false;
  bool technicalDialogClicked = false;

  List<String> currencyList = [];
  List<String> currencySymbolList = [];
  List<ResourcesData?> resourceDetail = [];
  List<ProposalDetails> proposalAdditionalDetails = [];

  List<Map<String, dynamic>> resourceMap = [];
  Map<String, Object> resource = {};

  List<CreateProjectData> createBasicDetails = [];
  List<ProjectsData> basicDetails = [];
  List<CreateProposalData> createProposalBasicDetails = [];
  List<ProposalsData> proposalBasicDetails = [];
  dynamic result = [];

  ///Get data Declaration
  String draftProjectName = " ";
  dynamic draftDomain;
  String draftObjective = " ";
  String draftSummery = " ";
  dynamic draftFunctionality;
  List<String> draftFunction = [];
  String draftStartDate = " ";
  String? draftEndDate;
  dynamic draftStatus;
  String draftKnownIssue = " ";
  String draftDependencies = " ";
  dynamic draftPlatform;
  List<String> draftPlat = [];
  dynamic draftTechnology;
  List<String> draftTech = [];
  dynamic document;
  List<String> draftDoc = [];
  dynamic methodology;
  List<String> draftMethodology = [];
  List<String>? draftResources = [];
  String draftClientName = " ";
  String draftCurrency = " ";
  String draftBudget = " ";
  String draftLocation = " ";
  String draftComment = " ";
  String draftFeedback = " ";
  String draftRiskFactor = " ";
  CreateProjectResourcesData draftResource = CreateProjectResourcesData();
  CreateProposalDataAttributesResources draftProposalResource =
      CreateProposalDataAttributesResources();
  String draftResourcesName = " ";
  String draftResourcesEmail = " ";
  String draftResourcesDesignation = " ";

  ///Database declaration.
  final db = CustomDataBaseWrapper();

  ///Create Project Additional Detail Controllers
  final TextEditingController clientNameController = TextEditingController();
  final TextEditingController currencyController = TextEditingController();
  final TextEditingController projectBudgetController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController resourceNameController = TextEditingController();
  final TextEditingController resourceDesignationController =
      TextEditingController();
  final TextEditingController resourceEmailAddressController =
      TextEditingController();
  final TextEditingController commentController = TextEditingController();
  final TextEditingController projectFeedbackController =
      TextEditingController();

  ///Create Proposal Additional Detail Controllers

  final TextEditingController proposalClientNameController =
      TextEditingController();
  final TextEditingController proposalCurrencyController =
      TextEditingController();
  final TextEditingController proposalBudgetController =
      TextEditingController();
  final TextEditingController proposalLocationController =
      TextEditingController();
  final TextEditingController proposalResourceNameController =
      TextEditingController();
  final TextEditingController proposalResourceDesignationController =
      TextEditingController();
  final TextEditingController proposalResourceEmailAddressController =
      TextEditingController();
  final TextEditingController proposalCommentController =
      TextEditingController();
  final TextEditingController proposalFeedbackController =
      TextEditingController();

  final AdditionalDetailScreenBloc additionalDetailScreenBloc =
      AdditionalDetailScreenBloc();

  List<String> locationList = [];

  @override
  void initState() {
    isProject = widget.isProject;

    ///Get localDb data
    db.getSpecificProjectsList(widget.projectName);
    getData();

    ///Event for Currency dropdown list.
    additionalDetailScreenBloc.add(CurrencyLoadedEvent());

    ///Event for Location dropdown list.
    additionalDetailScreenBloc.add(LocationLoadedEvent());

    if (isProject) {
      clientNameController.addListener(_checkButtonStatus);
      currencyController.addListener(_checkButtonStatus);
      projectBudgetController.addListener(_checkButtonStatus);
      locationController.addListener(_checkButtonStatus);
      projectFeedbackController.addListener(_checkButtonStatus);
    } else {
      proposalClientNameController.addListener(_checkButtonStatus);
      proposalCurrencyController.addListener(_checkButtonStatus);
      proposalBudgetController.addListener(_checkButtonStatus);
      proposalLocationController.addListener(_checkButtonStatus);
      proposalFeedbackController.addListener(_checkButtonStatus);
    }
    super.initState();
  }

  /// Button enable & disable function.
  void _checkButtonStatus() {
    setState(() {
      if (isProject == true) {
        if (clientNameController.text.isNotEmpty &&
            currencyController.text.isNotEmpty &&
            projectBudgetController.text.isNotEmpty &&
            locationController.text.isNotEmpty &&
            projectFeedbackController.text.isNotEmpty) {
          isButtonEnabled = true;
        } else {
          isButtonEnabled = false;
        }
      } else {
        if (proposalClientNameController.text.isNotEmpty &&
            proposalCurrencyController.text.isNotEmpty &&
            proposalBudgetController.text.isNotEmpty &&
            proposalLocationController.text.isNotEmpty &&
            proposalFeedbackController.text.isNotEmpty) {
          isButtonEnabled = true;
        } else {
          isButtonEnabled = false;
        }
      }
    });
  }

  List<Map<String, dynamic>> convert(List<dynamic> list) {
    List<Map<String, dynamic>> map = [];
    Map<String, dynamic> u = {};
    for (var j = 0; j < list.length; j++) {
      setState(() {
        u = {"id": list[j]!.id};
        map.add(u);
      });
    }
    return map;
  }

  void getData() async {
    if (isProject) {
      result = await db.getSpecificProjectsList(widget.projectName);
    } else {
      result = await db.getSpecificProposalList(widget.projectName);
    }

    int index = result.length;
    for (int i = 0; i < index; i++) {
      setState(() {
        draftProjectName = result[i].attributes!.name!;
        draftObjective = result[i].attributes!.objectives!;

        if (isProject) {
          draftSummery = result[i].attributes!.summary!;
        } else {
          draftSummery = result[i].attributes!.summery!;
        }

        List<Map<String, dynamic>> mapFun = [];
        List<Map<String, dynamic>> mapPlat = [];
        List<Map<String, dynamic>> mapTech = [];
        List<Map<String, dynamic>> mapDomain = [];
        List<Map<String, dynamic>> mapStatus = [];
        List<Map<String, dynamic>> mapMeth = [];

        Map<String, dynamic> uFun = {};
        for (var j = 0;
            j < result[i].attributes!.functionalities!.data!.length;
            j++) {
          setState(() {
            uFun = {"id": result[i].attributes!.functionalities!.data![j]!.id};
            mapFun.add(uFun);
          });
        }
        draftFunctionality = mapFun;

        Map<String, dynamic> uPlat = {};
        for (var j = 0;
            j < result[i].attributes!.platforms!.data!.length;
            j++) {
          setState(() {
            uPlat = {"id": result[i].attributes!.platforms!.data![j]!.id};
            mapPlat.add(uPlat);
          });
        }
        draftPlatform = mapPlat;

        Map<String, dynamic> uTech = {};
        for (var j = 0;
            j < result[i].attributes!.technologies!.data!.length;
            j++) {
          setState(() {
            uTech = {"id": result[i].attributes!.technologies!.data![j]!.id};
            mapTech.add(uTech);
          });
        }
        draftTechnology = mapTech;

        Map<String, dynamic> uDomain = {};
        setState(() {
          uDomain = {"id": result[i].attributes!.domain!.data!.id};
          mapDomain.add(uDomain);
        });
        draftDomain = mapDomain;

        Map<String, dynamic> uStatus = {};
        setState(() {
          uStatus = {"id": result[i].attributes!.status!.data!.id};
          mapStatus.add(uStatus);
        });
        draftStatus = mapStatus;

        if (isProject) {
          Map<String, dynamic> uMeth = {};
          setState(() {
            uMeth = {"id": result[i].attributes!.methodology!.data!.id};
            mapMeth.add(uMeth);
          });
          methodology = mapMeth;
          draftKnownIssue = result[i].attributes!.knownIssues!;
        }

        if (isProject) {
          draftStartDate = result[i].attributes!.startDate!;
          draftEndDate = result[i].attributes!.endDate;
          draftClientName = result[i].attributes!.clientName!;
          draftRiskFactor = result[i].attributes!.riskFactor!;
        } else {
          draftStartDate = result[i].attributes!.proposalReceivedDate!;
          draftEndDate = result[i].attributes!.proposalSubmittedDate;
          draftClientName = result[i].attributes!.clientDetails!;
          draftRiskFactor = result[i].attributes!.riskFactors!;
        }
        draftDependencies = result[i].attributes!.dependencies!;
        document = result[i].attributes!.documents;
        draftCurrency = result[i].attributes!.currency!;
        draftBudget = result[i].attributes!.budget!;
        draftLocation = result[i].attributes!.location!;
        if (isProject) {
          draftResource = result[i].attributes!.resources;
          if (widget.isReviewScreen) {
            SharedPrefs.instance.setString(
                Constants.resourceDetailDraft, jsonEncode(draftResource));
          }

          var res =
              SharedPrefs.instance.getString(Constants.resourceDetailDraft);

          if (res != null) {
            List<ResourcesData> storedItems = [];
            ResourcesData y = ResourcesData();
            if (draftResource.data != null) {
              for (var j = 0; j < draftResource.data!.length; j++) {
                setState(() {
                  y.id = draftResource.data![i]!.id;
                  y.designation =
                      draftResource.data![i]!.attributes!.designation;
                  y.resourceEmail =
                      draftResource.data![i]!.attributes!.resourceEmail;
                  y.resourceName =
                      draftResource.data![i]!.attributes!.resourceName;
                  storedItems.add(y);
                });
              }
              resourceDetail = storedItems;
            }
          }
        } else {
          draftProposalResource = result[i].attributes!.resources;
          if (widget.isReviewScreen) {
            SharedPrefs.instance.setString(Constants.resourceDetailDraft,
                jsonEncode(draftProposalResource));
          }

          var res =
              SharedPrefs.instance.getString(Constants.resourceDetailDraft);

          if (res != null) {
            List<ResourcesData> storedItems = [];
            ResourcesData y = ResourcesData();
            if (draftProposalResource.data != null) {
              for (var j = 0; j < draftProposalResource.data!.length; j++) {
                setState(() {
                  y.id = draftProposalResource.data![i]!.id;
                  y.designation =
                      draftProposalResource.data![i]!.attributes!.designation;
                  y.resourceEmail =
                      draftProposalResource.data![i]!.attributes!.resourceEmail;
                  y.resourceName =
                      draftProposalResource.data![i]!.attributes!.resourceName;
                  storedItems.add(y);
                });
              }
              resourceDetail = storedItems;
            }
          }
        }

        draftComment = result[i].attributes!.comments!;
        draftFeedback = result[i].attributes!.feedback!;
        if (widget.basicDetailDraft) {
          if (isProject) {
            clientNameController.text = draftClientName;
            currencyController.text = draftCurrency;
            projectBudgetController.text = draftBudget;
            locationController.text = draftLocation;
            commentController.text = draftComment;
            projectFeedbackController.text = draftFeedback;
          } else {
            proposalClientNameController.text = draftClientName;
            proposalCurrencyController.text = draftCurrency;
            proposalBudgetController.text = draftBudget;
            proposalLocationController.text = draftLocation;
            proposalCommentController.text = draftComment;
            proposalFeedbackController.text = draftFeedback;
          }
        }
        if (widget.isTechnicalScreen) {
          if (isProject) {
            clientNameController.text = draftClientName;
            currencyController.text = draftCurrency;
            projectBudgetController.text = draftBudget;
            locationController.text = draftLocation;
            commentController.text = draftComment;
            projectFeedbackController.text = draftFeedback;
          } else {
            proposalClientNameController.text = draftClientName;
            proposalCurrencyController.text = draftCurrency;
            proposalBudgetController.text = draftBudget;
            proposalLocationController.text = draftLocation;
            proposalCommentController.text = draftComment;
            proposalFeedbackController.text = draftFeedback;
          }
        }
        if (widget.isReviewScreen) {
          if (isProject) {
            clientNameController.text = draftClientName;
            currencyController.text = draftCurrency;
            projectBudgetController.text = draftBudget;
            locationController.text = draftLocation;
            commentController.text = draftComment;
            projectFeedbackController.text = draftFeedback;
          } else {
            proposalClientNameController.text = draftClientName;
            proposalCurrencyController.text = draftCurrency;
            proposalBudgetController.text = draftBudget;
            proposalLocationController.text = draftLocation;
            proposalCommentController.text = draftComment;
            proposalFeedbackController.text = draftFeedback;
          }
        }
      });
    }
  }

  /// Navigation to Technical Detail Screen.
  void navigateToTechnicalScreen(BuildContext context) {
    Navigator.of(context)
        .popUntil(ModalRoute.withName('/technicalInformationScreen'));
  }

  @override
  void dispose() {
    clientNameController.dispose();
    currencyController.dispose();
    projectBudgetController.dispose();
    locationController.dispose();
    projectFeedbackController.dispose();
    proposalClientNameController.dispose();
    proposalCurrencyController.dispose();
    proposalBudgetController.dispose();
    proposalLocationController.dispose();
    proposalFeedbackController.dispose();
    super.dispose();
  }

  ///Screen size function.
  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  ///Navigation to Resource detail screen.
  void _resourceDetails(BuildContext context) async {
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ResourceDetailScreen(widget.currentIndex)));

    setState(() {
      resourceDetail = result;
      SharedPrefs.instance
          .setString(Constants.resourceDetailDraft, jsonEncode(resourceDetail));
    });
  }

  ///Navigate to Home screen.
  void navigateToHomePage(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/homeScreen'));
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => HomeScreen(
                isFilterScreen: false,
                isProposalFilterScreen: false,
                isProjectFiltersApplied: false,
                isProposalFiltersApplied: false,
                database: widget.database)));
  }

  String trimAfterSpace(String input) {
    int spaceIndex = input.indexOf(' ');
    if (spaceIndex == -1) {
      return input;
    } else {
      return input.substring(0, spaceIndex);
    }
  }

  void returnProjectDetails(BuildContext context) {
    if (isProject == true) {
      var index = resourceDetail.length;
      for (int i = 0; i < index; i++) {
        Map<String, dynamic> res = {
          "id": 4,
          "attributes": {
            "resource_name": resourceDetail[i]!.resourceName,
            "designation": resourceDetail[i]!.designation,
            "resource_email": resourceDetail[i]!.resourceEmail,
            "createdAt": "2023-11-22T07:02:13.112Z",
            "updatedAt": "2023-11-22T07:02:18.684Z",
            "publishedAt": "2023-11-22T07:02:17.834Z"
          }
        };
        resourceMap.add(res);
      }

      ///Resource list
      var resourceList = {"data": resourceMap};

      var r = ProjectsDataAttributesResources.fromJson(resourceList);

      setState(() {

        print(clientNameController.text);
        var attributes = ProjectsDataAttributes(
          name: widget.projectName,
          clientName: clientNameController.text,
          currency: currencyController.text,
          // location: locationController.text,
          budget: projectBudgetController.text,
          resources: r,
          comments: commentController.text,
          feedback: projectFeedbackController.text,
        );
        basicDetails.add(ProjectsData(attributes: attributes));
        db.updateAdditionalDetail(basicDetails);

        additionalDetailDraft = true;
        SharedPrefs.instance
            .setBool(Constants.additionalDetailDraft, additionalDetailDraft);
      });
    } else {
      var index = resourceDetail.length;
      for (int i = 0; i < index; i++) {
        Map<String, dynamic> res = {
          "id": 4,
          "attributes": {
            "resource_name": resourceDetail[i]!.resourceName,
            "designation": resourceDetail[i]!.designation,
            "resource_email": resourceDetail[i]!.resourceEmail,
            "createdAt": "2023-11-22T07:02:13.112Z",
            "updatedAt": "2023-11-22T07:02:18.684Z",
            "publishedAt": "2023-11-22T07:02:17.834Z"
          }
        };
        resourceMap.add(res);
      }

      ///Resource list
      var resourceList = {"data": resourceMap};

      var r = ProposalsDataAttributesResources.fromJson(resourceList);

      setState(() {
        var attributes = ProposalsDataAttributes(
          name: widget.projectName,
          clientDetails: proposalClientNameController.text,
          currency: proposalCurrencyController.text,
          location: proposalLocationController.text,
          budget: proposalBudgetController.text,
          resources: r,
          comments: proposalCommentController.text,
          feedback: proposalFeedbackController.text,
        );
        proposalBasicDetails.add(ProposalsData(attributes: attributes));
        db.updateProposalAdditionalDetail(proposalBasicDetails);
        additionalDetailDraft = true;
        SharedPrefs.instance
            .setBool(Constants.additionalDetailDraft, additionalDetailDraft);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    ///Bloc implementation.
    return BlocConsumer<AdditionalDetailScreenBloc, AdditionalDetailState>(
      bloc: additionalDetailScreenBloc,
      listenWhen: (previous, current) => current is AdditionalDetailActionState,
      buildWhen: (previous, current) => current is! AdditionalDetailActionState,
      listener: (context, state) {
        {
          ///State for Additional detail Attachment button.
          if (state is AdditionalDetailAttachmentButtonState) {
            ShowBottomSheet.getInstance.permissionHandlerMethod(context);
          }

          ///State for Additional detail Save button.
          else if (state is AdditionalDetailSaveButtonState) {
            if (isProject == true) {
              if (clientNameController.text.isNotEmpty ||
                  currencyController.text.isNotEmpty ||
                  projectBudgetController.text.isNotEmpty ||
                  locationController.text.isNotEmpty ||
                  projectFeedbackController.text.isNotEmpty ||
                  resourceDetail.isNotEmpty) {
                returnProjectDetails(context);
                setState(() {
                  isSaved = true;
                });
                DisplayMessageUtils.toastMessage(
                    Strings().dataSavedSuccessfullyToastMessage);
              } else {
                return;
              }
            } else {
              if (proposalClientNameController.text.isNotEmpty ||
                  proposalCurrencyController.text.isNotEmpty ||
                  proposalBudgetController.text.isNotEmpty ||
                  proposalLocationController.text.isNotEmpty ||
                  proposalLocationController.text.isNotEmpty ||
                  resourceDetail.isNotEmpty) {
                returnProjectDetails(context);
                setState(() {
                  isSaved = true;
                });
                DisplayMessageUtils.toastMessage(
                    Strings().dataSavedSuccessfullyToastMessage);
              } else {
                return;
              }
            }
          }

          ///State for Currency dropdown list.
          else if (state is CurrencyLoadedState) {
            setState(() {
              for (var i = 0; i < state.currencyFilter.length; i++) {
                currencyList.add(
                    "${state.currencyFilter[i]!.symbol!}  ${state.currencyFilter[i]!.name!}");
              }
            });
          }

          ///State for Location dropdown list.
          else if (state is LocationLoadedState) {
            setState(() {
              for (var i = 0; i < state.locationFilter.length; i++) {
                locationList.add("${state.locationFilter[i]!.country}");
              }
            });
            setState(() {
              for (var i = 0; i < state.locationFilter.length; i++) {
                locationList.add("${state.locationFilter[i]!.country!} ");
              }
            });
          }

          ///State for Navigation from Additional detail screen to Resources detail screen.
          else if (state is NavigateAdditionalDetailToResourceDetailState) {
            _resourceDetails(context);
          }

          ///State for Navigation from Additional detail screen to Review screen.
          else if (state is NavigateAdditionalDetailToReviewState) {
            if (isProject == true) {
              if (clientNameController.text.isNotEmpty ||
                  currencyController.text.isNotEmpty ||
                  projectBudgetController.text.isNotEmpty ||
                  locationController.text.isNotEmpty ||
                  projectFeedbackController.text.isNotEmpty ||
                  resourceDetail.isNotEmpty) {
                isSaved == false ? returnProjectDetails(context) : null;
                additionalDetailScreen = false;
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReviewScreen(
                            widget.currentIndex,
                            widget.projectName,
                            additionalDetailDraft,
                            widget.draftSelected,
                            additionalDetailScreen,
                            isProject: isProject,
                            database: widget.database)));
              } else {
                additionalDetailScreen = true;
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReviewScreen(
                            widget.currentIndex,
                            widget.projectName,
                            additionalDetailDraft,
                            widget.draftSelected,
                            additionalDetailScreen,
                            isProject: isProject,
                            database: widget.database)));
              }
            } else {
              if (proposalClientNameController.text.isNotEmpty ||
                  proposalCurrencyController.text.isNotEmpty ||
                  proposalBudgetController.text.isNotEmpty ||
                  proposalLocationController.text.isNotEmpty ||
                  proposalLocationController.text.isNotEmpty ||
                  resourceDetail.isNotEmpty) {
                isSaved == false ? returnProjectDetails(context) : null;
                additionalDetailScreen = false;
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReviewScreen(
                            widget.currentIndex,
                            widget.projectName,
                            additionalDetailDraft,
                            widget.draftSelected,
                            additionalDetailScreen,
                            isProject: isProject,
                            database: widget.database)));
              } else {
                additionalDetailScreen = true;
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReviewScreen(
                            widget.currentIndex,
                            widget.projectName,
                            additionalDetailDraft,
                            widget.draftSelected,
                            additionalDetailScreen,
                            isProject: isProject,
                            database: widget.database)));
              }
            }
          } else if (state is ResourceStoreState) {
            setState(() {
              resourceDetail = state.resources;
            });
            List<int?> mapResources = [];
            List<Map<String, dynamic>> mapRes = [];

            ///Resources list
            Map<String, dynamic>? q;
            for (var i = 0; i < resourceDetail.length; i++) {
              if (widget.isReviewScreen) {
                setState(() {
                  var resItem = (resourceDetail[i]!.id);
                  mapResources.add(resItem);
                  q = {"id": jsonEncode(mapResources[i])};
                  mapRes.add(q!);
                });
              } else {
                var resItem = (resourceDetail[i]!.id);
                mapResources.add(resItem);
                setState(() {
                  q = {"id": jsonEncode(mapResources[i])};
                  mapRes.add(q!);
                });
              }
            }

            List<int?> mapResources1 = [];
            List<Map<String, dynamic>>? d;
            Map<String, dynamic>? dd;
            if (document != null) {
              if (jsonEncode(document) != "{}") {
                print("document: ${jsonEncode(document)}");
                d = [];
                for (var i = 0; i < document.length; i++) {
                  var doc = (document![i]!.id);
                  mapResources1.add(doc);
                  setState(() {
                    dd = {"id": jsonEncode(mapResources1[i])};
                    d!.add(dd!);
                  });
                }
              }
            }

            print(proposalBudgetController.text);
            print(proposalCurrencyController.text);
            print(proposalLocationController.text);

            if (isProject) {
              additionalDetailScreenBloc.add(
                  AdditionalDetailCreateProjectBtnEvent(
                      objectives: draftObjective,
                      startDate: draftStartDate,
                      endDate: draftEndDate,
                      clientName: clientNameController.text,
                      budget: projectBudgetController.text,
                      knownIssues: draftKnownIssue,
                      dependencies: draftDependencies,
                      comments: commentController.text,
                      documents: d,
                      feedback: projectFeedbackController.text,
                      name: draftProjectName,
                      summary: draftSummery,
                      currency: currencyController.text,
                      location: locationController.text,
                      riskFactor: draftRiskFactor,
                      technologies: draftTechnology,
                      domain: draftDomain,
                      platforms: draftPlatform,
                      resources: mapRes.isNotEmpty ? mapRes : null,
                      functionalities:
                          jsonDecode(jsonEncode(draftFunctionality)),
                      status: draftStatus,
                      methodology: methodology));
              db.deleteProjectModel(result);
              navigateToHomePage(context);
              DisplayMessageUtils.flushBarErrorMessage(
                  context,
                  Strings().projectCreatedMessage,
                  AppColors.flushBarBackgroundColor,
                  Strings().view,
                  () {});
            } else {
              ///Proposal Post API
              additionalDetailScreenBloc
                  .add(AdditionalDetailCreateProposalBtnEvent(
                objectives: draftObjective,
                proposalReceivedDate: draftStartDate,
                proposalSubmittedDate: draftEndDate,
                clientDetails: proposalClientNameController.text,
                budget: proposalBudgetController.text,
                dependencies: draftDependencies,
                comments: proposalCommentController.text,
                documents: d,
                feedback: proposalFeedbackController.text,
                name: draftProjectName,
                summery: draftSummery,
                currency: proposalCurrencyController.text,
                location: proposalLocationController.text,
                riskFactors: draftRiskFactor,
                technologies: draftTechnology,
                domain: draftDomain,
                platforms: draftPlatform,
                resources: mapRes.isNotEmpty ? mapRes : null,
                functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                status: draftStatus,
              ));
              db.deleteProposalModel(result);
              navigateToHomePage(context);
              DisplayMessageUtils.flushBarErrorMessage(
                  context,
                  Strings().proposalCreatedMessage,
                  AppColors.flushBarBackgroundColor,
                  Strings().view,
                  () {});
            }
          } else if (state is UploadDocumentState) {
            setState(() {
              document = state.details;
            });
            List<int?> mapResources1 = [];
            List<Map<String, dynamic>> d = [];
            Map<String, dynamic>? dd;
            for (var i = 0; i < document!.length; i++) {
              var doc = (document![i]!.id);
              mapResources1.add(doc);
              setState(() {
                dd = {"id": jsonEncode(mapResources1[i])};
                d.add(dd!);
              });
            }
            files.clear();

            int index = resourceDetail.length;
            if (resourceDetail.isNotEmpty) {
              for (int i = 0; i < index; i++) {
                additionalDetailScreenBloc.add(ResourceStoreEvent(
                    resourceName: resourceDetail[i]!.resourceName,
                    resourceEmail: resourceDetail[i]!.resourceEmail,
                    designation: resourceDetail[i]!.designation));
              }
            } else {
              if (isProject) {
                additionalDetailScreenBloc.add(
                    AdditionalDetailCreateProjectBtnEvent(
                        objectives: draftObjective,
                        startDate: draftStartDate,
                        endDate: draftEndDate,
                        clientName: clientNameController.text,
                        budget: projectBudgetController.text,
                        knownIssues: draftKnownIssue,
                        dependencies: draftDependencies,
                        comments: commentController.text,
                        documents: d,
                        feedback: projectFeedbackController.text,
                        name: draftProjectName,
                        summary: draftSummery,
                        currency: currencyController.text,
                        location: locationController.text,
                        riskFactor: draftRiskFactor,
                        technologies: draftTechnology,
                        domain: draftDomain,
                        platforms: draftPlatform,
                        resources: null,
                        functionalities:
                            jsonDecode(jsonEncode(draftFunctionality)),
                        status: draftStatus,
                        methodology: methodology));
                db.deleteProjectModel(result);
                navigateToHomePage(context);
                DisplayMessageUtils.flushBarErrorMessage(
                    context,
                    Strings().projectCreatedMessage,
                    AppColors.flushBarBackgroundColor,
                    Strings().view,
                    () {});
              } else {
                ///Proposal Post API
                additionalDetailScreenBloc
                    .add(AdditionalDetailCreateProposalBtnEvent(
                  objectives: draftObjective,
                  proposalReceivedDate: draftStartDate,
                  proposalSubmittedDate: draftEndDate,
                  clientDetails: proposalClientNameController.text,
                  budget: proposalBudgetController.text,
                  dependencies: draftDependencies,
                  comments: proposalCommentController.text,
                  documents: d,
                  feedback: proposalFeedbackController.text,
                  name: draftProjectName,
                  summery: draftSummery,
                  currency: proposalCurrencyController.text,
                  location: proposalLocationController.text,
                  riskFactors: draftRiskFactor,
                  technologies: draftTechnology,
                  domain: draftDomain,
                  platforms: draftPlatform,
                  resources: null,
                  functionalities: jsonDecode(jsonEncode(draftFunctionality)),
                  status: draftStatus,
                ));
                db.deleteProposalModel(result);
                navigateToHomePage(context);
                DisplayMessageUtils.flushBarErrorMessage(
                    context,
                    Strings().proposalCreatedMessage,
                    AppColors.flushBarBackgroundColor,
                    Strings().view,
                    () {});
              }

              // DisplayMessageUtils.showSnackBar(Strings().fileIsUploadString);
              files.clear();
            }
          } else if (state is UploadDocumentFailedState) {
            // DisplayMessageUtils.showSnackBar(
            //     NetworkExceptions.getErrorMessage(state.exception));
          }

          ///State for Additional detail screen Create project button.
          else if (state is AdditionalDetailCreateProjectButtonState) {
            print("state");
            db.deleteSingleProjectModel(state.createProject!);
            navigateToHomePage(context);
            DisplayMessageUtils.flushBarErrorMessage(
                context,
                Strings().projectCreatedMessage,
                AppColors.flushBarBackgroundColor,
                Strings().view,
                () {});
          } else if (state is AdditionalDetailCreateProposalButtonState) {
            db.deleteSingleProposalModel(state.createProposal!);
            navigateToHomePage(context);
            DisplayMessageUtils.flushBarErrorMessage(
                context,
                Strings().proposalCreatedMessage,
                AppColors.flushBarBackgroundColor,
                Strings().view,
                () {});
          }
        }
      },
      builder: (context, state) {
        return WillPopScope(
          onWillPop: () async {
            technicalDialogClicked = true;
            if (widget.isTechnicalScreen) {
              if (draftProjectName.isEmpty) {
                showDialog(
                    barrierDismissible: false,
                    context: context,
                    builder: (BuildContext context) {
                      return technicalDialog();
                    });
              } else {
                Navigator.pop(context);
              }
            } else if (widget.isReviewScreen) {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ReviewScreen(
                          widget.currentIndex,
                          widget.projectName,
                          widget.additionalDetailDraft,
                          widget.draftSelected,
                          additionalDetailScreen,
                          isProject: isProject,
                          database: widget.database)));
            } else {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CreateProjectScreen(
                          widget.currentIndex,
                          widget.projectName,
                          widget.isProject,
                          database: widget.database)));
            }
            return false;
          },
          child: Scaffold(
            backgroundColor: AppColors.white,
            appBar: AppBar(
              backgroundColor: AppColors.createProjectAppBarColor,
              iconTheme: IconThemeData(color: AppColors.white),
              title: Text(
                isProject == true
                    ? Strings().createProjectAppbarTitle.toTitleCase()
                    : Strings().createProposalAppbarTitle.toTitleCase(),
                style: TextStyle(
                    color: AppColors.white, fontSize: Dimensions.font_20),
              ),
              actions: [
                IconButton(
                    onPressed: () {
                      ///Event for Additional detail Attachment button.
                      additionalDetailScreenBloc
                          .add(AdditionalDetailAttachmentBtnEvent());
                    },
                    icon: Icon(
                      Icons.attach_file,
                      size: Dimensions.iconSize_20,
                      color: AppColors.white,
                    )),
                TextButton(
                  onPressed: () {
                    ///Event for Additional detail Save button.
                    additionalDetailScreenBloc
                        .add(AdditionalDetailSaveBtnEvent());
                  },
                  child: Text(
                    Strings().saveDraftAppbarTitle.toTitleCase(),
                    style: TextStyle(color: AppColors.white),
                  ),
                ),
              ],
            ),
            body: GestureDetector(
              onTap: () {
                setState(() {
                  isDropdownOpened = false;
                  currencyDropdownOpened = false;
                  locationDropdownOpened = false;
                });
                FocusScope.of(context).requestFocus(FocusNode());
              },
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                      Dimensions.padding_16,
                      Dimensions.padding_24,
                      Dimensions.padding_16,
                      Dimensions.padding_0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: AppColors.green,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color:
                                      AppColors.createScreenButtonBorderColor),
                            ),
                            child: Center(
                                child: Icon(
                              Icons.done,
                              size: Dimensions.iconSize_18,
                              color: AppColors.white,
                            )),
                          ),
                          SizedBox(
                            width: Dimensions.width_25,
                            child: Divider(
                              color: AppColors.grey,
                              thickness: Dimensions.verticalDividerThickness_1,
                            ),
                          ),
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: AppColors.green,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color:
                                      AppColors.createScreenButtonBorderColor),
                            ),
                            child: Center(
                                child: Icon(
                              Icons.done,
                              size: Dimensions.iconSize_18,
                              color: AppColors.white,
                            )),
                          ),
                          SizedBox(
                            width: Dimensions.width_25,
                            child: Divider(
                              color: AppColors.grey,
                              thickness: Dimensions.verticalDividerThickness_1,
                            ),
                          ),
                          Container(
                            height: Dimensions.height_24,
                            width: Dimensions.width_24,
                            decoration: BoxDecoration(
                              color: AppColors.createProjectAppBarColor,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_40),
                              border: Border.all(
                                  color: AppColors.stepperBorderColor),
                            ),
                            child: Center(
                                child: Text(Strings().progressIndicatorTitle_3,
                                    style: TextStyle(color: AppColors.white))),
                          ),
                        ],
                      ),
                      SizedBox(height: Dimensions.height_24),
                      Text(
                        Strings().additionalDetailTitle,
                        style: TextStyle(
                            fontSize: Dimensions.font_16,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: Dimensions.height_24),
                      Text(
                        Strings().clientDetails.toTitleCase(),
                        style: TextStyle(
                            fontSize: Dimensions.font_14,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: Dimensions.height_24),
                      CustomTextField(
                        onTapped: () {
                          setState(() {
                            isDropdownOpened = false;
                            currencyDropdownOpened = false;
                            locationDropdownOpened = false;
                          });
                        },
                        textEditingController: isProject == true
                            ? clientNameController
                            : proposalClientNameController,
                        textCapitalization: TextCapitalization.words,
                        keyboardType: TextInputType.text,
                        labelText: Strings().textFieldClientName.toTitleCase(),
                        regEx: RegEx().projectObjectiveRegEx,
                      ),
                      SizedBox(height: Dimensions.height_24),
                      currencyDropdown(),
                      SizedBox(height: Dimensions.height_29),
                      CustomTextField(
                        onTapped: () {
                          setState(() {
                            isDropdownOpened = false;
                            currencyDropdownOpened = false;
                            locationDropdownOpened = false;
                          });
                        },
                        textEditingController: isProject == true
                            ? projectBudgetController
                            : proposalBudgetController,
                        keyboardType: TextInputType.phone,
                        labelText: Strings().textFieldProjectBudget,
                        regEx: RegEx().projectNumberRegEx,
                      ),
                      SizedBox(height: Dimensions.height_24),
                      locationDropdown(),
                      SizedBox(height: Dimensions.height_16),
                      Visibility(
                        visible: resourceDetail.isNotEmpty ? true : false,
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            border: Border.all(
                              color: AppColors.itemBorderButtonColor,
                              width: Dimensions.width_2,
                            ),
                            borderRadius: BorderRadius.circular(
                                Dimensions.borderRadius_10),
                          ),
                          child: resourceDetail.isNotEmpty
                              ? Padding(
                                  padding: EdgeInsets.all(Dimensions.padding_8),
                                  child: ConstrainedBox(
                                    constraints: BoxConstraints(
                                        maxHeight: Dimensions.height_200,
                                        minHeight: Dimensions.height_80),
                                    child: ListView(
                                      scrollDirection: Axis.vertical,
                                      shrinkWrap: true,
                                      children: [
                                        Column(
                                          children: resourceDetail.map((e) {
                                            return Column(
                                              children: [
                                                Container(
                                                  width: getSize(context).width,
                                                  decoration: BoxDecoration(
                                                    color: AppColors
                                                        .itemBodyButtonColor,
                                                    border: Border.all(
                                                        color: AppColors
                                                            .itemBorderButtonColor),
                                                    borderRadius: BorderRadius
                                                        .circular(Dimensions
                                                            .borderRadius_5),
                                                  ),
                                                  child: Padding(
                                                    padding: EdgeInsets.all(
                                                        Dimensions.padding_8),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Flexible(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child: Text(
                                                                      '${e!.resourceName} : ${e.designation}',
                                                                      overflow:
                                                                          TextOverflow
                                                                              .fade,
                                                                      maxLines:
                                                                          Dimensions
                                                                              .minLength_1,
                                                                      softWrap:
                                                                          false,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              Dimensions.font_16),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: Dimensions
                                                                    .height_4,
                                                              ),
                                                              if (e.resourceEmail !=
                                                                  null)
                                                                Text(
                                                                  e.resourceEmail!,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          Dimensions
                                                                              .font_12),
                                                                ),
                                                            ],
                                                          ),
                                                        ),
                                                        Stack(
                                                          children: <Widget>[
                                                            IconButton(
                                                              padding: EdgeInsets.fromLTRB(
                                                                  Dimensions
                                                                      .padding_10,
                                                                  Dimensions
                                                                      .padding_0,
                                                                  Dimensions
                                                                      .padding_0,
                                                                  Dimensions
                                                                      .padding_0),
                                                              onPressed: () {
                                                                setState(() {
                                                                  resourceDetail
                                                                      .remove(
                                                                          e);
                                                                  SharedPrefs
                                                                      .instance
                                                                      .setString(
                                                                          Constants
                                                                              .resourceDetailDraft,
                                                                          jsonEncode(
                                                                              resourceDetail));
                                                                });
                                                              },
                                                              icon: Icon(
                                                                Icons
                                                                    .cancel_outlined,
                                                                color: AppColors
                                                                    .createProjectAppBarColor,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: Dimensions.height_8,
                                                )
                                              ],
                                            );
                                          }).toList(),
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              : null,
                        ),
                      ),
                      SizedBox(height: Dimensions.height_16),
                      CustomButton(
                        title: Strings().resourceDetails,
                        height: Dimensions.height_40,
                        width: getSize(context).width,
                        buttonColor: AppColors.createProjectAppBarColor,
                        onPress: () async {
                          ///Event for Navigation from Additional detail screen to Resources detail screen.
                          additionalDetailScreenBloc.add(
                              NavigateAdditionalDetailToResourceDetailEvent());
                        },
                        textStyle: TextStyle(
                          fontSize: Dimensions.font_14,
                          color: AppColors.white,
                        ),
                        borderRadius: Dimensions.borderRadius_10,
                      ),
                      SizedBox(height: Dimensions.height_32),
                      Text(
                        Strings().otherDetails,
                        style: TextStyle(
                            fontSize: Dimensions.font_14,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: Dimensions.height_16),
                      CustomTextField(
                        textEditingController: isProject == true
                            ? commentController
                            : proposalCommentController,
                        labelText: Strings().textFieldComments,
                        regEx: RegEx().projectObjectiveRegEx,
                        onTapped: () {
                          setState(() {
                            isDropdownOpened = false;
                            currencyDropdownOpened = false;
                            locationDropdownOpened = false;
                          });
                        },
                      ),
                      SizedBox(height: Dimensions.height_24),
                      CustomTextField(
                        textEditingController: isProject == true
                            ? projectFeedbackController
                            : proposalFeedbackController,
                        labelText:
                            Strings().textFieldProjectFeedback.toTitleCase(),
                        regEx: RegEx().projectObjectiveRegEx,
                        onTapped: () {
                          setState(() {
                            isDropdownOpened = false;
                            currencyDropdownOpened = false;
                            locationDropdownOpened = false;
                          });
                        },
                      ),
                      SizedBox(height: Dimensions.height_29),
                      Visibility(
                        visible: widget.isReviewScreen ? false : true,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () {
                                ///Event for Navigation from Additional detail screen to Review screen.
                                // additionalDetailScreenBloc.add(
                                //     NavigateAdditionalDetailToReviewEvent());
                              },
                              borderRadius: BorderRadius.circular(
                                  Dimensions.borderRadius_60),
                              child: Container(
                                height: Dimensions.height_40,
                                width: Dimensions.width_160,
                                decoration: BoxDecoration(
                                  color: AppColors.white,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.borderRadius_60),
                                  border: Border.all(
                                      color:
                                          AppColors.createProjectAppBarColor),
                                ),
                                child: Center(
                                  child: Text(
                                    Strings().reviewButton,
                                    style: TextStyle(
                                        fontSize: Dimensions.font_14,
                                        fontWeight: FontWeight.bold,
                                        color:
                                            AppColors.createProjectAppBarColor),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: Dimensions.width_32),
                            createProjectButton()
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.height_29),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Navigation to Create Project Screen.
  void navigateToCreateProjectScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/createProjectScreen'));
  }

  /// listener for positive button
  void positiveButtonCallback() {
    if (technicalDialogClicked) {
      navigateToTechnicalScreen(context);
    } else {
      Navigator.of(context).pop();
      ShowBottomSheet.getInstance.permissionHandlerMethod(context);
    }
  }

  /// listener for negative button
  void negativeButtonCallback() {
    Navigator.of(context).pop();
  }

  /// listener for single button (Create Anyway button & )
  void actionSingleButtonCallback() {
    print(6);
    if (technicalDialogClicked) {
      Navigator.of(context).pop();
    } else if (resourceDetail.isNotEmpty) {
      print(7);
      Dialogs.showLoadingDialog(context, _keyLoader, isProject);
      int index = resourceDetail.length;
      for (int i = 0; i < index; i++) {
        additionalDetailScreenBloc.add(ResourceStoreEvent(
            resourceName: resourceDetail[i]!.resourceName,
            resourceEmail: resourceDetail[i]!.resourceEmail,
            designation: resourceDetail[i]!.designation));
      }
    } else {
      print(8);
      Dialogs.showLoadingDialog(context, _keyLoader, isProject);
      if (isProject) {
        additionalDetailScreenBloc.add(AdditionalDetailCreateProjectBtnEvent(
            objectives: draftObjective,
            startDate: draftStartDate,
            endDate: draftEndDate,
            clientName: clientNameController.text,
            budget: projectBudgetController.text,
            knownIssues: draftKnownIssue,
            dependencies: draftDependencies,
            comments: commentController.text,
            documents: null,
            feedback: projectFeedbackController.text,
            name: draftProjectName,
            summary: draftSummery,
            currency: currencyController.text,
            location: locationController.text,
            riskFactor: draftRiskFactor,
            technologies: draftTechnology,
            domain: draftDomain,
            platforms: draftPlatform,
            resources: null,
            functionalities: jsonDecode(jsonEncode(draftFunctionality)),
            status: draftStatus,
            methodology: methodology));
      } else {
        ///Proposal Post API
        additionalDetailScreenBloc.add(AdditionalDetailCreateProposalBtnEvent(
          objectives: draftObjective,
          proposalReceivedDate: draftStartDate,
          proposalSubmittedDate: draftEndDate,
          clientDetails: proposalClientNameController.text,
          budget: proposalBudgetController.text,
          dependencies: draftDependencies,
          comments: proposalCommentController.text,
          documents: null,
          feedback: proposalFeedbackController.text,
          name: draftProjectName,
          summery: draftSummery,
          currency: proposalCurrencyController.text,
          location: proposalLocationController.text,
          riskFactors: draftRiskFactor,
          technologies: draftTechnology,
          domain: draftDomain,
          platforms: draftPlatform,
          resources: null,
          functionalities: jsonDecode(jsonEncode(draftFunctionality)),
          status: draftStatus,
        ));
      }
    }
  }

  /// All with yes no button without background
  CustomDialogBox dialog() {
    return CustomDialogBox(
      title: Strings().dialogTitle.toTitleCase(),
      description: Strings().dialogDiscription,
      actionPositive: Strings().positiveButton.toTitleCase(),
      actionNegative: Strings().negativeButton.toTitleCase(),
      showTitle: true,
      showDescription: true,
      showDialogImage: true,
      showActionPositive: true,
      showActionNegative: true,
      showSingleActionButton: false,
      buttonTextColor: Colors.black,
      onPositiveButtonClick: positiveButtonCallback,
      onNegativeButtonClick: negativeButtonCallback,
      actionOnPressed: actionSingleButtonCallback,
    );
  }

  /// All with yes no button without background
  CustomDialogBox technicalDialog() {
    return CustomDialogBox(
      title: Strings().dialogTitle.toTitleCase(),
      description: Strings().dialogAdditionalDraftDiscription,
      actionPositive: Strings().dialogDraftNegativeButton.toTitleCase(),
      actionNegative: Strings().dialogDraftPositiveButton.toTitleCase(),
      showTitle: true,
      showDescription: true,
      showDialogImage: true,
      showActionPositive: true,
      showActionNegative: true,
      showSingleActionButton: false,
      buttonTextColor: Colors.black,
      onPositiveButtonClick: positiveButtonCallback,
      onNegativeButtonClick: negativeButtonCallback,
      actionOnPressed: actionSingleButtonCallback,
    );
  }

  /// Currency dropdown list Bloc Implementation.
  Widget currencyDropdown() {
    return BlocProvider(
      create: (_) => additionalDetailScreenBloc,
      child: BlocListener<AdditionalDetailScreenBloc, AdditionalDetailState>(
        listener: (context, state) {},
        child: BlocBuilder<AdditionalDetailScreenBloc, AdditionalDetailState>(
          builder: (context, state) {
            return CustomDropDown(
                controller: currencyController,
                list: currencyList,
                wlist: const [],
                isTitleCase: false,
                dbkey: "currency",
                title: Strings().textFieldCurrency.toTitleCase(),
                onChanged: (selectedItem) {
                  if (isProject == true) {
                    currencyController.text = selectedItem!;
                  } else {
                    proposalCurrencyController.text = selectedItem!;
                  }
                  currencyDropdownOpened = false;
                },
                isStretchedDropDown: currencyDropdownOpened,
                onTapped: () {
                  setState(() {
                    FocusScope.of(context).requestFocus(FocusNode());
                    currencyDropdownOpened = !currencyDropdownOpened;
                    isDropdownOpened = false;
                    locationDropdownOpened = false;
                  });
                });
          },
        ),
      ),
    );
  }

  /// Location dropdown list Bloc Implementation.
  Widget locationDropdown() {
    return BlocProvider(
      create: (_) => additionalDetailScreenBloc,
      child: BlocListener<AdditionalDetailScreenBloc, AdditionalDetailState>(
        listener: (context, state) {},
        child: BlocBuilder<AdditionalDetailScreenBloc, AdditionalDetailState>(
          builder: (context, state) {
            return CustomDropDown(
              controller: locationController,
              onTapped: () {
                setState(() {
                  FocusScope.of(context).requestFocus(FocusNode());
                  locationDropdownOpened = !locationDropdownOpened;
                  isDropdownOpened = false;
                  currencyDropdownOpened = false;
                });
              },
              isTitleCase: false,
              wlist: const [],
              dbkey: "location",
              list: locationList,
              title: Strings().textFieldLocation.toTitleCase(),
              onChanged: (selectedItem) {
                if (isProject == true) {
                  locationController.text = selectedItem!;
                } else {
                  proposalLocationController.text = selectedItem!;
                }
                locationDropdownOpened = false;
              },
              isStretchedDropDown: locationDropdownOpened,
            );
          },
        ),
      ),
    );
  }

  Widget createProjectButton() {
    return InkWell(
      onTap: () {
        if (isProject) {
          if (clientNameController.text.isNotEmpty &&
              currencyController.text.isNotEmpty &&
              projectBudgetController.text.isNotEmpty &&
              locationController.text.isNotEmpty) {
            if (isSaved) {
              if (widget.isTechnicalScreen) {
                navigateToHomePage(context);
                DisplayMessageUtils.flushBarErrorMessage(
                    context,
                    Strings().projectCreatedMessage,
                    AppColors.flushBarBackgroundColor,
                    Strings().view,
                    () {});
              } else {
                null;
              }
            } else {
              DisplayMessageUtils.snackBarMessage(
                  context, Strings().createProjectSaveDraft);
            }
          } else {
            DisplayMessageUtils.snackBarMessage(
                context, "Please fill Additional Details");
          }
        } else {
          print(1);
          print(proposalClientNameController.text);
          print(proposalCurrencyController.text);
          print(projectBudgetController.text);
          print(proposalLocationController.text);
          if (proposalClientNameController.text.isNotEmpty &&
              proposalCurrencyController.text.isNotEmpty &&
              proposalBudgetController.text.isNotEmpty &&
              proposalLocationController.text.isNotEmpty) {
            print(2);
            if (isSaved) {
              print(3);
              if (widget.isTechnicalScreen) {
                navigateToHomePage(context);
                DisplayMessageUtils.flushBarErrorMessage(
                    context,
                    Strings().proposalCreatedMessage,
                    AppColors.flushBarBackgroundColor,
                    Strings().view,
                    () {});
              } else {
                null;
              }
            } else {
              DisplayMessageUtils.snackBarMessage(
                  context, Strings().createProposalSaveDraft);
            }
          } else {
            DisplayMessageUtils.snackBarMessage(
                context, "Please fill Additional Details");
          }
        }
      },
      borderRadius: BorderRadius.circular(Dimensions.borderRadius_60),
      child: Container(
        height: Dimensions.height_40,
        width: Dimensions.width_160,
        decoration: BoxDecoration(
          color: AppColors.createProjectAppBarColor,
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_60),
          border: Border.all(color: Colors.transparent),
        ),
        child: BlocProvider.value(
          value: additionalDetailScreenBloc,
          child:
              BlocListener<AdditionalDetailScreenBloc, AdditionalDetailState>(
            listener: (context, state) {},
            child:
                BlocBuilder<AdditionalDetailScreenBloc, AdditionalDetailState>(
              builder: (context, state) {
                if (state is CreateProjectLoadingState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is UploadDocumentState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is ResourceStoreState) {
                  return Center(
                    child: SizedBox(
                      height: Dimensions.height_20,
                      width: Dimensions.width_20,
                      child: CircularProgressIndicator(color: AppColors.white),
                    ),
                  );
                } else if (state is AdditionalDetailCreateProjectButtonState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else if (state is AdditionalDetailCreateProposalButtonState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else if (state is CreateProjectFailedState) {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                } else {
                  return Center(
                    child: Text(
                      isProject
                          ? Strings().createProjectButton.toTitleCase()
                          : Strings().createProposalButton.toTitleCase(),
                      style: TextStyle(
                          fontSize: Dimensions.font_14,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white),
                    ),
                  );
                }
              },
            ),
          ),
        ),
      ),
    );
  }
}
