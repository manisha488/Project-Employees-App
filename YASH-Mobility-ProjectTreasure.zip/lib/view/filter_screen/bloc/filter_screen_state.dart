part of 'filter_screen_bloc.dart';

@immutable
abstract class FilterScreenState {}

/// First state to emit on filter screen.
class FilterScreenInitial extends FilterScreenState {}
 class FiltersActionState extends FilterScreenState {}

/// State to emit after main project filters loaded successfully.
class ProjectsFiltersLoadedSuccessState extends FiltersActionState {
  final List<AllFilters> filters;
  ProjectsFiltersLoadedSuccessState(this.filters);
}

/// State to emit after main proposal filters loaded successfully.
class ProposalFiltersLoadedSuccessState extends FiltersActionState {
  final List<AllFilters> filters;
  ProposalFiltersLoadedSuccessState(this.filters);
}

/// State to emit after successful loading of sub filters.
class FilterPlatformLoadedSuccessState extends FilterScreenState{
  final List<DummyMultiselectFilters> platformFilters;

  FilterPlatformLoadedSuccessState(this.platformFilters) ;
}

/// State to load after getting filtered data.
class ApplyFiltersState extends FiltersActionState {
  final List<ProjectsData?> filters;
  ApplyFiltersState(this.filters);
}

/// State to load after getting filtered data.
class ApplyProposalFiltersState extends FiltersActionState {
  final List<ProposalsData?> filters;
  ApplyProposalFiltersState(this.filters);
}

/// State to enable apply filters button.
class ApplyButtonEnabledState extends FiltersActionState{}

/// State to disable apply filters button.
class ApplyButtonDisableState extends FiltersActionState{}
class ApplyButtonLoadingState extends FiltersActionState{}
class ApplyButtonDisableProposalState extends FiltersActionState{}
class ApplyButtonEnableProposalState extends FiltersActionState{}


