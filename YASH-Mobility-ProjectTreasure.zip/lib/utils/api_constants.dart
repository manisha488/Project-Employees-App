class ApiConstants {
  static const scheme = 'https';
  // static const baseUrl = 'https://projecttreasure.azurewebsites.net/api/';
  //   static const baseUrl = 'http://10.0.2.2:1338/api/';
  static const baseUrlCurrency = 'https://api.sandbox.transferwise.tech/v1/';
  static const baseUrlLocation = 'https://countriesnow.space/api/v0.1/';
  static const baseUrl = 'http://127.0.0.1:1338/api/';


  /// API end points
  static const loginApi = "auth/local";
  static const projectsListApi = "projects/?populate=*";
  static const proposalsListApi = "proposals/?populate=*";
  static const searchProjectApi = "searchProjects?value=";
  static const searchProposalApi = "searchProposals?value=";
  static const platformsListApi = "platforms";
  static const technologiesListApi = "technologies";
  static const domainsListApi = "domains";
  static const searchProjectsApi = "searchProjects?value=";
  static const filterProjectsApi = "filterProjects";
  static const postProjectDataApi = "projects/?populate=*";
  static const postProposalDataApi = "proposals/?populate=*";
  static const filterProposalsApi = "filterProposals?populate=*";
  static const postDataApi = "projects/?populate=*";
  static const resourceDataApi = "addResources";
  static const statusListApi = "statuses";
  static const functionalityListApi = "functionalities";
  static const methodologyListApi = "methodologies";
  static const designationsListApi = "designations";
  static const documentApi = "upload";
  static const currenciesApi =
      "https://api.sandbox.transferwise.tech/v1/currencies";
  static const resourcesListApi = "resources";
  static const locationApi = "https://countriesnow.space/api/v0.1/countries";
}
