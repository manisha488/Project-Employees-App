import 'dart:async';
import 'dart:convert';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/filteredProjects.dart';
import 'package:yash_mobility_project_treasure/model/filteredProposals.dart';
import 'package:yash_mobility_project_treasure/model/resoucesList.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/model/response/proposals_list.dart';

import '../../model/User.dart';
import '../../model/response/create_project_model_list.dart';
import '../../model/response/create_proposal_model_list.dart';

class CustomDataBaseWrapper {
  late Database _database;

  /// Create Table for Projects Database
  Future openDb() async {
    _database = await openDatabase(join(await getDatabasesPath(), "pt.db"),
        version: 1, onCreate: (Database db, int version) async {
      await db.execute(
        "CREATE TABLE projects(id INTEGER PRIMARY KEY autoincrement, name TEXT, objectives TEXT,startDate TEXT, endDate TEXT, clientName TEXT, budget TEXT,  knownIssues TEXT, dependencies TEXT,  comments TEXT, currencies TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT, documents TEXT, feedback TEXT, summary TEXT, technologies TEXT, domains TEXT, platforms TEXT, resources TEXT,  functionalities TEXT, status TEXT, location TEXT, riskFactors TEXT, methodology TEXT)",
      );
      await db.execute(
        "CREATE TABLE proposals(id INTEGER PRIMARY KEY autoincrement, name TEXT, objectives TEXT,proposalReceivedDate TEXT, proposalSubmittedDate TEXT, clientDetails TEXT, riskFactors TEXT, dependencies TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT, documents TEXT, feedback TEXT, summary TEXT, comments TEXT, technologies TEXT, domains TEXT, platforms TEXT, resources TEXT,  functionalities TEXT, status TEXT, location TEXT, budget TEXT, currency TEXT)",
      );
      await db.execute(
        "CREATE TABLE createProjects(id INTEGER PRIMARY KEY autoincrement, name TEXT UNIQUE, objectives TEXT, startDate TEXT, endDate TEXT, clientName TEXT, budget TEXT,  knownIssues TEXT, dependencies TEXT,  comments TEXT, currencies TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT, documents TEXT, feedback TEXT, summary TEXT, technologies TEXT, domains TEXT, platforms TEXT, resources TEXT,  functionalities TEXT, status TEXT, methodology Text,location Text, riskFactors Text)",
      );
      await db.execute(
        "CREATE TABLE createProposal(id INTEGER PRIMARY KEY autoincrement, name TEXT UNIQUE, objectives TEXT, receivedDate TEXT, submittedDate TEXT, clientName TEXT, budget TEXT, dependencies TEXT,  comments TEXT, currencies TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT, documents TEXT, feedback TEXT, summery TEXT, technologies TEXT, domains TEXT, platforms TEXT, resources TEXT,  functionalities TEXT, status TEXT,location Text, riskFactors Text)",
      );
      await db.execute(
        "CREATE TABLE filteredProjects(id INTEGER PRIMARY KEY autoincrement, name TEXT, objectives TEXT,startDate TEXT, endDate TEXT, clientName TEXT, budget TEXT,  knownIssues TEXT, dependencies TEXT,  comments TEXT, currencies TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT, documents TEXT, feedback TEXT, summary TEXT, technologies TEXT, domains TEXT, platforms TEXT, resources TEXT,  functionalities TEXT, status TEXT)",
      );
      await db.execute(
        "CREATE TABLE filteredProposals(id INTEGER PRIMARY KEY autoincrement, name TEXT, objectives TEXT,proposalReceivedDate TEXT, proposalSubmittedDate TEXT, clientDetails TEXT, riskFactors TEXT, dependencies TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT, documents TEXT, feedback TEXT, summary TEXT, comments TEXT, technologies TEXT, domains TEXT, platforms TEXT, resources TEXT,  functionalities TEXT, status TEXT)",
      );
      await db.execute(
          "CREATE TABLE technologies (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
          "CREATE TABLE platforms (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
          "CREATE TABLE domains (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
          "CREATE TABLE status (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
          "CREATE TABLE functionalities (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
          "CREATE TABLE methodologies (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
          "CREATE TABLE resources (id INTEGER PRIMARY KEY autoincrement, name TEXT, email TEXT, designation Text)");
      await db.execute(
          "CREATE TABLE designations (id INTEGER PRIMARY KEY autoincrement, name TEXT, createdAt TEXT, updatedAt TEXT, publishedAt TEXT)");
      await db.execute(
        "CREATE TABLE login(id INTEGER PRIMARY KEY autoincrement, username TEXT, password TEXT, userRole TEXT)",
      );
    });
    return _database;
  }

  /// As we are not getting data in Map<String, dynamic>, this method will be used to convert Json into Map<String, dynamic>.
  /// This method is used before inserting the data to database
  List<Map<String, dynamic>> convertStringJsonToMapForInsertion(
      Map<String, dynamic> json) {
    var encodedJson = jsonEncode(json);
    var encodedList = [encodedJson];
    List<Map<String, dynamic>> mapList = [];
    for (var element in encodedList) {
      mapList.add({
        "data": element,
      });
    }
    return mapList;
  }

  /// This method is used to convert Json to Map<String, dynamic> and used while retrieving data.
  Map<String, dynamic> convertStringJsonToMapToRetrieveData(
      List<dynamic> json) {
    Map<String, dynamic> mapList = {};
    mapList.addAll({
      "data": json[0],
    });
    return mapList;
  }

  Map<String, dynamic> convertStringJsonToMapWithoutKey(List<dynamic> json) {
    Map<String, dynamic> mapList = {};
    mapList.addAll(
      json[0],
    );
    return mapList;
  }

  /// Insert Projects Data
  Future insertProjects(List<ProjectsData> projects, String tableName) async {
    await openDb();
    int index = projects.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          projects[i].attributes!.technologies!.toJson());
      var domains = convertStringJsonToMapForInsertion(
          projects[i].attributes!.domain!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          projects[i].attributes!.platforms!.toJson());
      var resources = convertStringJsonToMapForInsertion(
          projects[i].attributes!.resources!.toJson());
      var functionalities = convertStringJsonToMapForInsertion(
          projects[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          projects[i].attributes!.status!.toJson());
      List<Map<String, dynamic>> methodology = [];
      if (projects[i].attributes!.methodology != null) {
        methodology = convertStringJsonToMapForInsertion(
            projects[i].attributes!.methodology!.toJson());
      }
      List<Map<String, dynamic>> documents = [];
      if (projects[i].attributes!.documents != null) {
        documents = convertStringJsonToMapForInsertion(
            projects[i].attributes!.documents!.toJson());
      }
      _database.insert(
          tableName,
          {
            'id': projects[i].id,
            'name': projects[i].attributes!.name,
            'objectives': projects[i].attributes!.objectives,
            'startDate': projects[i].attributes!.startDate,
            'endDate': projects[i].attributes!.endDate,
            'clientName': projects[i].attributes!.clientName,
            'budget': projects[i].attributes!.budget,
            'knownIssues': projects[i].attributes!.knownIssues,
            'dependencies': projects[i].attributes!.dependencies,
            'comments': projects[i].attributes!.comments,
            'currencies': projects[i].attributes!.currency,
            'createdAt': projects[i].attributes!.createdAt,
            'updatedAt': projects[i].attributes!.updatedAt,
            'publishedAt': projects[i].attributes!.publishedAt,
            'documents': documents.isEmpty ? null : documents[0]['data'],
            'feedback': projects[i].attributes!.feedback,
            'summary': projects[i].attributes!.summary,
            'technologies': technologies[0]['data'],
            'domains': domains[0]['data'],
            'platforms': platforms[0]['data'],
            'resources': resources[0]['data'],
            'functionalities': functionalities[0]['data'],
            'status': status[0]['data'],
            'location': projects[i].attributes!.location,
            'riskFactors': projects[i].attributes!.riskFactor,
            'methodology': methodology[0]['data'],
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Insert Filtered Projects Data
  Future insertFilteredProjects(
      List<FilteredProjectsData> projects, String tableName) async {
    await openDb();
    int index = projects.length;

    for (int i = 0; i < index; i++) {
      _database.insert(
          tableName,
          {
            'id': projects[i].id,
            'name': projects[i].name,
            'objectives': projects[i].objectives,
            'startDate': projects[i].startDate,
            'endDate': projects[i].endDate,
            'clientName': projects[i].clientName,
            'budget': projects[i].budget,
            'knownIssues': projects[i].knownIssues,
            'dependencies': projects[i].dependencies,
            'comments': projects[i].comments,
            'currencies': projects[i].currency,
            'createdAt': projects[i].createdAt,
            'updatedAt': projects[i].updatedAt,
            'publishedAt': projects[i].publishedAt,
            'documents': projects[i].documents,
            'feedback': projects[i].feedback,
            'summary': projects[i].summary,
            'technologies': json.encode(projects[i].technologies),
            'domain': json.encode(projects[i].domain!),
            'platforms': json.encode(projects[i].platforms!),
            'resources': json.encode(projects[i].resources!),
            'functionalities': json.encode(projects[i].functionalities!),
            'status': json.encode(projects[i].status!),
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Insert Proposals Data
  Future insertProposals(
      List<ProposalsData> proposals, String tableName) async {
    await openDb();
    int index = proposals.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          proposals[i].attributes!.technologies!.toJson());
      var domains = convertStringJsonToMapForInsertion(
          proposals[i].attributes!.domain!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          proposals[i].attributes!.platforms!.toJson());
      var resources = convertStringJsonToMapForInsertion(
          proposals[i].attributes!.resources!.toJson());
      var functionalities = convertStringJsonToMapForInsertion(
          proposals[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          proposals[i].attributes!.status!.toJson());
      List<Map<String, dynamic>> documents = [];
      if (proposals[i].attributes!.documents != null) {
        documents = convertStringJsonToMapForInsertion(
            proposals[i].attributes!.documents!.toJson());
      }
      _database.insert(
          tableName,
          {
            'id': proposals[i].id,
            'name': proposals[i].attributes!.name,
            'objectives': proposals[i].attributes!.objectives,
            'proposalReceivedDate':
                proposals[i].attributes!.proposalReceivedDate,
            'proposalSubmittedDate':
                proposals[i].attributes!.proposalSubmittedDate,
            'clientDetails': proposals[i].attributes!.clientDetails,
            'riskFactors': proposals[i].attributes!.riskFactors,
            'dependencies': proposals[i].attributes!.dependencies,
            'comments': proposals[i].attributes!.comments,
            'createdAt': proposals[i].attributes!.createdAt,
            'updatedAt': proposals[i].attributes!.updatedAt,
            'publishedAt': proposals[i].attributes!.publishedAt,
            'documents': documents.isEmpty ? null : documents[0]['data'],
            'feedback': proposals[i].attributes!.feedback,
            'summary': proposals[i].attributes!.summery,
            'location': proposals[i].attributes!.location,
            'budget': proposals[i].attributes!.budget,
            'currency': proposals[i].attributes!.currency,
            'technologies': technologies[0]['data'],
            'domains': domains[0]['data'],
            'platforms': platforms[0]['data'],
            'resources': resources[0]['data'],
            'functionalities': functionalities[0]['data'],
            'status': status[0]['data'],
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Insert Filtered Proposals Data
  Future insertFilteredProposals(List<FilteredProposalsData> proposals) async {
    await openDb();
    int index = proposals.length;

    for (int i = 0; i < index; i++) {
      _database.insert(
          'filteredProposals',
          {
            'id': proposals[i].id,
            'name': proposals[i].name,
            'objectives': proposals[i].objectives,
            'proposalReceivedDate': proposals[i].proposalReceivedDate,
            'proposalSubmittedDate': proposals[i].proposalSubmittedDate,
            'clientDetails': proposals[i].clientDetails,
            'riskFactors': proposals[i].riskFactors,
            'dependencies': proposals[i].dependencies,
            'comments': proposals[i].comments,
            'createdAt': proposals[i].createdAt,
            'updatedAt': proposals[i].updatedAt,
            'publishedAt': proposals[i].publishedAt,
            'documents': proposals[i].documents,
            'feedback': proposals[i].feedback,
            'summary': proposals[i].summery,
            'technologies': json.encode(proposals[i].technologies),
            'domain': json.encode(proposals[i].domain),
            'platforms': json.encode(proposals[i].platforms),
            'resources': json.encode(proposals[i].resources),
            'functionalities': json.encode(proposals[i].functionalities),
            'status': json.encode(proposals[i].status),
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Insert Create Projects Data
  Future insertCreateProjects(List<CreateProjectData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      List<Map<String, dynamic>> technologies = [
        {"data": null}
      ];
      if (createProject[i].attributes!.technologies!.data != null) {
        technologies = convertStringJsonToMapForInsertion(
            createProject[i].attributes!.technologies!.toJson());
      }
      var domains = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.domain!.toJson());
      List<Map<String, dynamic>> platforms = [
        {"data": null}
      ];
      if (createProject[i].attributes!.platforms!.data != null) {
        platforms = convertStringJsonToMapForInsertion(
            createProject[i].attributes!.platforms!.toJson());
      }
      var resources = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.resources!.toJson());
      var functionalities = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.status!.toJson());
      List<Map<String, dynamic>> methodology = [
        {"data": null}
      ];
      if (createProject[i].attributes!.methodology!.data != null) {
        methodology = convertStringJsonToMapForInsertion(
            createProject[i].attributes!.methodology!.toJson());
      }
      var document = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.documents!.toJson());

      _database.insert(
          'createProjects',
          {
            'name': createProject[i].attributes!.name,
            'objectives': createProject[i].attributes!.objectives,
            'startDate': createProject[i].attributes!.startDate,
            'endDate': createProject[i].attributes!.endDate,
            'clientName': createProject[i].attributes!.clientName,
            'budget': createProject[i].attributes!.budget,
            'knownIssues': createProject[i].attributes!.knownIssues,
            'dependencies': createProject[i].attributes!.dependencies,
            'comments': createProject[i].attributes!.comments,
            'currencies': createProject[i].attributes!.currency,
            'createdAt': createProject[i].attributes!.createdAt,
            'updatedAt': createProject[i].attributes!.updatedAt,
            'publishedAt': createProject[i].attributes!.publishedAt,
            'documents': document[0]['data'],
            'feedback': createProject[i].attributes!.feedback,
            'summary': createProject[i].attributes!.summary,
            'technologies': technologies[0]['data'],
            'domains': domains[0]['data'],
            'platforms': platforms[0]['data'],
            'resources': resources[0]['data'],
            'functionalities': functionalities[0]['data'],
            'status': status[0]['data'],
            'methodology': methodology[0]['data'],
            'location': createProject[i].attributes!.location,
            'riskFactors': createProject[i].attributes!.riskFactor,
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Insert Create Proposal Data
  Future insertCreateProposals(List<CreateProposalData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.technologies!.toJson());
      var domains = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.domain!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.platforms!.toJson());
      var resources = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.resources!.toJson());
      var functionalities = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.status!.toJson());
      var document = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.documents!.toJson());

      _database.insert(
          'createProposal',
          {
            'name': createProposal[i].attributes!.name,
            'objectives': createProposal[i].attributes!.objectives,
            'receivedDate': createProposal[i].attributes!.proposalReceivedDate,
            'submittedDate':
                createProposal[i].attributes!.proposalSubmittedDate,
            'clientName': createProposal[i].attributes!.clientDetails,
            'budget': createProposal[i].attributes!.budget,
            'dependencies': createProposal[i].attributes!.dependencies,
            'comments': createProposal[i].attributes!.comments,
            'currencies': createProposal[i].attributes!.currency,
            'createdAt': createProposal[i].attributes!.createdAt,
            'updatedAt': createProposal[i].attributes!.updatedAt,
            'publishedAt': createProposal[i].attributes!.publishedAt,
            'documents': document[0]['data'],
            'feedback': createProposal[i].attributes!.feedback,
            'summery': createProposal[i].attributes!.summery,
            'technologies': technologies[0]['data'],
            'domains': domains[0]['data'],
            'platforms': platforms[0]['data'],
            'resources': resources[0]['data'],
            'functionalities': functionalities[0]['data'],
            'status': status[0]['data'],
            'location': createProposal[i].attributes!.location,
            'riskFactors': createProposal[i].attributes!.riskFactors,
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  Future insertData(
      List<MultiSelectionFiltersData?> list, String tableName) async {
    await openDb();
    int index = list.length;

    for (int i = 0; i < index; i++) {
      _database.insert(
          tableName,
          {
            'id': list[i]!.id,
            'name': list[i]!.attributes!.name,
            "createdAt": list[i]!.attributes!.createdAt,
            "updatedAt": list[i]!.attributes!.updatedAt,
            "publishedAt": list[i]!.attributes!.publishedAt,
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  Future insertResourcesData(List<ResourcesListData?> list) async {
    await openDb();
    int index = list.length;

    for (int i = 0; i < index; i++) {
      _database.insert(
          "resources",
          {
            'id': list[i]!.id,
            'name': list[i]!.attributes!.resourceName,
            'email': list[i]!.attributes!.resourceEmail,
            'designation': list[i]!.attributes!.designation
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Get all Projects List
  Future<List<ProjectsData>> getProjectsList(String tableName) async {
    await openDb();
    final List<Map<String, dynamic>> allProjects =
        await _database.query(tableName);

    return List.generate(allProjects.length, (i) {
      var technologies = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['technologies']))]);
      var domains = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['domains']))]);
      var platforms = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['platforms']))]);
      var resources = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['resources']))]);
      var functionalities = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['functionalities']))]);
      var status = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['status']))]);
      Map<String, dynamic> documents = {};
      Map<String, dynamic> methodology = {};
      if (allProjects[i]['documents'] != null) {
        documents = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['documents']))]);
      }
      if (allProjects[i]['methodology'] != null) {
        methodology = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['methodology']))]);
      }
      var attributes = ProjectsDataAttributes(
          name: allProjects[i]['name'],
          objectives: allProjects[i]['objectives'],
          startDate: allProjects[i]['startDate'],
          endDate: allProjects[i]['endDate'],
          clientName: allProjects[i]['clientName'],
          budget: allProjects[i]['budget'],
          knownIssues: allProjects[i]['knownIssues'],
          dependencies: allProjects[i]['dependencies'],
          comments: allProjects[i]['comments'],
          currency: allProjects[i]['currencies'],
          createdAt: allProjects[i]['createdAt'],
          updatedAt: allProjects[i]['updatedAt'],
          publishedAt: allProjects[i]['publishedAt'],
          feedback: allProjects[i]['feedback'],
          summary: allProjects[i]['summary'],
          location: allProjects[i]['location'],
          riskFactor: allProjects[i]['riskFactors'],
          documents: documents.isEmpty
              ? null
              : ProjectsDataAttributesDocuments.fromJson(documents['data']),
          methodology:
              ProjectsDataAttributesMethodology.fromJson(methodology['data']),
          technologies:
              ProjectsDataAttributesTechnologies.fromJson(technologies['data']),
          domain: ProjectsDataAttributesDomain.fromJson(domains['data']),
          platforms:
              ProjectsDataAttributesPlatforms.fromJson(platforms['data']),
          resources:
              ProjectsDataAttributesResources.fromJson(resources['data']),
          functionalities: ProjectsDataAttributesFunctionalities.fromJson(
              functionalities['data']),
          status: ProjectsDataAttributesStatus.fromJson(status['data']));
      return ProjectsData(id: allProjects[i]['id'], attributes: attributes);
    });
  }

  Future<List<FilteredProjectsData>> getFilteredProjectsList(
      String tableName) async {
    await openDb();
    final List<Map<String, dynamic>> allProjects =
        await _database.query(tableName);
    return List.generate(allProjects.length, (i) {
      List tech = jsonDecode(allProjects[i]['technologies']);
      List platformList = (jsonDecode(allProjects[i]['platforms']));
      List resourcesList = (jsonDecode(allProjects[i]['resources']));
      List functionalitiesList =
          (jsonDecode(allProjects[i]['functionalities']));

      var technologies = List.generate(tech.length, (index) {
        return FilteredProjectsDataTechnologies.fromJson(tech[index]);
      }).toList();

      var platforms = List.generate(platformList.length, (index) {
        return FilteredProjectsDataPlatforms.fromJson(platformList[index]);
      }).toList();

      var resources = List.generate(resourcesList.length, (index) {
        return FilteredProjectsDataResources.fromJson(resourcesList[index]);
      }).toList();

      var functionalities = List.generate(functionalitiesList.length, (index) {
        return FilteredProjectsDataFunctionalities.fromJson(
            functionalitiesList[index]);
      }).toList();

      var domains = convertStringJsonToMapWithoutKey(
          [(jsonDecode(allProjects[i]['domain']))]);

      var status = convertStringJsonToMapWithoutKey(
          [(jsonDecode(allProjects[i]['status']))]);

      return FilteredProjectsData(
          id: allProjects[i]['id'],
          name: allProjects[i]['name'],
          objectives: allProjects[i]['objectives'],
          startDate: allProjects[i]['startDate'],
          endDate: allProjects[i]['endDate'],
          clientName: allProjects[i]['clientName'],
          budget: allProjects[i]['budget'],
          knownIssues: allProjects[i]['knownIssues'],
          dependencies: allProjects[i]['dependencies'],
          comments: allProjects[i]['comments'],
          currency: allProjects[i]['currencies'],
          createdAt: allProjects[i]['createdAt'],
          updatedAt: allProjects[i]['updatedAt'],
          publishedAt: allProjects[i]['publishedAt'],
          documents: allProjects[i]['documents'],
          feedback: allProjects[i]['feedback'],
          summary: allProjects[i]['summary'],
          technologies: technologies,
          functionalities: functionalities,
          platforms: platforms,
          domain: FilteredProjectsDataDomain.fromJson(domains),
          status: FilteredProjectsDataStatus.fromJson(status),
          resources: resources);
    });
  }

  /// Get all Proposals List
  Future<List<ProposalsData>> getProposalsList(String tableName) async {
    await openDb();
    final List<Map<String, dynamic>> allProposals =
        await _database.query(tableName);

    return List.generate(allProposals.length, (i) {
      var technologies = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['technologies']))]);
      var domains = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['domains']))]);
      var platforms = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['platforms']))]);
      var resources = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['resources']))]);
      var functionalities = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['functionalities']))]);
      var status = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['status']))]);
      Map<String, dynamic> documents = {};
      if (allProposals[i]['documents'] != null) {
        documents = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProposals[i]['documents']))]);
      }
      var attributes = ProposalsDataAttributes(
          name: allProposals[i]['name'],
          objectives: allProposals[i]['objectives'],
          proposalReceivedDate: allProposals[i]['proposalReceivedDate'],
          proposalSubmittedDate: allProposals[i]['proposalSubmittedDate'],
          clientDetails: allProposals[i]['clientDetails'],
          riskFactors: allProposals[i]['riskFactors'],
          dependencies: allProposals[i]['dependencies'],
          comments: allProposals[i]['comments'],
          createdAt: allProposals[i]['createdAt'],
          updatedAt: allProposals[i]['updatedAt'],
          publishedAt: allProposals[i]['publishedAt'],
          feedback: allProposals[i]['feedback'],
          summery: allProposals[i]['summary'],
          currency: allProposals[i]['currency'],
          budget: allProposals[i]['budget'],
          location: allProposals[i]['location'],
          documents: documents.isEmpty
              ? null
              : ProposalsDataAttributesDocuments.fromJson(documents['data']),
          technologies: ProposalsDataAttributesTechnologies.fromJson(
              technologies['data']),
          domain: ProposalsDataAttributesDomain.fromJson(domains['data']),
          platforms:
              ProposalsDataAttributesPlatforms.fromJson(platforms['data']),
          resources:
              ProposalsDataAttributesResources.fromJson(resources['data']),
          functionalities: ProposalsDataAttributesFunctionalities.fromJson(
              functionalities['data']),
          status: ProposalsDataAttributesStatus.fromJson(status['data']));
      return ProposalsData(id: allProposals[i]['id'], attributes: attributes);
    });
  }

  /// Get all Filtered Proposals List
  Future<List<FilteredProposalsData>> getFilteredProposalsList() async {
    await openDb();
    final List<Map<String, dynamic>> allProposals =
        await _database.query('filteredProposals');

    return List.generate(allProposals.length, (i) {
      List tech = jsonDecode(allProposals[i]['technologies']);
      List platformList = (jsonDecode(allProposals[i]['platforms']));
      List resourcesList = (jsonDecode(allProposals[i]['resources']));
      List functionalitiesList =
          (jsonDecode(allProposals[i]['functionalities']));

      var technologies = List.generate(tech.length, (index) {
        return FilteredProposalsDataTechnologies.fromJson(tech[index]);
      }).toList();

      var platforms = List.generate(platformList.length, (index) {
        return FilteredProposalsDataPlatforms.fromJson(platformList[index]);
      }).toList();

      var resources = List.generate(resourcesList.length, (index) {
        return FilteredProposalsDataResources.fromJson(resourcesList[index]);
      }).toList();

      var functionalities = List.generate(functionalitiesList.length, (index) {
        return FilteredProposalsDataFunctionalities.fromJson(
            functionalitiesList[index]);
      }).toList();

      var domains = convertStringJsonToMapWithoutKey(
          [(jsonDecode(allProposals[i]['domain']))]);

      var status = convertStringJsonToMapWithoutKey(
          [(jsonDecode(allProposals[i]['status']))]);
      return FilteredProposalsData(
          name: allProposals[i]['name'],
          objectives: allProposals[i]['objectives'],
          proposalReceivedDate: allProposals[i]['proposalReceivedDate'],
          proposalSubmittedDate: allProposals[i]['proposalSubmittedDate'],
          clientDetails: allProposals[i]['clientDetails'],
          riskFactors: allProposals[i]['riskFactors'],
          dependencies: allProposals[i]['dependencies'],
          comments: allProposals[i]['comments'],
          createdAt: allProposals[i]['createdAt'],
          updatedAt: allProposals[i]['updatedAt'],
          publishedAt: allProposals[i]['publishedAt'],
          documents: allProposals[i]['documents'],
          feedback: allProposals[i]['feedback'],
          summery: allProposals[i]['summary'],
          technologies: technologies,
          domain: FilteredProposalsDataDomain.fromJson(domains),
          platforms: platforms,
          resources: resources,
          functionalities: functionalities,
          status: FilteredProposalsDataStatus.fromJson(status));
    });
  }

  /// Get Draft Projects List
  Future<List<CreateProjectData>> getDraftProjectsList() async {
    await openDb();
    final List<Map<String, dynamic>> allProjects =
        await _database.query('createProjects');

    return List.generate(allProjects.length, (i) {
      Map<String, dynamic> technologies = {"data": null};
      if (allProjects[i]['technologies'] != null) {
        technologies = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['technologies']))]);
      }
      var domains = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['domains']))]);
      Map<String, dynamic> platforms = {"data": null};
      if (allProjects[i]['platforms'] != null) {
        platforms = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['platforms']))]);
      }
      var resources = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['resources']))]);
      var functionalities = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['functionalities']))]);
      var status = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['status']))]);
      Map<String, dynamic> methodology = {"data": null};
      if (allProjects[i]['methodology'] != null) {
        methodology = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['methodology']))]);
      }
      // var document = convertStringJsonToMapToRetrieveData(
      //     [(jsonDecode(allProjects[i]['documents']))]);

      var attributes = CreateProjectDataAttributes(
        name: allProjects[i]['name'],
        objectives: allProjects[i]['objectives'],
        startDate: allProjects[i]['startDate'],
        endDate: allProjects[i]['endDate'],
        clientName: allProjects[i]['clientName'],
        budget: allProjects[i]['budget'],
        knownIssues: allProjects[i]['knownIssues'],
        dependencies: allProjects[i]['dependencies'],
        comments: allProjects[i]['comments'],
        currency: allProjects[i]['currencies'],
        createdAt: allProjects[i]['createdAt'],
        updatedAt: allProjects[i]['updatedAt'],
        publishedAt: allProjects[i]['publishedAt'],
        feedback: allProjects[i]['feedback'],
        summary: allProjects[i]['summary'],
        location: allProjects[i]['location'],
        riskFactor: allProjects[i]['riskFactors'],
        technologies: CreateProjectTechnologiesData.fromJson(
            technologies['data'] ?? technologies),
        domain: CreateProjectDomainData.fromJson(domains['data']),
        platforms:
            CreateProjectPlatformData.fromJson(platforms['data'] ?? platforms),
        resources: CreateProjectResourcesData.fromJson(resources['data']),
        functionalities:
            CreateProjectFunctionalitiesData.fromJson(functionalities['data']),
        status: CreateProjectStatusData.fromJson(status['data']),
        methodology: CreateProjectMethodologyData.fromJson(
            methodology['data'] ?? methodology),
        // documents:  CreateProjectDocumentsData.fromJson(document['documents'])
      );
      return CreateProjectData(id: i, attributes: attributes);
    });
  }

  /// Get Draft Proposal List
  Future<List<CreateProposalData>> getDraftProposalList() async {
    await openDb();
    final List<Map<String, dynamic>> allProposal =
        await _database.query('createProposal');

    return List.generate(allProposal.length, (i) {
      var technologies = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposal[i]['technologies']))]);
      var domains = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposal[i]['domains']))]);
      var platforms = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposal[i]['platforms']))]);
      var resources = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposal[i]['resources']))]);
      var functionalities = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposal[i]['functionalities']))]);
      var status = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposal[i]['status']))]);

      var attributes = CreateProposalDataAttributes(
        name: allProposal[i]['name'],
        objectives: allProposal[i]['objectives'],
        proposalReceivedDate: allProposal[i]['receivedDate'],
        proposalSubmittedDate: allProposal[i]['submittedDate'],
        clientDetails: allProposal[i]['clientName'],
        budget: allProposal[i]['budget'],
        dependencies: allProposal[i]['dependencies'],
        comments: allProposal[i]['comments'],
        currency: allProposal[i]['currencies'],
        createdAt: allProposal[i]['createdAt'],
        updatedAt: allProposal[i]['updatedAt'],
        publishedAt: allProposal[i]['publishedAt'],
        feedback: allProposal[i]['feedback'],
        summery: allProposal[i]['summery'],
        location: allProposal[i]['location'],
        riskFactors: allProposal[i]['riskFactors'],
        technologies: CreateProposalDataAttributesTechnologies.fromJson(
            technologies['data']),
        domain: CreateProposalDataAttributesDomain.fromJson(domains['data']),
        platforms:
            CreateProposalDataAttributesPlatforms.fromJson(platforms['data']),
        resources:
            CreateProposalDataAttributesResources.fromJson(resources['data']),
        functionalities: CreateProposalDataAttributesFunctionalities.fromJson(
            functionalities['data']),
        status: CreateProposalDataAttributesStatus.fromJson(status['data']),
      );
      return CreateProposalData(id: i, attributes: attributes);
    });
  }

  /// Get specific Projects List
  Future<List<ProjectsData>> getSpecificProjectsList(String name) async {
    await openDb();
    final List<Map<String, dynamic>> allProjects =
        await _database.query('Projects', where: 'name = ?', whereArgs: [name]);

    return List.generate(allProjects.length, (i) {
      Map<String, dynamic> technologies = {"data": null};
      if (allProjects[i]['technologies'] != null) {
        technologies = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['technologies']))]);
      }
      var domains = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['domains']))]);
      Map<String, dynamic> platforms = {"data": null};
      if (allProjects[i]['platforms'] != null) {
        platforms = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['platforms']))]);
      }
      var resources = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['resources']))]);
      var functionalities = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['functionalities']))]);
      var status = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProjects[i]['status']))]);
      Map<String, dynamic> methodology = {"data": null};
      if (allProjects[i]['methodology'] != null) {
        methodology = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['methodology']))]);
      }
      Map<String, dynamic> document = {};
      if (allProjects[i]['documents'] != null) {
        document = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProjects[i]['documents']))]);
      }

      var attributes = ProjectsDataAttributes(
        name: allProjects[i]['name'],
        objectives: allProjects[i]['objectives'],
        startDate: allProjects[i]['startDate'],
        endDate: allProjects[i]['endDate'],
        clientName: allProjects[i]['clientName'],
        budget: allProjects[i]['budget'],
        knownIssues: allProjects[i]['knownIssues'],
        dependencies: allProjects[i]['dependencies'],
        comments: allProjects[i]['comments'],
        currency: allProjects[i]['currencies'],
        createdAt: allProjects[i]['createdAt'],
        updatedAt: allProjects[i]['updatedAt'],
        publishedAt: allProjects[i]['publishedAt'],
        feedback: allProjects[i]['feedback'],
        summary: allProjects[i]['summary'],
        location: allProjects[i]['location'],
        riskFactor: allProjects[i]['riskFactors'],
        technologies: ProjectsDataAttributesTechnologies.fromJson(
            technologies['data'] ?? technologies),
        domain: ProjectsDataAttributesDomain.fromJson(domains['data']),
        platforms: ProjectsDataAttributesPlatforms.fromJson(
            platforms['data'] ?? platforms),
        resources: ProjectsDataAttributesResources.fromJson(resources['data']),
        functionalities: ProjectsDataAttributesFunctionalities.fromJson(
            functionalities['data']),
        status: ProjectsDataAttributesStatus.fromJson(status['data']),
        methodology: ProjectsDataAttributesMethodology.fromJson(
            methodology['data'] ?? methodology),
        documents: ProjectsDataAttributesDocuments.fromJson(
            document['data'] ?? document),
      );
      return ProjectsData(attributes: attributes);
    });
  }

  Future<List<User>> getUserList(String email) async {
    await openDb();
    final List<Map<String, dynamic>> users = await _database
        .query('login', where: 'username = ?', whereArgs: [email]);

    return List.generate(users.length, (i) {
      return User(
        id: users[i]['id'],
        name: users[i]['name'],
        username: users[i]['username'],
        password: users[i]['password'],
      );
    });
  }

  /// Get specific Projects List
  Future<List<ProposalsData>> getSpecificProposalList(String name) async {
    await openDb();
    final List<Map<String, dynamic>> allProposals = await _database
        .query('Proposals', where: 'name = ?', whereArgs: [name]);

    return List.generate(allProposals.length, (i) {
      var technologies = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['technologies']))]);
      var domains = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['domains']))]);
      var platforms = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['platforms']))]);
      var resources = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['resources']))]);
      var functionalities = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['functionalities']))]);
      var status = convertStringJsonToMapToRetrieveData(
          [(jsonDecode(allProposals[i]['status']))]);
      Map<String, dynamic> document = {};
      if (allProposals[i]['documents'] != null) {
        document = convertStringJsonToMapToRetrieveData(
            [(jsonDecode(allProposals[i]['documents']))]);
      }

      var attributes = ProposalsDataAttributes(
        name: allProposals[i]['name'],
        objectives: allProposals[i]['objectives'],
        proposalReceivedDate: allProposals[i]['receivedDate'],
        proposalSubmittedDate: allProposals[i]['submittedDate'],
        clientDetails: allProposals[i]['clientName'],
        budget: allProposals[i]['budget'],
        dependencies: allProposals[i]['dependencies'],
        comments: allProposals[i]['comments'],
        currency: allProposals[i]['currencies'],
        createdAt: allProposals[i]['createdAt'],
        updatedAt: allProposals[i]['updatedAt'],
        publishedAt: allProposals[i]['publishedAt'],
        feedback: allProposals[i]['feedback'],
        summery: allProposals[i]['summery'],
        location: allProposals[i]['location'],
        riskFactors: allProposals[i]['riskFactors'],
        technologies:
            ProposalsDataAttributesTechnologies.fromJson(technologies['data']),
        domain: ProposalsDataAttributesDomain.fromJson(domains['data']),
        platforms: ProposalsDataAttributesPlatforms.fromJson(platforms['data']),
        resources: ProposalsDataAttributesResources.fromJson(resources['data']),
        functionalities: ProposalsDataAttributesFunctionalities.fromJson(
            functionalities['data']),
        status: ProposalsDataAttributesStatus.fromJson(status['data']),
        documents: ProposalsDataAttributesDocuments.fromJson(
            document['data'] ?? document),
      );
      return ProposalsData(attributes: attributes);
    });
  }

  Future<List<MultiSelectionFiltersData>> getData(String tableName) async {
    await openDb();
    final List<Map<String, dynamic>> data = await _database.query(tableName);

    return List.generate(data.length, (i) {
      var attributes = MultiSelectionFiltersDataAttributes(
          name: data[i]['name'],
          createdAt: data[i]['createdAt'],
          updatedAt: data[i]['updatedAt'],
          publishedAt: data[i]['publishedAt']);
      return MultiSelectionFiltersData(
          id: data[i]['id'], attributes: attributes);
    });
  }

  Future<List<ResourcesListData>> getResourcesData() async {
    await openDb();
    final List<Map<String, dynamic>> data = await _database.query('resources');

    return List.generate(data.length, (i) {
      var attributes = ResourcesListDataAttributes(
          resourceName: data[i]['name'],
          resourceEmail: data[i]['email'],
          designation: data[i]['designation']);
      return ResourcesListData(id: data[i]['id'], attributes: attributes);
    });
  }

  /// Update Create Project Basic details.
  Future updateBasicDetail(List<ProjectsData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      var domains = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.domain!.toJson());
      var functionality = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.status!.toJson());

      _database.update(
        'projects',
        {
          'name': createProject[i].attributes!.name,
          'domains': domains[0]['data'],
          'objectives': createProject[i].attributes!.objectives,
          'startDate': createProject[i].attributes!.startDate,
          'endDate': createProject[i].attributes!.endDate,
          'summary': createProject[i].attributes!.summary,
          'functionalities': functionality[0]['data'],
          'status': status[0]['data'],
        },
        where: 'name = ?',
        whereArgs: [createProject[i].attributes!.name],
      );
    }
  }

  /// Update Create Project Basic details.
  Future updateCreateBasicDetail(List<CreateProjectData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      var domains = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.domain!.toJson());
      var functionality = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.status!.toJson());

      _database.update(
        'createProjects',
        {
          'name': createProject[i].attributes!.name,
          'domains': domains[0]['data'],
          'objectives': createProject[i].attributes!.objectives,
          'startDate': createProject[i].attributes!.startDate,
          'endDate': createProject[i].attributes!.endDate,
          'summary': createProject[i].attributes!.summary,
          'functionalities': functionality[0]['data'],
          'status': status[0]['data'],
        },
        where: 'name = ?',
        whereArgs: [createProject[i].attributes!.name],
      );
    }
  }

  /// Update Create Proposal Basic details.
  Future updateProposalBasicDetail(List<ProposalsData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var domains = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.domain!.toJson());
      var functionality = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.status!.toJson());

      _database.update(
        'proposals',
        {
          'name': createProposal[i].attributes!.name,
          'domains': domains[0]['data'],
          'objectives': createProposal[i].attributes!.objectives,
          'receivedDate': createProposal[i].attributes!.proposalReceivedDate,
          'submittedDate': createProposal[i].attributes!.proposalSubmittedDate,
          'summery': createProposal[i].attributes!.summery,
          'functionalities': functionality[0]['data'],
          'status': status[0]['data'],
        },
        where: 'name = ?',
        whereArgs: [createProposal[i].attributes!.name],
      );
    }
  }

  /// Update Create Proposal Basic details.
  Future updateCreateProposalBasicDetail(
      List<CreateProposalData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var domains = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.domain!.toJson());
      var functionality = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.functionalities!.toJson());
      var status = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.status!.toJson());

      _database.update(
        'createProposal',
        {
          'name': createProposal[i].attributes!.name,
          'domains': domains[0]['data'],
          'objectives': createProposal[i].attributes!.objectives,
          'receivedDate': createProposal[i].attributes!.proposalReceivedDate,
          'submittedDate': createProposal[i].attributes!.proposalSubmittedDate,
          'summery': createProposal[i].attributes!.summery,
          'functionalities': functionality[0]['data'],
          'status': status[0]['data'],
        },
        where: 'name = ?',
        whereArgs: [createProposal[i].attributes!.name],
      );
    }
  }

  /// Update Create project Technical details.
  Future updateTechnicalDetail(List<ProjectsData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.technologies!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.platforms!.toJson());
      var methodology = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.methodology!.toJson());

      print(methodology);

      _database.update(
        'Projects',
        {
          'knownIssues': createProject[i].attributes!.knownIssues,
          'dependencies': createProject[i].attributes!.dependencies,
          'technologies': technologies[0]['data'],
          'platforms': platforms[0]['data'],
          'methodology': methodology[0]['data'],
          'riskFactors': createProject[i].attributes!.riskFactor,
        },
        where: 'name = ?',
        whereArgs: [createProject[i].attributes!.name],
      );
    }
  }

  /// Update Create project Technical details.
  Future updateCreateTechnicalDetail(
      List<CreateProjectData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.technologies!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.platforms!.toJson());
      var methodology = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.methodology!.toJson());

      _database.update(
        'createProjects',
        {
          'knownIssues': createProject[i].attributes!.knownIssues,
          'dependencies': createProject[i].attributes!.dependencies,
          'technologies': technologies[0]['data'],
          'platforms': platforms[0]['data'],
          'methodology': methodology[0]['data'],
          'riskFactors': createProject[i].attributes!.riskFactor,
        },
        where: 'name = ?',
        whereArgs: [createProject[i].attributes!.name],
      );
    }
  }

  /// Update Create project Technical details.
  Future updateProposalTechnicalDetail(
      List<ProposalsData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.technologies!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.platforms!.toJson());

      _database.update(
        'proposals',
        {
          'dependencies': createProposal[i].attributes!.dependencies,
          'technologies': technologies[0]['data'],
          'platforms': platforms[0]['data'],
          'riskFactors': createProposal[i].attributes!.riskFactors,
        },
        where: 'name = ?',
        whereArgs: [createProposal[i].attributes!.name],
      );
    }
  }

  /// Update Create project Technical details.
  Future updateCreateProposalTechnicalDetail(
      List<CreateProposalData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var technologies = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.technologies!.toJson());
      var platforms = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.platforms!.toJson());

      _database.update(
        'createProposal',
        {
          'dependencies': createProposal[i].attributes!.dependencies,
          'technologies': technologies[0]['data'],
          'platforms': platforms[0]['data'],
          'riskFactors': createProposal[i].attributes!.riskFactors,
        },
        where: 'name = ?',
        whereArgs: [createProposal[i].attributes!.name],
      );
    }
  }

  /// Update Create Project Additional details.
  Future updateAdditionalDetail(List<ProjectsData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      var resources = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.resources!.toJson());
      _database.update(
          'projects',
          {
            'clientName': createProject[i].attributes!.clientName,
            'budget': createProject[i].attributes!.budget,
            // 'location': createProject[i].attributes!.location,
            'resources': resources[0]['data'],
            'comments': createProject[i].attributes!.comments,
            'currencies': createProject[i].attributes!.currency,
            'feedback': createProject[i].attributes!.feedback,
          },
          where: 'name = ?',
          whereArgs: [createProject[i].attributes!.name],
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Update Create Project Additional details.
  Future updateCreateAdditionalDetail(
      List<CreateProjectData> createProject) async {
    await openDb();
    int index = createProject.length;

    for (int i = 0; i < index; i++) {
      var resources = convertStringJsonToMapForInsertion(
          createProject[i].attributes!.resources!.toJson());
      _database.update(
          'createProjects',
          {
            'clientName': createProject[i].attributes!.clientName,
            'budget': createProject[i].attributes!.budget,
            'location': createProject[i].attributes!.location,
            'resources': resources[0]['data'],
            'comments': createProject[i].attributes!.comments,
            'currencies': createProject[i].attributes!.currency,
            'feedback': createProject[i].attributes!.feedback,
          },
          where: 'name = ?',
          whereArgs: [createProject[i].attributes!.name],
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Update Create Proposal Additional details.
  Future updateProposalAdditionalDetail(
      List<ProposalsData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var resources = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.resources!.toJson());
      _database.update(
          'Proposals',
          {
            'clientDetails': createProposal[i].attributes!.clientDetails,
            'budget': createProposal[i].attributes!.budget,
            'location': createProposal[i].attributes!.location,
            'resources': resources[0]['data'],
            'comments': createProposal[i].attributes!.comments,
            'currency': createProposal[i].attributes!.currency,
            'feedback': createProposal[i].attributes!.feedback,
          },
          where: 'name = ?',
          whereArgs: [createProposal[i].attributes!.name],
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Update Create Proposal Additional details.
  Future updateCreateProposalAdditionalDetail(
      List<CreateProposalData> createProposal) async {
    await openDb();
    int index = createProposal.length;

    for (int i = 0; i < index; i++) {
      var resources = convertStringJsonToMapForInsertion(
          createProposal[i].attributes!.resources!.toJson());
      _database.update(
          'createProposal',
          {
            'clientName': createProposal[i].attributes!.clientDetails,
            'budget': createProposal[i].attributes!.budget,
            'location': createProposal[i].attributes!.location,
            'resources': resources[0]['data'],
            'comments': createProposal[i].attributes!.comments,
            'currencies': createProposal[i].attributes!.currency,
            'feedback': createProposal[i].attributes!.feedback,
          },
          where: 'name = ?',
          whereArgs: [createProposal[i].attributes!.name],
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  Future<void> deleteSingleProjectModel(CreateProjectData createProject) async {
    await openDb();
    _database.delete('createProjects',
        where: "name = ?", whereArgs: [createProject.attributes!.name]);
  }

  Future<void> deleteProjectModel(List<CreateProjectData> createProject) async {
    await openDb();
    int index = createProject.length;
    for (int i = 0; i < index; i++) {
      _database.delete('createProjects',
          where: "name = ?", whereArgs: [createProject[i].attributes!.name]);
    }
  }

  Future<void> deleteSingleProposalModel(
      CreateProposalData createProposal) async {
    await openDb();
    _database.delete('createProposal',
        where: "name = ?", whereArgs: [createProposal.attributes!.name]);
  }

  Future<void> deleteProposalModel(
      List<CreateProposalData> createProposal) async {
    await openDb();
    int index = createProposal.length;
    for (int i = 0; i < index; i++) {
      _database.delete('createProposal',
          where: "name = ?", whereArgs: [createProposal[i].attributes!.name]);
    }
  }

  Future<void> deleteAll(String tableName) async {
    await openDb();
    await _database.delete(tableName);
  }

  Future<List<Map<String, dynamic>>> getUsers() async {
    await openDb();
    final List<Map<String, dynamic>> allUsers = await _database.query('login');

    return List.generate(allUsers.length, (i) {
      return {
        'username': allUsers[i]['username'],
        'password': allUsers[i]['password'],
        'userRole': allUsers[i]['userRole'],
        'name': allUsers[i]['name'],
      };
    });
  }
}
