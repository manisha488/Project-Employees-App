part of 'resource_detail_screen_bloc.dart';

@immutable
abstract class ResourceDetailState {}

class ResourceDetailInitialState extends ResourceDetailState {}

class ResourceDetailActionState extends ResourceDetailState {}

/// State for Resource detail Save button.
class ResourceDetailSaveBtnState extends ResourceDetailActionState {}

/// State for Resource detail Add button.
class ResourceDetailAddBtnState extends ResourceDetailActionState {}

/// State for Designation dropdown list.
class DesignationLoadedState extends ResourceDetailActionState {
  final List<MultiSelectionFiltersData> designationFilter;

  DesignationLoadedState(this.designationFilter);
}

/// State for Internet disconnection.
class InternetDisconnectedState extends ResourceDetailActionState{
  final NetworkExceptions exceptions;

  InternetDisconnectedState(this.exceptions);
}
