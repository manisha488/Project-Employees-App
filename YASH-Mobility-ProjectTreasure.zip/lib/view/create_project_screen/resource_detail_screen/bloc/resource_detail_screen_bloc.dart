import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/MultiSelectionFilters.dart';
import '../../../../repository/api_repository.dart';
import '../../../../resources/error_strings.dart';
import '../../../../services/api_result.dart';
import '../../../../services/network_exceptions.dart';
import '../../../../utils/common_utils/utils.dart';

part 'resource_detail_screen_event.dart';
part 'resource_detail_screen_state.dart';

class ResourceDetailScreenBloc
    extends Bloc<ResourceDetailEvent, ResourceDetailState> {
  final db = CustomDataBaseWrapper();
  ResourceDetailScreenBloc() : super(ResourceDetailInitialState()) {
    on<ResourceDetailEvent>((event, emit) {});
    on<ResourceDetailSaveBtnEvent>(resourceDetailSaveBtnEvent);
    on<ResourceDetailAddBtnEvent>(resourceDetailAddBtnEvent);
    on<DesignationLoadedEvent>(designationLoadedEvent);
  }

  /// State for Resource detail Save button.
  FutureOr<void> resourceDetailSaveBtnEvent(
      ResourceDetailSaveBtnEvent event, Emitter<ResourceDetailState> emit) {
    emit(ResourceDetailSaveBtnState());
  }

  /// State for Resource detail Add button.
  FutureOr<void> resourceDetailAddBtnEvent(
      ResourceDetailAddBtnEvent event, Emitter<ResourceDetailState> emit) {
    emit(ResourceDetailAddBtnState());
  }

  /// State for Designation dropdown list.
  FutureOr<void> designationLoadedEvent(
      DesignationLoadedEvent event, Emitter<ResourceDetailState> emit) async {
    List<MultiSelectionFiltersData>? offlineDesignations;
    await db.getData('designations').then((value) {
      offlineDesignations = value;
    });
    emit(DesignationLoadedState(offlineDesignations!));
  }
}
