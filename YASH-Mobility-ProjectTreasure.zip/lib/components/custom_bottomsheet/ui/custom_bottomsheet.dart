import 'package:device_info_plus/device_info_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_alert_dialog/custom_alert_dialog.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/view/draft_screen/ui/draft_screen.dart';

import '../../../resources/colors.dart';
import '../../../utils/common_utils/display_message_utils.dart';
import '../../../utils/constants.dart';
import '../../../utils/shared_preference_utils.dart';

List<Map<String, dynamic>> files = [];
List<Map<String, dynamic>> fileDetails = [];
double sizeCount = Dimensions.total_0_0;

class ShowBottomSheet {
  late BuildContext context;
  static final ShowBottomSheet getInstance = ShowBottomSheet.instance();


  int selectedButton = Dimensions.selection_0;

  bool isProject = false;
  bool isButtonEnabled = false;
  Database? database;
  ShowBottomSheet.instance();

  factory ShowBottomSheet(BuildContext context) {
    getInstance.context = context;
    return getInstance;
  }
  double sizeCount = Dimensions.total_0_0;

  /// declare the app setting function
  void settingApp() {
    openAppSettings();
  }

  /// Declare the toast message function
  void toastMessageButton(BuildContext context) {
    DisplayMessageUtils.flushBarToastMessage(
        context,
        Strings().toastMessageStorage,
        Strings().toastMessageStorageSetting,
        AppColors.flushBarBackgroundColor,
        settingApp);
  }

  /// Declare function file pick
  pickFile(BuildContext context) async {
    var result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;
    var file = result.files;
    for (int i = Dimensions.countIndex; i < file.length; i++) {
      Map<String, dynamic> fileDetails = {
        Strings().nameText: file[i].name,
        Strings().sizeText: '${(file[i].size / 1000).ceil()} KB',
        Strings().pathText: file[i].path,
        Strings().extensionText: file[i].extension,
      };
      files.add(fileDetails);
      if (!context.mounted) return;
      Navigator.of(context).pop();
      showBottomSheet(context);
    }
  }

  /// Method to get colors with respect to the files extension.
  Color _getColors(
      List<Map<String, dynamic>> filesList, int index, String fileExtension) {
    if (filesList[index][fileExtension].contains(Strings().xlsxText)) {
      return AppColors.green;
    } else if (filesList[index][fileExtension] == Strings().pptText) {
      return AppColors.orange;
    } else if (filesList[index][fileExtension] == Strings().docText) {
      return AppColors.blue;
    } else if (filesList[index][fileExtension] == Strings().pdfText) {
      return AppColors.red;
    }
    return AppColors.black;
  }

  navigateToBasicPage(BuildContext context) {
    Navigator.of(context).pop();
    files.clear();
  }

  /// Method for cancel button
  cancelButtonCallback(BuildContext context) {
    Navigator.of(context).pop();
    navigateToBasicPage(context);
  }

  /// Method for upload button
  uploadButtonCallback(BuildContext context) {
    Navigator.of(context).pop();
    Navigator.of(context).pop();
  }

  showBottomSheet(BuildContext context) {
    return showModalBottomSheet(
        backgroundColor: AppColors.white,
        context: context,
        showDragHandle: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Dimensions.borderRadius_10),
        ),
        isScrollControlled: true,
        isDismissible: false,
        builder: (context) {
          return SingleChildScrollView(
              physics: const NeverScrollableScrollPhysics(),
              child: Padding(
                  padding: MediaQuery.of(context).viewInsets,
                  child: StatefulBuilder(
                      builder: (BuildContext context, StateSetter setState) {
                    return DefaultTabController(
                      length: Dimensions.tabLength_1,
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(
                            Dimensions.padding_20,
                            Dimensions.padding_0,
                            Dimensions.padding_20,
                            Dimensions.padding_20),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Stack(
                                fit: StackFit.passthrough,
                                children: [
                                  Container(
                                    height: Dimensions.height_60,
                                    alignment: Alignment.bottomCenter,
                                    margin: EdgeInsets.zero,
                                    child: TabBar(
                                        dividerColor: Colors.transparent,
                                        unselectedLabelColor: AppColors.white,
                                        indicatorColor:
                                            AppColors.bottomSheetTabColor,
                                        tabs: [
                                          Tab(
                                            child: Text(
                                              files.isEmpty
                                                  ? Strings().documentText
                                                  : Strings()
                                                      .documentAttachText,
                                              style: TextStyle(
                                                  color: AppColors
                                                      .bottomSheetTabColor,
                                                  fontSize: Dimensions.font_14),
                                            ),
                                          )
                                        ]),
                                  ),
                                  Positioned(
                                    bottom: Dimensions.padding_20,
                                    left: Dimensions.padding_50,
                                    right: Dimensions.padding_0,
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          IconButton(
                                            icon: const Icon(Icons.close_sharp),
                                            color:
                                                AppColors.bottomSheetIconTColor,
                                            onPressed: () {
                                              files.isNotEmpty == true
                                                  ? showDialog(
                                                      barrierDismissible: false,
                                                      context: context,
                                                      builder: (BuildContext
                                                          context) {
                                                        return CustomDialogBox(
                                                            title: Strings()
                                                                .dialogTitleDoc,
                                                            description: Strings()
                                                                .dialogDiscriptionDoc,
                                                            actionPositive: Strings()
                                                                .positiveButtonSave,
                                                            actionNegative:
                                                                Strings()
                                                                    .negativeButtonCancel,
                                                            showTitle: true,
                                                            showDescription:
                                                                true,
                                                            showDialogImage:
                                                                true,
                                                            showActionPositive:
                                                                true,
                                                            showActionNegative:
                                                                true,
                                                            showSingleActionButton:
                                                                false,
                                                            buttonTextColor:
                                                                Colors.black,
                                                            onPositiveButtonClick:
                                                                () {
                                                              cancelButtonCallback(context);
                                                            },
                                                            onNegativeButtonClick:
                                                                () {},
                                                            actionOnPressed:
                                                                () {
                                                              uploadButtonCallback(
                                                                  context);
                                                            });
                                                      })
                                                  : Navigator.of(context).pop();
                                            },
                                          ),
                                        ]),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: Dimensions.height_15,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    Strings().basicDetailsUploadFrom,
                                    style: TextStyle(
                                        color: AppColors.bottomSheetTextColor),
                                  ),
                                  TextButton.icon(
                                    onPressed: () {
                                      pickFile(context);
                                    },
                                    icon: Icon(
                                        color: AppColors.bottomSheetIconTColor,
                                        Icons.add_to_drive),
                                    label: Text(
                                        Strings()
                                            .basicDetailsButtonOneDriveText,
                                        style: TextStyle(
                                            color: AppColors
                                                .bottomSheetIconTextColor,
                                            fontSize: Dimensions.font_18,
                                            fontWeight: FontWeight.normal)),
                                  ),
                                  Row(children: [
                                    TextButton.icon(
                                      onPressed: () {
                                        pickFile(context);
                                      },
                                      icon: Icon(
                                          color:
                                              AppColors.bottomSheetIconTColor,
                                          Icons.phone_android_rounded),
                                      label: Text(
                                          Strings()
                                              .basicDetailsButtonThisDeviceText,
                                          style: TextStyle(
                                              color: AppColors
                                                  .bottomSheetIconTextColor,
                                              fontSize: Dimensions.font_18,
                                              fontWeight: FontWeight.normal)),
                                    ),
                                  ]),
                                ],
                              ),
                              if (files.isNotEmpty)
                                Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Divider(
                                        color:
                                            AppColors.bottomSheetDividerColor,
                                        thickness: Dimensions
                                            .horizontalDividerThickness,
                                        indent: Dimensions.indentDivider,
                                        endIndent: Dimensions.endIndentDivider,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            '${files.length} ${Strings().documentAttachText}',
                                            style: TextStyle(
                                                color: AppColors
                                                    .bottomSheetTextColor),
                                          )
                                        ],
                                      ),
                                      ConstrainedBox(
                                        constraints: BoxConstraints(
                                            minHeight: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                Dimensions.minLength_02,
                                            maxHeight: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                Dimensions.maxLength_03),
                                        child: ListView.builder(
                                          shrinkWrap: true,
                                          itemCount: files.length,
                                          itemBuilder: (context, index) {
                                            return ListTile(
                                                leading: Icon(
                                                    Icons.description_outlined,
                                                    color: _getColors(
                                                        files,
                                                        index,
                                                        Strings()
                                                            .extensionText)),
                                                title: Text(
                                                  '${files[index][Strings().nameText]}',
                                                  style: TextStyle(
                                                    color: AppColors
                                                        .bottomSheetListTitleColor,
                                                    decoration: TextDecoration
                                                        .underline,
                                                    decorationColor: AppColors
                                                        .bottomSheetListTitleColor,
                                                  ),
                                                ),
                                                subtitle: Text(
                                                    '${files[index][Strings().sizeText]}',
                                                    style: TextStyle(
                                                      color: AppColors
                                                          .bottomSheetIconTextColor,
                                                    )),
                                                trailing: IconButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      files.removeAt(index);
                                                    });
                                                  },
                                                  icon: Icon(
                                                      color: AppColors
                                                          .bottomSheetIconTColor,
                                                      Icons.close),
                                                ));
                                          },
                                        ),
                                      ),
                                    ]),
                              _uploadButton(context),
                            ]),
                      ),
                    );
                  })));
        });
  }

  /// create the widget for the loginButton
  Widget _uploadButton(BuildContext context) {
    return ElevatedButton(
        onPressed: files.isNotEmpty
            ? () {
                // SharedPrefs.instance.setBool("docAttached", true);
                Navigator.of(context).pop(context);
              }
            : null,
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.resolveWith<Color?>(
            (Set<MaterialState> states) {
              if (states.contains(MaterialState.disabled)) {
                SharedPrefs.instance.setBool("docAttached", false);
                return AppColors.grey; // Disabled color
              }else{
                SharedPrefs.instance.setBool("docAttached", true);
                return AppColors.enableLoginButtonColor;
              }// Enabled color
            },
          ),
        ),
        child: Text(
          Strings().negativeButtonCancel,
          style: TextStyle(fontSize: Dimensions.font_16, color: Colors.white),
        ));
  }

  /// Method for the permission handler
  permissionHandlerMethod(BuildContext context) async {
    Map<Permission, PermissionStatus> multipleStatus =
        await [Permission.storage, Permission.notification].request();
    if (multipleStatus[Permission.storage]!.isGranted) {
      if (!context.mounted) return;

      ShowBottomSheet.getInstance.showBottomSheet(context);
    }
    if (multipleStatus[Permission.storage]!.isDenied) {
      DeviceInfoPlugin plugin = DeviceInfoPlugin();
      AndroidDeviceInfo multipleStatus = await plugin.androidInfo;

      if (multipleStatus.version.sdkInt >= Dimensions.sdkLength_33) {
        if (!context.mounted) return;

        ShowBottomSheet.getInstance.showBottomSheet(context);
      } else if (multipleStatus.version.sdkInt <= Dimensions.sdkLength_33) {
        if (!context.mounted) return;

        /// toast message
        ShowBottomSheet.getInstance.toastMessageButton(context);
      }
    }
    if (multipleStatus[Permission.storage]!.isPermanentlyDenied) {
      if (!context.mounted) return;

      /// toast messag
      ShowBottomSheet.getInstance.toastMessageButton(context);
    }
  }

  /// The uploaded documents on Project Details Screen will be visible using following UI.
  showUploadedDocuments(BuildContext context, List<String> documents,
      TabController tabController) {
    return showModalBottomSheet(
        showDragHandle: true,
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return Padding(
            padding: EdgeInsets.fromLTRB(
                Dimensions.padding_20,
                Dimensions.padding_0,
                Dimensions.padding_20,
                Dimensions.padding_20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: Dimensions.height_25,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          icon: const Icon(Icons.close))
                    ],
                  ),
                ),
                TabBar(
                  controller: tabController,
                  labelPadding: EdgeInsets.only(right: Dimensions.padding_5),
                  padding: EdgeInsets.zero,
                  indicatorColor: AppColors.appBottomNavigationBar,
                  indicatorPadding: EdgeInsets.zero,
                  labelColor: AppColors.appBottomNavigationBar,
                  indicatorSize: TabBarIndicatorSize.label,
                  dividerColor: Colors.transparent,
                  tabs: [
                    Tab(
                      child: Text(
                        Strings().yourAttachmentsText,
                        style: TextStyle(
                            color: AppColors.bottomSheetTabColor,
                            fontSize: Dimensions.font_14),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(top: Dimensions.padding_8),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: MediaQuery.of(context).size.height *
                          Dimensions.multiplier_0_2,
                      maxHeight: MediaQuery.of(context).size.height *
                          Dimensions.multiplier_0_4,
                    ),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: documents.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(documents[index]),
                            leading: Icon(
                              Icons.description_outlined,
                              color: AppColors.blue,
                            ),
                          );
                        }),
                  ),
                )
              ],
            ),
          );
        });
  }

  /// This Bottom sheet is for more options
  showMoreOptions(BuildContext context, void Function() onTapped) {
    showModalBottomSheet(
      showDragHandle: true,
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.fromLTRB(
              Dimensions.padding_20,
              Dimensions.padding_0,
              Dimensions.padding_20,
              Dimensions.padding_20),
          child: StatefulBuilder(
            builder: (BuildContext context,
                void Function(void Function()) setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.only(top: Dimensions.padding_8),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: MediaQuery.of(context).size.height *
                            Dimensions.multiplier_0_2,
                        maxHeight: MediaQuery.of(context).size.height *
                            Dimensions.multiplier_0_4,
                      ),
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: EdgeInsets.only(top: Dimensions.padding_20),
                          child: Column(
                            children: [
                              Visibility(
                                visible: SharedPrefs.instance.getString(Constants.userRole) !=
                                    Strings().user,
                                child: Row(
                                  children: [
                                    Image.asset(Strings().draftSelectedIcon),
                                    SizedBox(
                                      width: Dimensions.width_15,
                                    ),
                                    Text(
                                      Strings().draftText,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.loginTextFieldTitleColor,
                                        fontSize: Dimensions.font_16,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Visibility(
                                visible: SharedPrefs.instance.getString(Constants.userRole) !=
                                    Strings().user,
                                child: Transform.scale(
                                  scale: Dimensions.scale_09,
                                  child: RadioListTile(
                                    visualDensity: const VisualDensity(
                                      horizontal: VisualDensity.minimumDensity,
                                      vertical: VisualDensity.minimumDensity,
                                    ),
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    title: Text(
                                        Strings().bottomNavigationTitleProjects),
                                    value: Dimensions.value_1,
                                    groupValue: selectedButton,
                                    onChanged: (value) {
                                      setState(() {
                                        isProject = true;
                                        selectedButton = value!;
                                        Navigator.pop(context);
                                        Navigator.of(context).push(
                                          MaterialPageRoute(
                                            settings: const RouteSettings(
                                                name: "/draftScreen"),
                                            builder: (context) =>
                                                DraftScreen(isProject,database: database!),
                                          ),
                                        );
                                        SharedPrefs.instance.remove(
                                            Constants.resourceDetailDraft);
                                      });
                                    },
                                  ),
                                ),
                              ),
                              Visibility(
                                visible: SharedPrefs.instance.getString(Constants.userRole) !=
                                    Strings().user,
                                child: Transform.scale(
                                  scale: Dimensions.scale_09,
                                  child: RadioListTile(
                                    visualDensity: const VisualDensity(
                                      horizontal: VisualDensity.minimumDensity,
                                      vertical: VisualDensity.minimumDensity,
                                    ),
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    title: Text(
                                        Strings().bottomNavigationTitleProposals),
                                    value: Dimensions.value_2,
                                    groupValue: selectedButton,
                                    onChanged: (value) {
                                      setState(() {
                                        isProject = false;
                                        selectedButton = value!;
                                        Navigator.pop(context);
                                        Navigator.of(context).push(
                                          MaterialPageRoute(
                                            settings: const RouteSettings(
                                                name: "/draftScreen"),
                                            builder: (context) =>
                                                DraftScreen(isProject,database: database!),
                                          ),
                                        );
                                        SharedPrefs.instance.remove(
                                            Constants.resourceDetailDraft);
                                      });
                                    },
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: Dimensions.height_5,
                              ),
                              Row(
                                children: [
                                  Image.asset(
                                      Strings().notificationSelectedIcon),
                                  SizedBox(
                                    width: Dimensions.width_10,
                                  ),
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                      child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          Strings().notificationText,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: AppColors
                                                .loginTextFieldTitleColor,
                                            fontSize: Dimensions.font_16,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: Dimensions.height_5,
                              ),
                              Row(
                                children: [
                                  Image.asset(Strings().versionSelectedIcon),
                                  SizedBox(
                                    width: Dimensions.width_10,
                                  ),
                                  Expanded(
                                    child: TextButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                      child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          Strings().versionInfoText,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: AppColors
                                                .loginTextFieldTitleColor,
                                            fontSize: Dimensions.font_16,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: Dimensions.height_5,
                              ),
                              Row(
                                children: [
                                  Image.asset(Strings().logOutSelectedIcon),
                                  SizedBox(
                                    width: Dimensions.width_10,
                                  ),
                                  Expanded(
                                    child: TextButton(
                                      onPressed: onTapped,
                                      child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          Strings().logOutText,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: AppColors
                                                .homeSearchBarBorderColor1,
                                            fontSize: Dimensions.font_16,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              );
            },
          ),
        );
      },
    ).then((value) {
      selectedButton = 0;
    });
  }

  void setState(Null Function() param0) {}
}
