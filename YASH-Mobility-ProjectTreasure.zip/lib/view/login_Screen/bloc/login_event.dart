part of 'login_bloc.dart';

@immutable
abstract class LoginEvent {}

/// This event will be triggered on login Screen.
class LoginInitialEvent extends LoginEvent {}

class CreateDBEvent extends LoginEvent {}

/// This event will be triggered on login Screen when user login in login page.
class LoginScreenEvent extends LoginEvent {
  final Function login;
  LoginScreenEvent({required this.login});
}

/// This event will be triggered on login Screen when writes input of the user.
class GetUserLoggedIn extends LoginEvent {
  final String userName;
  final String password;
  GetUserLoggedIn({required this.userName, required this.password});
}
