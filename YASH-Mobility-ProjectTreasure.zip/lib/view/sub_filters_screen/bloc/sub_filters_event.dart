part of 'sub_filters_bloc.dart';

@immutable
abstract class SubFiltersEvent {}

class SubFiltersInitialEvent extends SubFiltersEvent{}

class ProjectNamesFiltersClickedEvent extends SubFiltersEvent{}

class ProposalNamesFiltersClickedEvent extends SubFiltersEvent{}


class OfflineTechnologiesLoadedEvent extends SubFiltersEvent{}
class OfflinePlatformsLoadedEvent extends SubFiltersEvent{}
class OfflineFunctionalitiesLoadedEvent extends SubFiltersEvent{}
class OfflineDomainsLoadedEvent extends SubFiltersEvent{}
class OfflineStatusLoadedEvent extends SubFiltersEvent{}


class DatesFilterClickedEvent extends SubFiltersEvent{}

class DocumentFilterClickedEvent extends SubFiltersEvent{}

class ResourceNameFilterClickedEvent extends SubFiltersEvent{}

class FiltersLoadingEvent extends SubFiltersEvent{}

