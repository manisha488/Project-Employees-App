
class RegEx{

  //UserName RegEx
  final RegExp userNameRegEx = RegExp(r'^[a-zA-Z\s]*$');
  //Email RegEx
  final RegExp emailRegEx = RegExp(r'[a-zA-Z0-9._-]+@[a-z]+\.+[a-z]+');
  //Phone Number RegEx
  final RegExp phoneNumberRegEx = RegExp(r'^[0-9]+$');
  //Password RegEx
  final RegExp passwordRegEx = RegExp(r'^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{4,}$');
  //Person Address RegEx
  final RegExp personAddressRegEx = RegExp(r'^[#.0-9a-zA-Z\s,-]+$');
  //Project/Proposal Name Regex
  final RegExp projectNameRegEx = RegExp(r'[a-zA-Zá-úÁ-Ú0-9 @-_]');
  //Project/Proposal Name Regex
  final RegExp projectObjectiveRegEx = RegExp(r"[a-zA-Zá-úÁ-Ú0-9 @-_&,.;'%@!/-_ " "\$\n]");
  //Project/Proposal Number Regex
  final RegExp projectNumberRegEx = RegExp(r"[0-9]");

}