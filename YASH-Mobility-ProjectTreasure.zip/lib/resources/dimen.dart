class Dimensions {
  static double width_1 = 1;
  static double width_2 = 2;
  static double width_90 = 90;
  static double width_50 = 50;

  /// padding
  static double paddingMinus_4 = -4;
  static double padding_4 = 4;
  static double padding_5 = 5;
  static double padding_8 = 8;
  static double padding_10 = 10;
  static double padding_15 = 15;
  static double padding_18 = 18;
  static double padding_20 = 20;

  ///fonts
  static double font_4 = 4;
  static double font_12 = 12;
  static double font_14 = 14;
  static double font_16 = 16;

  static double height_10 = 10;
  static double height_30 = 30;
  static double borderRadius_5 = 5;
  static double borderRadius_20 = 20;
  static double borderRadius_30 = 30;
  static double width_300 = 300;
  static double height_8 = 8;
  static double height_50 = 50;
  static double borderRadius_60 = 60;
  static int selection_1 = 1;
  static int maxLines_3 = 3;
  static double elevation_0 = 0;
  static double elevation_1 = 1;
  static double scale_05 = 0.5;
  static double scale_09 = 0.9;

  static int maxLine_1 = 1;

  ///Splash Screen

  ///Year
  static int year_1950 = 1950;
  static int add_100 = 100;
  static int lastDate_2100 = 2100;
  static int lastDate_2200 = 2200;

  ///Seconds
  static int seconds_3 = 3;
  static int seconds_5 = 5;
  static int seconds_4 = 4;
  static int seconds_500 = 500;
  static int milliseconds_500 = 500;

  ///Login Screen
  static double padding_16 = 16;
  static double padding_25 = 25;
  static double height0_2 = 0.2;
  static double height_20 = 20;
  static double height_40 = 40;
  static double height_2 = 2;
  static double height_4 = 4;
  static double height_48 = 48;
  static double height_60 = 60;
  static double height_70 = 70;
  static double height_80 = 80;
  static double height_500 = 500;
  static double bottomSheetHeight_300 = 300.0;
  static double dynamicHeight = 250.0;
  static double height_5 = 5;
  static double mediaQuaryWidth_1 = 0.3;
  static double mediaQuaryWidth_2 = 0.2;
  static double height_120 = 120;
  static double height_180 = 180;
  static double width_5 = 5;
  static double width_20 = 20;
  static double width_10 = 10;
  static double width_15 = 15;
  static double width_30 = 30;
  static double width_12 = 12;
  static double width_13 = 13;
  static double width_14 = 14;
  static double width_56 = 56;
  static double width_70 = 70;
  static double width_71 = 71;
  static double width_80 = 80;
  static double width_110 = 110;
  static double width_120 = 120;
  static double width_160 = 160;
  static double width_180 = 180;
  static double width_85 = 85;

  ///thickness
  static double verticalDividerThickness_1 = 1;
  static double width_72 = 72;
  static double verticalDividerThickness = 1.5;
  static double padding_0 = 0;
  static double horizontalDividerThickness = 1;
  static double indentDivider = 10;
  static double endIndentDivider = 10;
  static double kScrollbarThickness_12 = 12;

  ///Animation
  static double alwaysStoppedAnimation_1 = 1;

  ///selection
  static int selection_0 = 0;
  static double selection_40 = 40;
  static double selection_100 = 100;

  ///DateTime
  static int year_2100 = 2100;
  static int year_2200 = 2200;

  ///offset
  static double offset_0 = 0;
  static int mediaQueryHeight = 3;
  static int mediaQueryHeight_4 = 4;
  static double opacity_05 = 0.5;

  ///elevation

  static double positionOffset_20 = 20;

  ///count
  static int tabsCount_1 = 1;
  static double padding_30 = 30;

  /// padding
  static double padding_7 = 7;
  static double padding_6 = 6;
  static double padding_9 = 9;
  static double padding_11 = 11;
  static double padding_12 = 12;
  static double padding_50 = 50;
  static double padding_350 = 350;
  static double padding_21 = 21;
  static double padding_24 = 24;
  static double padding_45 = 45;
  static double padding_60 = 60;

  ///fonts
  static double font_5 = 5;
  static double font_6 = 6;
  static double font_10 = 10;
  static double font_11 = 11;
  static double font_13 = 13;
  static double font_22 = 22;
  static double font_20 = 20;
  static double font_18 = 18;
  static double font_19 = 19;
  static double font_24 = 24;

  ///icon size
  static double total_0_0 = 0.0;
  static double iconSize_15 = 15;
  static double iconSize_18 = 18;
  static double iconSize_20 = 20;
  static double iconSize_24 = 24;
  static double iconSize_30 = 30;
  static double iconSize_31 = 31;

  ///length
  static int minLength_6 = 6;
  static int minLength_4 = 4;
  static int minLength_5 = 5;
  static int maxLength_10 = 10;
  static int tabLength_1 = 1;
  static int tabBarIndexLength_3 = 3;
  static int maxTextLines_1 = 1;
  static int sdkLength_33 = 33;
  static int characterLimit_170 = 170;
  static double horizontalMargin_10 = 10;
  static double verticalLength_4 = -4;
  static double horizontalMargin_20 = 20;
  static double verticalMargin_10 = 10;
  static double borderRadius_40 = 40;
  static double borderRadius_50 = 50;
  static double minLength_02 = 0.02;
  static double maxLength_03 = 0.3;

  ///length
  static int countIndex = 0;
  static int? minLength_1 = 1;
  static double borderRadius_4 = 4;
  static double borderRadius_13 = 13;
  static double borderRadius_18 = 18;

  /// filter screen
  static int flex_6 = 6;
  static int flex_5 = 5;
  static int count_0 = 0;
  static double stokeAlign_3 = -3;
  static double heightFactor_8 = 8;
  static double heightFactor_16 = 16;
  static double applyButtonWidth_148 = 148;
  static double paddingNegative_5 = -5;
  static double width_4 = 4;
  static double mediaQueryHeight_002 = 0.02;

  ///height
  static double height0_4 = 0.4;
  static double height_1 = 1;
  static double height_15 = 15;
  static double height_16 = 16;
  static double height_19 = 19;
  static double height_22 = 22;
  static double height_23 = 23;
  static double height_24 = 24;
  static double height_25 = 25;
  static double height_29 = 29;
  static double height_32 = 32;
  static double height_35 = 35;
  static double height_55 = 55;
  static double height_56 = 56;
  static double height_100 = 100;
  static double height_150 = 150;
  static double height_195 = 195;
  static double height_200 = 200;

  ///width
  static double width_24 = 24;
  static double width_25 = 25;
  static double width_32 = 32;
  static double width_77 = 77;
  static double width_100 = 100;
  static double width_148 = 148;
  static double width_220 = 220;
  static double width_250 = 250;

  ///border radius
  static double borderRadius_0 = 0;
  static double borderRadius_8 = 8;
  static double borderRadius_10 = 10;
  static double kScrollbarThickness = 12.0;

  ///axis alignment
  static double axisAlignment_1 = 1;
  static double multiplier_0_2 = 0.2;
  static double multiplier_0_4 = 0.4;

  ///values
  static int value_1 = 1;
  static int value_2 = 2;
}
