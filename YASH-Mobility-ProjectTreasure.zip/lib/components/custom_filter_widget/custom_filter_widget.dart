import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/resoucesList.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/model/response/proposals_list.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import 'package:yash_mobility_project_treasure/view/filter_screen/bloc/filter_screen_bloc.dart';

class SubFilterList extends StatefulWidget {
  SubFilterList(
      {super.key,
      this.selectedIndex,
      this.items,
      this.isDateFilter,
      this.length,
      this.isResourceFilter,
      this.isProjectsFilter,
      this.filterKey,
      this.dummyItems,
      this.projects,
      this.isStatusFilter,
      this.isPlatformFilter,
      this.isTechFilter,
      this.isFunctionalityFilter,
      this.isDocFilter,
      this.isDomainsFilter,
      this.isProposalNamesFilter,
      this.proposals,
      this.allFiltersKey,
      this.resources,
      required this.bloc,
      this.proposalDates});
  final int? selectedIndex;
  late List<MultiSelectionFiltersData?>? items;
  late List<DummyMultiselectFilters>? dummyItems;
  final List<ProjectsData>? projects;
  final List<ProposalsData>? proposals;
  final List<ResourcesListData>? resources;
  final bool? isDateFilter;
  final bool? proposalDates;
  final bool? isProjectsFilter;
  final bool? isProposalNamesFilter;
  final bool? isResourceFilter;
  final bool? isStatusFilter;
  final bool? isPlatformFilter;
  final bool? isTechFilter;
  final bool? isFunctionalityFilter;
  final bool? isDocFilter;
  final bool? isDomainsFilter;
  final String? filterKey;
  final String? allFiltersKey;
  final int? length;
  final FilterScreenBloc bloc;

  @override
  State<SubFilterList> createState() => _SubFilterListState();
}

class _SubFilterListState extends State<SubFilterList> {
  List<DummyMultiselectFilters> dummySearchedList = [];
  List<ProjectsData> selectedProjectsNamesList = [];
  List<ProposalsData> selectedProposalsNamesList = [];
  List<String>? selectedProjects = [];
  List<String>? selectedFilters = [];
  List<String> selectedResources = [];
  List<ResourcesListData> resourcesList = [];
  List<ResourcesListData> searchedResourcesList = [];
  List<ProjectsData> projectsNamesList = [];
  List<ProposalsData> proposalsNamesList = [];
  TextEditingController resourcesController = TextEditingController();
  TextEditingController projectsController = TextEditingController();
  TextEditingController startDateController = TextEditingController(
      text: SharedPrefs.instance
              .getString(Strings().selectedStartDateFilterKey) ??
          "");
  TextEditingController endDateController = TextEditingController(
      text:
          SharedPrefs.instance.getString(Strings().selectedEndDateFilterKey) ??
              "");
  TextEditingController proposalStartDateController = TextEditingController(
      text: SharedPrefs.instance
              .getString(Strings().proposalSelectedStartDateFilterKey) ??
          "");
  TextEditingController proposalEndDateController = TextEditingController(
      text: SharedPrefs.instance
              .getString(Strings().proposalSelectedEndDateFilterKey) ??
          "");
  bool? isChecked;

  @override
  void initState() {
    super.initState();
    startDateController.addListener(_addEventStartDate);
    endDateController.addListener(_addEventEndDate);
    proposalStartDateController.addListener(_addEventStartDate);
    proposalEndDateController.addListener(_addEventEndDate);
  }

  /// Listener function for Start date Text field.
  void _addEventStartDate() {
   if (startDateController.text.isNotEmpty && startDateController.text != "" && widget.allFiltersKey == Strings().filtersToApplyKey)
        { widget.bloc.add(ApplyButtonEnableEvent());}
   else if (proposalStartDateController.text.isNotEmpty && proposalStartDateController.text != "" && widget.allFiltersKey == Strings().proposalFiltersToApplyKey)
   {
     widget.bloc.add(ApplyButtonEnableForProposalsEvent());
   }

  }

  /// Listener function for End date Text field.
  void _addEventEndDate() {
    if (endDateController.text.isNotEmpty && endDateController.text != "" && widget.allFiltersKey == Strings().filtersToApplyKey)
    { widget.bloc.add(ApplyButtonEnableEvent());}
    else if (proposalEndDateController.text.isNotEmpty && proposalEndDateController.text != "" && widget.allFiltersKey == Strings().proposalFiltersToApplyKey)
    {
      widget.bloc.add(ApplyButtonEnableForProposalsEvent());
    }
  }

  @override
  void dispose() {
    resourcesController.dispose();
    projectsController.dispose();
    super.dispose();
  }

  /// Function to perform selection and deselection of the Filter Checkboxes.
  void _onSelected(
      {required bool selected,
      required String dataName,
      required List<String> list,
      required String key}) async {
    if (selected == true) {
      setState(() {
        list = SharedPrefs.instance.getStringList(key) ?? [];
        list.add(dataName);
      });
    } else {
      setState(() {
        list.remove(dataName);
      });
    }
    setState(() {
      SharedPrefs.instance.setStringList(key, list);
    });
  }

  /// Function to display Date Picker.
  void _presentDatePicker({
    required TextEditingController controller,
    required DateTime firstDate,
    required DateTime lastDate,
    required DateTime initialDate,
    required String key,
    required String datesListKey,
  }) async {
    final formatter =DateFormat('yyyy-MM-dd');

    if (!context.mounted) {
      return;
    }
    final pickedDate = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: firstDate,
        lastDate: lastDate);

    setState(() {
      controller.text = formatter.format(pickedDate!);
      List<String> stringListValue =
          SharedPrefs.instance.getStringList(datesListKey) ?? [];
      stringListValue.add(controller.text);
      SharedPrefs.instance.setString(key, controller.text);
      SharedPrefs.instance.setStringList(datesListKey, stringListValue);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isDateFilter!) {
      if (widget.proposalDates!) {
        return dateFilters(
          startDateController: proposalStartDateController,
          endDateController: proposalEndDateController,
          startDateKey: Strings().proposalSelectedStartDateFilterKey,
          endDateKey: Strings().proposalSelectedEndDateFilterKey,
          datesListKey: Strings().proposalSelectedDatesFilterKey,
        );
      } else {
        return dateFilters(
            startDateController: startDateController,
            endDateController: endDateController,
            startDateKey: Strings().selectedStartDateFilterKey,
            endDateKey: Strings().selectedEndDateFilterKey,
            datesListKey: Strings().selectedDatesFilterKey);
      }
    } else if (widget.isProjectsFilter!) {
      projectsNamesList = widget.projects!;
      selectedProjects =
          SharedPrefs.instance.getStringList(widget.filterKey!) ?? [];
      return BlocProvider.value(
        value: widget.bloc,
        child: SingleChildScrollView(
          child: Column(
            children: [
              searchBar(
                  controller: projectsController,
                  hint: Strings().searchProjectsText.toTitleCase(),
                  onChanged: (text) {
                    text = text.toLowerCase();
                    setState(() {
                      selectedProjectsNamesList =
                          projectsNamesList.where((note) {
                        var noteTitle =
                            note.attributes!.name?.toLowerCase() ?? "";
                        return noteTitle.contains(text);
                      }).toList();
                    });
                  }),
              ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: projectsController.text.isEmpty
                      ? projectsNamesList.length
                      : selectedProjectsNamesList.length,
                  itemBuilder: (context, index) {
                    return CheckboxListTile(
                      value: selectedProjects!.contains(projectsController
                              .text.isEmpty
                          ? projectsNamesList[index].attributes!.name ?? ""
                          : selectedProjectsNamesList[index].attributes!.name!),
                      onChanged: (bool? value) {
                        _onSelected(
                            selected: value!,
                            dataName: projectsController.text.isEmpty
                                ? projectsNamesList[index].attributes!.name!
                                : selectedProjectsNamesList[index]
                                    .attributes!
                                    .name!,
                            list: selectedProjects!,
                            key: widget.filterKey!);
                        var all = SharedPrefs.instance
                                .getStringList(widget.allFiltersKey!) ??
                            [];
                        if (value == true) {
                          all.add(
                            projectsController.text.isEmpty
                                ? projectsNamesList[index].attributes!.name!
                                : selectedProjectsNamesList[index]
                                    .attributes!
                                    .name!,
                          );
                        } else {
                          all.remove(
                            projectsController.text.isEmpty
                                ? projectsNamesList[index].attributes!.name!
                                : selectedProjectsNamesList[index]
                                    .attributes!
                                    .name!,
                          );
                        }
                        SharedPrefs.instance
                            .setStringList(widget.allFiltersKey!, all);
                        resourcesController.clear();
                        projectsController.clear();
                        widget.bloc.add(ApplyButtonEnableEvent());
                      },
                      side: MaterialStateBorderSide.resolveWith((states) =>
                          BorderSide(
                              width: 1.5, color: AppColors.applyButtonColor)),
                      activeColor: AppColors.applyButtonColor,
                      title: Text(
                        projectsController.text.isEmpty
                            ? projectsNamesList[index].attributes!.name ?? " "
                            : selectedProjectsNamesList[index]
                                    .attributes!
                                    .name ??
                                " ",
                        style: TextStyle(
                            color: AppColors.selectedFilterColor,
                            fontWeight: FontWeight.w600),
                      ),
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  }),
            ],
          ),
        ),
      );
    } else if (widget.isProposalNamesFilter!) {
      proposalsNamesList = widget.proposals!;
      selectedProjects =
          SharedPrefs.instance.getStringList(widget.filterKey!) ?? [];
      return BlocProvider.value(
        value: widget.bloc,
        child: SingleChildScrollView(
          child: Column(
            children: [
              searchBar(
                  controller: projectsController,
                  hint: Strings().searchProposalsText.toTitleCase(),
                  onChanged: (text) {
                    text = text.toLowerCase();
                    setState(() {
                      selectedProposalsNamesList =
                          proposalsNamesList.where((note) {
                        var noteTitle =
                            note.attributes!.name?.toLowerCase() ?? "";
                        return noteTitle.contains(text);
                      }).toList();
                    });
                  }),
              ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: projectsController.text.isEmpty
                      ? proposalsNamesList.length
                      : selectedProposalsNamesList.length,
                  itemBuilder: (context, index) {
                    return CheckboxListTile(
                      value: selectedProjects!.contains(projectsController
                              .text.isEmpty
                          ? proposalsNamesList[index].attributes!.name ?? " "
                          : selectedProposalsNamesList[index]
                              .attributes!
                              .name!),
                      onChanged: (bool? value) {
                        _onSelected(
                            selected: value!,
                            dataName: projectsController.text.isEmpty
                                ? proposalsNamesList[index].attributes!.name!
                                : selectedProposalsNamesList[index]
                                    .attributes!
                                    .name!,
                            list: selectedProjects!,
                            key: widget.filterKey!);
                        var all = SharedPrefs.instance
                                .getStringList(widget.allFiltersKey!) ??
                            [];
                        if (value == true) {
                          all.add(projectsController.text.isEmpty
                              ? proposalsNamesList[index].attributes!.name ??
                                  " "
                              : selectedProposalsNamesList[index]
                                  .attributes!
                                  .name!);
                        } else {
                          all.remove(projectsController.text.isEmpty
                              ? proposalsNamesList[index].attributes!.name ??
                                  " "
                              : selectedProposalsNamesList[index]
                                  .attributes!
                                  .name!);
                        }
                        SharedPrefs.instance
                            .setStringList(widget.allFiltersKey!, all);
                        resourcesController.clear();
                        projectsController.clear();
                        widget.bloc.add(ApplyButtonEnableForProposalsEvent());
                      },
                      side: MaterialStateBorderSide.resolveWith((states) =>
                          BorderSide(
                              width: 1.5, color: AppColors.applyButtonColor)),
                      activeColor: AppColors.applyButtonColor,
                      title: Text(
                        projectsController.text.isEmpty
                            ? proposalsNamesList[index].attributes!.name ?? " "
                            : selectedProposalsNamesList[index]
                                    .attributes!
                                    .name ??
                                " ",
                        style: TextStyle(
                            color: AppColors.selectedFilterColor,
                            fontWeight: FontWeight.w600),
                      ),
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  }),
            ],
          ),
        ),
      );
    } else if (widget.isResourceFilter!) {
      resourcesList = widget.resources!;
      selectedResources =
          SharedPrefs.instance.getStringList(widget.filterKey!) ?? [];
      return BlocProvider.value(
        value: widget.bloc,
        child: SingleChildScrollView(
          child: Column(
            children: [
              searchBar(
                controller: resourcesController,
                hint: Strings().searchResourcesText.toTitleCase(),
                onChanged: (text) {
                  text = text.toLowerCase();
                  setState(() {
                    searchedResourcesList = resourcesList.where((note) {
                      var noteTitle =
                          note.attributes!.resourceName!.toLowerCase();
                      return noteTitle.contains(text);
                    }).toList();
                  });
                },
              ),
              ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: resourcesController.text.isEmpty
                      ? resourcesList.length
                      : searchedResourcesList.length,
                  itemBuilder: (context, index) {
                    return CheckboxListTile(
                      value: selectedResources.contains(
                        resourcesController.text.isEmpty
                            ? resourcesList[index].attributes!.resourceName!
                            : searchedResourcesList[index]
                                .attributes!
                                .resourceName!,
                      ),
                      onChanged: (bool? value) {
                        _onSelected(
                            selected: value!,
                            dataName: resourcesController.text.isEmpty
                                ? resourcesList[index].attributes!.resourceName!
                                : searchedResourcesList[index]
                                    .attributes!
                                    .resourceName!,
                            list: selectedResources,
                            key: widget.filterKey!);
                        var all = SharedPrefs.instance
                                .getStringList(widget.allFiltersKey!) ??
                            [];

                        if (value == true) {
                          all.add(resourcesController.text.isEmpty
                              ? resourcesList[index].attributes!.resourceName!
                              : searchedResourcesList[index]
                                  .attributes!
                                  .resourceName!
                                  .toTitleCase());
                        } else {
                          all.remove(resourcesController.text.isEmpty
                              ? resourcesList[index].attributes!.resourceName!
                              : searchedResourcesList[index]
                                  .attributes!
                                  .resourceName!
                                  .toTitleCase());
                        }
                        SharedPrefs.instance
                            .setStringList(widget.allFiltersKey!, all);
                        resourcesController.clear();
                        projectsController.clear();
                        if (widget.allFiltersKey == Strings().filtersToApplyKey) {
                          widget.bloc.add(ApplyButtonEnableEvent());
                        } else if (widget.allFiltersKey ==
                            Strings().proposalFiltersToApplyKey) {
                          widget.bloc.add(ApplyButtonEnableForProposalsEvent());
                        }
                      },
                      side: MaterialStateBorderSide.resolveWith((states) =>
                          BorderSide(
                              width: 1.5, color: AppColors.applyButtonColor)),
                      activeColor: AppColors.applyButtonColor,
                      title: Text(
                        resourcesController.text.isEmpty
                            ? resourcesList[index]
                                .attributes!
                                .resourceName!
                                .toTitleCase()
                            : searchedResourcesList[index]
                                .attributes!
                                .resourceName!
                                .toTitleCase(),
                        style: TextStyle(
                            color: AppColors.selectedFilterColor,
                            fontWeight: FontWeight.w600),
                      ),
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  }),
              //multiSelectListWidget(theKey: widget.filterKey!)
            ],
          ),
        ),
      );
    } else if (widget.isTechFilter!) {
      return multiSelectListWidget(theKey: widget.filterKey!);
    } else if (widget.isStatusFilter!) {
      return multiSelectListWidget(theKey: widget.filterKey!);
    } else if (widget.isPlatformFilter!) {
      return multiSelectListWidget(theKey: widget.filterKey!);
    } else if (widget.isDocFilter!) {
      return multiSelectDummyListWidget(theKey: widget.filterKey!);
    } else if (widget.isDomainsFilter!) {
      return multiSelectListWidget(theKey: widget.filterKey!);
    } else if (widget.isFunctionalityFilter!) {
      return multiSelectListWidget(theKey: widget.filterKey!);
    } else {
      return Container();
    }
  }

  /// Widget to display Listview with checkboxes.
  Widget multiSelectListWidget({required String theKey}) {
    selectedFilters =
        SharedPrefs.instance.getStringList(theKey)?.toList() ?? [];
    return BlocProvider.value(
      value: widget.bloc,
      child: SingleChildScrollView(
        child: Column(
          children: [
            ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.items!.length,
                itemBuilder: (context, index) {
                  return CheckboxListTile(
                    value: selectedFilters!
                        .contains(widget.items![index]!.attributes!.name!),
                    onChanged: (bool? value) async {
                      _onSelected(
                          selected: value!,
                          dataName: widget.items![index]!.attributes!.name!,
                          list: selectedFilters!,
                          key: theKey);
                      var all = SharedPrefs.instance
                              .getStringList(widget.allFiltersKey!) ??
                          [];
                      if (value == true) {
                        all.add(widget.items![index]!.attributes!.name!);
                      } else {
                        all.remove(widget.items![index]!.attributes!.name!);
                      }
                      SharedPrefs.instance
                          .setStringList(widget.allFiltersKey!, all);
                      if (widget.allFiltersKey == Strings().filtersToApplyKey) {
                        widget.bloc.add(ApplyButtonEnableEvent());
                      } else if (widget.allFiltersKey ==
                          Strings().proposalFiltersToApplyKey) {
                        widget.bloc.add(ApplyButtonEnableForProposalsEvent());
                      }

                    },
                    activeColor: AppColors.applyButtonColor,
                    checkColor: AppColors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.0),
                    ),
                    side: MaterialStateBorderSide.resolveWith(
                      (states) => BorderSide(
                          width: 1.5, color: AppColors.applyButtonColor),
                    ),
                    title: Text(
                      widget.items![index]!.attributes!.name!.toTitleCase(),
                      style: TextStyle(
                          color: AppColors.selectedFilterColor,
                          fontWeight: FontWeight.w600),
                    ),
                    controlAffinity: ListTileControlAffinity.leading,
                  );
                }),
          ],
        ),
      ),
    );
  }

  Widget multiSelectDummyListWidget({required String theKey}) {
    selectedFilters =
        SharedPrefs.instance.getStringList(theKey)?.toList() ?? [];
    return BlocProvider.value(
      value: widget.bloc,
      child: SingleChildScrollView(
        child: Column(
          children: [
            ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.dummyItems!.length,
                itemBuilder: (context, index) {
                  return CheckboxListTile(
                    value: selectedFilters!
                        .contains(widget.dummyItems![index].title),
                    onChanged: (bool? value) async {
                      _onSelected(
                          selected: value!,
                          dataName: widget.dummyItems![index].title,
                          list: selectedFilters!,
                          key: theKey);
                      var all = SharedPrefs.instance
                              .getStringList(widget.allFiltersKey!) ??
                          [];
                      if (value == true) {
                        all.add(widget.dummyItems![index].title);
                      } else {
                        all.remove(widget.dummyItems![index].title);
                      }
                      SharedPrefs.instance
                          .setStringList(widget.allFiltersKey!, all);
                      if (widget.allFiltersKey == Strings().filtersToApplyKey) {
                        widget.bloc.add(ApplyButtonEnableEvent());
                      } else if (widget.allFiltersKey ==
                          Strings().proposalFiltersToApplyKey) {
                        widget.bloc.add(ApplyButtonEnableForProposalsEvent());
                      }

                    },
                    activeColor: AppColors.applyButtonColor,
                    checkColor: AppColors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.0),
                    ),
                    side: MaterialStateBorderSide.resolveWith(
                      (states) => BorderSide(
                          width: 1.5, color: AppColors.applyButtonColor),
                    ),
                    title: Text(
                      widget.dummyItems![index].title.toTitleCase(),
                      style: TextStyle(
                          color: AppColors.selectedFilterColor,
                          fontWeight: FontWeight.w600),
                    ),
                    controlAffinity: ListTileControlAffinity.leading,
                  );
                }),
          ],
        ),
      ),
    );
  }

  /// Widget to display search bar.
  Widget searchBar(
      {required TextEditingController controller,
      required String hint,
      required void Function(String)? onChanged}) {
    return Padding(
      padding: EdgeInsets.all(Dimensions.padding_10),
      child: TextField(
          controller: controller,
          decoration: InputDecoration(
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(Dimensions.borderRadius_30),
                borderSide: BorderSide(
                    color: AppColors.applyButtonColor.withOpacity(0.5))),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(Dimensions.borderRadius_30),
                borderSide: BorderSide(color: AppColors.searchBarBorderColor)),
            hintText: hint,
            hintStyle: TextStyle(
                color: AppColors.searchBarHintTextColor,
                fontSize: Dimensions.font_14),
            prefixIcon: const Icon(Icons.search),
            prefixIconColor: AppColors.searchBarIconColor,
            suffixIcon: controller.text.isEmpty
                ? null
                : InkWell(
                    onTap: () {
                      setState(() {
                        controller.clear();
                      });
                    },
                    child: const Icon(
                      Icons.clear,
                      color: Colors.grey,
                    ),
                  ),
          ),
          onChanged: onChanged),
    );
  }

  /// Widget to display Date Filters Screen
  Widget dateFilters({
    required TextEditingController startDateController,
    required TextEditingController endDateController,
    required startDateKey,
    required String endDateKey,
    required String datesListKey,
  }) {
    return BlocProvider.value(
      value: widget.bloc,
      child: SafeArea(
          child: Padding(
        padding: EdgeInsets.all(Dimensions.padding_10),
        child: Column(
          children: [
            TextField(
              controller: startDateController,
              decoration: InputDecoration(
                labelText: Strings().startDateText,
              ),
              onTap: () {
                final now = DateTime.now();
                _presentDatePicker(
                  controller: startDateController,
                  firstDate: DateTime(Dimensions.year_1950, now.month, now.day),
                  lastDate: DateTime(DateTime.now().year + Dimensions.add_100),
                  initialDate: DateTime(now.year, now.month, now.day),
                  key: startDateKey,
                  datesListKey: datesListKey,
                );
                var all = SharedPrefs.instance
                    .getStringList(widget.allFiltersKey!) ??
                    [];
                all.add(startDateController.text);
                SharedPrefs.instance
                    .setStringList(widget.allFiltersKey!, all);
              },
            ),
            SizedBox(
              height: Dimensions.height_10,
            ),
            TextField(
              controller: endDateController,
              decoration: InputDecoration(
                labelText: Strings().endDateText,
              ),
              onTap: () async {
                final formatter = DateFormat('yyyy-MM-dd');
                final now = DateTime.now();
                DateTime? startDate;
                if (startDateController.text.isNotEmpty) {
                  DateTime tempDate = formatter.parse(startDateController.text);
                  startDate = tempDate;
                }
                _presentDatePicker(
                    controller: endDateController,
                    firstDate: startDateController.text.isNotEmpty
                        ? startDate!
                        : DateTime(Dimensions.year_1950, now.month, now.day),
                    lastDate:
                        DateTime(DateTime.now().year + Dimensions.add_100),
                    initialDate: startDateController.text.isNotEmpty
                        ? startDate!
                        : DateTime(now.year, now.month, now.day),
                    key: endDateKey,
                    datesListKey: datesListKey);
                var all = SharedPrefs.instance
                    .getStringList(widget.allFiltersKey!) ??
                    [];
                all.add(startDateController.text);
                SharedPrefs.instance
                    .setStringList(widget.allFiltersKey!, all);
              },
            )
          ],
        ),
      )),
    );
  }
}
