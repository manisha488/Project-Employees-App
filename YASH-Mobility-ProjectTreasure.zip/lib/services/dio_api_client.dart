import 'package:dio/dio.dart';
import 'package:yash_mobility_project_treasure/resources/error_strings.dart';
import 'package:yash_mobility_project_treasure/services/api_interceptor.dart';
import 'package:yash_mobility_project_treasure/services/api_interceptor_currency.dart';

import 'network_exceptions.dart';

enum RequestType { get, post, delete}

class DioApiClient {
  final dio = createDio();

  DioApiClient._internal();

  // singleton class created to avoid multiple objects
  static final _singleton = DioApiClient._internal();

  factory DioApiClient() => _singleton;

  static Dio createDio() {
    var dio = Dio();
    dio.httpClientAdapter;
    dio.interceptors.add(ApiInterceptor());
    return dio;
  }

  // Generic method created to considering request type of API
  Future<dynamic> apiCall(
      String url,
      Map<String, dynamic>? queryParameters,
      Object? body,
      RequestType requestType,
      Options? options) async {
    Response result;
    try {
      switch (requestType) {
        case RequestType.get:
          {
            result = await dio.get(url,
                queryParameters: queryParameters, data: body, options: options);
            break;
          }
        case RequestType.post:
          {
            result = await dio.post(url,
                queryParameters: queryParameters, data: body, options: options);
            break;
          }
        case RequestType.delete:
          {
            result =
                await dio.delete(url, data: queryParameters, options: options);
            break;
          }
      }
      if (result.data != null) {
        return result;
      } else {
        return result.statusCode;
      }
    } on FormatException catch (_) {
      throw NetworkExceptions.formatExceptionError(
          ErrorStrings().unableToProcessData);
    }
  }
}

class DioApiCurrencyClient {
  final dio = createCurrencyDio();

  DioApiCurrencyClient._internal();

  // singleton class created to avoid multiple objects
  static final _singleton = DioApiCurrencyClient._internal();

  factory DioApiCurrencyClient() => _singleton;


  static Dio createCurrencyDio() {
    var dio = Dio();
    dio.httpClientAdapter;
    dio.interceptors.add(ApiInterceptorCurrency());
    return dio;
  }

  // Generic method created to considering request type of API
  Future<dynamic> apiCurrencyCall(
      String url,
      Map<String, dynamic>? queryParameters,
      Object? body,
      RequestType requestType,
      Options? options) async {
    Response result;
    try {
      switch (requestType) {
        case RequestType.get:
          {
            result = await dio.get(url,
                queryParameters: queryParameters, data: body, options: options);
            break;
          }
        case RequestType.post:
          {
            result = await dio.post(url,
                queryParameters: queryParameters, data: body, options: options);
            break;
          }
        case RequestType.delete:
          {
            result =
            await dio.delete(url, data: queryParameters, options: options);
            break;
          }
      }
      if (result.data != null) {
        return result;
      } else {
        return result.statusCode;
      }
    } on FormatException catch (_) {
      throw NetworkExceptions.formatExceptionError(
          ErrorStrings().unableToProcessData);
    }
  }
}
