import 'dart:async';
import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/document_list.dart';
import '../../../../model/response/resource_model_list.dart';
import '../../../../repository/api_repository.dart';
import '../../../../resources/error_strings.dart';
import '../../../../services/api_result.dart';
import '../../../../services/network_exceptions.dart';
import '../../../../utils/common_utils/utils.dart';

part 'review_screen_event.dart';
part 'review_screen_state.dart';

class ReviewScreenBloc extends Bloc<ReviewEvent, ReviewState> {
  ReviewScreenBloc() : super(ReviewInitialState()) {
    on<ReviewEvent>((event, emit) {});
    on<ReviewAttachmentBtnEvent>(reviewAttachmentBtnEvent);
    on<ReviewSaveDraftBtnEvent>(reviewSaveDraftBtnEvent);
    on<ReviewBasicDetailEditBtnEvent>(reviewBasicDetailEditBtnEvent);
    on<ReviewBasicDetailExpandBtnEvent>(reviewBasicDetailExpandBtnEvent);
    on<ReviewTechnicalInfoEditBtnEvent>(reviewTechnicalInformationEditBtnEvent);
    on<ReviewTechnicalInfoExpandBtnEvent>(
        reviewTechnicalInformationExpandBtnEvent);
    on<ReviewAdditionalDetailEditBtnEvent>(reviewAdditionalDetailEditBtnEvent);
    on<ReviewAdditionalDetailExpandBtnEvent>(
        reviewAdditionalDetailExpandBtnEvent);
    on<ReviewCreateProjectBtnEvent>(reviewCreateProjectBtnEvent);
    on<ReviewCreateProposalBtnEvent>(reviewCreateProposalBtnEvent);
    on<UploadDocumentEvent>(uploadDocumentEvent);
    on<ResourceStoreEvent>(resourceStoreEvent);
  }

  /// Event for Review screen Attachment button.
  FutureOr<void> reviewAttachmentBtnEvent(
      ReviewAttachmentBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewAttachmentBtnState());
  }

  /// Event for Review screen Save button.
  FutureOr<void> reviewSaveDraftBtnEvent(
      ReviewSaveDraftBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewSaveDraftBtnState());
  }

  /// Event for Review screen Basic detail Edit button.
  FutureOr<void> reviewBasicDetailEditBtnEvent(
      ReviewBasicDetailEditBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewBasicDetailEditBtnState());
  }

  /// Event for Review screen Basic detail Expand button.
  FutureOr<void> reviewBasicDetailExpandBtnEvent(
      ReviewBasicDetailExpandBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewBasicDetailExpandBtnState());
  }

  /// Event for Review screen Technical information Edit button.
  FutureOr<void> reviewTechnicalInformationEditBtnEvent(
      ReviewTechnicalInfoEditBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewTechnicalInfoEditBtnState());
  }

  /// Event for Review screen Technical information Expand button.
  FutureOr<void> reviewTechnicalInformationExpandBtnEvent(
      ReviewTechnicalInfoExpandBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewTechnicalInfoExpandBtnState());
  }

  /// Event for Review screen Additional detail Edit button.
  FutureOr<void> reviewAdditionalDetailEditBtnEvent(
      ReviewAdditionalDetailEditBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewAdditionalDetailEditBtnState());
  }

  /// Event for Review screen Additional detail Expand button
  FutureOr<void> reviewAdditionalDetailExpandBtnEvent(
      ReviewAdditionalDetailExpandBtnEvent event, Emitter<ReviewState> emit) {
    emit(ReviewAdditionalDetailExpandBtnState());
  }

  /// Event for Review screen Create project button.
  FutureOr<void> reviewCreateProjectBtnEvent(
      ReviewCreateProjectBtnEvent event, Emitter<ReviewState> emit) async {
    ///Database declaration.
    final db = CustomDataBaseWrapper();
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<CreateProjectData?> createProjects =
          await repository.createProject(
        event.objectives,
        event.startDate,
        event.endDate,
        event.clientName,
        event.budget,
        event.knownIssues,
        event.dependencies,
        event.comments,
        event.documents,
        event.feedback,
        event.name,
        event.summary,
        event.currency,
        event.location,
        event.riskFactor,
        event.technologies,
        event.domain,
        event.platforms,
        event.resources,
        event.functionalities,
        event.status,
        event.methodology,
      );
      emit(CreateProjectLoadedState());
      createProjects.when(
          success: (createdProject) async {
            emit(ReviewCreateProjectBtnState(createdProject));
          },
          failure: (NetworkExceptions exceptions) async {});
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> reviewCreateProposalBtnEvent(
      ReviewCreateProposalBtnEvent event, Emitter<ReviewState> emit) async {
    ///Database declaration.
    final db = CustomDataBaseWrapper();
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<CreateProposalData?> createProposal =
          await repository.createProposal(
        event.objectives,
        event.proposalReceivedDate,
        event.proposalSubmittedDate,
        event.clientDetails,
        event.budget,
        event.dependencies,
        event.comments,
        event.documents,
        event.feedback,
        event.name,
        event.summery,
        event.currency,
        event.location,
        event.riskFactors,
        event.technologies,
        event.domain,
        event.platforms,
        event.resources,
        event.functionalities,
        event.status,
      );
      emit(CreateProjectLoadedState());
      createProposal.when(
          success: (createdProposal) async {
            emit(ReviewCreateProposalBtnState(createdProposal));
          },
          failure: (NetworkExceptions exceptions) async {});
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> uploadDocumentEvent(
      UploadDocumentEvent event, Emitter<ReviewState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        return emit(UploadDocumentFailedState(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
      }
      ApiResult<List<DocumentsData?>?> userDocument =
          await repository.uploadDocument(event.file);
      userDocument.when(success: (userDocuments) {
        print("print the statereview $userDocuments!");
        emit(UploadDocumentState((userDocuments)));
        print("print the statereview2 $userDocuments!");
        print(jsonEncode(userDocument.toString()));
      }, failure: (NetworkExceptions exception) async {
        emit(UploadDocumentFailedState(exception));
      });
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> resourceStoreEvent(
      ResourceStoreEvent event, Emitter<ReviewState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<List<ResourcesData?>> resources = await repository.resources(
          event.resourceName, event.resourceEmail, event.designation);
      resources.when(
          success: (resource) {
            emit(ResourceStoreState(resource));
          },
          failure: (NetworkExceptions exceptions) async {});
    } on NetworkExceptions catch (_) {}
  }
}
