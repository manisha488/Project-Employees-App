import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';

import '../../resources/colors.dart';
import '../../resources/string.dart';

class StatusColors{
  /// Method to get colors with respect to the project status.
  static Color getColors(String status) {
    if (status == Strings().inProgressStatus) {
      return AppColors.inProgressStatus;
    } else if (status == Strings().onHoldStatus) {
      return AppColors.onHoldStatus;
    } else if (status == Strings().cancelledStatus) {
      return AppColors.cancelledStatus;
    } else if (status == Strings().notStartedStatus.toTitleCase()) {
      return AppColors.notStartedStatus;
    } else if (status == Strings().completedStatus) {
      return AppColors.completeStatus;
    } else if (status == Strings().inCompletedStatus) {
      return AppColors.incompleteStatus;
    } else if (status == Strings().overdueStatus) {
      return AppColors.overdueStatus;
    } else if (status == Strings().approvedStatus) {
      return AppColors.approvedStatus;
    } else {
      return AppColors.white;
    }
  }
}