part of 'create_project_screen_bloc.dart';

@immutable
abstract class CreateProjectEvent {}

class CreateProjectInitialEvent extends CreateProjectEvent {}

///Event for Navigation from Create project Screen to Basic detail screen.
class NavigateCreateProjectToBasicDetailEvent extends CreateProjectEvent {}

///Event for Navigation from Create project Screen to Technical detail screen.
class NavigateCreateProjectToTechInfoEvent extends CreateProjectEvent {}

///Event for Navigation from Create project Screen to Additional detail screen.
class NavigateCreateProjectToAdditionalDetailEvent extends CreateProjectEvent {}

///Event for Navigation from Create project Screen to Review screen.
class NavigateCreateProjectToReviewEvent extends CreateProjectEvent {}

///Create project button Event.
class CreateProjectClickedEvent extends CreateProjectEvent {
  final String? objectives;
  final String? startDate;
  final String? endDate;
  final String? clientName;
  final String? budget;
  final String? knownIssues;
  final String? dependencies;
  final String? comments;
  final dynamic documents;
  final String? feedback;
  final String? name;
  final String? summary;
  final String? currency;
  final String? location;
  final String? riskFactor;
  final dynamic technologies;
  final dynamic domain;
  final dynamic platforms;
  final dynamic resources;
  final dynamic functionalities;
  final dynamic status;
  final dynamic methodology;

  CreateProjectClickedEvent(
      {this.objectives,
      this.startDate,
      this.endDate,
      this.clientName,
      this.budget,
      this.knownIssues,
      this.dependencies,
      this.comments,
      this.documents,
      this.feedback,
      this.name,
      this.summary,
      this.currency,
      this.location,
      this.riskFactor,
      this.technologies,
      this.domain,
      this.platforms,
      this.resources,
      this.functionalities,
      this.status,
      this.methodology});
}

///Event for Review screen Create Proposal button.
class CreateProposalClickedEvent extends CreateProjectEvent {
  final String? objectives;
  final String? proposalReceivedDate;
  final String? proposalSubmittedDate;
  final String? clientDetails;
  final String? budget;
  final String? dependencies;
  final String? comments;
  final dynamic documents;
  final String? feedback;
  final String? name;
  final String? summery;
  final String? currency;
  final String? location;
  final String? riskFactors;
  final dynamic technologies;
  final dynamic domain;
  final dynamic platforms;
  final dynamic resources;
  final dynamic functionalities;
  final dynamic status;

  CreateProposalClickedEvent({
    this.objectives,
    this.proposalReceivedDate,
    this.proposalSubmittedDate,
    this.clientDetails,
    this.budget,
    this.dependencies,
    this.comments,
    this.documents,
    this.feedback,
    this.name,
    this.summery,
    this.currency,
    this.location,
    this.riskFactors,
    this.technologies,
    this.domain,
    this.platforms,
    this.resources,
    this.functionalities,
    this.status,
  });
}

/// Event for the Upload Document list
class UploadDocumentEvent extends CreateProjectEvent {
  List<Map<String, dynamic>> file;
  UploadDocumentEvent({required this.file});
}

class ResourceStoreEvent extends CreateProjectEvent {
  final int? id;
  final String? resourceName;
  final String? resourceEmail;
  final String? designation;

  ResourceStoreEvent(
      {this.id, this.resourceName, this.resourceEmail, this.designation});
}
