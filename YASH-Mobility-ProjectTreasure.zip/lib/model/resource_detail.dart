class ResourceDetails {
  String resourceName;
  String resourceDesignation;
  String resourceEmailAddress;

  ResourceDetails(
      this.resourceName, this.resourceDesignation, this.resourceEmailAddress);
}

