import 'dart:async';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';

class Utils {
  /// Method to verify device network connection
  static Future<bool> isNetworkConnected() async {
    return await InternetConnection().hasInternetAccess;
  }

  static Duration getActiveLifeSpan() {
    String? startTime =
        SharedPrefs.instance.getString(Constants.appActiveLifeSpanStart);
    return DateTime.now().difference(DateTime.parse(startTime!));
  }
}

/// class to format strings to display on UI
extension StringCasingExtension on String {
  String toCapitalized() => length > Dimensions.selection_0
      ? '${this[Dimensions.selection_0].toUpperCase()}${substring(Dimensions.selection_1).toLowerCase()}'
      : '';
  String toTitleCase() => replaceAll(RegExp(' +'), ' ')
      .split(' ')
      .map((str) => str.toCapitalized())
      .join(' ');
  // String capitalizeIfFewerThanThree(String input) {
  //   List<String> words = input.split(' ');
  //   if (words.length <= 3) {
  //     return input.toUpperCase();
  //   } else {
  //     return input;
  //   }
  // }
  String capitalizeSpecialWords() {
    List<String> words = this.split(' ');
    List<String> capitalizedWords = [];

    for (String word in words) {
      if ((word.length <= 3 &&  word != 'of') || word.toUpperCase() == word ) {
        capitalizedWords.add(word.toUpperCase());
      } else {
        capitalizedWords.add(word);
      }
    }

    return capitalizedWords.join(' ');
  }
}
