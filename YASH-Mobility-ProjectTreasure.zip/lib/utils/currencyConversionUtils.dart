
class CurrencyConversionUtils{

  static String getCurrencySymbol(String currency) {
    switch(currency.toLowerCase()) {
      case 'dollar':
        return '\$';
      case 'rupee':
        return '₹';
      case 'euro':
        return '€';
      default:
        return currency;
    }
  }

}