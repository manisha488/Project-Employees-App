import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';

class CustomDatePicker extends StatefulWidget {
  final TextEditingController dateInput;
  final String dateTitle;
  final String? Function(String?)? validator;
  final void Function(String?)? onSaved;
  final String? firstDate;
  final String? firstDateString;
  final DateTime lastDate;
  final void Function()? onTap;

  const CustomDatePicker(
      {super.key,
      required this.dateInput,
      required this.dateTitle,
      this.validator,
      this.onSaved,
      this.firstDate,
      this.firstDateString,
      required this.lastDate,
      this.onTap});

  @override
  State<CustomDatePicker> createState() => _CustomDatePickerState();
}

class _CustomDatePickerState extends State<CustomDatePicker> {
  bool isFocused = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (hasFocus) {
        setState(() {
          isFocused = hasFocus;
        });
      },
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(
              color: isFocused
                  ? AppColors.basicDetailTextFieldBorderColor
                  : AppColors.basicDetailTextFieldBorderColor,
            ),
            borderRadius: BorderRadius.circular(Dimensions.borderRadius_5)),
        child: TextFormField(
          controller: widget.dateInput,
          decoration: InputDecoration(
              labelText: widget.dateTitle,
              labelStyle: TextStyle(
                color: AppColors.createProjectAppBarColor,
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(
                  left: Dimensions.padding_16,
                  top: Dimensions.padding_12,
                  bottom: Dimensions.padding_12),
              suffixIcon: Icon(
                Icons.calendar_month_outlined,
                size: Dimensions.iconSize_24,
                color: AppColors.createProjectAppBarColor,
              )),
          readOnly: true,
          onTap: widget.onTap,
          validator: (value) {
            if (widget.validator != null) {
              return widget.validator!(value);
            }
            return null;
          },
          onSaved: widget.onSaved,
        ),
      ),
    );
  }
}
