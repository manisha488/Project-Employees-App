import 'dart:async';
import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/document_list.dart';
import '../../../../model/response/resource_model_list.dart';
import '../../../../repository/api_repository.dart';
import '../../../../resources/error_strings.dart';
import '../../../../services/api_result.dart';
import '../../../../services/network_exceptions.dart';
import '../../../../utils/common_utils/utils.dart';

part 'create_project_screen_event.dart';
part 'create_project_screen_state.dart';

class CreateProjectScreenBloc
    extends Bloc<CreateProjectEvent, CreateProjectState> {
  CreateProjectScreenBloc() : super(CreateProjectInitialState()) {
    on<CreateProjectEvent>((event, emit) {});
    on<NavigateCreateProjectToBasicDetailEvent>(
        navigateCreateProjectToBasicDetailEvent);
    on<NavigateCreateProjectToTechInfoEvent>(
        navigateCreateProjectToTechInfoEvent);
    on<NavigateCreateProjectToAdditionalDetailEvent>(
        navigateCreateProjectToAdditionalDetailEvent);
    on<NavigateCreateProjectToReviewEvent>(navigateCreateProjectToReviewEvent);
    on<CreateProjectClickedEvent>(createProjectClickedEvent);
    on<CreateProposalClickedEvent>(createProposalClickedEvent);
    on<UploadDocumentEvent>(uploadDocumentEvent);
    on<ResourceStoreEvent>(resourceStoreEvent);
  }

  ///Event for Navigation from Create project Screen to Basic detail screen.
  FutureOr<void> navigateCreateProjectToBasicDetailEvent(
      NavigateCreateProjectToBasicDetailEvent event,
      Emitter<CreateProjectState> emit) {
    emit(NavigateCreateProjectToBasicDetailState());
  }

  ///Event for Navigation from Create project Screen to Technical detail screen.
  FutureOr<void> navigateCreateProjectToTechInfoEvent(
      NavigateCreateProjectToTechInfoEvent event,
      Emitter<CreateProjectState> emit) {
    emit(NavigateCreateProjectToTechInfoState());
  }

  ///Event for Navigation from Create project Screen to Additional detail screen.
  FutureOr<void> navigateCreateProjectToAdditionalDetailEvent(
      NavigateCreateProjectToAdditionalDetailEvent event,
      Emitter<CreateProjectState> emit) {
    emit(NavigateCreateProjectToAdditionalDetailState());
  }

  ///Event for Navigation from Create project Screen to Review screen.
  FutureOr<void> navigateCreateProjectToReviewEvent(
      NavigateCreateProjectToReviewEvent event,
      Emitter<CreateProjectState> emit) {
    emit(NavigateCreateProjectToReviewState());
  }

  ///Create project button Event.
  FutureOr<void> createProjectClickedEvent(
      CreateProjectClickedEvent event, Emitter<CreateProjectState> emit) async {
    ///Database declaration.
    final db = CustomDataBaseWrapper();
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<CreateProjectData?> createProjects =
          await repository.createProject(
        event.objectives,
        event.startDate,
        event.endDate,
        event.clientName,
        event.budget,
        event.knownIssues,
        event.dependencies,
        event.comments,
        event.documents,
        event.feedback,
        event.name,
        event.summary,
        event.currency,
        event.location,
        event.riskFactor,
        event.technologies,
        event.domain,
        event.platforms,
        event.resources,
        event.functionalities,
        event.status,
        event.methodology,
      );
      emit(CreateProjectLoadedState());
      createProjects.when(success: (createdProject) async {
        emit(CreateProjectClickedState(createdProject));
      }, failure: (NetworkExceptions exceptions) async {
        emit(CreateProjectFailedState());
      });
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> createProposalClickedEvent(CreateProposalClickedEvent event,
      Emitter<CreateProjectState> emit) async {
    ///Database declaration.
    final db = CustomDataBaseWrapper();
    try {
      emit(CreateProjectLoadingState());
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<CreateProposalData?> createProposal =
          await repository.createProposal(
        event.objectives,
        event.proposalReceivedDate,
        event.proposalSubmittedDate,
        event.clientDetails,
        event.budget,
        event.dependencies,
        event.comments,
        event.documents,
        event.feedback,
        event.name,
        event.summery,
        event.currency,
        event.location,
        event.riskFactors,
        event.technologies,
        event.domain,
        event.platforms,
        event.resources,
        event.functionalities,
        event.status,
      );
      emit(CreateProjectLoadedState());
      createProposal.when(success: (createdProposal) async {
        emit(CreateProposalClickedState(createdProposal));
      }, failure: (NetworkExceptions exceptions) async {
        emit(CreateProjectFailedState());
      });
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> uploadDocumentEvent(
      UploadDocumentEvent event, Emitter<CreateProjectState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        return emit(UploadDocumentFailedState(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
      }
      ApiResult<List<DocumentsData?>?> userDocument =
          await repository.uploadDocument(event.file);
      userDocument.when(success: (userDocuments) {
        emit(UploadDocumentState((userDocuments)));
      }, failure: (NetworkExceptions exception) async {
        emit(UploadDocumentFailedState(exception));
      });
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> resourceStoreEvent(
      ResourceStoreEvent event, Emitter<CreateProjectState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {}
      ApiResult<List<ResourcesData?>> resources = await repository.resources(
          event.resourceName, event.resourceEmail, event.designation);
      resources.when(
          success: (resource) {
            emit(ResourceStoreState(resource));
          },
          failure: (NetworkExceptions exceptions) async {});
    } on NetworkExceptions catch (_) {}
  }
}
