// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'network_exceptions.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NetworkExceptions {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkExceptionsCopyWith<$Res> {
  factory $NetworkExceptionsCopyWith(
          NetworkExceptions value, $Res Function(NetworkExceptions) then) =
      _$NetworkExceptionsCopyWithImpl<$Res, NetworkExceptions>;
}

/// @nodoc
class _$NetworkExceptionsCopyWithImpl<$Res, $Val extends NetworkExceptions>
    implements $NetworkExceptionsCopyWith<$Res> {
  _$NetworkExceptionsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$RequestCancelledErrorImplCopyWith<$Res> {
  factory _$$RequestCancelledErrorImplCopyWith(
          _$RequestCancelledErrorImpl value,
          $Res Function(_$RequestCancelledErrorImpl) then) =
      __$$RequestCancelledErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$RequestCancelledErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$RequestCancelledErrorImpl>
    implements _$$RequestCancelledErrorImplCopyWith<$Res> {
  __$$RequestCancelledErrorImplCopyWithImpl(_$RequestCancelledErrorImpl _value,
      $Res Function(_$RequestCancelledErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$RequestCancelledErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RequestCancelledErrorImpl implements RequestCancelledError {
  const _$RequestCancelledErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.requestCancelledError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RequestCancelledErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RequestCancelledErrorImplCopyWith<_$RequestCancelledErrorImpl>
      get copyWith => __$$RequestCancelledErrorImplCopyWithImpl<
          _$RequestCancelledErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return requestCancelledError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return requestCancelledError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (requestCancelledError != null) {
      return requestCancelledError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return requestCancelledError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return requestCancelledError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (requestCancelledError != null) {
      return requestCancelledError(this);
    }
    return orElse();
  }
}

abstract class RequestCancelledError implements NetworkExceptions {
  const factory RequestCancelledError(final String error) =
      _$RequestCancelledErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$RequestCancelledErrorImplCopyWith<_$RequestCancelledErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UnauthorizedRequestErrorImplCopyWith<$Res> {
  factory _$$UnauthorizedRequestErrorImplCopyWith(
          _$UnauthorizedRequestErrorImpl value,
          $Res Function(_$UnauthorizedRequestErrorImpl) then) =
      __$$UnauthorizedRequestErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String reason});
}

/// @nodoc
class __$$UnauthorizedRequestErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res,
        _$UnauthorizedRequestErrorImpl>
    implements _$$UnauthorizedRequestErrorImplCopyWith<$Res> {
  __$$UnauthorizedRequestErrorImplCopyWithImpl(
      _$UnauthorizedRequestErrorImpl _value,
      $Res Function(_$UnauthorizedRequestErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? reason = null,
  }) {
    return _then(_$UnauthorizedRequestErrorImpl(
      null == reason
          ? _value.reason
          : reason // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UnauthorizedRequestErrorImpl implements UnauthorizedRequestError {
  const _$UnauthorizedRequestErrorImpl(this.reason);

  @override
  final String reason;

  @override
  String toString() {
    return 'NetworkExceptions.unauthorizedRequestError(reason: $reason)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UnauthorizedRequestErrorImpl &&
            (identical(other.reason, reason) || other.reason == reason));
  }

  @override
  int get hashCode => Object.hash(runtimeType, reason);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UnauthorizedRequestErrorImplCopyWith<_$UnauthorizedRequestErrorImpl>
      get copyWith => __$$UnauthorizedRequestErrorImplCopyWithImpl<
          _$UnauthorizedRequestErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return unauthorizedRequestError(reason);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return unauthorizedRequestError?.call(reason);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unauthorizedRequestError != null) {
      return unauthorizedRequestError(reason);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return unauthorizedRequestError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return unauthorizedRequestError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unauthorizedRequestError != null) {
      return unauthorizedRequestError(this);
    }
    return orElse();
  }
}

abstract class UnauthorizedRequestError implements NetworkExceptions {
  const factory UnauthorizedRequestError(final String reason) =
      _$UnauthorizedRequestErrorImpl;

  String get reason;
  @JsonKey(ignore: true)
  _$$UnauthorizedRequestErrorImplCopyWith<_$UnauthorizedRequestErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$BadRequestErrorImplCopyWith<$Res> {
  factory _$$BadRequestErrorImplCopyWith(_$BadRequestErrorImpl value,
          $Res Function(_$BadRequestErrorImpl) then) =
      __$$BadRequestErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$BadRequestErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$BadRequestErrorImpl>
    implements _$$BadRequestErrorImplCopyWith<$Res> {
  __$$BadRequestErrorImplCopyWithImpl(
      _$BadRequestErrorImpl _value, $Res Function(_$BadRequestErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$BadRequestErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$BadRequestErrorImpl implements BadRequestError {
  const _$BadRequestErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.badRequestError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BadRequestErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BadRequestErrorImplCopyWith<_$BadRequestErrorImpl> get copyWith =>
      __$$BadRequestErrorImplCopyWithImpl<_$BadRequestErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return badRequestError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return badRequestError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (badRequestError != null) {
      return badRequestError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return badRequestError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return badRequestError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (badRequestError != null) {
      return badRequestError(this);
    }
    return orElse();
  }
}

abstract class BadRequestError implements NetworkExceptions {
  const factory BadRequestError(final String error) = _$BadRequestErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$BadRequestErrorImplCopyWith<_$BadRequestErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NotFoundErrorImplCopyWith<$Res> {
  factory _$$NotFoundErrorImplCopyWith(
          _$NotFoundErrorImpl value, $Res Function(_$NotFoundErrorImpl) then) =
      __$$NotFoundErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String reason});
}

/// @nodoc
class __$$NotFoundErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$NotFoundErrorImpl>
    implements _$$NotFoundErrorImplCopyWith<$Res> {
  __$$NotFoundErrorImplCopyWithImpl(
      _$NotFoundErrorImpl _value, $Res Function(_$NotFoundErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? reason = null,
  }) {
    return _then(_$NotFoundErrorImpl(
      null == reason
          ? _value.reason
          : reason // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$NotFoundErrorImpl implements NotFoundError {
  const _$NotFoundErrorImpl(this.reason);

  @override
  final String reason;

  @override
  String toString() {
    return 'NetworkExceptions.notFoundError(reason: $reason)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NotFoundErrorImpl &&
            (identical(other.reason, reason) || other.reason == reason));
  }

  @override
  int get hashCode => Object.hash(runtimeType, reason);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NotFoundErrorImplCopyWith<_$NotFoundErrorImpl> get copyWith =>
      __$$NotFoundErrorImplCopyWithImpl<_$NotFoundErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return notFoundError(reason);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return notFoundError?.call(reason);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (notFoundError != null) {
      return notFoundError(reason);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return notFoundError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return notFoundError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (notFoundError != null) {
      return notFoundError(this);
    }
    return orElse();
  }
}

abstract class NotFoundError implements NetworkExceptions {
  const factory NotFoundError(final String reason) = _$NotFoundErrorImpl;

  String get reason;
  @JsonKey(ignore: true)
  _$$NotFoundErrorImplCopyWith<_$NotFoundErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MethodNotAllowedErrorImplCopyWith<$Res> {
  factory _$$MethodNotAllowedErrorImplCopyWith(
          _$MethodNotAllowedErrorImpl value,
          $Res Function(_$MethodNotAllowedErrorImpl) then) =
      __$$MethodNotAllowedErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$MethodNotAllowedErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$MethodNotAllowedErrorImpl>
    implements _$$MethodNotAllowedErrorImplCopyWith<$Res> {
  __$$MethodNotAllowedErrorImplCopyWithImpl(_$MethodNotAllowedErrorImpl _value,
      $Res Function(_$MethodNotAllowedErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$MethodNotAllowedErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$MethodNotAllowedErrorImpl implements MethodNotAllowedError {
  const _$MethodNotAllowedErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.methodNotAllowedError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MethodNotAllowedErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MethodNotAllowedErrorImplCopyWith<_$MethodNotAllowedErrorImpl>
      get copyWith => __$$MethodNotAllowedErrorImplCopyWithImpl<
          _$MethodNotAllowedErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return methodNotAllowedError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return methodNotAllowedError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (methodNotAllowedError != null) {
      return methodNotAllowedError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return methodNotAllowedError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return methodNotAllowedError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (methodNotAllowedError != null) {
      return methodNotAllowedError(this);
    }
    return orElse();
  }
}

abstract class MethodNotAllowedError implements NetworkExceptions {
  const factory MethodNotAllowedError(final String error) =
      _$MethodNotAllowedErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$MethodNotAllowedErrorImplCopyWith<_$MethodNotAllowedErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NotAcceptableErrorImplCopyWith<$Res> {
  factory _$$NotAcceptableErrorImplCopyWith(_$NotAcceptableErrorImpl value,
          $Res Function(_$NotAcceptableErrorImpl) then) =
      __$$NotAcceptableErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$NotAcceptableErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$NotAcceptableErrorImpl>
    implements _$$NotAcceptableErrorImplCopyWith<$Res> {
  __$$NotAcceptableErrorImplCopyWithImpl(_$NotAcceptableErrorImpl _value,
      $Res Function(_$NotAcceptableErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$NotAcceptableErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$NotAcceptableErrorImpl implements NotAcceptableError {
  const _$NotAcceptableErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.notAcceptableError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NotAcceptableErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NotAcceptableErrorImplCopyWith<_$NotAcceptableErrorImpl> get copyWith =>
      __$$NotAcceptableErrorImplCopyWithImpl<_$NotAcceptableErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return notAcceptableError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return notAcceptableError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (notAcceptableError != null) {
      return notAcceptableError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return notAcceptableError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return notAcceptableError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (notAcceptableError != null) {
      return notAcceptableError(this);
    }
    return orElse();
  }
}

abstract class NotAcceptableError implements NetworkExceptions {
  const factory NotAcceptableError(final String error) =
      _$NotAcceptableErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$NotAcceptableErrorImplCopyWith<_$NotAcceptableErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$RequestTimeoutErrorImplCopyWith<$Res> {
  factory _$$RequestTimeoutErrorImplCopyWith(_$RequestTimeoutErrorImpl value,
          $Res Function(_$RequestTimeoutErrorImpl) then) =
      __$$RequestTimeoutErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$RequestTimeoutErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$RequestTimeoutErrorImpl>
    implements _$$RequestTimeoutErrorImplCopyWith<$Res> {
  __$$RequestTimeoutErrorImplCopyWithImpl(_$RequestTimeoutErrorImpl _value,
      $Res Function(_$RequestTimeoutErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$RequestTimeoutErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$RequestTimeoutErrorImpl implements RequestTimeoutError {
  const _$RequestTimeoutErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.requestTimeoutError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RequestTimeoutErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RequestTimeoutErrorImplCopyWith<_$RequestTimeoutErrorImpl> get copyWith =>
      __$$RequestTimeoutErrorImplCopyWithImpl<_$RequestTimeoutErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return requestTimeoutError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return requestTimeoutError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (requestTimeoutError != null) {
      return requestTimeoutError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return requestTimeoutError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return requestTimeoutError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (requestTimeoutError != null) {
      return requestTimeoutError(this);
    }
    return orElse();
  }
}

abstract class RequestTimeoutError implements NetworkExceptions {
  const factory RequestTimeoutError(final String error) =
      _$RequestTimeoutErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$RequestTimeoutErrorImplCopyWith<_$RequestTimeoutErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SendTimeoutErrorImplCopyWith<$Res> {
  factory _$$SendTimeoutErrorImplCopyWith(_$SendTimeoutErrorImpl value,
          $Res Function(_$SendTimeoutErrorImpl) then) =
      __$$SendTimeoutErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$SendTimeoutErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$SendTimeoutErrorImpl>
    implements _$$SendTimeoutErrorImplCopyWith<$Res> {
  __$$SendTimeoutErrorImplCopyWithImpl(_$SendTimeoutErrorImpl _value,
      $Res Function(_$SendTimeoutErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$SendTimeoutErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SendTimeoutErrorImpl implements SendTimeoutError {
  const _$SendTimeoutErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.sendTimeoutError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SendTimeoutErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SendTimeoutErrorImplCopyWith<_$SendTimeoutErrorImpl> get copyWith =>
      __$$SendTimeoutErrorImplCopyWithImpl<_$SendTimeoutErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return sendTimeoutError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return sendTimeoutError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (sendTimeoutError != null) {
      return sendTimeoutError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return sendTimeoutError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return sendTimeoutError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (sendTimeoutError != null) {
      return sendTimeoutError(this);
    }
    return orElse();
  }
}

abstract class SendTimeoutError implements NetworkExceptions {
  const factory SendTimeoutError(final String error) = _$SendTimeoutErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$SendTimeoutErrorImplCopyWith<_$SendTimeoutErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ConflictErrorImplCopyWith<$Res> {
  factory _$$ConflictErrorImplCopyWith(
          _$ConflictErrorImpl value, $Res Function(_$ConflictErrorImpl) then) =
      __$$ConflictErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ConflictErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$ConflictErrorImpl>
    implements _$$ConflictErrorImplCopyWith<$Res> {
  __$$ConflictErrorImplCopyWithImpl(
      _$ConflictErrorImpl _value, $Res Function(_$ConflictErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ConflictErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ConflictErrorImpl implements ConflictError {
  const _$ConflictErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.conflictError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ConflictErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ConflictErrorImplCopyWith<_$ConflictErrorImpl> get copyWith =>
      __$$ConflictErrorImplCopyWithImpl<_$ConflictErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return conflictError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return conflictError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (conflictError != null) {
      return conflictError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return conflictError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return conflictError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (conflictError != null) {
      return conflictError(this);
    }
    return orElse();
  }
}

abstract class ConflictError implements NetworkExceptions {
  const factory ConflictError(final String error) = _$ConflictErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ConflictErrorImplCopyWith<_$ConflictErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InternalServerErrorImplCopyWith<$Res> {
  factory _$$InternalServerErrorImplCopyWith(_$InternalServerErrorImpl value,
          $Res Function(_$InternalServerErrorImpl) then) =
      __$$InternalServerErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$InternalServerErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$InternalServerErrorImpl>
    implements _$$InternalServerErrorImplCopyWith<$Res> {
  __$$InternalServerErrorImplCopyWithImpl(_$InternalServerErrorImpl _value,
      $Res Function(_$InternalServerErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$InternalServerErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$InternalServerErrorImpl implements InternalServerError {
  const _$InternalServerErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.internalServerError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InternalServerErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$InternalServerErrorImplCopyWith<_$InternalServerErrorImpl> get copyWith =>
      __$$InternalServerErrorImplCopyWithImpl<_$InternalServerErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return internalServerError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return internalServerError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (internalServerError != null) {
      return internalServerError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return internalServerError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return internalServerError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (internalServerError != null) {
      return internalServerError(this);
    }
    return orElse();
  }
}

abstract class InternalServerError implements NetworkExceptions {
  const factory InternalServerError(final String error) =
      _$InternalServerErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$InternalServerErrorImplCopyWith<_$InternalServerErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NotImplementedErrorImplCopyWith<$Res> {
  factory _$$NotImplementedErrorImplCopyWith(_$NotImplementedErrorImpl value,
          $Res Function(_$NotImplementedErrorImpl) then) =
      __$$NotImplementedErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$NotImplementedErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$NotImplementedErrorImpl>
    implements _$$NotImplementedErrorImplCopyWith<$Res> {
  __$$NotImplementedErrorImplCopyWithImpl(_$NotImplementedErrorImpl _value,
      $Res Function(_$NotImplementedErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$NotImplementedErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$NotImplementedErrorImpl implements NotImplementedError {
  const _$NotImplementedErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.notImplementedError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NotImplementedErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NotImplementedErrorImplCopyWith<_$NotImplementedErrorImpl> get copyWith =>
      __$$NotImplementedErrorImplCopyWithImpl<_$NotImplementedErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return notImplementedError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return notImplementedError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (notImplementedError != null) {
      return notImplementedError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return notImplementedError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return notImplementedError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (notImplementedError != null) {
      return notImplementedError(this);
    }
    return orElse();
  }
}

abstract class NotImplementedError implements NetworkExceptions {
  const factory NotImplementedError(final String error) =
      _$NotImplementedErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$NotImplementedErrorImplCopyWith<_$NotImplementedErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ServiceUnavailableErrorImplCopyWith<$Res> {
  factory _$$ServiceUnavailableErrorImplCopyWith(
          _$ServiceUnavailableErrorImpl value,
          $Res Function(_$ServiceUnavailableErrorImpl) then) =
      __$$ServiceUnavailableErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ServiceUnavailableErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$ServiceUnavailableErrorImpl>
    implements _$$ServiceUnavailableErrorImplCopyWith<$Res> {
  __$$ServiceUnavailableErrorImplCopyWithImpl(
      _$ServiceUnavailableErrorImpl _value,
      $Res Function(_$ServiceUnavailableErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ServiceUnavailableErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ServiceUnavailableErrorImpl implements ServiceUnavailableError {
  const _$ServiceUnavailableErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.serviceUnavailableError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceUnavailableErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceUnavailableErrorImplCopyWith<_$ServiceUnavailableErrorImpl>
      get copyWith => __$$ServiceUnavailableErrorImplCopyWithImpl<
          _$ServiceUnavailableErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return serviceUnavailableError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return serviceUnavailableError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (serviceUnavailableError != null) {
      return serviceUnavailableError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return serviceUnavailableError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return serviceUnavailableError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (serviceUnavailableError != null) {
      return serviceUnavailableError(this);
    }
    return orElse();
  }
}

abstract class ServiceUnavailableError implements NetworkExceptions {
  const factory ServiceUnavailableError(final String error) =
      _$ServiceUnavailableErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ServiceUnavailableErrorImplCopyWith<_$ServiceUnavailableErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NoInternetConnectionErrorImplCopyWith<$Res> {
  factory _$$NoInternetConnectionErrorImplCopyWith(
          _$NoInternetConnectionErrorImpl value,
          $Res Function(_$NoInternetConnectionErrorImpl) then) =
      __$$NoInternetConnectionErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$NoInternetConnectionErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res,
        _$NoInternetConnectionErrorImpl>
    implements _$$NoInternetConnectionErrorImplCopyWith<$Res> {
  __$$NoInternetConnectionErrorImplCopyWithImpl(
      _$NoInternetConnectionErrorImpl _value,
      $Res Function(_$NoInternetConnectionErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$NoInternetConnectionErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$NoInternetConnectionErrorImpl implements NoInternetConnectionError {
  const _$NoInternetConnectionErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.noInternetConnectionError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NoInternetConnectionErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NoInternetConnectionErrorImplCopyWith<_$NoInternetConnectionErrorImpl>
      get copyWith => __$$NoInternetConnectionErrorImplCopyWithImpl<
          _$NoInternetConnectionErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return noInternetConnectionError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return noInternetConnectionError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (noInternetConnectionError != null) {
      return noInternetConnectionError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return noInternetConnectionError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return noInternetConnectionError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (noInternetConnectionError != null) {
      return noInternetConnectionError(this);
    }
    return orElse();
  }
}

abstract class NoInternetConnectionError implements NetworkExceptions {
  const factory NoInternetConnectionError(final String error) =
      _$NoInternetConnectionErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$NoInternetConnectionErrorImplCopyWith<_$NoInternetConnectionErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$FormatExceptionErrorImplCopyWith<$Res> {
  factory _$$FormatExceptionErrorImplCopyWith(_$FormatExceptionErrorImpl value,
          $Res Function(_$FormatExceptionErrorImpl) then) =
      __$$FormatExceptionErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$FormatExceptionErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$FormatExceptionErrorImpl>
    implements _$$FormatExceptionErrorImplCopyWith<$Res> {
  __$$FormatExceptionErrorImplCopyWithImpl(_$FormatExceptionErrorImpl _value,
      $Res Function(_$FormatExceptionErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$FormatExceptionErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$FormatExceptionErrorImpl implements FormatExceptionError {
  const _$FormatExceptionErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.formatExceptionError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FormatExceptionErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FormatExceptionErrorImplCopyWith<_$FormatExceptionErrorImpl>
      get copyWith =>
          __$$FormatExceptionErrorImplCopyWithImpl<_$FormatExceptionErrorImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return formatExceptionError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return formatExceptionError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (formatExceptionError != null) {
      return formatExceptionError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return formatExceptionError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return formatExceptionError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (formatExceptionError != null) {
      return formatExceptionError(this);
    }
    return orElse();
  }
}

abstract class FormatExceptionError implements NetworkExceptions {
  const factory FormatExceptionError(final String error) =
      _$FormatExceptionErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$FormatExceptionErrorImplCopyWith<_$FormatExceptionErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UnableToProcessErrorImplCopyWith<$Res> {
  factory _$$UnableToProcessErrorImplCopyWith(_$UnableToProcessErrorImpl value,
          $Res Function(_$UnableToProcessErrorImpl) then) =
      __$$UnableToProcessErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$UnableToProcessErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$UnableToProcessErrorImpl>
    implements _$$UnableToProcessErrorImplCopyWith<$Res> {
  __$$UnableToProcessErrorImplCopyWithImpl(_$UnableToProcessErrorImpl _value,
      $Res Function(_$UnableToProcessErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$UnableToProcessErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UnableToProcessErrorImpl implements UnableToProcessError {
  const _$UnableToProcessErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.unableToProcessError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UnableToProcessErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UnableToProcessErrorImplCopyWith<_$UnableToProcessErrorImpl>
      get copyWith =>
          __$$UnableToProcessErrorImplCopyWithImpl<_$UnableToProcessErrorImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return unableToProcessError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return unableToProcessError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unableToProcessError != null) {
      return unableToProcessError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return unableToProcessError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return unableToProcessError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unableToProcessError != null) {
      return unableToProcessError(this);
    }
    return orElse();
  }
}

abstract class UnableToProcessError implements NetworkExceptions {
  const factory UnableToProcessError(final String error) =
      _$UnableToProcessErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$UnableToProcessErrorImplCopyWith<_$UnableToProcessErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DefaultErrorImplCopyWith<$Res> {
  factory _$$DefaultErrorImplCopyWith(
          _$DefaultErrorImpl value, $Res Function(_$DefaultErrorImpl) then) =
      __$$DefaultErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$DefaultErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$DefaultErrorImpl>
    implements _$$DefaultErrorImplCopyWith<$Res> {
  __$$DefaultErrorImplCopyWithImpl(
      _$DefaultErrorImpl _value, $Res Function(_$DefaultErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$DefaultErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$DefaultErrorImpl implements DefaultError {
  const _$DefaultErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.defaultError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DefaultErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DefaultErrorImplCopyWith<_$DefaultErrorImpl> get copyWith =>
      __$$DefaultErrorImplCopyWithImpl<_$DefaultErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return defaultError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return defaultError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (defaultError != null) {
      return defaultError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return defaultError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return defaultError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (defaultError != null) {
      return defaultError(this);
    }
    return orElse();
  }
}

abstract class DefaultError implements NetworkExceptions {
  const factory DefaultError(final String error) = _$DefaultErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$DefaultErrorImplCopyWith<_$DefaultErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ConnectionErrorImplCopyWith<$Res> {
  factory _$$ConnectionErrorImplCopyWith(_$ConnectionErrorImpl value,
          $Res Function(_$ConnectionErrorImpl) then) =
      __$$ConnectionErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ConnectionErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$ConnectionErrorImpl>
    implements _$$ConnectionErrorImplCopyWith<$Res> {
  __$$ConnectionErrorImplCopyWithImpl(
      _$ConnectionErrorImpl _value, $Res Function(_$ConnectionErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ConnectionErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ConnectionErrorImpl implements ConnectionError {
  const _$ConnectionErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.connectionError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ConnectionErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ConnectionErrorImplCopyWith<_$ConnectionErrorImpl> get copyWith =>
      __$$ConnectionErrorImplCopyWithImpl<_$ConnectionErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return connectionError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return connectionError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (connectionError != null) {
      return connectionError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return connectionError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return connectionError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (connectionError != null) {
      return connectionError(this);
    }
    return orElse();
  }
}

abstract class ConnectionError implements NetworkExceptions {
  const factory ConnectionError(final String error) = _$ConnectionErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ConnectionErrorImplCopyWith<_$ConnectionErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$BadCertificateErrorImplCopyWith<$Res> {
  factory _$$BadCertificateErrorImplCopyWith(_$BadCertificateErrorImpl value,
          $Res Function(_$BadCertificateErrorImpl) then) =
      __$$BadCertificateErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$BadCertificateErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$BadCertificateErrorImpl>
    implements _$$BadCertificateErrorImplCopyWith<$Res> {
  __$$BadCertificateErrorImplCopyWithImpl(_$BadCertificateErrorImpl _value,
      $Res Function(_$BadCertificateErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$BadCertificateErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$BadCertificateErrorImpl implements BadCertificateError {
  const _$BadCertificateErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.badCertificateError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BadCertificateErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BadCertificateErrorImplCopyWith<_$BadCertificateErrorImpl> get copyWith =>
      __$$BadCertificateErrorImplCopyWithImpl<_$BadCertificateErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return badCertificateError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return badCertificateError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (badCertificateError != null) {
      return badCertificateError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return badCertificateError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return badCertificateError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (badCertificateError != null) {
      return badCertificateError(this);
    }
    return orElse();
  }
}

abstract class BadCertificateError implements NetworkExceptions {
  const factory BadCertificateError(final String error) =
      _$BadCertificateErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$BadCertificateErrorImplCopyWith<_$BadCertificateErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$BadResponseErrorImplCopyWith<$Res> {
  factory _$$BadResponseErrorImplCopyWith(_$BadResponseErrorImpl value,
          $Res Function(_$BadResponseErrorImpl) then) =
      __$$BadResponseErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$BadResponseErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$BadResponseErrorImpl>
    implements _$$BadResponseErrorImplCopyWith<$Res> {
  __$$BadResponseErrorImplCopyWithImpl(_$BadResponseErrorImpl _value,
      $Res Function(_$BadResponseErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$BadResponseErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$BadResponseErrorImpl implements BadResponseError {
  const _$BadResponseErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.badResponseError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BadResponseErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BadResponseErrorImplCopyWith<_$BadResponseErrorImpl> get copyWith =>
      __$$BadResponseErrorImplCopyWithImpl<_$BadResponseErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return badResponseError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return badResponseError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (badResponseError != null) {
      return badResponseError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return badResponseError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return badResponseError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (badResponseError != null) {
      return badResponseError(this);
    }
    return orElse();
  }
}

abstract class BadResponseError implements NetworkExceptions {
  const factory BadResponseError(final String error) = _$BadResponseErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$BadResponseErrorImplCopyWith<_$BadResponseErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UnknownErrorImplCopyWith<$Res> {
  factory _$$UnknownErrorImplCopyWith(
          _$UnknownErrorImpl value, $Res Function(_$UnknownErrorImpl) then) =
      __$$UnknownErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$UnknownErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$UnknownErrorImpl>
    implements _$$UnknownErrorImplCopyWith<$Res> {
  __$$UnknownErrorImplCopyWithImpl(
      _$UnknownErrorImpl _value, $Res Function(_$UnknownErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$UnknownErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UnknownErrorImpl implements UnknownError {
  const _$UnknownErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.unknownError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UnknownErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UnknownErrorImplCopyWith<_$UnknownErrorImpl> get copyWith =>
      __$$UnknownErrorImplCopyWithImpl<_$UnknownErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return unknownError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return unknownError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unknownError != null) {
      return unknownError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return unknownError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return unknownError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unknownError != null) {
      return unknownError(this);
    }
    return orElse();
  }
}

abstract class UnknownError implements NetworkExceptions {
  const factory UnknownError(final String error) = _$UnknownErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$UnknownErrorImplCopyWith<_$UnknownErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UnexpectedErrorImplCopyWith<$Res> {
  factory _$$UnexpectedErrorImplCopyWith(_$UnexpectedErrorImpl value,
          $Res Function(_$UnexpectedErrorImpl) then) =
      __$$UnexpectedErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$UnexpectedErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$UnexpectedErrorImpl>
    implements _$$UnexpectedErrorImplCopyWith<$Res> {
  __$$UnexpectedErrorImplCopyWithImpl(
      _$UnexpectedErrorImpl _value, $Res Function(_$UnexpectedErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$UnexpectedErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$UnexpectedErrorImpl implements UnexpectedError {
  const _$UnexpectedErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.unexpectedError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UnexpectedErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UnexpectedErrorImplCopyWith<_$UnexpectedErrorImpl> get copyWith =>
      __$$UnexpectedErrorImplCopyWithImpl<_$UnexpectedErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return unexpectedError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return unexpectedError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unexpectedError != null) {
      return unexpectedError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return unexpectedError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return unexpectedError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (unexpectedError != null) {
      return unexpectedError(this);
    }
    return orElse();
  }
}

abstract class UnexpectedError implements NetworkExceptions {
  const factory UnexpectedError(final String error) = _$UnexpectedErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$UnexpectedErrorImplCopyWith<_$UnexpectedErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ConnectionTimeOutErrorImplCopyWith<$Res> {
  factory _$$ConnectionTimeOutErrorImplCopyWith(
          _$ConnectionTimeOutErrorImpl value,
          $Res Function(_$ConnectionTimeOutErrorImpl) then) =
      __$$ConnectionTimeOutErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ConnectionTimeOutErrorImplCopyWithImpl<$Res>
    extends _$NetworkExceptionsCopyWithImpl<$Res, _$ConnectionTimeOutErrorImpl>
    implements _$$ConnectionTimeOutErrorImplCopyWith<$Res> {
  __$$ConnectionTimeOutErrorImplCopyWithImpl(
      _$ConnectionTimeOutErrorImpl _value,
      $Res Function(_$ConnectionTimeOutErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ConnectionTimeOutErrorImpl(
      null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ConnectionTimeOutErrorImpl implements ConnectionTimeOutError {
  const _$ConnectionTimeOutErrorImpl(this.error);

  @override
  final String error;

  @override
  String toString() {
    return 'NetworkExceptions.connectionTimeOutError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ConnectionTimeOutErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ConnectionTimeOutErrorImplCopyWith<_$ConnectionTimeOutErrorImpl>
      get copyWith => __$$ConnectionTimeOutErrorImplCopyWithImpl<
          _$ConnectionTimeOutErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) requestCancelledError,
    required TResult Function(String reason) unauthorizedRequestError,
    required TResult Function(String error) badRequestError,
    required TResult Function(String reason) notFoundError,
    required TResult Function(String error) methodNotAllowedError,
    required TResult Function(String error) notAcceptableError,
    required TResult Function(String error) requestTimeoutError,
    required TResult Function(String error) sendTimeoutError,
    required TResult Function(String error) conflictError,
    required TResult Function(String error) internalServerError,
    required TResult Function(String error) notImplementedError,
    required TResult Function(String error) serviceUnavailableError,
    required TResult Function(String error) noInternetConnectionError,
    required TResult Function(String error) formatExceptionError,
    required TResult Function(String error) unableToProcessError,
    required TResult Function(String error) defaultError,
    required TResult Function(String error) connectionError,
    required TResult Function(String error) badCertificateError,
    required TResult Function(String error) badResponseError,
    required TResult Function(String error) unknownError,
    required TResult Function(String error) unexpectedError,
    required TResult Function(String error) connectionTimeOutError,
  }) {
    return connectionTimeOutError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? requestCancelledError,
    TResult? Function(String reason)? unauthorizedRequestError,
    TResult? Function(String error)? badRequestError,
    TResult? Function(String reason)? notFoundError,
    TResult? Function(String error)? methodNotAllowedError,
    TResult? Function(String error)? notAcceptableError,
    TResult? Function(String error)? requestTimeoutError,
    TResult? Function(String error)? sendTimeoutError,
    TResult? Function(String error)? conflictError,
    TResult? Function(String error)? internalServerError,
    TResult? Function(String error)? notImplementedError,
    TResult? Function(String error)? serviceUnavailableError,
    TResult? Function(String error)? noInternetConnectionError,
    TResult? Function(String error)? formatExceptionError,
    TResult? Function(String error)? unableToProcessError,
    TResult? Function(String error)? defaultError,
    TResult? Function(String error)? connectionError,
    TResult? Function(String error)? badCertificateError,
    TResult? Function(String error)? badResponseError,
    TResult? Function(String error)? unknownError,
    TResult? Function(String error)? unexpectedError,
    TResult? Function(String error)? connectionTimeOutError,
  }) {
    return connectionTimeOutError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? requestCancelledError,
    TResult Function(String reason)? unauthorizedRequestError,
    TResult Function(String error)? badRequestError,
    TResult Function(String reason)? notFoundError,
    TResult Function(String error)? methodNotAllowedError,
    TResult Function(String error)? notAcceptableError,
    TResult Function(String error)? requestTimeoutError,
    TResult Function(String error)? sendTimeoutError,
    TResult Function(String error)? conflictError,
    TResult Function(String error)? internalServerError,
    TResult Function(String error)? notImplementedError,
    TResult Function(String error)? serviceUnavailableError,
    TResult Function(String error)? noInternetConnectionError,
    TResult Function(String error)? formatExceptionError,
    TResult Function(String error)? unableToProcessError,
    TResult Function(String error)? defaultError,
    TResult Function(String error)? connectionError,
    TResult Function(String error)? badCertificateError,
    TResult Function(String error)? badResponseError,
    TResult Function(String error)? unknownError,
    TResult Function(String error)? unexpectedError,
    TResult Function(String error)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (connectionTimeOutError != null) {
      return connectionTimeOutError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(RequestCancelledError value)
        requestCancelledError,
    required TResult Function(UnauthorizedRequestError value)
        unauthorizedRequestError,
    required TResult Function(BadRequestError value) badRequestError,
    required TResult Function(NotFoundError value) notFoundError,
    required TResult Function(MethodNotAllowedError value)
        methodNotAllowedError,
    required TResult Function(NotAcceptableError value) notAcceptableError,
    required TResult Function(RequestTimeoutError value) requestTimeoutError,
    required TResult Function(SendTimeoutError value) sendTimeoutError,
    required TResult Function(ConflictError value) conflictError,
    required TResult Function(InternalServerError value) internalServerError,
    required TResult Function(NotImplementedError value) notImplementedError,
    required TResult Function(ServiceUnavailableError value)
        serviceUnavailableError,
    required TResult Function(NoInternetConnectionError value)
        noInternetConnectionError,
    required TResult Function(FormatExceptionError value) formatExceptionError,
    required TResult Function(UnableToProcessError value) unableToProcessError,
    required TResult Function(DefaultError value) defaultError,
    required TResult Function(ConnectionError value) connectionError,
    required TResult Function(BadCertificateError value) badCertificateError,
    required TResult Function(BadResponseError value) badResponseError,
    required TResult Function(UnknownError value) unknownError,
    required TResult Function(UnexpectedError value) unexpectedError,
    required TResult Function(ConnectionTimeOutError value)
        connectionTimeOutError,
  }) {
    return connectionTimeOutError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(RequestCancelledError value)? requestCancelledError,
    TResult? Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult? Function(BadRequestError value)? badRequestError,
    TResult? Function(NotFoundError value)? notFoundError,
    TResult? Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult? Function(NotAcceptableError value)? notAcceptableError,
    TResult? Function(RequestTimeoutError value)? requestTimeoutError,
    TResult? Function(SendTimeoutError value)? sendTimeoutError,
    TResult? Function(ConflictError value)? conflictError,
    TResult? Function(InternalServerError value)? internalServerError,
    TResult? Function(NotImplementedError value)? notImplementedError,
    TResult? Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult? Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult? Function(FormatExceptionError value)? formatExceptionError,
    TResult? Function(UnableToProcessError value)? unableToProcessError,
    TResult? Function(DefaultError value)? defaultError,
    TResult? Function(ConnectionError value)? connectionError,
    TResult? Function(BadCertificateError value)? badCertificateError,
    TResult? Function(BadResponseError value)? badResponseError,
    TResult? Function(UnknownError value)? unknownError,
    TResult? Function(UnexpectedError value)? unexpectedError,
    TResult? Function(ConnectionTimeOutError value)? connectionTimeOutError,
  }) {
    return connectionTimeOutError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(RequestCancelledError value)? requestCancelledError,
    TResult Function(UnauthorizedRequestError value)? unauthorizedRequestError,
    TResult Function(BadRequestError value)? badRequestError,
    TResult Function(NotFoundError value)? notFoundError,
    TResult Function(MethodNotAllowedError value)? methodNotAllowedError,
    TResult Function(NotAcceptableError value)? notAcceptableError,
    TResult Function(RequestTimeoutError value)? requestTimeoutError,
    TResult Function(SendTimeoutError value)? sendTimeoutError,
    TResult Function(ConflictError value)? conflictError,
    TResult Function(InternalServerError value)? internalServerError,
    TResult Function(NotImplementedError value)? notImplementedError,
    TResult Function(ServiceUnavailableError value)? serviceUnavailableError,
    TResult Function(NoInternetConnectionError value)?
        noInternetConnectionError,
    TResult Function(FormatExceptionError value)? formatExceptionError,
    TResult Function(UnableToProcessError value)? unableToProcessError,
    TResult Function(DefaultError value)? defaultError,
    TResult Function(ConnectionError value)? connectionError,
    TResult Function(BadCertificateError value)? badCertificateError,
    TResult Function(BadResponseError value)? badResponseError,
    TResult Function(UnknownError value)? unknownError,
    TResult Function(UnexpectedError value)? unexpectedError,
    TResult Function(ConnectionTimeOutError value)? connectionTimeOutError,
    required TResult orElse(),
  }) {
    if (connectionTimeOutError != null) {
      return connectionTimeOutError(this);
    }
    return orElse();
  }
}

abstract class ConnectionTimeOutError implements NetworkExceptions {
  const factory ConnectionTimeOutError(final String error) =
      _$ConnectionTimeOutErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ConnectionTimeOutErrorImplCopyWith<_$ConnectionTimeOutErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}
