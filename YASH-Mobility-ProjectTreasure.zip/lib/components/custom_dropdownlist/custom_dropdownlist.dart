import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';

class CustomDropDownList extends StatefulWidget {
  final String title;
  final String? value;
  final List<DropdownMenuItem<String>> dropdownItems;
  final void Function(String?)? onChanged;
  final String? errorMessage;

  const CustomDropDownList({
    super.key,
    required this.value,
    required this.dropdownItems,
    this.onChanged,
    required this.title,
    this.errorMessage,
  });

  @override
  State<CustomDropDownList> createState() => _CustomDropDownListState();
}

class _CustomDropDownListState extends State<CustomDropDownList> {
  bool isFocused = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (hasFocus) {
        setState(() {
          isFocused = hasFocus;
        });
      },
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(
              color: isFocused
                  ? AppColors.basicDetailTextFieldBorderColor
                  : AppColors.basicDetailTextFieldBorderColor,
            ),
            borderRadius: BorderRadius.circular(Dimensions.borderRadius_5)),
        child: DropdownButtonFormField(
          style:
              TextStyle(color: AppColors.black, fontSize: Dimensions.font_16),
          decoration: InputDecoration(
            border: InputBorder.none,
            labelText: widget.title,
            labelStyle: TextStyle(
                color: AppColors.createProjectAppBarColor,
                fontSize: Dimensions.font_16),
            contentPadding: EdgeInsets.only(
                left: Dimensions.padding_16,
                top: Dimensions.padding_12,
                bottom: Dimensions.padding_12),
          ),
          icon: Padding(
            padding: EdgeInsets.only(right: Dimensions.padding_8),
            child: Icon(
              Icons.keyboard_arrow_down,
              color: AppColors.createProjectAppBarColor,
            ),
          ),
          dropdownColor: AppColors.white,
          value: widget.value,
          onChanged: (String? newValue) {
            if (widget.onChanged != null) {
              widget.onChanged!(newValue);
            }
          },
          items: widget.dropdownItems,
          validator: (value) => value == null ? widget.errorMessage : null,
        ),
      ),
    );
  }
}

/// MultiSelection dropdown list

class MultiSelect extends StatefulWidget {
  final List<MultiSelectionFiltersData?> items;
  final String alertDialogTitle;
  final String dKey;
  const MultiSelect({
    super.key,
    required this.dKey,
    required this.items,
    required this.alertDialogTitle,
  });

  @override
  State<MultiSelect> createState() => _MultiSelectState();
}

class _MultiSelectState extends State<MultiSelect> {
  final List<MultiSelectionFiltersData?> _selectedItems = [];
  List<String> list = [];
  List<String> selectedItemsNames = [];

  bool get isAnyCheckboxSelected => _selectedItems.isNotEmpty;

  @override
  void initState() {
    super.initState();

    if (SharedPrefs.instance.getString(widget.dKey) != null) {
      if (getSelectedItems(jsonDecode(SharedPrefs.instance.getString(widget.dKey) ?? "") ?? []).data!.isNotEmpty) {
        for (var i = 0; i < getSelectedItems(jsonDecode(SharedPrefs.instance.getString(widget.dKey) ?? "") ?? []).data!.length;
        i++) {
          _selectedItems.add(getSelectedItems(jsonDecode(SharedPrefs.instance.getString(widget.dKey) ?? "") ?? []).data![i]!);
          selectedItemsNames.add(getSelectedItems(jsonDecode(SharedPrefs.instance.getString(widget.dKey) ?? "") ?? []).data![i]!.attributes!.name!);
        }
      }
    }
  }

  MultiSelectionFilters getSelectedItems(List<dynamic> list) {
    List<Map<String, dynamic>> storedItems = [];
    for (var i = 0; i < list.length; i++) {
      storedItems.add(list[i]);
    }
    var m = {"data": storedItems};
    var n = MultiSelectionFilters.fromJson(m);

    return n;
  }

  void _itemChange(MultiSelectionFiltersData itemValue, bool isSelected) {
    if (isSelected == true) {
      setState(() {
        _selectedItems.add(itemValue);
        selectedItemsNames.add(itemValue.attributes!.name!);
        list.add(jsonEncode(itemValue));
        var save = jsonEncode(list);
        SharedPrefs.instance.setString(widget.dKey, save);
      });
    } else {
      setState(() {
        selectedItemsNames.remove(itemValue.attributes!.name!);
        _selectedItems.removeWhere((item) => item!.id == itemValue.id);
        list.remove(jsonEncode(itemValue));
        var save = jsonEncode(list);
        SharedPrefs.instance.setString(widget.dKey, save);
      });
    }
  }

  void _cancel() {
    Navigator.pop(context);
  }

  void _submit() {
    setState(() {});
    SharedPrefs.instance.setString(widget.dKey, jsonEncode(_selectedItems));
    Navigator.pop(context, _selectedItems);
  }

  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  @override
  Widget build(BuildContext context) {
    Color saveButtonColor = isAnyCheckboxSelected
        ? AppColors.createProjectAppBarColor
        : AppColors.grey;
    return AlertDialog(
      shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.all(Radius.circular(Dimensions.borderRadius_0))),
      backgroundColor: AppColors.white,
      title: Text(widget.alertDialogTitle),
      content: SingleChildScrollView(
        child: SizedBox(
          width: getSize(context).width,
          child: ListBody(
              children: widget.items.map((item) {
            return CheckboxListTile(
              value: selectedItemsNames.contains(item!.attributes!.name) ? true : false,
              activeColor: AppColors.bottomSheetTabColor,
              title: Text(item.attributes!.name!.toTitleCase()),
              controlAffinity: ListTileControlAffinity.leading,
              onChanged: (isChecked) {
                _itemChange(item, isChecked!);
              },
            );
          }).toList()),
        ),
      ),
      actions: [
        TextButton(
            onPressed: _cancel,
            child: Text(
              Strings().multiDialogCancelButtonTitle,
              style: TextStyle(color: AppColors.createProjectAppBarColor),
            )),
        ElevatedButton(
          onPressed: _submit,
          style: ElevatedButton.styleFrom(backgroundColor: saveButtonColor),
          child: Text(
            Strings().multiDialogSaveButtonTitle,
            style: TextStyle(
              color: AppColors.white,
            ),
          ),
        )
      ],
    );
  }
}

class MultiDropDown extends StatefulWidget {
  final List<MultiSelectionFiltersData?>? controller;
  final List<MultiSelectionFiltersData?> items;
  final String title;
  final String dKey;
  final String alertDialogTitle;
  final double height;
  final double width;
  final void Function(List<MultiSelectionFiltersData?>)? onSelectionChanged;

  const MultiDropDown({
    super.key,
    this.controller,
    required this.dKey,
    required this.items,
    required this.title,
    required this.alertDialogTitle,
    required this.height,
    required this.width,
    this.onSelectionChanged,
  });
  @override
  State<MultiDropDown> createState() => _MultiDropDownState();
}

class _MultiDropDownState extends State<MultiDropDown> {
  TextEditingController textEditingController = TextEditingController();

  List<MultiSelectionFiltersData?> selectedItems = [];

  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  @override
  void initState() {
    super.initState();
    if (SharedPrefs.instance.getString(widget.dKey) != null) {
      if (getSelectedItems(
              jsonDecode(SharedPrefs.instance.getString(widget.dKey)!) ?? [])
          .data!
          .isNotEmpty && SharedPrefs.instance.getString(widget.dKey)! != "[]") {
        for (var i = 0; i < getSelectedItems(jsonDecode(SharedPrefs.instance.getString(widget.dKey!)!) ?? []).data!.length; i++) {
          selectedItems.add(getSelectedItems(
                  jsonDecode(SharedPrefs.instance.getString(widget.dKey)!) ??
                      [])
              .data![i]!);
        }
      }
    }
  }

  MultiSelectionFilters getSelectedItems(List<dynamic> list) {
    List<Map<String, dynamic>> storedItems = [];
    for (var i = 0; i < list.length; i++) {
      var items = (list[i]);
      storedItems.add(items);
    }
    var m = {"data": storedItems};
    var n = MultiSelectionFilters.fromJson(m);
    return (n);
  }

  void _showMultiSelect() async {
    setState(() {});
    selectedItems = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return MultiSelect(
          items: widget.items,
          alertDialogTitle: widget.alertDialogTitle,
          dKey: widget.dKey,
        );
      },
    );

    print("selectedItems: ${selectedItems.length}");


    if (selectedItems != []) {
      widget.onSelectionChanged!(selectedItems);
    }
  }

  bool isFocused = false;

  @override
  Widget build(BuildContext context) {
    print("selectedItems: ${selectedItems.length}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Focus(
          onFocusChange: (hasFocus) {
            setState(() {
              isFocused = hasFocus;
            });
          },
          child: Container(
            width: getSize(context).width,
            decoration: BoxDecoration(
                border: Border.all(
                  color: isFocused
                      ? AppColors.createProjectAppBarColor
                      : AppColors.basicDetailTextFieldBorderColor,
                ),
                borderRadius: BorderRadius.circular(Dimensions.borderRadius_5)),
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                  Dimensions.padding_0,
                  Dimensions.padding_8,
                  Dimensions.padding_5,
                  Dimensions.padding_8),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: getSize(context).width,
                          child: TextButton(
                            onPressed: widget.items.isEmpty
                                ? null
                                : () async {
                                    FocusScope.of(context)
                                        .requestFocus(FocusNode());
                                    setState(() {
                                      _showMultiSelect();
                                    });
                                  },
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                widget.title,
                                style: TextStyle(
                                  color: AppColors.createProjectAppBarColor,
                                  fontSize: selectedItems.isEmpty
                                      ? Dimensions.font_16
                                      : Dimensions.font_12,
                                ),
                              ),
                            ),
                          ),
                        ),
                        //if (selectedItems[0]!.attributes!.name != "[]")
                        Padding(
                          padding: EdgeInsets.only(left: Dimensions.padding_8),
                          child: Wrap(
                            spacing: Dimensions.padding_8,
                            runSpacing: Dimensions.padding_8,
                            children:
                            selectedItems.isNotEmpty
                                ?
                            selectedItems
                                    .map(
                                      (e) => Container(
                                        width: widget.width,
                                        decoration: BoxDecoration(
                                          color: AppColors.itemBodyButtonColor,
                                          border: Border.all(
                                              color: AppColors
                                                  .itemBorderButtonColor),
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.borderRadius_5),
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.all(
                                              Dimensions.borderRadius_8),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              //if (e!.attributes!.name != "[]")
                                              Expanded(
                                                child: Text(
                                                    e!.attributes!.name!
                                                        .toTitleCase(),
                                                    style: TextStyle(
                                                        color: AppColors
                                                            .projectBody)),
                                              ),
                                             // if (e.attributes!.name != "[]")
                                              InkWell(
                                                onTap: () {
                                                  selectedItems.removeWhere((item) => item!.id == e.id);
                                                  setState(() {
                                                    SharedPrefs.instance
                                                        .setString(
                                                        widget.dKey,
                                                        jsonEncode(
                                                            selectedItems));
                                                  });
                                                },
                                                child: Icon(
                                                  Icons.cancel_outlined,
                                                  color: AppColors
                                                      .itemRemoveButtonColor,
                                                  size: Dimensions.iconSize_20,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                    .toList()
                                : widget.controller!
                                    .map(
                                      (e) => Container(
                                        height: widget.height,
                                        width: widget.width,
                                        decoration: BoxDecoration(
                                          color: AppColors.itemBodyButtonColor,
                                          border: Border.all(
                                              color: AppColors
                                                  .itemBorderButtonColor),
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.borderRadius_5),
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.all(
                                              Dimensions.borderRadius_8),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(e!.attributes!.name!.toTitleCase(),
                                                  style: TextStyle(
                                                      color: AppColors
                                                          .projectBody)),
                                              InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    widget.controller!
                                                        .remove(e);
                                                  });
                                                },
                                                child: Icon(
                                                  Icons.cancel_outlined,
                                                  color: AppColors
                                                      .itemRemoveButtonColor,
                                                  size: Dimensions.iconSize_20,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                    .toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(15, 8, 10, 8),
                    child: widget.items.isEmpty
                        ? Center(
                            child: SizedBox(
                                height: Dimensions.height_20,
                                width: Dimensions.width_20,
                                child: const CircularProgressIndicator()))
                        : InkWell(
                            onTap: () {
                              FocusScope.of(context).requestFocus(FocusNode());
                              setState(() {
                                _showMultiSelect();
                              });
                            },
                            child: const Icon(Icons.keyboard_arrow_down)),
                  )
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
