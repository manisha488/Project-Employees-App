class ProposalListPagination {
  int? page;
  int? pageSize;
  int? pageCount;
  int? total;

  ProposalListPagination({
    this.page,
    this.pageSize,
    this.pageCount,
    this.total,
  });
  ProposalListPagination.fromJson(Map<String, dynamic> json) {
    page = json['page']?.toInt();
    pageSize = json['pageSize']?.toInt();
    pageCount = json['pageCount']?.toInt();
    total = json['total']?.toInt();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['pageCount'] = pageCount;
    data['total'] = total;
    return data;
  }
}

class ProposalListDataUpdatedBy {
  int? id;
  String? firstname;
  String? lastname;
  String? username;
  String? email;
  String? password;
  String? resetPasswordToken;
  String? registrationToken;
  bool? isActive;
  bool? blocked;
  String? preferedLanguage;
  String? createdAt;
  String? updatedAt;

  ProposalListDataUpdatedBy({
    this.id,
    this.firstname,
    this.lastname,
    this.username,
    this.email,
    this.password,
    this.resetPasswordToken,
    this.registrationToken,
    this.isActive,
    this.blocked,
    this.preferedLanguage,
    this.createdAt,
    this.updatedAt,
  });
  ProposalListDataUpdatedBy.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    firstname = json['firstname']?.toString();
    lastname = json['lastname']?.toString();
    username = json['username']?.toString();
    email = json['email']?.toString();
    password = json['password']?.toString();
    resetPasswordToken = json['resetPasswordToken']?.toString();
    registrationToken = json['registrationToken']?.toString();
    isActive = json['isActive'];
    blocked = json['blocked'];
    preferedLanguage = json['preferedLanguage']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['username'] = username;
    data['email'] = email;
    data['password'] = password;
    data['resetPasswordToken'] = resetPasswordToken;
    data['registrationToken'] = registrationToken;
    data['isActive'] = isActive;
    data['blocked'] = blocked;
    data['preferedLanguage'] = preferedLanguage;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class ProposalListDataCreatedBy {
  int? id;
  String? firstname;
  String? lastname;
  String? username;
  String? email;
  String? password;
  String? resetPasswordToken;
  String? registrationToken;
  bool? isActive;
  bool? blocked;
  String? preferedLanguage;
  String? createdAt;
  String? updatedAt;

  ProposalListDataCreatedBy({
    this.id,
    this.firstname,
    this.lastname,
    this.username,
    this.email,
    this.password,
    this.resetPasswordToken,
    this.registrationToken,
    this.isActive,
    this.blocked,
    this.preferedLanguage,
    this.createdAt,
    this.updatedAt,
  });
  ProposalListDataCreatedBy.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    firstname = json['firstname']?.toString();
    lastname = json['lastname']?.toString();
    username = json['username']?.toString();
    email = json['email']?.toString();
    password = json['password']?.toString();
    resetPasswordToken = json['resetPasswordToken']?.toString();
    registrationToken = json['registrationToken']?.toString();
    isActive = json['isActive'];
    blocked = json['blocked'];
    preferedLanguage = json['preferedLanguage']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['username'] = username;
    data['email'] = email;
    data['password'] = password;
    data['resetPasswordToken'] = resetPasswordToken;
    data['registrationToken'] = registrationToken;
    data['isActive'] = isActive;
    data['blocked'] = blocked;
    data['preferedLanguage'] = preferedLanguage;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class ProposalListDataStatus {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalListDataStatus({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalListDataStatus.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalListDataResources {
  int? id;
  String? resourceName;
  String? designation;
  String? resourceEmail;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;

  ProposalListDataResources({
    this.id,
    this.resourceName,
    this.designation,
    this.resourceEmail,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
  });
  ProposalListDataResources.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    resourceName = json['resource_name']?.toString();
    designation = json['designation']?.toString();
    resourceEmail = json['resource_email']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['resource_name'] = resourceName;
    data['designation'] = designation;
    data['resource_email'] = resourceEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    return data;
  }
}

class ProposalListDataTechnologies {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalListDataTechnologies({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalListDataTechnologies.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalListDataPlatforms {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalListDataPlatforms({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalListDataPlatforms.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalListDataFunctionalities {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalListDataFunctionalities({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalListDataFunctionalities.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalListDataDomain {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;

  ProposalListDataDomain({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
  });
  ProposalListDataDomain.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    return data;
  }
}

class ProposalListData {
  int? id;
  String? proposalReceivedDate;
  String? proposalSubmittedDate;
  String? clientDetails;
  String? riskFactors;
  String? dependencies;
  String? documents;
  String? feedback;
  String? createdAt;
  String? updatedAt;
  String? publishedAt;
  String? name;
  String? objectives;
  String? summery;
  String? comments;
  ProposalListDataDomain? domain;
  List<ProposalListDataFunctionalities?>? functionalities;
  List<ProposalListDataPlatforms?>? platforms;
  List<ProposalListDataTechnologies?>? technologies;
  List<ProposalListDataResources?>? resources;
  ProposalListDataStatus? status;
  ProposalListDataCreatedBy? createdBy;
  ProposalListDataUpdatedBy? updatedBy;

  ProposalListData({
    this.id,
    this.proposalReceivedDate,
    this.proposalSubmittedDate,
    this.clientDetails,
    this.riskFactors,
    this.dependencies,
    this.documents,
    this.feedback,
    this.createdAt,
    this.updatedAt,
    this.publishedAt,
    this.name,
    this.objectives,
    this.summery,
    this.comments,
    this.domain,
    this.functionalities,
    this.platforms,
    this.technologies,
    this.resources,
    this.status,
    this.createdBy,
    this.updatedBy,
  });
  ProposalListData.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toInt();
    proposalReceivedDate = json['proposal_received_date']?.toString();
    proposalSubmittedDate = json['proposal_submitted_date']?.toString();
    clientDetails = json['client_details']?.toString();
    riskFactors = json['risk_factors']?.toString();
    dependencies = json['dependencies']?.toString();
    documents = json['documents']?.toString();
    feedback = json['feedback']?.toString();
    createdAt = json['createdAt']?.toString();
    updatedAt = json['updatedAt']?.toString();
    publishedAt = json['publishedAt']?.toString();
    name = json['name']?.toString();
    objectives = json['objectives']?.toString();
    summery = json['summery']?.toString();
    comments = json['comments']?.toString();
    domain = (json['domain'] != null)
        ? ProposalListDataDomain.fromJson(json['domain'])
        : null;
    if (json['functionalities'] != null) {
      final v = json['functionalities'];
      final arr0 = <ProposalListDataFunctionalities>[];
      v.forEach((v) {
        arr0.add(ProposalListDataFunctionalities.fromJson(v));
      });
      functionalities = arr0;
    }
    if (json['platforms'] != null) {
      final v = json['platforms'];
      final arr0 = <ProposalListDataPlatforms>[];
      v.forEach((v) {
        arr0.add(ProposalListDataPlatforms.fromJson(v));
      });
      platforms = arr0;
    }
    if (json['technologies'] != null) {
      final v = json['technologies'];
      final arr0 = <ProposalListDataTechnologies>[];
      v.forEach((v) {
        arr0.add(ProposalListDataTechnologies.fromJson(v));
      });
      technologies = arr0;
    }
    if (json['resources'] != null) {
      final v = json['resources'];
      final arr0 = <ProposalListDataResources>[];
      v.forEach((v) {
        arr0.add(ProposalListDataResources.fromJson(v));
      });
      resources = arr0;
    }
    status = (json['status'] != null)
        ? ProposalListDataStatus.fromJson(json['status'])
        : null;
    createdBy = (json['createdBy'] != null)
        ? ProposalListDataCreatedBy.fromJson(json['createdBy'])
        : null;
    updatedBy = (json['updatedBy'] != null)
        ? ProposalListDataUpdatedBy.fromJson(json['updatedBy'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['proposal_received_date'] = proposalReceivedDate;
    data['proposal_submitted_date'] = proposalSubmittedDate;
    data['client_details'] = clientDetails;
    data['risk_factors'] = riskFactors;
    data['dependencies'] = dependencies;
    data['documents'] = documents;
    data['feedback'] = feedback;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['publishedAt'] = publishedAt;
    data['name'] = name;
    data['objectives'] = objectives;
    data['summery'] = summery;
    data['comments'] = comments;
    if (domain != null) {
      data['domain'] = domain!.toJson();
    }
    if (functionalities != null) {
      final v = functionalities;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['functionalities'] = arr0;
    }
    if (platforms != null) {
      final v = platforms;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['platforms'] = arr0;
    }
    if (technologies != null) {
      final v = technologies;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['technologies'] = arr0;
    }
    if (resources != null) {
      final v = resources;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['resources'] = arr0;
    }
    if (status != null) {
      data['status'] = status!.toJson();
    }
    if (createdBy != null) {
      data['createdBy'] = createdBy!.toJson();
    }
    if (updatedBy != null) {
      data['updatedBy'] = updatedBy!.toJson();
    }
    return data;
  }
}

class ProposalList {
  List<ProposalListData?>? data;
  ProposalListPagination? pagination;

  ProposalList({
    this.data,
    this.pagination,
  });
  ProposalList.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      final v = json['data'];
      final arr0 = <ProposalListData>[];
      v.forEach((v) {
        arr0.add(ProposalListData.fromJson(v));
      });
      this.data = arr0;
    }
    pagination = (json['pagination'] != null)
        ? ProposalListPagination.fromJson(json['pagination'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (this.data != null) {
      final v = this.data;
      final arr0 = [];
      v!.forEach((v) {
        arr0.add(v!.toJson());
      });
      data['data'] = arr0;
    }
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    return data;
  }
}
