import 'package:flutter/material.dart';
import 'package:yash_mobility_project_treasure/components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';

import '../../../model/response/proposals_list.dart';

class ProposalDetailsScreen extends StatefulWidget {
  final ProposalsDataAttributes? proposalData;

  const ProposalDetailsScreen({super.key, required this.proposalData});

  @override
  State<ProposalDetailsScreen> createState() => _ProposalDetailsScreenState();
}

class _ProposalDetailsScreenState extends State<ProposalDetailsScreen>
    with TickerProviderStateMixin {
  late final TabController _tabController;
  late final TabController _docController;
  bool isExpand = false;
  bool isExpanded = false;
  List<String> dummyFiles = [
    'First file',
    'Second File',
    'First file',
    'Second File',
    'First file',
    'Second File',
    'First file',
    'Second File',
    'First file',
    'Second File'
  ];

  @override
  void initState() {
    _tabController =
        TabController(length: Dimensions.tabBarIndexLength_3, vsync: this);
    _docController = TabController(length: Dimensions.tabsCount_1, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// Method to get colors with respect to the project status.
  Color _getColors(String status) {
    if (status == Strings().inProgressStatus) {
      return AppColors.inProgressStatus;
    } else if (status == Strings().onHoldStatus) {
      return AppColors.onHoldStatus;
    } else if (status == Strings().cancelledStatus) {
      return AppColors.cancelledStatus;
    } else if (status == Strings().notStartedStatus.toTitleCase()) {
      return AppColors.notStartedStatus;
    } else if (status == Strings().completedStatus) {
      return AppColors.completeStatus;
    } else if (status == Strings().inCompletedStatus) {
      return AppColors.incompleteStatus;
    } else if (status == Strings().overdueStatus) {
      return AppColors.overdueStatus;
    } else if (status == Strings().approvedStatus) {
      return AppColors.approvedStatus;
    } else {
      return AppColors.white;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            widget.proposalData!.name.toString(),
            maxLines: Dimensions.maxTextLines_1,
            textAlign: TextAlign.center,
            style:
                TextStyle(color: AppColors.white, fontSize: Dimensions.font_20),
          ),
          centerTitle: false,
          backgroundColor: AppColors.appBottomNavigationBar,
          actions: [
            IconButton(
                onPressed: () {
                  ShowBottomSheet.getInstance.showUploadedDocuments(
                      context, dummyFiles, _docController);
                },
                icon: Icon(
                  Icons.attach_file,
                  color: AppColors.white,
                )),
          ],
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back,
                color: AppColors.white,
              ))),
      body: Column(
        children: [
          Container(
            color: AppColors.tabBarBackground,
            height: Dimensions.height_50,
            child: TabBar(
                controller: _tabController,
                labelPadding: EdgeInsets.only(right: Dimensions.padding_5),
                padding: EdgeInsets.zero,
                indicatorColor: AppColors.appBottomNavigationBar,
                indicatorPadding: EdgeInsets.zero,
                labelColor: AppColors.appBottomNavigationBar,
                indicatorSize: TabBarIndicatorSize.tab,
                unselectedLabelStyle: TextStyle(
                    color: AppColors.appBottomNavigationBar,
                    fontWeight: FontWeight.normal,
                    fontSize: Dimensions.font_14),
                labelStyle: TextStyle(
                    color: AppColors.appBottomNavigationBar,
                    fontWeight: FontWeight.w600,
                    fontSize: Dimensions.font_14),
                tabs: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_0,
                        right: Dimensions.padding_0),
                    child: Text(
                      Strings().basicDetailsText,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_0,
                        right: Dimensions.padding_0),
                    child: Text(
                      Strings().technicalInfoText,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Dimensions.padding_0,
                        right: Dimensions.padding_0),
                    child: Text(
                      Strings().additionalDetailsText,
                      maxLines: Dimensions.maxTextLines_1,
                    ),
                  ),
                ]),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(Dimensions.padding_10),
              child: TabBarView(controller: _tabController, children: [
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      detailsTextFields(Strings().proposalName,
                          widget.proposalData!.name.toString()),
                      detailsTextFields(
                        Strings().domainText,
                        widget.proposalData!.domain!.data!.attributes!.name!
                            .toTitleCase(),
                      ),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().objectiveText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpanded = !isExpanded;
                                });
                              },
                              child: AnimatedCrossFade(
                                duration: Duration(
                                    milliseconds: Dimensions.milliseconds_500),
                                firstChild: Text(
                                  maxLines: Dimensions.minLength_4,
                                  overflow: TextOverflow.ellipsis,
                                  widget.proposalData!.objectives!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                                crossFadeState: isExpanded
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                secondChild: Text(
                                  widget.proposalData!.objectives!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().summaryText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpand = !isExpand;
                                });
                              },
                              child: AnimatedCrossFade(
                                duration: Duration(
                                    milliseconds: Dimensions.milliseconds_500),
                                firstChild: Text(
                                  maxLines: Dimensions.minLength_4,
                                  overflow: TextOverflow.ellipsis,
                                  widget.proposalData!.summery!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                                crossFadeState: isExpand
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                secondChild: Text(
                                  widget.proposalData!.summery!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      detailsTextFields(
                          Strings().functionalityText,
                          widget.proposalData!.functionalities!.data!.first!
                              .attributes!.name!
                              .toTitleCase()),
                      detailsTextFields(Strings().startDateText,
                          widget.proposalData!.proposalReceivedDate!),
                      detailsTextFields(Strings().endDateText,
                          widget.proposalData!.proposalSubmittedDate!),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().statusText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            Container(
                                decoration: BoxDecoration(
                                    color: _getColors(widget.proposalData!
                                        .status!.data!.attributes!.name!
                                        .toTitleCase()),
                                    borderRadius: BorderRadius.circular(
                                        Dimensions.borderRadius_20)),
                                child: Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        Dimensions.padding_10,
                                        Dimensions.padding_5,
                                        Dimensions.padding_10,
                                        Dimensions.padding_5),
                                    child: Text(widget.proposalData!.status!
                                        .data!.attributes!.name!
                                        .toTitleCase()
                                        .toString())))
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      detailsTextFields(
                          Strings().platformText,
                          widget.proposalData!.platforms!.data!.first!
                              .attributes!.name!
                              .toTitleCase()),
                      detailsTextFields(
                          Strings().technologyText,
                          widget.proposalData!.technologies!.data!.first!
                              .attributes!.name!
                              .toTitleCase()),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().riskFactorText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpanded = !isExpanded;
                                });
                              },
                              child: AnimatedCrossFade(
                                duration: Duration(
                                    milliseconds: Dimensions.milliseconds_500),
                                firstChild: Text(
                                  maxLines: Dimensions.minLength_4,
                                  overflow: TextOverflow.ellipsis,
                                  widget.proposalData!.riskFactors!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                                crossFadeState: isExpanded
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                secondChild: Text(
                                  widget.proposalData!.riskFactors!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().dependenciesText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpand = !isExpand;
                                });
                              },
                              child: AnimatedCrossFade(
                                duration: Duration(
                                    milliseconds: Dimensions.milliseconds_500),
                                firstChild: Text(
                                  maxLines: Dimensions.minLength_4,
                                  overflow: TextOverflow.ellipsis,
                                  widget.proposalData!.dependencies!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                                crossFadeState: isExpand
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                secondChild: Text(
                                  widget.proposalData!.dependencies!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      detailsTextFields(Strings().clientsNameText,
                          widget.proposalData!.clientDetails!.toTitleCase()),
                      detailsTextFields(
                          Strings().projectResourceText,
                          widget.proposalData!.resources!.data!.first!
                              .attributes!.resourceName!
                              .toTitleCase()),
                      detailsTextFields(
                          Strings().projectResourceEmailText,
                          widget.proposalData!.resources!.data!.first!
                              .attributes!.resourceEmail!
                              .toTitleCase()),
                      detailsTextFields(
                          Strings().projectDesignationText,
                          widget.proposalData!.resources!.data!.first!
                              .attributes!.designation!
                              .toTitleCase()),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().commentsText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpanded = !isExpanded;
                                });
                              },
                              child: AnimatedCrossFade(
                                duration: Duration(
                                    milliseconds: Dimensions.milliseconds_500),
                                firstChild: Text(
                                  maxLines: Dimensions.minLength_4,
                                  overflow: TextOverflow.ellipsis,
                                  widget.proposalData!.comments!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                                crossFadeState: isExpanded
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                secondChild: Text(
                                  widget.proposalData!.comments!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(Dimensions.padding_10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings().feedbackText,
                              style: TextStyle(
                                color: AppColors.titleColor,
                                fontSize: Dimensions.font_12,
                              ),
                            ),
                            SizedBox(
                              height: Dimensions.height_8,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  isExpand = !isExpand;
                                });
                              },
                              child: AnimatedCrossFade(
                                duration: Duration(
                                    milliseconds: Dimensions.milliseconds_500),
                                firstChild: Text(
                                  maxLines: Dimensions.minLength_4,
                                  overflow: TextOverflow.ellipsis,
                                  widget.proposalData!.feedback!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                                crossFadeState: isExpand
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                secondChild: Text(
                                  widget.proposalData!.feedback!.trim(),
                                  style: TextStyle(
                                      color: AppColors.subTitleColor,
                                      fontSize: Dimensions.font_16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ]),
            ),
          )
        ],
      ),
    );
  }
}

/// This widget is used to showcase all detailsTextField
Widget detailsTextFields(String title, String subtitle) {
  return Padding(
    padding: EdgeInsets.all(Dimensions.padding_10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: AppColors.titleColor,
            fontSize: Dimensions.font_12,
          ),
        ),
        SizedBox(
          height: Dimensions.height_8,
        ),
        Text(
          subtitle,
          style: TextStyle(
              color: AppColors.subTitleColor, fontSize: Dimensions.font_16),
        )
      ],
    ),
  );
}
