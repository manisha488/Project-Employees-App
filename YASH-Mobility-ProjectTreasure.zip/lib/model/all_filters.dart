class AllFilters {
  final String title;
  AllFilters(this.title);
}