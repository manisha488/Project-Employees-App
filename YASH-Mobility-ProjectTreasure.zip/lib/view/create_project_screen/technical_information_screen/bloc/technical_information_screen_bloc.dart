import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/services/network_exceptions.dart';

part 'technical_information_screen_event.dart';
part 'technical_information_screen_state.dart';

class TechnicalInformationScreenBloc
    extends Bloc<TechnicalInformationEvent, TechnicalInformationState> {
  final db = CustomDataBaseWrapper();
  TechnicalInformationScreenBloc() : super(TechnicalInfoInitialState()) {
    on<TechnicalInformationEvent>((event, emit) {});
    on<TechnicalInfoAttachmentBtnEvent>(technicalInfoAttachmentBtnEvent);
    on<TechnicalInfoSaveBtnEvent>(technicalInfoSaveBtnEvent);
    on<NavigateTechInfoToAdditionalDetailEvent>(
        navigateTechInfoToAdditionalDetailEvent);
    on<PlatformLoadedEvent>(platformLoadedEvent);
    on<TechnologyLoadedEvent>(technologyLoadedEvent);
    on<ProjectMethodologyEvent>(projectMethodologyEvent);
  }

  /// Event for Technical information Attachment button.
  FutureOr<void> technicalInfoAttachmentBtnEvent(
      TechnicalInfoAttachmentBtnEvent event,
      Emitter<TechnicalInformationState> emit) {
    emit(TechnicalInfoAttachmentBtnState());
  }

  /// Event for Technical information Save button.
  FutureOr<void> technicalInfoSaveBtnEvent(TechnicalInfoSaveBtnEvent event,
      Emitter<TechnicalInformationState> emit) {
    emit(TechnicalInfoSaveBtnState());
  }

  ///Event for Navigation from Technical information screen to Additional detail screen.
  FutureOr<void> navigateTechInfoToAdditionalDetailEvent(
      NavigateTechInfoToAdditionalDetailEvent event,
      Emitter<TechnicalInformationState> emit) {
    emit(NavigateTechInfoToAdditionalDetailState());
  }

  ///Event for Platform dropdown list.
  FutureOr<void> platformLoadedEvent(PlatformLoadedEvent event,
      Emitter<TechnicalInformationState> emit) async {
    List<MultiSelectionFiltersData>? offlinePlatforms;
    await db.getData('platforms').then((value) {
      offlinePlatforms = value;
    });
    emit(PlatformLoadedState(offlinePlatforms!));
  }

  ///Event for Technology dropdown list.
  FutureOr<void> technologyLoadedEvent(TechnologyLoadedEvent event,
      Emitter<TechnicalInformationState> emit) async {
    List<MultiSelectionFiltersData>? offlineTech;
    await db.getData('technologies').then((value) {
      offlineTech = value;
    });
    emit(TechnologyLoadedState(offlineTech!));
  }

  ///Event for Project Management Methodology dropdown list.
  FutureOr<void> projectMethodologyEvent(ProjectMethodologyEvent event,
      Emitter<TechnicalInformationState> emit) async {
    List<MultiSelectionFiltersData>? offlineMethodologies;
    await db.getData('methodologies').then((value) {
      offlineMethodologies = value;
    });
    emit(ProjectMethodologyState(offlineMethodologies!));
  }
}
