part of 'sub_filters_bloc.dart';

@immutable
abstract class SubFiltersState {}

class SubFiltersInitial extends SubFiltersState {}

class SubFiltersActionState extends SubFiltersState{}

class NoInternetState extends SubFiltersState{
  final NetworkExceptions exceptions;
  NoInternetState(this.exceptions);
}

class LoadingState extends SubFiltersState {}

class ProjectNamesFiltersLoadedState extends SubFiltersState{
  final List<ProjectsData> projectNames;
  ProjectNamesFiltersLoadedState(this.projectNames) ;
}

class ProposalsNamesFiltersLoadedState extends SubFiltersState{
  final List<ProposalsData> proposalNames;
  ProposalsNamesFiltersLoadedState(this.proposalNames);
}
class DateFiltersClickedState extends SubFiltersState{}

class ResourceNameFiltersClickedState extends SubFiltersState{
  final List<ResourcesListData> resourceNamesFilters;
  ResourceNameFiltersClickedState(this.resourceNamesFilters) ;
}

class DocumentFiltersLoadedState extends SubFiltersState{
  final List<DummyMultiselectFilters> documentFilters;
  DocumentFiltersLoadedState(this.documentFilters) ;
}

class FiltersLoadingState extends SubFiltersState {

}
class OfflineTechnologiesLoadedState extends SubFiltersState {
  final List<MultiSelectionFiltersData?> offlineTech;
  OfflineTechnologiesLoadedState(this.offlineTech) ;
}
class OfflineStatusLoadedState extends SubFiltersState {
  final List<MultiSelectionFiltersData?> offlineStatus;
  OfflineStatusLoadedState(this.offlineStatus) ;
}
class OfflinePlatformsLoadedState extends SubFiltersState {
  final List<MultiSelectionFiltersData?> offlinePlatforms;
  OfflinePlatformsLoadedState(this.offlinePlatforms) ;
}
class OfflineFunctionalitiesLoadedState extends SubFiltersState {
  final List<MultiSelectionFiltersData?> offlineFunctionalities;
  OfflineFunctionalitiesLoadedState(this.offlineFunctionalities) ;
}
class OfflineDomainsLoadedState extends SubFiltersState {
  final List<MultiSelectionFiltersData?> offlineDomains;
  OfflineDomainsLoadedState(this.offlineDomains) ;
}

