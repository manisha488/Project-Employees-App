import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:meta/meta.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/services/network_exceptions.dart';

part 'basic_details_screen_event.dart';
part 'basic_details_screen_state.dart';

class BasicDetailsScreenBloc extends Bloc<BasicDetailEvent, BasicDetailState> {
  final db = CustomDataBaseWrapper();
  BasicDetailsScreenBloc() : super(BasicDetailInitialState()) {
    on<BasicDetailEvent>((event, emit) {});
    on<BasicDetailAttachmentBtnEvent>(basicDetailAttachmentBtnEvent);
    on<BasicDetailSaveBtnEvent>(basicDetailSaveBtnEvent);
    on<NavigateBasicDetailToTechInfoEvent>(navigateBasicDetailToTechInfoEvent);
    on<DomainLoadedEvent>(domainLoadedEvent);
    on<FunctionalityLoadedEvent>(functionalityLoadedEvent);
    on<StatusLoadedEvent>(statusLoadedEvent);
  }

  /// Event for Basic detail screen Attachment button.
  FutureOr<void> basicDetailAttachmentBtnEvent(
      BasicDetailAttachmentBtnEvent event, Emitter<BasicDetailState> emit) {
    emit(BasicDetailAttachmentBtnState());
  }

  /// Event for Basic detail screen Save button.
  FutureOr<void> basicDetailSaveBtnEvent(
      BasicDetailSaveBtnEvent event, Emitter<BasicDetailState> emit) {
    emit(BasicDetailSaveBtnState());
  }

  /// Event for Navigation from Basic detail screen to Technical information screen.
  FutureOr<void> navigateBasicDetailToTechInfoEvent(
      NavigateBasicDetailToTechInfoEvent event,
      Emitter<BasicDetailState> emit) {
    emit(NavigateBasicDetailToTechInfoState());
  }

  /// Event for Basic detail screen Domain list.
  FutureOr<void> domainLoadedEvent(
      DomainLoadedEvent event, Emitter<BasicDetailState> emit) async {
    List<MultiSelectionFiltersData>? offlineDomains;
    await db.getData('domains').then((value) {
      offlineDomains = value;
    });
    emit(DomainLoadedState(offlineDomains!));
  }

  FutureOr<void> functionalityLoadedEvent(
      FunctionalityLoadedEvent event, Emitter<BasicDetailState> emit) async {
    List<MultiSelectionFiltersData>? offlineFunctionalities;
    await db.getData('functionalities').then((value) {
      offlineFunctionalities = value;
    });
    emit(FunctionalityLoadedState(offlineFunctionalities!));
  }

  /// Event for Basic detail screen Status list.
  FutureOr<void> statusLoadedEvent(
      StatusLoadedEvent event, Emitter<BasicDetailState> emit) async {
    List<MultiSelectionFiltersData>? offlineStatus;
    await db.getData('status').then((value) {
      offlineStatus = value;
    });
    emit(StatusLoadedState(offlineStatus!));
  }
}
