
class Filters {
  String? projectName;
  List<String?>? projectStatus;
  String? startDate;
  String? endDate;
  String? resourceName;
  List<String?>? platform;
  List<String?>? technologies;
  List<String?>? domain;
  String? availableDoc;

  Filters({
    this.projectName,
    this.projectStatus,
    this.startDate,
    this.endDate,
    this.resourceName,
    this.platform,
    this.technologies,
    this.domain,
    this.availableDoc,
  });
  Filters.fromJson(Map<String, dynamic> json) {
    projectName = json['projectName']?.toString();
    if (json['projectStatus'] != null) {
      final v = json['projectStatus'];
      final arr0 = <String>[];
      v.forEach((v) {
        arr0.add(v.toString());
      });
      projectStatus = arr0;
    }
    startDate = json['start_date']?.toString();
    endDate = json['end_date']?.toString();
    resourceName = json['resourceName']?.toString();
    if (json['platform'] != null) {
      final v = json['platform'];
      final arr0 = <String>[];
      v.forEach((v) {
        arr0.add(v.toString());
      });
      platform = arr0;
    }
    if (json['technologies'] != null) {
      final v = json['technologies'];
      final arr0 = <String>[];
      v.forEach((v) {
        arr0.add(v.toString());
      });
      technologies = arr0;
    }
    if (json['Domain'] != null) {
      final v = json['Domain'];
      final arr0 = <String>[];
      v.forEach((v) {
        arr0.add(v.toString());
      });
      domain = arr0;
    }
    availableDoc = json['AvailableDoc']?.toString();
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['projectName'] = projectName;
    if (projectStatus != null) {
      final v = projectStatus;
      final arr0 = [];
      for (var v in v!) {
        arr0.add(v);
      }
      data['projectStatus'] = arr0;
    }
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['resourceName'] = resourceName;
    if (platform != null) {
      final v = platform;
      final arr0 = [];
      for (var v in v!) {
        arr0.add(v);
      }
      data['platform'] = arr0;
    }
    if (technologies != null) {
      final v = technologies;
      final arr0 = [];
      for (var v in v!) {
        arr0.add(v);
      }
      data['technologies'] = arr0;
    }
    if (domain != null) {
      final v = domain;
      final arr0 = [];
      for (var v in v!) {
        arr0.add(v);
      }
      data['Domain'] = arr0;
    }
    data['AvailableDoc'] = availableDoc;
    return data;
  }
}
