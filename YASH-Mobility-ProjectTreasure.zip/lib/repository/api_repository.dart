import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import "package:http/http.dart" as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/filteredProjects.dart';
import 'package:yash_mobility_project_treasure/model/filteredProposals.dart';
import 'package:yash_mobility_project_treasure/model/resoucesList.dart';
import 'package:yash_mobility_project_treasure/model/response/create_project_model_list.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/model/response/resource_model_list.dart';
import 'package:yash_mobility_project_treasure/model/response/user_details.dart';
import 'package:yash_mobility_project_treasure/services/network_exceptions.dart';
import 'package:yash_mobility_project_treasure/utils/api_constants.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';

import '../../../model/response/search_project_list.dart';
import '../model/response/create_proposal_model_list.dart';
import '../model/response/document_list.dart';
import '../model/response/location_list.dart';
import '../model/response/proposals_list.dart';
import '../model/response/search_proposal_list.dart';
import '../model/weather_model.dart';
import '../resources/string.dart';
import '../services/api_result.dart';
import '../services/dio_api_client.dart';

class APIRepository {
  ///User login api
  Future<ApiResult<UserDetails>> userLogin(
      String username, String password) async {
    Map<String, dynamic> body = {
      Constants.identifier: username,
      Constants.password: password
    };
    UserDetails userDetails;
    try {
      final response = await DioApiClient()
          .apiCall(ApiConstants.loginApi, null, body, RequestType.post, null);
      if (response.statusCode == 200 && response.data != null) {
        userDetails = UserDetails.fromJson(response.data);
        return ApiResult.success(userDetails);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  ///Projects List API
  Future<ApiResult<List<ProjectsData?>>> allProjects() async {
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.projectsListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          },
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<ProjectsData?> allProjects =
            Projects.fromJson(response.data).data!;
        return ApiResult.success(allProjects);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  ///Proposals List API
  Future<ApiResult<List<ProposalsData?>>> allProposals() async {
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.proposalsListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          },
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<ProposalsData?> allProposals =
            Proposals.fromJson(response.data).data!;
        return ApiResult.success(allProposals);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Search api for project
  Future<ApiResult<List<SearchProjectData?>>>
      searchProjectByNameAndFunctionality(String projectName) async {
    String searchApi = ApiConstants.searchProjectApi + projectName.toString();

    try {
      final response = await DioApiClient().apiCall(
          searchApi,
          null,
          null,
          RequestType.get,
          Options(headers: {
            Constants.authorization:
                'Bearer ${SharedPrefs.instance.getString(Constants.token)}'
          }));
      if (response.statusCode == 200 && response.data != null) {
        List<SearchProjectData?> searchProject =
            SearchProject.fromJson(response.data).data!;
        return ApiResult.success(searchProject);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Search api for proposal
  Future<ApiResult<List<ProposalListData?>>>
      searchProposalByNameAndFunctionality(String proposalName) async {
    String searchApi = ApiConstants.searchProposalApi + proposalName.toString();

    try {
      final response = await DioApiClient().apiCall(
          searchApi,
          null,
          null,
          RequestType.get,
          Options(headers: {
            Constants.authorization:
                'Bearer ${SharedPrefs.instance.getString(Constants.token)}'
          }));
      if (response.statusCode == 200 && response.data != null) {
        List<ProposalListData?> searchProject =
            ProposalList.fromJson(response.data).data!;
        return ApiResult.success(searchProject);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  ///Platforms List API
  Future<ApiResult<List<MultiSelectionFiltersData?>>> allPlatforms() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.platformsListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allPlatforms =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allPlatforms);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Technology List Api
  Future<ApiResult<List<MultiSelectionFiltersData?>>> allTechnologies() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.technologiesListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allTechnologies =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allTechnologies);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Functionality List Api
  Future<ApiResult<List<MultiSelectionFiltersData?>>> allFunctionality() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.functionalityListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allFunctionality =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allFunctionality);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Domain List Api
  Future<ApiResult<List<MultiSelectionFiltersData?>>> allDomain() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.domainsListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allDomain =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allDomain);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Status List Api
  Future<ApiResult<List<MultiSelectionFiltersData?>>> allStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.statusListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allStatus =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allStatus);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Project Methodologies List Api
  Future<ApiResult<List<MultiSelectionFiltersData?>>>
      allProjectMethodologies() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.methodologyListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allMethodologies =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allMethodologies);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Designation List Api
  Future<ApiResult<List<MultiSelectionFiltersData?>>> allDesignation() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.designationsListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<MultiSelectionFiltersData?> allDesignation =
            MultiSelectionFilters.fromJson(response.data).data!;
        return ApiResult.success(allDesignation);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  ///Location Api
  Future<ApiResult<List<LocationData?>>> locations() async {
    List<LocationData?> locationList = [];
    try {
      final response = await DioApiCurrencyClient().apiCurrencyCall(
          ApiConstants.locationApi, null, null, RequestType.get, null);
      if (response.statusCode == 200 && response.data != null) {
        locationList = ProjectLocation.fromJson(response.data).data!;
        return ApiResult.success(locationList);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  ///Currencies Api
  // Future<ApiResult<List<Currencies?>>> currencies() async {
  //   Currencies currencies;
  //   List<Currencies> currenciesList = [];
  //   try {
  //     print("object");
  //     final response = await DioApiCurrencyClient().apiCurrencyCall(
  //         ApiConstants.currenciesApi, null, null, RequestType.get, null);
  //     if (response.statusCode == 200 && response.data != null) {
  //       var list = response.data.length;
  //       for (var i = 0; i < list; i++) {
  //         currencies = Currencies.fromJson(response.data[i]);
  //         currenciesList.add(currencies);
  //       }
  //       return ApiResult.success(currenciesList);
  //     } else {
  //       return ApiResult.failure(NetworkExceptions.handleResponse(response));
  //     }
  //   } catch (exception) {
  //     print(exception);
  //     return ApiResult.failure(
  //         NetworkExceptions.getNetworkException(exception));
  //   }
  // }

  Future<ApiResult<List<ResourcesListData?>>> allResources() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    try {
      final response = await DioApiClient().apiCall(
        ApiConstants.resourcesListApi,
        null,
        null,
        RequestType.get,
        Options(
          headers: {"Authorization": "Bearer ${prefs.getString('token')}"},
        ),
      );
      if (response.statusCode == 200 && response.data != null) {
        List<ResourcesListData?> allResources =
            ResourcesList.fromJson(response.data).data!;
        return ApiResult.success(allResources);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Create resource Api implementation.
  Future<ApiResult<List<ResourcesData?>>> resources(
      String? resourceName, String? resourceEmail, String? designation) async {
    List<Map<String, dynamic>> body = [
      {
        "resource_name": resourceName,
        "resource_email": resourceEmail,
        "designation": designation,
      }
    ];
    try {
      final response = await DioApiClient().apiCall(
          ApiConstants.resourceDataApi,
          null,
          body,
          RequestType.post,
          Options(headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          }));
      if (response.statusCode == 200 && response.data != null) {
        List<ResourcesData?> resources =
            Resources.fromJson(response.data).data!;

        return ApiResult.success(resources);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Apply project filters
  Future<ApiResult<List<FilteredProjectsData?>>> applyFilters(
      String? projectName,
      List<String>? projectStatus,
      String? startDate,
      String? endDate,
      String? resourceName,
      List<String>? platform,
      List<String>? technologies,
      List<String>? domain,
      List<String>? functionalities,
      String? availableDoc) async {
    Map<String, dynamic> body = {
      "projectName": projectName ?? "",
      "projectStatus": projectStatus ?? [],
      "start_date": startDate ?? "",
      "end_date": endDate ?? "",
      "resourceName": resourceName ?? "",
      "platform": platform ?? [],
      "technologies": technologies ?? [],
      "domainName": domain ?? [],
      "functionalities": functionalities ?? [],
      "availableDoc": availableDoc ?? ""
    };
    try {
      final response = await DioApiClient().apiCall(
          ApiConstants.filterProjectsApi,
          null,
          body,
          RequestType.post,
          Options(headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          }));
      if (response.statusCode == 200 && response.data != null) {
        List<FilteredProjectsData?> filters =
            FilteredProjects.fromJson(response.data).data!;
        return ApiResult.success(filters);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Apply proposal filters
  Future<ApiResult<List<FilteredProposalsData?>>> applyProposalFilters(
      String? proposalName,
      List<String>? proposalStatus,
      String? startDate,
      String? endDate,
      String? resourceName,
      List<String>? platform,
      List<String>? technologies,
      List<String>? domain,
      List<String>? functionalities,
      String? availableDoc) async {
    Map<String, dynamic> body = {
      "proposalName": proposalName ?? "",
      "proposalStatus": proposalStatus ?? [],
      "proposalReceivedDate": startDate ?? "",
      "proposalSubmittedDate": endDate ?? "",
      "resourceName": resourceName ?? "",
      "platform": platform ?? [],
      "technologies": technologies ?? [],
      "domainName": domain ?? [],
      "functionalities": functionalities ?? [],
      "availableDoc": availableDoc ?? ""
    };
    try {
      final response = await DioApiClient().apiCall(
          ApiConstants.filterProposalsApi,
          null,
          body,
          RequestType.post,
          Options(headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          }));
      if (response.statusCode == 200 && response.data != null) {
        List<FilteredProposalsData?> filters =
            FilteredProposals.fromJson(response.data).data!;
        return ApiResult.success(filters);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Create project Api implementation.
  Future<ApiResult<CreateProjectData?>> createProject(
    String? objectives,
    String? startDate,
    String? endDate,
    String? clientName,
    String? budget,
    String? knownIssues,
    String? dependencies,
    String? comments,
    dynamic documents,
    String? feedback,
    String? name,
    String? summary,
    String? currency,
    String? location,
    String? riskFactor,
    dynamic technologies,
    dynamic domain,
    dynamic platforms,
    dynamic resources,
    dynamic functionalities,
    dynamic status,
    dynamic methodology,
  ) async {
    Map<String, dynamic> body = {
      "data": {
        "resources": {"connect": resources},
        "technologies": {"connect": technologies},
        "domain": {"connect": domain},
        "platforms": {"connect": platforms},
        "status": {"connect": status},
        "functionalities": {"connect": functionalities},
        "documents": {"connect": documents},
        "methodology": {"connect": methodology},
        "name": name,
        "objectives": objectives,
        "summary": summary,
        "start_date": startDate,
        "end_date": endDate,
        "client_name": clientName,
        "budget": budget,
        "known_issues": knownIssues,
        "dependencies": dependencies,
        "comments": comments,
        "feedback": feedback,
        "location": location,
        "currency": currency,
        "risk_factor": riskFactor
      }
    };
    print("project body: $body");
    print(1);
    try {
      final response = await DioApiClient().apiCall(
          ApiConstants.postProjectDataApi,
          null,
          body,
          RequestType.post,
          Options(headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          }));
      print(response.statusCode);
      if (response.statusCode == 200 && response.data != null) {
        CreateProjectData? createProject =
            CreateProject.fromJson(response.data).data!;
        print(ApiResult.success(createProject));
        return ApiResult.success(createProject);
      } else {
        print("fail");
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      print(exception);
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Create project Api implementation.
  Future<ApiResult<CreateProposalData?>> createProposal(
    String? objectives,
    String? proposalReceivedDate,
    String? proposalSubmittedDate,
    String? clientDetails,
    String? budget,
    String? dependencies,
    String? comments,
    dynamic documents,
    String? feedback,
    String? name,
    String? summery,
    String? currency,
    String? location,
    String? riskFactors,
    dynamic technologies,
    dynamic domain,
    dynamic platforms,
    dynamic resources,
    dynamic functionalities,
    dynamic status,
  ) async {
    Map<String, dynamic> body = {
      "data": {
        "proposal_received_date": proposalReceivedDate,
        "proposal_submitted_date": proposalSubmittedDate,
        "client_details": clientDetails,
        "risk_factors": riskFactors,
        "dependencies": dependencies,
        "feedback": feedback,
        "name": name,
        "location": location,
        "budget": budget,
        "currency": currency,
        "objectives": objectives,
        "summery": summery,
        "comments": comments,
        "domain": {"connect": domain},
        "functionalities": {"connect": functionalities},
        "platforms": {"connect": platforms},
        "technologies": {"connect": technologies},
        "resources": {"connect": resources},
        "status": {"connect": status},
        "documents": {"connect": documents},
      }
    };
    print("proposal body: $body");
    try {
      final response = await DioApiClient().apiCall(
          ApiConstants.postProposalDataApi,
          null,
          body,
          RequestType.post,
          Options(headers: {
            Constants.authorization:
                "Bearer ${SharedPrefs.instance.getString(Constants.token)}"
          }));
      if (response.statusCode == 200 && response.data != null) {
        CreateProposalData? createProposal =
            CreateProposal.fromJson(response.data).data!;
        return ApiResult.success(createProposal);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  /// Create document Api implementation.
  Future<ApiResult<List<DocumentsData?>?>> uploadDocument(
      List<Map<String, dynamic>> filepath) async {
    FormData formData = FormData();
    for (var file in filepath) {
      File fileInstance = File(file['path']);
      String filename = fileInstance.path.split('/').last;
      formData.files.add(MapEntry(
        'files',
        await MultipartFile.fromFile(fileInstance.path, filename: filename),
      ));
    }
    try {
      final response = await DioApiClient().apiCall(
          ApiConstants.documentApi,
          null,
          formData,
          RequestType.post,
          Options(
            headers: {
              Constants.authorization:
                  "Bearer ${SharedPrefs.instance.getString(Constants.token)}",
            },
          ));

      if (response.statusCode == 200 && response != null) {
        List<DocumentsData?>? data = [];
        for (var i = 0; i < response.data.length; i++) {
          DocumentsData doc = DocumentsData.fromJson(response.data[i]);
          data.add(doc);
        }
        print("data: ${jsonEncode(data)}");

        return ApiResult.success(data);
      } else {
        return ApiResult.failure(NetworkExceptions.handleResponse(response));
      }
    } catch (exception) {
      print(exception);
      return ApiResult.failure(
          NetworkExceptions.getNetworkException(exception));
    }
  }

  Future<WeatherModel> callWeatherAPi(bool current, String cityName) async {
    try {
      //Position currentPosition = await getCurrentPosition();

      if (current) {
        List<Placemark> placemarks =
            await placemarkFromCoordinates(18.520430, 73.856743);

        Placemark place = placemarks[0];
        cityName = place.locality!;
      }

      var url = Uri.https('api.openweathermap.org', '/data/2.5/weather',
          {'q': cityName, "units": "metric", "appid": Strings().apiKey});
      final http.Response response = await http.get(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> decodedJson = json.decode(response.body);
        return WeatherModel.fromMap(decodedJson);
      } else {
        throw Exception('Failed to load weather data');
      }
    } catch (e) {
      throw Exception('Failed to load weather data');
    }
  }

  Future<Position> getCurrentPosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.best,
    );
  }
}
