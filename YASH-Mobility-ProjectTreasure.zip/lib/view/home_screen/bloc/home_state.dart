part of 'home_bloc.dart';

@immutable
abstract class HomeState {}

class HomeInitialState extends HomeState {}

class HomeActionState extends HomeState {}

class HomeScreenNavigateToProfileScreenState extends HomeActionState {}