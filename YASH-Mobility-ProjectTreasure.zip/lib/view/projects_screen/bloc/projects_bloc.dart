import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:flutter_logs/flutter_logs.dart';
import 'package:meta/meta.dart';
import 'package:yash_mobility_project_treasure/components/custom_db_wrapper/custom_db_wrapper.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/resoucesList.dart';
import 'package:yash_mobility_project_treasure/model/response/projects_list.dart';
import 'package:yash_mobility_project_treasure/repository/api_repository.dart';
import 'package:yash_mobility_project_treasure/resources/error_strings.dart';
import 'package:yash_mobility_project_treasure/services/api_result.dart';
import 'package:yash_mobility_project_treasure/services/network_exceptions.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/constants.dart';
import 'package:yash_mobility_project_treasure/utils/shared_preference_utils.dart';
import '../../../model/response/proposals_list.dart';
import '../../../model/response/search_project_list.dart';
import '../../../model/response/search_proposal_list.dart';

part 'projects_event.dart';
part 'projects_state.dart';

class ProjectsBloc extends Bloc<ProjectsEvent, ProjectsState> {
  final db = CustomDataBaseWrapper();
  ProjectsBloc() : super(ProjectsInitialState()) {
    on<ProjectsEvent>((event, emit) {});
    on<ProjectsInitialEvent>(projectsInitialEvent);
    on<ProposalsInitialEvent>(proposalsInitialEvent);
    on<FilteredProjectsLoadedEvent>(filteredProjectsLoadedEvent);
    on<FilteredProposalsLoadedEvent>(filteredProposalsLoadedEvent);
    on<OfflineProjectsLoadedEvent>(offlineProjectsLoadedEvent);
    on<OfflineProposalsLoadedEvent>(offlineProposalsLoadedEvent);
    on<GetUserSearchIn>(getUserSearchIn);
    on<GetUserSearchInProposal>(getUserSearchInProposal);
    on<LoadPlatformsListEvent>(loadPlatformsListEvent);
    on<LoadStatusListEvent>(loadStatusListEvent);
    on<LoadTechListEvent>(loadTechListEvent);
    on<LoadFunctionalitiesListEvent>(loadFunctionalitiesListEvent);
    on<LoadDomainsListEvent>(loadDomainsListEvent);
    on<LoadResourcesListEvent>(loadResourcesListEvent);
    on<LoadMethodologiesListEvent>(loadMethodologiesListEvent);
  }

  /// The Event will emit the state which will have the array of all projects.
  FutureOr<void> projectsInitialEvent(
      ProjectsInitialEvent event, Emitter<ProjectsState> emit) async {
    FlutterLogs.logInfo('Api Called', "Timer", "Event is Triggered");
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        emit(ProjectsInternetDisconnected(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
        SharedPrefs.instance.setString(
            Constants.appActiveLifeSpanStart, DateTime.now().toString());
        FlutterLogs.logInfo(
            "App_timer", "ProjectList_NoInternet", DateTime.now().toString());
      } else {
        ApiResult<List<ProjectsData?>> allProjects =
            (await repository.allProjects());
        allProjects.when(success: (projects) {
          emit(ProjectsLoadedSuccessState(projects as List<ProjectsData>));
          db.insertProjects(projects, 'projects');
          SharedPrefs.instance.setString(
              Constants.appActiveLifeSpanStart, DateTime.now().toString());
        }, failure: (NetworkExceptions exception) {
          emit(ProjectsErrorState(exception));
        });
      }
    } on NetworkExceptions catch (_) {}
  }

  /// The Event will emit the state which will have the array of all proposals.
  FutureOr<void> proposalsInitialEvent(
      ProposalsInitialEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        emit(ProjectsInternetDisconnected(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
        SharedPrefs.instance.setString(
            Constants.appActiveLifeSpanStart, DateTime.now().toString());
        FlutterLogs.logInfo(
            "App_timer", "ProposalList_NoInternet", DateTime.now().toString());
      } else {
        ApiResult<List<ProposalsData?>> allProposals =
            (await repository.allProposals());
        allProposals.when(success: (proposals) {
          emit(ProposalsLoadedSuccessfully(proposals as List<ProposalsData>));
          db.insertProposals(proposals, 'proposals');
          SharedPrefs.instance.setString(
              Constants.appActiveLifeSpanStart, DateTime.now().toString());
        }, failure: (NetworkExceptions exception) {
          emit(ProjectsErrorState(exception));
        });
      }
    } on NetworkExceptions catch (_) {}
  }

  /// The Event will emit the state which will have the array of data.
  /// This event will be triggered on Project Screen.
  FutureOr<void> getUserSearchIn(
      GetUserSearchIn event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository apiRepository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        return emit(ProjectsInternetDisconnected(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
      }
      ApiResult<List<SearchProjectData?>> userDetails = await apiRepository
          .searchProjectByNameAndFunctionality(event.searchInProjects);
      userDetails.when(
        success: (result) {
          emit(SearchProjectActionState(result));
          SharedPrefs.instance.setString(
              Constants.appActiveLifeSpanStart, DateTime.now().toString());
        },
        failure: (NetworkExceptions exception) async {
          emit(SearchFailedState(exception));
        },
      );
    } on NetworkExceptions catch (_) {}
  }

  /// The Event will emit the state which will have the array of data.
  /// This event will be triggered on Proposal Screen.
  FutureOr<void> getUserSearchInProposal(
      GetUserSearchInProposal event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository apiRepository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
        return emit(ProjectsInternetDisconnected(
            NetworkExceptions.noInternetConnectionError(
                ErrorStrings().noInternet)));
      }
      ApiResult<List<ProposalListData?>> userDetails = await apiRepository
          .searchProposalByNameAndFunctionality(event.searchInProposal);
      userDetails.when(
        success: (result) {
          SharedPrefs.instance.setString(
              Constants.appActiveLifeSpanStart, DateTime.now().toString());
          emit(SearchProposalActionState(result));
        },
        failure: (NetworkExceptions exception) async {
          emit(SearchFailedState(exception));
        },
      );
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> filteredProjectsLoadedEvent(
      FilteredProjectsLoadedEvent event, Emitter<ProjectsState> emit) async {
    emit(FilteredProjectsLoaded());
  }

  FutureOr<void> filteredProposalsLoadedEvent(
      FilteredProposalsLoadedEvent event, Emitter<ProjectsState> emit) {
    emit(FilteredProposalsLoaded());
  }

  FutureOr<void> offlineProjectsLoadedEvent(
      OfflineProjectsLoadedEvent event, Emitter<ProjectsState> emit) {
    emit(OfflineProjectsLoaded());
  }

  FutureOr<void> offlineProposalsLoadedEvent(
      OfflineProposalsLoadedEvent event, Emitter<ProjectsState> emit) {
    emit(OfflineProposalsLoaded());
  }

  FutureOr<void> loadPlatformsListEvent(
      LoadPlatformsListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<MultiSelectionFiltersData?>> allProposals =
            (await repository.allPlatforms());
        allProposals.when(
            success: (platforms) {
              db.insertData(platforms, 'platforms');
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> loadStatusListEvent(
      LoadStatusListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<MultiSelectionFiltersData?>> allStatuses =
            (await repository.allStatus());
        allStatuses.when(
            success: (status) {
              db.insertData(status, 'status');
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> loadTechListEvent(
      LoadTechListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<MultiSelectionFiltersData?>> technologyFilters =
            (await repository.allTechnologies());
        technologyFilters.when(
            success: (technologies) {
              db.insertData(technologies, "technologies");
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> loadFunctionalitiesListEvent(
      LoadFunctionalitiesListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<MultiSelectionFiltersData?>> functionalities =
            (await repository.allFunctionality());
        functionalities.when(
            success: (functionality) {
              db.insertData(functionality, 'functionalities');
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> loadDomainsListEvent(
      LoadDomainsListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<MultiSelectionFiltersData?>> domainFilters =
            (await repository.allDomain());
        domainFilters.when(
            success: (domains) {
              db.insertData(domains, 'domains');
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> loadResourcesListEvent(
      LoadResourcesListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<ResourcesListData?>> allResources =
            (await repository.allResources());
        allResources.when(
            success: (resources) {
              db.insertResourcesData(resources);
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }

  FutureOr<void> loadMethodologiesListEvent(
      LoadMethodologiesListEvent event, Emitter<ProjectsState> emit) async {
    try {
      final APIRepository repository = APIRepository();
      if (!await Utils.isNetworkConnected()) {
      } else {
        ApiResult<List<MultiSelectionFiltersData?>> domainFilters =
        (await repository.allProjectMethodologies());
        domainFilters.when(
            success: (methodologies) {
              db.insertData(methodologies, 'methodologies');
            },
            failure: (NetworkExceptions exception) {});
      }
    } on NetworkExceptions catch (_) {}
  }
}
