import 'dart:convert';
import 'dart:core';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';
import 'package:yash_mobility_project_treasure/components/custom_date_picker/custom_date_picker.dart';
import 'package:yash_mobility_project_treasure/components/custom_dropdownlist/custom_dropdownlist.dart';
import 'package:yash_mobility_project_treasure/components/custom_textfield/custom_text_form_field.dart';
import 'package:yash_mobility_project_treasure/components/drop_DownList/dropdownlist.dart';
import 'package:yash_mobility_project_treasure/model/MultiSelectionFilters.dart';
import 'package:yash_mobility_project_treasure/model/proposal_details.dart';
import 'package:yash_mobility_project_treasure/resources/colors.dart';
import 'package:yash_mobility_project_treasure/resources/dimen.dart';
import 'package:yash_mobility_project_treasure/resources/string.dart';
import 'package:yash_mobility_project_treasure/utils/common_utils/utils.dart';
import 'package:yash_mobility_project_treasure/utils/text_form_field_utils/regex.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/basic_details_screen/bloc/basic_details_screen_bloc.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/create_project_screen/ui/create_project_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/review_screen/ui/review_screen.dart';
import 'package:yash_mobility_project_treasure/view/create_project_screen/technical_information_screen/ui/technical_information_screen.dart';

import '../../../../components/custom_alert_dialog/custom_alert_dialog.dart';
import '../../../../components/custom_bottomsheet/ui/custom_bottomsheet.dart';
import '../../../../components/custom_db_wrapper/custom_db_wrapper.dart';
import '../../../../model/response/create_project_model_list.dart';
import '../../../../model/response/create_proposal_model_list.dart';
import '../../../../model/response/projects_list.dart';
import '../../../../model/response/proposals_list.dart';
import '../../../../utils/common_utils/display_message_utils.dart';
import '../../../../utils/constants.dart';
import '../../../../utils/shared_preference_utils.dart';

class BasicDetailScreen extends StatefulWidget {
  const BasicDetailScreen(this.currentIndex, this.projectName,
      this.draftSelected, this.isReviewScreen, this.additionalDetailDraft,
      {required this.isProject, required this.database, super.key});

  final int currentIndex;
  final String projectName;
  final bool draftSelected;
  final bool isProject;
  final bool isReviewScreen;
  final bool additionalDetailDraft;
  final Database database;

  @override
  State<BasicDetailScreen> createState() => _BasicDetailScreenState();
}

class _BasicDetailScreenState extends State<BasicDetailScreen> {
  ///Form key declaration for validation
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool isProject = false;
  bool isButtonEnabled = false;
  bool domainDropdownOpened = false;
  bool statusDropdownOpened = false;

  String? domainValue;
  String? functionalityValue;
  String? projectStatusValue;

  String name = "";
  String clientName = "";
  String budget = "";
  String knownIssues = "";
  String dependencies = "";
  String comments = "";
  String currency = "";
  String createdAt = "";
  String publishedAt = "";
  String updatedAt = "";
  String feedback = "";
  String location = "";
  String riskFactor = "";

  ///Get data Declaration
  String draftProjectName = " ";
  String draftDomain = " ";
  String draftObjective = " ";
  String draftSummery = " ";
  dynamic draftFunctionality;
  List<String> draftFunction = [];
  String draftStartDate = " ";
  String draftEndDate = " ";
  String draftStatus = " ";
  String draftKnownIssue = " ";
  String draftDependencies = " ";
  dynamic draftPlatform;
  List<String> draftPlat = [];
  dynamic draftTechnology;
  List<String> draftTech = [];

  List<String> selectedDomain = [];
  List<String> selectedStatus = [];
  List<String> selectedPlatform = [];
  List<String> selectedTechnology = [];
  List<String> selectedResource = [];
  List<String> selectedDocuments = [];
  List<String> selectedMethodology = [];

  List<String> domainName = [];
  List<String> statusName = [];
  List<String> functionalityName = [];
  List<MultiSelectionFiltersData> domainList = [];
  List<MultiSelectionFiltersData> statusList = [];
  List<MultiSelectionFiltersData?> selectedFunctionality = [];
  List<String> selectFunctionality = [];
  List<MultiSelectionFiltersData?> proposalSelectedFunctionality = [];
  List<String> statusDropDownList = [];
  List<CreateProjectData> createBasicDetails = [];
  List<ProjectsData> basicDetails = [];
  List<CreateProposalData> createProposalBasicDetails = [];
  List<ProposalsData> proposalBasicDetails = [];
  List<MultiSelectionFiltersData> functionalityList = [];
  List<MultiSelectionFiltersData?> draftFunctionalityList = [];
  List<MultiSelectionFiltersData?> draftPlatformsList = [];

  List<ProjectsData> result = [];
  List<ProposalsData> proposalResult = [];

  final formatter = DateFormat.yMd();
  List<Map<String, dynamic>> functionalityMap = [];

  bool basicDetailDraft = false;
  bool isBasicScreen = false;
  bool additionalDetailScreen = false;

  dynamic createDomainAt;

  ///Database declaration.
  final db = CustomDataBaseWrapper();


  ///Create Project Basic Detail Screen Controllers
  final TextEditingController projectNameController = TextEditingController();
  final TextEditingController domainController = TextEditingController();
  final TextEditingController objectivesController = TextEditingController();
  final TextEditingController projectSummeryController =
      TextEditingController();
  final TextEditingController functionalityController = TextEditingController();
  final TextEditingController projectStatusController = TextEditingController();
  final TextEditingController startDateInputController =
      TextEditingController();
  final TextEditingController endDateInputController = TextEditingController();
  final functionalityNotifier =
      ValueNotifier<List<MultiSelectionFiltersData?>>([]);

  ///Create Proposal Basic Detail Screen Controllers
  final TextEditingController proposalNameController = TextEditingController();
  final TextEditingController proposalDomainController =
      TextEditingController();
  final TextEditingController proposalObjectivesController =
      TextEditingController();
  final TextEditingController proposalSummeryController =
      TextEditingController();
  final TextEditingController proposalFunctionalityController =
      TextEditingController();
  final TextEditingController proposalStatusController =
      TextEditingController();
  final TextEditingController proposalStartDateInputController =
      TextEditingController();
  final TextEditingController proposalEndDateInputController =
      TextEditingController();
  final proposalFunctionalityNotifier =
      ValueNotifier<List<MultiSelectionFiltersData?>>([]);

  ///Bloc declaration
  final BasicDetailsScreenBloc basicDetailsScreenBloc =
      BasicDetailsScreenBloc();

  ///Button Enable & disable functionality.
  void _checkButtonStatus() {
    setState(() {
      if (isProject == true) {
        if (projectNameController.text.isNotEmpty &&
            domainController.text.isNotEmpty &&
            projectSummeryController.text.isNotEmpty &&
            startDateInputController.text.isNotEmpty &&
            functionalityNotifier.value.isNotEmpty &&
            projectStatusController.text.isNotEmpty) {
          isButtonEnabled = true;
        } else {
          isButtonEnabled = false;
        }
      } else {
        if (proposalNameController.text.isNotEmpty &&
            proposalDomainController.text.isNotEmpty &&
            proposalSummeryController.text.isNotEmpty &&
            proposalStartDateInputController.text.isNotEmpty &&
            proposalFunctionalityNotifier.value.isNotEmpty &&
            proposalStatusController.text.isNotEmpty) {
          isButtonEnabled = true;
        } else {
          isButtonEnabled = false;
        }
      }
    });
  }

  Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  @override
  void initState() {
    db.getSpecificProjectsList(widget.projectName);
    db.getSpecificProposalList(widget.projectName);
    getData();
    getProposalData();
    startDateInputController.text = "";
    endDateInputController.text = "";

    setState(() {
      /// Event for Basic detail screen Domain list.
      basicDetailsScreenBloc.add(DomainLoadedEvent());

      ///Event for Functionality dropdown list.
      basicDetailsScreenBloc.add(FunctionalityLoadedEvent());

      /// Event for Basic detail screen Status list.
      basicDetailsScreenBloc.add(StatusLoadedEvent());
    });


    isProject = widget.isProject;

    if (isProject == true) {
      projectNameController.addListener(_checkButtonStatus);
      domainController.addListener(_checkButtonStatus);
      functionalityNotifier.addListener(_checkButtonStatus);
      projectSummeryController.addListener(_checkButtonStatus);
      startDateInputController.addListener(_checkButtonStatus);
      projectStatusController.addListener(_checkButtonStatus);
    } else {
      proposalNameController.addListener(_checkButtonStatus);
      proposalDomainController.addListener(_checkButtonStatus);
      proposalFunctionalityNotifier.addListener(_checkButtonStatus);
      proposalSummeryController.addListener(_checkButtonStatus);
      proposalStartDateInputController.addListener(_checkButtonStatus);
      proposalStatusController.addListener(_checkButtonStatus);
    }
    super.initState();
  }

  /// Navigation to Create Project Screen.
  void navigateToCreateProjectScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/createProjectScreen'));
  }

  /// Navigation to Draft Screen.
  void navigateToDraftScreen(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName('/draftScreen'));
  }

  /// Get all draft data.
  void getData() async {
    result = await db.getSpecificProjectsList(widget.projectName);
    int index = result.length;
    for (int i = 0; i < index; i++) {
      setState(() {
        draftProjectName = result[i].attributes!.name!;
        draftDomain = result[i].attributes!.domain!.data!.attributes!.name!;
        draftObjective = result[i].attributes!.objectives!;
        draftSummery = result[i].attributes!.summary!;
        var dataIndex = result[i].attributes!.functionalities!.data!.length;
        draftFunctionality = result[i].attributes!.functionalities;
        draftPlatform = result[i].attributes!.platforms;
        draftStartDate = result[i].attributes!.startDate!;
        draftEndDate = result[i].attributes!.endDate!;
        draftStatus = result[i].attributes!.status!.data!.attributes!.name!;
        if (widget.isReviewScreen) {
          projectNameController.text = draftProjectName;
          domainController.text = draftDomain;
          objectivesController.text = draftObjective;
          projectSummeryController.text = draftSummery;
          List<dynamic> t = jsonDecode(jsonEncode(draftFunctionality!.data!));
          List<Map<String, dynamic>> storedFunctionalityItems = [];
          for (var i = 0; i < t.length; i++) {
            storedFunctionalityItems.add(t[i]);
          }
          var m = {"data": storedFunctionalityItems};
          var n = MultiSelectionFilters.fromJson(m);

          for (int j = 0; j < dataIndex; j++) {
            setState(() {
              draftFunctionalityList = n.data!;
              draftFunction.add(draftFunctionality!.data![j]!.attributes!.name);
              selectFunctionality
                  .add(draftFunctionality!.data![j]!.attributes!.name);
            });
          }
          startDateInputController.text = draftStartDate;
          endDateInputController.text = draftEndDate;
          projectStatusController.text = draftStatus;
        }
      });
    }
  }

  void getProposalData() async {
    proposalResult = await db.getSpecificProposalList(widget.projectName);
    int index = proposalResult.length;
    for (int i = 0; i < index; i++) {
      setState(() {
        draftProjectName = proposalResult[i].attributes!.name!;
        draftDomain =
            proposalResult[i].attributes!.domain!.data!.attributes!.name!;
        draftObjective = proposalResult[i].attributes!.objectives!;
        draftSummery = proposalResult[i].attributes!.summery!;
        var dataIndex =
            proposalResult[i].attributes!.functionalities!.data!.length;
        draftFunctionality = proposalResult[i].attributes!.functionalities;
        draftPlatform = proposalResult[i].attributes!.platforms;
        draftTechnology = proposalResult[i].attributes!.technologies;
        draftStartDate = proposalResult[i].attributes!.proposalReceivedDate!;
        draftEndDate = proposalResult[i].attributes!.proposalSubmittedDate!;
        draftStatus =
            proposalResult[i].attributes!.status!.data!.attributes!.name!;
        if (widget.isReviewScreen) {
          proposalNameController.text = draftProjectName;
          domainController.text = draftDomain;
          proposalObjectivesController.text = draftObjective;
          proposalSummeryController.text = draftSummery;
          List<dynamic> t = jsonDecode(jsonEncode(draftFunctionality!.data!));
          List<Map<String, dynamic>> storedFunctionalityItems = [];
          for (var i = 0; i < t.length; i++) {
            storedFunctionalityItems.add(t[i]);
          }
          var m = {"data": storedFunctionalityItems};
          var n = MultiSelectionFilters.fromJson(m);

          for (int j = 0; j < dataIndex; j++) {
            setState(() {
              draftFunctionalityList = n.data!;
              draftFunction.add(draftFunctionality!.data![j]!.attributes!.name);
              selectFunctionality
                  .add(draftFunctionality!.data![j]!.attributes!.name);
            });
          }
          proposalStartDateInputController.text = draftStartDate;
          proposalEndDateInputController.text = draftEndDate;
          projectStatusController.text = draftStatus;
        }
      });
    }
  }

  void returnProjectDetails(BuildContext context) async {
    if (isProject == true) {
      setState(() {
        ///Domain list
        Map<String, dynamic> domain = {
          "data": jsonDecode(SharedPrefs.instance.getString('domain')!)
        };

        ///Functionality list
        List<dynamic> functionalities =
            jsonDecode(SharedPrefs.instance.getString('functionality') ?? "[]");
        Map<String, dynamic>? q;
        List<Map<String, dynamic>> funcMapList = [];
        for (var i = 0; i < functionalities.length; i++) {
          if (widget.isReviewScreen) {
            setState(() {
              var funcItem = (functionalities[i]);
              funcMapList.add(funcItem);
              q = {"data": funcMapList};
            });
          } else {
            var funcItem = (functionalities[i]);
            funcMapList.add(funcItem);
            setState(() {
              q = {"data": funcMapList};
            });
          }
        }

        ///Status list
        var status = {
          "data": jsonDecode(SharedPrefs.instance.getString('status')!)
        };

        ///Platform list
        Map<String, dynamic> platform = {};
        setState(() {
          if (draftPlatform != null) {
            platform = draftPlatform;
          } else {
            platform = {"data": null};
          }
        });

        ///Technology list
        Map<String, dynamic> technology = {};
        setState(() {
          if (draftTechnology != null) {
            technology = draftTechnology;
          } else {
            technology = {"data": null};
          }
        });

        Map<String, dynamic> resources;

        ///Resources list
        resources = {"data": null};

        ///Documents list
        var documents = {
          "data": null
        };

        ///Methodology list
        var methodology = {"data": null};

        var attributes = ProjectsDataAttributes(
              name: projectNameController.text,
              domain: ProjectsDataAttributesDomain.fromJson(domain),
              objectives: objectivesController.text.isEmpty
                  ? null
                  : objectivesController.text,
              functionalities: ProjectsDataAttributesFunctionalities.fromJson(q!),
              summary: projectSummeryController.text,
              startDate: startDateInputController.text,
              endDate: endDateInputController.text.isEmpty
                  ? null
                  : endDateInputController.text,
              status: ProjectsDataAttributesStatus.fromJson(status),
              platforms: ProjectsDataAttributesPlatforms.fromJson(platform),
              technologies: ProjectsDataAttributesTechnologies.fromJson(technology),
              knownIssues:
                  draftKnownIssue.isNotEmpty ? draftKnownIssue : knownIssues,
              dependencies:
                  draftDependencies.isNotEmpty ? draftDependencies : dependencies,
              comments: comments,
              clientName: clientName,
              budget: budget,
              currency: currency,
              createdAt: createdAt,
              updatedAt: updatedAt,
              publishedAt: publishedAt,
              feedback: feedback,
              resources: ProjectsDataAttributesResources.fromJson(resources),
              location: location,
            riskFactor: riskFactor,
            methodology: ProjectsDataAttributesMethodology.fromJson(methodology)
        );
        basicDetails.add(ProjectsData(attributes: attributes));
        widget.draftSelected || widget.isReviewScreen || basicDetailDraft
            ? db.updateBasicDetail(basicDetails)
            : db.insertProjects(basicDetails, "projects");
        basicDetailDraft = true;
        SharedPrefs.instance
            .setBool(Constants.basicDetailDraft, basicDetailDraft);
      });
    } else {
      setState(() {
        Map<String, dynamic> domain = {
          "data": jsonDecode(SharedPrefs.instance.getString('proposalDomain')!)
        };

        ///Functionality list
        List<dynamic> functionalities =
            jsonDecode(SharedPrefs.instance.getString('functionality') ?? "[]");
        Map<String, dynamic>? q;
        List<Map<String, dynamic>> funcMapList = [];
        for (var i = 0; i < functionalities.length; i++) {
          if (widget.isReviewScreen) {
            setState(() {
              var funcItem = (functionalities[i]);
              funcMapList.add(funcItem);
              q = {"data": funcMapList};
            });
          } else {
            var funcItem = (functionalities[i]);
            funcMapList.add(funcItem);
            setState(() {
              q = {"data": funcMapList};
            });
          }
        }

        ///Status list
        var status = {
          "data": jsonDecode(SharedPrefs.instance.getString('proposalStatus')!)
        };

        ///Platform list
        Map<String, dynamic> platform = {};
        setState(() {
          if (draftPlatform != null) {
            platform = draftPlatform;
          } else {
            platform = {"data": null};
          }
        });

        ///Technology list
        Map<String, dynamic> technology = {};
        setState(() {
          if (draftTechnology != null) {
            technology = draftTechnology;
          } else {
            technology = {"data": null};
          }
        });

        ///Resources list
        var resources = {"data": null};

        ///Documents list
        var documents = {
          "data": null
        };

        var attributes = ProposalsDataAttributes(
          name: proposalNameController.text,
          domain: ProposalsDataAttributesDomain.fromJson(domain),
          objectives: proposalObjectivesController.text.isEmpty
              ? null
              : proposalObjectivesController.text,
          functionalities:
          ProposalsDataAttributesFunctionalities.fromJson(q!),
          summery: proposalSummeryController.text,
          proposalReceivedDate: proposalStartDateInputController.text,
          proposalSubmittedDate: proposalEndDateInputController.text.isEmpty
              ? null
              : proposalEndDateInputController.text,
          status: ProposalsDataAttributesStatus.fromJson(status),
          platforms: ProposalsDataAttributesPlatforms.fromJson(platform),
          technologies:
          ProposalsDataAttributesTechnologies.fromJson(technology),
          dependencies:
              draftDependencies.isNotEmpty ? draftDependencies : dependencies,
          comments: comments,
          clientDetails: clientName,
          budget: budget,
          currency: currency,
          createdAt: createdAt,
          updatedAt: updatedAt,
          publishedAt: publishedAt,
          feedback: feedback,
          resources: ProposalsDataAttributesResources.fromJson(resources),
          location: location,
          riskFactors: riskFactor,
        );
        proposalBasicDetails
            .add(ProposalsData(attributes: attributes));
        widget.draftSelected || widget.isReviewScreen
            ? db.updateProposalBasicDetail(proposalBasicDetails)
            : db.insertProposals(proposalBasicDetails, 'proposals');

        basicDetailDraft = true;
        SharedPrefs.instance
            .setBool(Constants.basicDetailDraft, basicDetailDraft);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    /// Bloc implementation
    return BlocConsumer<BasicDetailsScreenBloc, BasicDetailState>(
      bloc: basicDetailsScreenBloc,
      listenWhen: (previous, current) => current is BasicDetailActionState,
      buildWhen: (previous, current) => current is! BasicDetailActionState,
      listener: (context, state) {
        /// State for Basic detail screen Attachment button.
        if (state is BasicDetailAttachmentBtnState) {
          ShowBottomSheet.getInstance.permissionHandlerMethod(context);
        }

        /// State for Basic detail screen Save button.
        else if (state is BasicDetailSaveBtnState) {
          if (isProject == true) {
            if (projectNameController.text.isNotEmpty ||
                draftProjectName.isNotEmpty &&
                    domainController.text.isNotEmpty &&
                    (functionalityNotifier.value.isNotEmpty ||
                        functionalityNotifier.value != []) &&
                    projectSummeryController.text.isNotEmpty &&
                    startDateInputController.text.isNotEmpty &&
                    projectStatusController.text.isNotEmpty) {
              returnProjectDetails(context);
              DisplayMessageUtils.toastMessage(
                  Strings().dataSavedSuccessfullyToastMessage);
            } else {
              return;
            }
          } else {
            if (proposalNameController.text.isNotEmpty &&
                proposalDomainController.text.isNotEmpty &&
                proposalSummeryController.text.isNotEmpty &&
                (proposalFunctionalityNotifier.value.isNotEmpty ||
                    proposalFunctionalityNotifier.value != []) &&
                proposalStartDateInputController.text.isNotEmpty &&
                proposalStatusController.text.isNotEmpty) {
              returnProjectDetails(context);
              DisplayMessageUtils.toastMessage(
                  Strings().dataSavedSuccessfullyToastMessage);
            } else {
              return;
            }
          }
        }

        /// State for Basic detail screen Domain list.
        else if (state is DomainLoadedState) {
          List<MultiSelectionFiltersData> jsonFilterDomain =
              state.domainFilters;
          domainList.addAll(jsonFilterDomain);
          var indexArray = domainList.length;
          for (var i = 0; i < indexArray; i++) {
            domainName.add(domainList[i].attributes!.name!);
          }
        }

        /// State for Basic detail screen Functionality list.
        else if (state is FunctionalityLoadedState) {
          List<MultiSelectionFiltersData> jsonFilterFunctionality =
              state.functionality;
          functionalityList.addAll(jsonFilterFunctionality);
        }

        /// State for Basic detail screen Status list.
        else if (state is StatusLoadedState) {
          List<MultiSelectionFiltersData> jsonFilterStatus =
              state.statusFilters;
          statusList.addAll(jsonFilterStatus);
        }

        /// State for Navigation from Basic detail screen to Technical information screen.
        else if (state is NavigateBasicDetailToTechInfoState) {}
      },
      builder: (context, state) {
        return WillPopScope(
          onWillPop: () async {
            if (isProject) {
              var result =
                  await db.getSpecificProjectsList(projectNameController.text);
              if (!context.mounted) return false;

              print(result);

              if (projectNameController.text.isNotEmpty) {
                if (result.isEmpty) {
                  showDialog(
                      barrierDismissible: false,
                      context: context,
                      builder: (BuildContext context) {
                        return dialog();
                      });
                } else {
                  if (widget.draftSelected) {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ReviewScreen(
                                widget.currentIndex,
                                projectNameController.text,
                                widget.additionalDetailDraft,
                                widget.draftSelected,
                                additionalDetailScreen,
                                isProject: isProject,
                                database: widget.database)));
                  } else if (widget.isReviewScreen) {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ReviewScreen(
                                widget.currentIndex,
                                projectNameController.text,
                                widget.additionalDetailDraft,
                                widget.draftSelected,
                                additionalDetailScreen,
                                isProject: isProject,
                                database: widget.database)));
                  } else {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CreateProjectScreen(
                                widget.currentIndex,
                                projectNameController.text,
                                widget.isProject,
                            database: widget.database,
                            )));
                  }
                }
              } else {
                String pName = projectNameController.text.isNotEmpty
                    ? projectNameController.text
                    : draftProjectName;

                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateProjectScreen(
                            widget.currentIndex, pName, widget.isProject, database: widget.database,)));
              }
            } else {
              var result =
                  await db.getSpecificProposalList(proposalNameController.text);
              if (!context.mounted) return false;

              print(result);

              if (proposalNameController.text.isNotEmpty) {
                if (result.isEmpty) {
                  showDialog(
                      barrierDismissible: false,
                      context: context,
                      builder: (BuildContext context) {
                        return dialog();
                      });
                } else {
                  if (widget.draftSelected) {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ReviewScreen(
                                widget.currentIndex,
                                proposalNameController.text,
                                widget.additionalDetailDraft,
                                widget.draftSelected,
                                additionalDetailScreen,
                                isProject: isProject,
                                database: widget.database)));
                  } else if (widget.isReviewScreen) {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ReviewScreen(
                                widget.currentIndex,
                                proposalNameController.text,
                                widget.additionalDetailDraft,
                                widget.draftSelected,
                                additionalDetailScreen,
                                isProject: isProject,
                                database: widget.database)));
                  } else {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CreateProjectScreen(
                                widget.currentIndex,
                                proposalNameController.text,
                                widget.isProject,
                                database: widget.database)));
                  }
                }
              } else {
                String pName = proposalNameController.text.isNotEmpty
                    ? proposalNameController.text
                    : draftProjectName;

                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateProjectScreen(
                            widget.currentIndex, pName, widget.isProject, database: widget.database)));
              }
            }
            return false;
          },
          child: Scaffold(
            backgroundColor: AppColors.white,
            appBar: AppBar(
              backgroundColor: AppColors.createProjectAppBarColor,
              title: Text(
                isProject == true
                    ? Strings().createProjectAppbarTitle.toTitleCase()
                    : Strings().createProposalAppbarTitle.toTitleCase(),
                style: TextStyle(
                    color: AppColors.white, fontSize: Dimensions.font_20),
              ),
              iconTheme: IconThemeData(
                color: AppColors.white,
              ),
              actions: [
                IconButton(
                    onPressed: () {
                      /// Event for Basic detail screen Attachment button.
                      basicDetailsScreenBloc
                          .add(BasicDetailAttachmentBtnEvent());
                    },
                    icon: Icon(Icons.attach_file,
                        size: Dimensions.iconSize_20, color: AppColors.white)),
                TextButton(
                  onPressed: () {
                    /// Event for Basic detail screen Save button.
                    basicDetailsScreenBloc.add(BasicDetailSaveBtnEvent());
                  },
                  child: Text(
                    Strings().saveDraftAppbarTitle.toTitleCase(),
                    style: TextStyle(color: AppColors.white),
                  ),
                ),
              ],
            ),
            body: GestureDetector(
              onTap: () {
                setState(() {
                  domainDropdownOpened = false;
                  statusDropdownOpened = false;
                });

                FocusScope.of(context).requestFocus(FocusNode());
              },
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(
                        Dimensions.padding_16,
                        Dimensions.padding_24,
                        Dimensions.padding_16,
                        Dimensions.padding_0),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                height: Dimensions.height_24,
                                width: Dimensions.width_24,
                                decoration: BoxDecoration(
                                  color: AppColors.createProjectAppBarColor,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.borderRadius_40),
                                  border: Border.all(
                                      color: AppColors
                                          .createScreenButtonBorderColor),
                                ),
                                child: Center(
                                    child: Text(
                                  Strings().progressIndicatorTitle_1,
                                  style: TextStyle(color: AppColors.white),
                                )),
                              ),
                              SizedBox(
                                width: Dimensions.width_25,
                                child: Divider(
                                  color: AppColors.grey,
                                  thickness:
                                      Dimensions.verticalDividerThickness_1,
                                ),
                              ),
                              Container(
                                height: Dimensions.height_24,
                                width: Dimensions.width_24,
                                decoration: BoxDecoration(
                                  color: AppColors.white,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.borderRadius_40),
                                  border: Border.all(
                                      color: AppColors.stepperBorderColor),
                                ),
                                child: Center(
                                    child: Text(
                                        Strings().progressIndicatorTitle_2)),
                              ),
                              SizedBox(
                                width: Dimensions.width_25,
                                child: Divider(
                                  color: AppColors.grey,
                                  thickness:
                                      Dimensions.verticalDividerThickness_1,
                                ),
                              ),
                              Container(
                                height: Dimensions.height_24,
                                width: Dimensions.width_24,
                                decoration: BoxDecoration(
                                  color: AppColors.white,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.borderRadius_40),
                                  border: Border.all(
                                      color: AppColors.stepperBorderColor),
                                ),
                                child: Center(
                                    child: Text(
                                        Strings().progressIndicatorTitle_3)),
                              ),
                            ],
                          ),
                          SizedBox(height: Dimensions.height_32),
                          Text(
                            Strings().basicDetailTitle.toTitleCase(),
                            style: TextStyle(
                                fontSize: Dimensions.font_16,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: Dimensions.height_16),
                          result.isEmpty
                              ? CustomTextField(
                                  onTapped: () {
                                    setState(() {
                                      domainDropdownOpened = false;
                                      statusDropdownOpened = false;
                                    });
                                  },
                                  textEditingController: isProject == true
                                      ? projectNameController
                                      : proposalNameController,
                                  labelText: isProject == true
                                      ? Strings()
                                          .textFieldProjectName
                                          .toTitleCase()
                                      : Strings()
                                          .textFieldProposalName
                                          .toTitleCase(),
                                  regEx: RegEx().projectNameRegEx,
                                  onSaved: (value) {
                                    if (isProject == true) {
                                      projectNameController.text = value!;
                                    } else {
                                      proposalNameController.text = value!;
                                    }
                                  },
                                )
                              : Container(
                                  width: getSize(context).width,
                                  height: 60,
                                  padding: EdgeInsets.only(
                                    left: Dimensions.padding_16,
                                  ),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: AppColors
                                              .basicDetailTextFieldBorderColor),
                                      borderRadius: BorderRadius.circular(
                                          Dimensions.borderRadius_5)),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        top: Dimensions.padding_8),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          isProject == true
                                              ? Strings()
                                                  .textFieldProjectName
                                                  .toTitleCase()
                                              : Strings()
                                                  .textFieldProposalName
                                                  .toTitleCase(),
                                          style: TextStyle(
                                              fontSize: Dimensions.font_12,
                                              color: AppColors
                                                  .createProjectAppBarColor),
                                        ),
                                        Text(
                                          draftProjectName,
                                          style: TextStyle(
                                              fontSize: Dimensions.font_16),
                                        ),
                                      ],
                                    ),
                                  )),
                          SizedBox(height: Dimensions.height_29),
                          domainDropdown(),
                          SizedBox(height: Dimensions.height_29),
                          CustomTextField(
                            onTapped: () {
                              setState(() {
                                domainDropdownOpened = false;
                                statusDropdownOpened = false;
                              });
                            },
                            textEditingController: isProject == true
                                ? objectivesController
                                : proposalObjectivesController,
                            labelText: isProject == true
                                ? Strings().textFieldObjectives
                                : Strings().textFieldProposalObjective,
                            onSaved: (value) {
                              if (isProject == true) {
                                objectivesController.text = value!;
                              } else {
                                proposalObjectivesController.text = value!;
                              }
                            },
                            regEx: RegEx().projectObjectiveRegEx,
                          ),
                          SizedBox(height: Dimensions.height_29),
                          CustomTextField(
                            onTapped: () {
                              setState(() {
                                domainDropdownOpened = false;
                                statusDropdownOpened = false;
                              });
                            },
                            textEditingController: isProject
                                ? projectSummeryController
                                : proposalSummeryController,
                            labelText: isProject == true
                                ? Strings()
                                    .textFieldProjectSummary
                                    .toTitleCase()
                                : Strings()
                                    .textFieldProposalSummary
                                    .toTitleCase(),
                            onSaved: (value) {
                              if (isProject == true) {
                                projectSummeryController.text = value!;
                              } else {
                                proposalSummeryController.text = value!;
                              }
                            },
                            regEx: RegEx().projectObjectiveRegEx,
                          ),
                          SizedBox(height: Dimensions.height_29),
                          technologyMultiDropdownList(),
                          SizedBox(height: Dimensions.height_29),
                          CustomDatePicker(
                            dateInput: isProject == true
                                ? startDateInputController
                                : proposalStartDateInputController,
                            dateTitle: isProject == true
                                ? Strings().textFieldStartDate.toTitleCase()
                                : Strings()
                                    .textFieldProposalStartDate
                                    .toTitleCase(),
                            firstDate: Strings().firstDate,
                            lastDate: DateTime(Dimensions.lastDate_2100),
                            onTap: () {
                              if (isProject == true) {
                                _presentDatePicker(startDateInputController);
                              } else {
                                _presentDatePicker(
                                    proposalStartDateInputController);
                              }
                            },
                          ),
                          SizedBox(height: Dimensions.height_29),
                          CustomDatePicker(
                            dateInput: isProject == true
                                ? endDateInputController
                                : proposalEndDateInputController,
                            dateTitle: isProject == true
                                ? Strings().textFieldEndDate
                                : Strings().textFieldProposalEndDate,
                            firstDate: isProject == true
                                ? startDateInputController.text
                                : proposalStartDateInputController.text,
                            lastDate: DateTime(Dimensions.lastDate_2200),
                            onTap: () async {
                              final formatter = DateFormat('yyyy-MM-dd');
                              DateTime? startDate;
                              if (isProject == true
                                  ? startDateInputController.text.isNotEmpty
                                  : proposalStartDateInputController
                                      .text.isNotEmpty) {
                                DateTime tempDate = formatter.parse(isProject ==
                                        true
                                    ? startDateInputController.text
                                    : proposalStartDateInputController.text);
                                startDate = tempDate;
                              }
                              if (!context.mounted) {
                                return;
                              }
                              final pickedDate = await showDatePicker(
                                  context: context,
                                  initialDate: (isProject == true
                                          ? startDateInputController
                                              .text.isNotEmpty
                                          : proposalStartDateInputController
                                              .text.isNotEmpty)
                                      ? startDate!
                                      : DateTime(
                                          DateTime.now().year,
                                          DateTime.now().month,
                                          DateTime.now().day),
                                  firstDate: (isProject == true
                                          ? startDateInputController
                                              .text.isNotEmpty
                                          : proposalStartDateInputController
                                              .text.isNotEmpty)
                                      ? startDate!
                                      : DateTime(
                                          DateTime.now().year,
                                          DateTime.now().month,
                                          DateTime.now().day),
                                  lastDate: DateTime(DateTime.now().year +
                                      Dimensions.add_100));

                              setState(() {
                                if (isProject == true) {
                                  endDateInputController.text =
                                      formatter.format(pickedDate!);
                                } else {
                                  proposalEndDateInputController.text =
                                      formatter.format(pickedDate!);
                                }
                              });
                            },
                          ),
                          SizedBox(height: Dimensions.height_29),
                          statusDropdown(),
                          SizedBox(height: Dimensions.height_29),
                          Visibility(
                            visible: widget.isReviewScreen ? false : true,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                SizedBox(
                                  height: Dimensions.height_40,
                                  width: Dimensions.width_160,
                                  child: ElevatedButton(
                                    onPressed: widget.draftSelected
                                        ? () {
                                            /// Event for Navigation from Basic detail screen to Technical information screen.
                                            basicDetailsScreenBloc.add(
                                                NavigateBasicDetailToTechInfoEvent());
                                          }
                                        : (isButtonEnabled
                                            ? () async {
                                                /// Event for Navigation from Basic detail screen to Technical information screen.
                                                final navigator =
                                                    Navigator.of(context);
                                                if (widget.draftSelected) {
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) => TechnicalInformationScreen(
                                                              widget
                                                                  .currentIndex,
                                                              projectNameController
                                                                  .text,
                                                              basicDetailDraft,
                                                              isBasicScreen,
                                                              widget
                                                                  .draftSelected,
                                                              widget
                                                                  .isReviewScreen,
                                                              widget
                                                                  .additionalDetailDraft,
                                                              widget
                                                                  .isProject, database: widget.database)));
                                                } else {
                                                  if (isProject == true) {
                                                    isBasicScreen = true;
                                                    var result = await db
                                                        .getSpecificProjectsList(
                                                            projectNameController
                                                                .text);
                                                    if (result.isNotEmpty) {
                                                      navigator.push(
                                                        MaterialPageRoute(
                                                            settings:
                                                                const RouteSettings(
                                                                    name:
                                                                        "/technicalInformationScreen"),
                                                            builder: (context) => TechnicalInformationScreen(
                                                                widget
                                                                    .currentIndex,
                                                                projectNameController
                                                                    .text,
                                                                basicDetailDraft,
                                                                isBasicScreen,
                                                                widget
                                                                    .draftSelected,
                                                                widget
                                                                    .isReviewScreen,
                                                                widget
                                                                    .additionalDetailDraft,
                                                                widget
                                                                    .isProject, database: widget.database)),
                                                      );
                                                    } else {
                                                      returnProjectDetails(
                                                          context);

                                                      navigator.push(
                                                        MaterialPageRoute(
                                                            settings:
                                                                const RouteSettings(
                                                                    name:
                                                                        "/technicalInformationScreen"),
                                                            builder: (context) => TechnicalInformationScreen(
                                                                widget
                                                                    .currentIndex,
                                                                projectNameController
                                                                    .text,
                                                                basicDetailDraft,
                                                                isBasicScreen,
                                                                widget
                                                                    .draftSelected,
                                                                widget
                                                                    .isReviewScreen,
                                                                widget
                                                                    .additionalDetailDraft,
                                                                widget
                                                                    .isProject, database: widget.database)),
                                                      );
                                                    }
                                                  } else {
                                                    isBasicScreen = true;
                                                    var result = await db
                                                        .getSpecificProposalList(
                                                            proposalNameController
                                                                .text);
                                                    if (result.isNotEmpty) {
                                                      navigator.push(
                                                        MaterialPageRoute(
                                                            settings:
                                                                const RouteSettings(
                                                                    name:
                                                                        "/technicalInformationScreen"),
                                                            builder: (context) => TechnicalInformationScreen(
                                                                widget
                                                                    .currentIndex,
                                                                proposalNameController
                                                                    .text,
                                                                basicDetailDraft,
                                                                isBasicScreen,
                                                                widget
                                                                    .draftSelected,
                                                                widget
                                                                    .isReviewScreen,
                                                                widget
                                                                    .additionalDetailDraft,
                                                                widget
                                                                    .isProject, database: widget.database)),
                                                      );
                                                    } else {
                                                      returnProjectDetails(
                                                          context);

                                                      navigator.push(
                                                        MaterialPageRoute(
                                                            settings:
                                                                const RouteSettings(
                                                                    name:
                                                                        "/technicalInformationScreen"),
                                                            builder: (context) => TechnicalInformationScreen(
                                                                widget
                                                                    .currentIndex,
                                                                proposalNameController
                                                                    .text,
                                                                basicDetailDraft,
                                                                isBasicScreen,
                                                                widget
                                                                    .draftSelected,
                                                                widget
                                                                    .isReviewScreen,
                                                                widget
                                                                    .additionalDetailDraft,
                                                                widget
                                                                    .isProject, database: widget.database)),
                                                      );
                                                    }
                                                  }
                                                }
                                              }
                                            : null),
                                    style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty
                                          .resolveWith<Color?>(
                                        (Set<MaterialState> states) {
                                          if (states.contains(
                                              MaterialState.disabled)) {
                                            return AppColors
                                                .nextButtonColor; // Disabled color
                                          }
                                          return AppColors
                                              .createProjectAppBarColor; // Enabled color
                                        },
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          Strings().nextButton.toTitleCase(),
                                          style: TextStyle(
                                            color: AppColors.white,
                                          ),
                                        ),
                                        SizedBox(
                                          width: Dimensions.width_5,
                                        ),
                                        Icon(
                                          Icons.arrow_forward_ios_sharp,
                                          size: Dimensions.iconSize_24,
                                          color: AppColors.white,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: Dimensions.height_29),
                        ]),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// This function for the presentDatePicker
  void _presentDatePicker(TextEditingController controller) async {
    final now = DateTime.now();
    final firstDate = DateTime(Dimensions.year_1950, now.month, now.day);
    final initialDate = DateTime(now.year, now.month, now.day);
    final lastDate =
        DateTime(now.year + Dimensions.add_100, now.month, now.day);
    final formatter = DateFormat('yyyy-MM-dd');

    if (!context.mounted) {
      return;
    }
    final pickedDate = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: firstDate,
        lastDate: lastDate);

    setState(() {
      controller.text = formatter.format(pickedDate!);
    });
  }

  /// Domain dropdown list Bloc
  Widget domainDropdown() {
    return BlocProvider(
      create: (_) => basicDetailsScreenBloc,
      child: BlocListener<BasicDetailsScreenBloc, BasicDetailState>(
        listener: (context, state) {},
        child: BlocBuilder<BasicDetailsScreenBloc, BasicDetailState>(
          builder: (context, state) {
            return CustomDropDown(
              controller: domainController,
              onTapped: () async {
                FocusScope.of(context).requestFocus(FocusNode());
                setState(() {
                  domainDropdownOpened = !domainDropdownOpened;
                  statusDropdownOpened = false;
                });
              },
              list: const [],
              isTitleCase: true,
              dbkey: isProject ? "domain" : "proposalDomain",
              wlist: domainList,
              title: Strings().textFieldDomain.toTitleCase(),
              onChanged: (selectedItem) {
                if (isProject == true) {
                  domainController.text = selectedItem!;
                  setState(() {
                    createDomainAt = DateTime.now();
                  });
                } else {
                  proposalDomainController.text = selectedItem!;
                }
                domainDropdownOpened = false;
              },
              isStretchedDropDown: domainDropdownOpened,
            );
          },
        ),
      ),
    );
  }

  /// Technology dropdown list Bloc implementation.
  Widget technologyMultiDropdownList() {
    return BlocProvider(
      create: (_) => basicDetailsScreenBloc,
      child: BlocListener<BasicDetailsScreenBloc, BasicDetailState>(
        listener: (context, state) {},
        child: BlocBuilder<BasicDetailsScreenBloc, BasicDetailState>(
          builder: (context, state) {
            return MultiDropDown(
              controller:
                  functionalityList.isNotEmpty ? [] : draftFunctionalityList,
              items: functionalityList,
              title: Strings().textFieldFunctionality.toTitleCase(),
              alertDialogTitle: Strings().dialogFunctionalitiesTitle,
              height: Dimensions.height_35,
              width: MediaQuery.of(context).size.width - 60,
              onSelectionChanged: (selectedItems) {
                if (isProject == true) {
                  if (selectedItems.isNotEmpty) {
                    if (functionalityNotifier.value != "[]") {
                      setState(() {
                        functionalityNotifier.value = selectedItems;
                        selectedFunctionality = selectedItems;
                      });
                    } else {
                      setState(() {
                        functionalityNotifier.value = selectedItems;
                        selectedFunctionality = selectedItems;
                      });
                      setState(() {});
                    }
                  }
                } else {
                  if (selectedItems.isNotEmpty) {
                    if (proposalFunctionalityNotifier.value != "[]") {
                      setState(() {
                        proposalFunctionalityNotifier.value = selectedItems;
                        proposalSelectedFunctionality = selectedItems;
                      });
                    } else {
                      setState(() {
                        proposalFunctionalityNotifier.value = selectedItems;
                        //proposalFunctionalityNotifier.value = selectedItems;
                      });
                    }
                  }
                  // proposalSelectedFunctionality = selectedItems;
                  // proposalFunctionalityNotifier.value = selectedItems;
                }
              },
              dKey: "functionality",
              //dKey: isProject ?  'functionality' : "proposalFunctionality",
            );
          },
        ),
      ),
    );
  }

  /// Project status dropdown list Bloc
  Widget statusDropdown() {
    return BlocProvider(
      create: (_) => basicDetailsScreenBloc,
      child: BlocListener<BasicDetailsScreenBloc, BasicDetailState>(
        listener: (context, state) {},
        child: BlocBuilder<BasicDetailsScreenBloc, BasicDetailState>(
          builder: (context, state) {
            return CustomDropDown(
              controller: projectStatusController,
              onTapped: () {
                setState(() {
                  FocusScope.of(context).requestFocus(FocusNode());
                  statusDropdownOpened = !statusDropdownOpened;
                  domainDropdownOpened = false;
                });
              },
              list: const [],
              wlist: statusList,
              isTitleCase: true,
              dbkey: isProject ? 'status' : 'proposalStatus',
              title: isProject == true
                  ? Strings().textFieldProjectStatus.toTitleCase()
                  : Strings().textFieldProposalStatus.toTitleCase(),
              onChanged: (selectedItem) {
                if (isProject == true) {
                  projectStatusController.text = selectedItem!;
                } else {
                  proposalStatusController.text = selectedItem!;
                }
                statusDropdownOpened = false;
              },
              isStretchedDropDown: statusDropdownOpened,
            );
          },
        ),
      ),
    );
  }

  // listener for positive button
  void positiveButtonCallback() {
    if (widget.draftSelected) {
      navigateToDraftScreen(context);
    } else {
      SharedPrefs.instance.remove('functionality');
      navigateToCreateProjectScreen(context);
    }
  }

  // listener for negative button
  void negativeButtonCallback() {
    Navigator.of(context).pop();
  }

  // listener for single button
  void actionSingleButtonCallback() {
    Navigator.of(context).pop();
  }

  // All with yes no button without background
  CustomDialogBox dialog() {
    return CustomDialogBox(
      title: Strings().dialogDraftTitle.toTitleCase(),
      description: Strings().dialogBasicDraftDiscription,
      actionPositive: Strings().dialogDraftNegativeButton.toTitleCase(),
      actionNegative: Strings().dialogDraftPositiveButton.toTitleCase(),
      showTitle: true,
      showDescription: true,
      showDialogImage: true,
      showActionPositive: true,
      showActionNegative: true,
      showSingleActionButton: false,
      buttonTextColor: Colors.black,
      onPositiveButtonClick: positiveButtonCallback,
      onNegativeButtonClick: negativeButtonCallback,
      actionOnPressed: actionSingleButtonCallback,
    );
  }
}
